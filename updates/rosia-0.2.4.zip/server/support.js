import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { config } from './config.js';
import { appVersion } from './version.js';
import { hardware, resolved, downloadJobs } from './models.js';
import { discordState } from './discord.js';

/*
 * The report for support (Settings, then Diagnostics): one text file the owner can send when she does not work on their
 * computer. What it has: her version, Windows, the hardware, what she is set to use and whether each file is there, what
 * the launcher and the model runner last printed, the antivirus on the computer and anything it caught of hers, and whether
 * the model runner can run at all. What it never has: chats, memories, the debugging log (data/logs/debug.jsonl), or keys
 * (anything that looks like one is blanked). It is plain text, so the person can read it before sending it.
 */

const LOGS = [
  ['launcher.log', 250], ['launcher.old.log', 80], ['desktop.log', 80], ['models.log', 80], ['model.log', 150],
  ['embed.log', 40], ['router.log', 40], ['app.log', 150], ['update.log', 60], ['images.log', 60], ['voice.log', 30]
];

/** The last `lines` lines of a file (reading only its end), or null when there is no such file. */
export function tail(file, lines, maxBytes = 256 * 1024) {
  let fd;
  try {
    const size = fs.statSync(file).size;
    const start = Math.max(0, size - maxBytes);
    const buf = Buffer.alloc(size - start);
    fd = fs.openSync(file, 'r');
    fs.readSync(fd, buf, 0, buf.length, start);
    const all = buf.toString('utf8').split(/\r?\n/);
    if (start > 0) all.shift(); // the first line was cut
    while (all.length && !all[all.length - 1]) all.pop();
    return all.slice(-lines);
  } catch {
    return null;
  } finally {
    if (fd !== undefined) fs.closeSync(fd);
  }
}

/** Anything that looks like a secret is blanked: link signatures, tokens, keys, passwords. */
export function redact(text) {
  return String(text)
    .replace(/([?&](?:token|key|api_key|apikey|access_token|sig|signature|hm|is|ex|code|password)=)[^&\s"']+/gi, '$1…')
    .replace(/\b(Bearer|Bot)\s+[A-Za-z0-9._~+/=-]{12,}/g, '$1 …')
    .replace(/("(?:[a-z]*token|[a-z]*key|[a-z]*secret|password)"\s*:\s*")[^"]*"/gi, '$1…"')
    .replace(/\bx-rosia-control:\s*\S+/gi, 'x-rosia-control: …');
}

function run(cmd, args, ms = 15_000) {
  return new Promise((resolve) => {
    execFile(cmd, args, { timeout: ms, windowsHide: true, maxBuffer: 4 * 1024 * 1024 }, (err, stdout, stderr) => {
      resolve({ ok: !err, code: err?.code ?? 0, out: `${stdout || ''}${stderr ? `\n${stderr}` : ''}`.trim(), error: err ? String(err.message || err) : '' });
    });
  });
}

/** The antivirus Windows knows of, and anything Microsoft Defender caught that is hers (needs no admin; may say nothing). */
async function antivirus() {
  if (process.platform !== 'win32') return ['(not Windows)'];
  const script = [
    "$ErrorActionPreference='SilentlyContinue'",
    "Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntiVirusProduct | ForEach-Object { 'antivirus: ' + $_.displayName + ' (state ' + ('{0:X6}' -f $_.productState) + ')' }",
    "$t = Get-MpThreatDetection | Where-Object { ($_.Resources -join ' ') -match 'rosia|llama|ggml|node\\.exe|comfy|7zr' } | Select-Object -First 15",
    "foreach ($d in $t) { $n = (Get-MpThreat -ThreatID $d.ThreatID).ThreatName; 'defender caught: ' + $d.InitialDetectionTime + ' ' + $n + ' in ' + ($d.Resources -join ', ') + ' (action ' + $d.ActionSuccess + ')' }",
    "if (-not $t) { 'defender caught: nothing of hers (or Defender is not the antivirus here)' }"
  ].join('; ');
  const r = await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], 30_000);
  return (r.out || r.error || 'no answer').split(/\r?\n/).filter(Boolean);
}

/** Can the model runner run at all? Its own --version, or how starting it failed (an antivirus block shows here). */
async function runnerCheck(runner) {
  if (!runner.found) return [`not there: ${runner.path || '(not set)'}`];
  const out = [`at ${runner.path}`];
  try {
    const dlls = fs.readdirSync(path.dirname(runner.path)).filter((f) => /\.dll$/i.test(f));
    out.push(`next to it: ${dlls.length} .dll files${dlls.length ? ` (${dlls.slice(0, 25).join(', ')})` : ''}`);
  } catch { /* unreadable folder */ }
  const r = await run(runner.path, ['--version'], 20_000);
  const code = typeof r.code === 'number' ? `exit ${r.code} (0x${(r.code >>> 0).toString(16)})` : r.code;
  out.push(r.ok ? 'runs: yes' : `runs: NO, ${code}${r.error ? `: ${r.error.split('\n')[0]}` : ''}`);
  if (r.out) out.push(...r.out.split(/\r?\n/).slice(-12));
  return out;
}

async function answers(url) {
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(2500) });
    return `answers (${res.status})`;
  } catch (err) {
    return `does not answer (${err.cause?.code || err.name})`;
  }
}

/** The whole report, as text. */
export async function buildReport({ logsDir = path.join(config.dataDir, 'logs') } = {}) {
  const lines = [];
  const add = (...l) => lines.push(...l);
  const section = (title) => add('', `===== ${title} =====`);
  const settings = resolved();
  const hw = await hardware().catch(() => null);

  add(`Rosia support report, made ${new Date().toISOString()}`, 'It has no chats or memories. Read it before sending if you like.');
  section('Rosia');
  add(`version: ${appVersion()}`, `app folder: ${config.root}`, `home folder: ${config.home}`, `data folder: ${config.dataDir}`, `node: ${process.version}`);
  section('This computer');
  add(`windows: ${os.type()} ${os.release()} (${os.arch()})`, `processor: ${os.cpus()[0]?.model || '?'} x${os.cpus().length}`);
  if (hw) add(`graphics: ${hw.gpu ? `${hw.gpu.name}, ${hw.gpu.vramGb} GB${hw.gpu.approximate ? ' (at least)' : ''}` : 'none found'}`, `memory: ${hw.ramGb} GB`, `free disk: ${hw.freeGb} GB`);
  section('What she is set to use');
  for (const [key, slot] of Object.entries(settings)) add(`${key}: ${slot.off ? 'off' : `${slot.path || '(not set)'}  ${slot.found ? 'FOUND' : 'NOT FOUND'}`}`);
  const jobs = downloadJobs();
  if (jobs.length) add('downloads this session:', ...jobs.map((j) => `  ${j.key}: ${j.state}${j.error ? `: ${j.error}` : ''} (${Math.round(j.received / 1048576)} MB)`));
  section('Model runner');
  add(...(await runnerCheck(settings.runner)));
  section('Is everything answering');
  add(`chat model (${config.ollamaUrl}): ${await answers(`${config.ollamaUrl}/health`)}`);
  if (process.env.ROSA_EMBED_URL) add(`memory model: ${await answers(`${process.env.ROSA_EMBED_URL}/health`)}`);
  if (process.env.ROSA_ROUTER_URL) add(`router model: ${await answers(`${process.env.ROSA_ROUTER_URL}/health`)}`);
  section('Antivirus');
  add(...(await antivirus()));
  section('Discord');
  try {
    const d = discordState();
    add(`discord: ${d.discord ? 'yes' : 'no'}, betterdiscord: ${d.betterDiscord ? 'yes' : 'no'}, rosia plugin: ${d.plugin.installed || 'not installed'} (bundled ${d.plugin.latest || 'MISSING'}, ${d.plugin.enabled ? 'on' : 'off'})`);
  } catch (err) {
    add(`could not check: ${err.message}`);
  }
  section('Startup');
  const startup = tail(path.join(logsDir, 'startup.json'), 5);
  add(startup ? startup.join('\n') : '(no startup.json: the launcher did not run, or did not get far)');
  for (const [name, n] of LOGS) {
    const got = tail(path.join(logsDir, name), n);
    if (!got) continue;
    section(`${name} (last ${got.length} lines)`);
    add(...got);
  }
  return redact(lines.join('\n'));
}

/** Writes the report next to the logs and returns its path. */
export async function saveReport({ logsDir = path.join(config.dataDir, 'logs') } = {}) {
  const text = await buildReport({ logsDir });
  fs.mkdirSync(logsDir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 16);
  const file = path.join(logsDir, `rosia-report-${stamp}.txt`);
  fs.writeFileSync(file, text, 'utf8');
  return file;
}

/** Shows the file in Explorer, selected, so it can be dragged into a message. */
export function revealFile(file) {
  if (process.platform !== 'win32') return;
  execFile('explorer.exe', [`/select,${file}`], { windowsHide: false }, () => {});
}
