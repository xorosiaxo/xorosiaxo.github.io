import http from 'node:http';
import fs from 'node:fs';
import { config } from './config.js';
import { serveStatic, rateLimit, sendJson, streamFile } from './http.js';
import {
  loadSession,
  createSession,
  saveSession,
  appendMessage,
  normaliseId,
  listSessions,
  renameSession,
  deleteSession,
  lastConversation,
  takeLegacyMemory
} from './sessions.js';
import { runChat } from './chat.js';
import { buildMessages, validTimezone, isReturning } from './context.js';
import { dueFollowUp } from './followups.js';
import { historyOf } from './history.js';
import { pickModel, listModels, warmup, visionSupported } from './llm.js';
import { IDENTITY } from './persona.js';
import { toolSchemas } from './tools/registry.js';
import { chatStarted, chatEnded, isBusy, isQuiet, msSinceActivity, queuedJobs, noteActivity } from './activity.js';
import { appVersion } from './version.js';
import { saveReport, revealFile } from './support.js';
import { migrate } from './migrate.js';
import { galleryOf } from './gallery.js';
import { discordState, installPlugin, openBetterDiscordInstaller } from './discord.js';
import { staleLinks, acceptFresh, catalogueStats } from './clips/catalogue.js';
import { hardware, resolved, scan, allSearchFolders, findComfy, recommendations, markHave, useSetting, startDownload, cancelDownload, downloadJobs, modelsDir } from './models.js';
import { initShare, saveAccess, startTunnel, stopTunnel, shareStatus } from './share.js';
import { status as updateStatus, checkForUpdate, installUpdate, startUpdates } from './update.js';
import { getUser, saveUser, publicNotes, addNote, updateNote, deleteNote } from './users.js';
import { afterReply, profileStale, startTidying } from './memory.js';
import { publicJokes, removeJoke } from './jokes.js';
import { publicGames } from './games.js';
import { watchTaste, publicTaste, clearTaste } from './music/taste.js';
import { startDiary, publicDiary, tryKey } from './diary.js';
import { warmRouter, warmModel } from './router.js';
import { screenSupported } from './screen.js';
import { publicWatching, changeWatching, watchReady } from './watch.js';
import { voiceEnabled, voices as voiceList, speak } from './voice.js';
import { chatReady, whenChatReady, control as gpuControl, swapAvailable } from './gpu.js';
import { publicImage, getJob, jobView, startPool, mayDraw, drawingEta } from './images.js';
import { loadPool, poolStats } from './pool.js';
import { listChats, chatEvents } from './debugview.js';
import { startBackups } from './backup.js';
import { saveImage, readMedia, mediaMime, MEDIA_ID, migrateFlatMedia } from './media.js';
import { writeExport, importData } from './portability.js';
import {
  initAuth, authenticate, admit, sessionCookie, accessMode, isDirectLocal, friendsSummary,
  devicesOf, renameDevice, revokeDevice, createPairingCode, redeemPairingCode
} from './auth.js';
import { findUrls, readLinks, publicLinks } from './links.js';
import { searcher } from './tools/search.js';
import { record, summarise, loadHistory, flushNow } from './metrics.js';
import { conversationRoom, conversationFull, usageOf, TOO_MANY_CONVERSATIONS, CONVERSATION_FULL } from './quota.js';
import './tools/basic.js';
import './tools/photos.js';
import './tools/weather.js';
import './tools/image.js';
import './tools/gif.js';
import './tools/video.js';
import './tools/picture.js';
import './tools/music.js';
import './tools/screen.js';
import './tools/games.js';
import './tools/watch.js';
import './tools/reminders.js';
import { publicReminders, addReminder, editReminder, removeReminder, finishReminder, snoozeReminder, startTelling, told as reminderTold } from './reminders/store.js';
import { publicVideo } from './videos/links.js';
import { debug, who, flushDebug } from './debuglog.js';
import { loadVideoCatalog, videoCatalogStats, videoIndexerError } from './videos/catalog.js';
import { publicGif, getItem as gifItem, fileFor as gifFile, libraryStats as gifStats, loadLibrary as loadGifs, MIME as GIF_MIME } from './gifs/library.js';
import { maybeSpontaneous } from './spontaneous.js';
import { startIndexer, indexerError } from './gifs/indexer.js';
import { readStartupStatus } from '../scripts/startup-status.js';
import { act as musicAct, publicPlayer } from './music/state.js';
import { syncLibrary as syncMusic, getSong, fileFor as songFile, songCount, folderReady as musicFolderReady, AUDIO, SONG_ID } from './music/library.js';
import { onlineReady as musicOnline } from './music/online.js';
import { youtubeReady } from './music/youtube.js';
import { keepUpdated as keepYtdlpUpdated, updateState as ytdlpState } from './music/ytdlp.js';
import { streamYoutube } from './music/stream.js';

const OWNER = 'local';

// chat is limited per person; pairing-code guesses are limited per address
const limiter = rateLimit({ ...config.rate, key: (req) => req.userId });
const ttsLimiter = rateLimit({ windowMs: 60_000, max: config.tts.perMinute, key: (req) => `tts:${req.userId}` });
const heavyLimiter = rateLimit({ windowMs: 60_000, max: 6, key: (req) => `data:${req.userId}` });
const redeemLimiter = rateLimit({
  windowMs: 60_000,
  max: 10,
  key: (req) => `pair:${req.headers['cf-connecting-ip'] || String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket?.remoteAddress}`
});

/* Keep the model's prompt cache primed with the persona + tool definitions, so the first message
   after a quiet spell doesn't pay to re-read them. Never runs while a reply is being generated. */
let lastWarm = 0;
const WARM_EVERY_MS = 5 * 60_000;

function maybeWarm() {
  const now = Date.now();
  if (isBusy() || now - lastWarm < WARM_EVERY_MS || msSinceActivity() < 60_000) return;
  lastWarm = now;
  warmup({ system: IDENTITY, tools: toolSchemas() }).then((ok) => {
    if (ok) console.log('[warmup] prompt cache primed');
  });
}

function json(res, status, payload) {
  return sendJson(res.req, res, status, payload);
}

async function readJson(req, limit = 256 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error('Payload too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        const raw = Buffer.concat(chunks).toString('utf8');
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

function sse(res, event) {
  res.write(`data: ${JSON.stringify(event)}\n\n`);
}

/** What the browser is given for each message. */
function publicMessages(session) {
  return session.messages
    .filter((m) => m.role === 'user' || m.role === 'assistant')
    .slice(-80)
    .map((m) => ({
      role: m.role,
      content: m.content,
      at: m.at,
      photo: m.photo || undefined,
      image: publicImage(m),
      gif: m.gif ? publicGif(m.gif) : undefined,
      video: publicVideo(m.video),
      images: m.images?.length ? m.images : undefined,
      links: m.links?.length ? publicLinks(m.links) : undefined,
      proactive: m.proactive || undefined
    }));
}

const KINDS = new Set(['greet', 'nudge', 'remind']);
let importing = false; // one import at a time (see /api/import)
const clientLogs = new Map(); // userId -> { at, n }: how many reports from the page this hour

async function handleChat(req, res, userId) {
  let body;
  try {
    body = await readJson(req, 24 * 1024 * 1024);
  } catch (err) {
    return json(res, 400, { error: err.message });
  }

  noteActivity(); // someone is here: pictures drawn ahead of time wait, even if this reply has to wait for the card
  const user = await getUser(userId);
  const tz = validTimezone(body.tz);
  const kind = KINDS.has(body.kind) ? body.kind : undefined;

  let session = body.sessionId ? await loadSession(normaliseId(body.sessionId), userId) : null;
  if (!session) {
    if (!(await conversationRoom(userId))) return json(res, 403, { error: TOO_MANY_CONVERSATIONS, code: 'quota' });
    session = createSession(userId);
  }
  if (!kind && conversationFull(session)) return json(res, 409, { error: CONVERSATION_FULL, code: 'quota' });

  // said to the person, so in their words: what is wrong and what to do (the details go to the log)
  const NO_MODEL = "She can't answer right now: her model isn't running. Restart Rosia, or open Settings, then Models, to set one up.";
  let model = config.model;
  // while a picture is being drawn the model is off the card; it is looked for after the wait instead
  if (!model && chatReady()) model = await pickModel();
  if (!model && chatReady()) return json(res, 503, { error: NO_MODEL });

  if (kind === 'nudge') {
    const last = session.messages.at(-1);
    if (!last || last.role !== 'assistant' || last.proactive === 'nudge' || !session.messages.some((m) => m.role === 'user')) {
      return json(res, 409, { error: 'Nothing to nudge about.' });
    }
  }
  if (kind === 'greet' && session.messages.at(-1)?.role === 'user') {
    return json(res, 409, { error: 'There is a message waiting for a reply.' });
  }
  // a reminder has come due and the page asks her to say it: only one that really is due, and only once
  // (two windows open at the same moment must not both get it)
  let reminder = null;
  if (kind === 'remind') {
    if (session.messages.at(-1)?.role === 'user') return json(res, 409, { error: 'There is a message waiting for a reply.' });
    reminder = startTelling(user, String(body.reminderId || ''));
    if (!reminder) return json(res, 409, { error: 'That reminder is not due.' });
  }

  if (!kind) {
    const text = String(body.message ?? '').trim();
    const pictures = Array.isArray(body.images) ? body.images.slice(0, config.maxImages) : [];
    if (!text && !pictures.length) return json(res, 400, { error: 'Empty message' });
    if (text.length > config.maxMessageChars) {
      return json(res, 413, { error: 'That message is a bit long. Trim it down.' });
    }

    const ids = [];
    if (pictures.length) {
      if (!(await visionSupported())) {
        return json(res, 400, { error: "The model that's running can't look at pictures." });
      }
      try {
        const saved = await Promise.all(pictures.map((dataUrl) => saveImage(userId, dataUrl)));
        ids.push(...saved.map((r) => r.id));
      } catch (err) {
        return json(res, 400, { error: err.message });
      }
    }
    appendMessage(session, 'user', text, ids.length ? { images: ids } : {});
    await saveSession(session);
    debug('chat.request', { user: who(userId), session: session.id, text, pictures: ids.length, tz });
  } else {
    debug('chat.request', { user: who(userId), session: session.id, kind });
  }
  const userMessage = kind ? null : session.messages.at(-1);
  const urls = userMessage ? findUrls(userMessage.content) : [];
  const lastConv = kind === 'greet' ? await lastConversation(userId, session.id) : null;

  res.writeHead(200, {
    'content-type': 'text/event-stream; charset=utf-8',
    'cache-control': 'no-cache, no-transform',
    connection: 'keep-alive',
    'x-accel-buffering': 'no'
  });
  res.write(': connected\n\n');
  sse(res, { type: 'session', id: session.id });

  const controller = new AbortController();
  res.on('close', () => controller.abort());

  // a slow model (or a game hogging the GPU) can go quiet for a while; keep proxies and the
  // browser from deciding the connection is dead
  const ping = setInterval(() => res.write(': ping\n\n'), config.keepAliveMs);

  let partial = '';
  let counted = false;
  try {
    // links in the message: read first (that needs no model, so it is done even while the card is lent out), with a time
    // limit of its own and the person's stop button, so a slow site can neither hold up the reply for long nor run on after stop
    if (urls.length) {
      sse(res, { type: 'tool', name: 'read_link', status: 'start' });
      userMessage.links = await readLinks(urls, userId, { signal: controller.signal });
      await saveSession(session);
      sse(res, { type: 'links', links: publicLinks(userMessage.links) });
      sse(res, { type: 'tool', name: 'read_link', status: 'done' });
    }
    if (controller.signal.aborted) throw Object.assign(new Error('Cancelled'), { name: 'AbortError' });

    // a picture is being drawn: the model is off the graphics card, so wait for it to come back. The reply only
    // counts as "in progress" once it really starts, so the picture's own wait for a quiet moment is never held up by it.
    if (!chatReady()) {
      // said again every few seconds with a fresh estimate, so the wait never looks like a hang
      const tell = () => sse(res, { type: 'status', state: 'drawing', ...drawingEta(userId) });
      tell();
      const every = setInterval(tell, 10_000);
      try {
        while (!chatReady()) await whenChatReady(controller.signal);
      } finally {
        clearInterval(every);
      }
      sse(res, { type: 'status', state: 'ready' });
    }
    chatStarted();
    counted = true;
    if (!model) {
      model = await pickModel();
      if (!model) throw new Error(NO_MODEL);
    }

    // something they told her about has just happened: her hello, or her first reply after a break, asks how it went (once)
    const followUp = (kind === 'greet' || (!kind && isReturning(session, user))) ? dueFollowUp(user.notes) : null;
    const messages = await buildMessages({ session, user, tz, kind, lastConversation: lastConv, followUp, reminder, call: !kind && body.call === true });
    const reply = await runChat({
      session,
      user,
      tz,
      kind,
      mode: !kind && body.mode === 'image' ? 'image' : undefined, // the "Create image" button

      messages,
      model,
      onEvent: (event) => {
        if (event.type === 'delta') partial += event.text;
        else if (event.type === 'reset') partial = '';
        sse(res, event);
      },
      signal: controller.signal
    });

    // now and then, on her own, something to go with what she just said: a GIF, a video, or a picture of herself
    // (the model can also send these itself, or be asked for them)
    let gifId = reply.gif?.id;
    let video = reply.video || undefined;
    let image = reply.image || undefined;
    if (!kind && !gifId && !video && !image && !reply.photo) {
      const extra = await maybeSpontaneous({ session, userId, text: reply.text, mood: reply.mood, photo: reply.photo, image: reply.image, gif: reply.gif, video: reply.video }).catch(() => null);
      if (extra?.gif) {
        gifId = extra.gif.item.id;
        debug('gif.reaction', { user: who(userId), session: session.id, id: gifId, why: extra.gif.item.reaction, score: extra.gif.score });
        sse(res, { type: 'gif', ...publicGif(gifId), id: gifId });
      } else if (extra?.video) {
        video = { url: extra.video.url, name: extra.video.name || '' };
        debug('video.spontaneous', { user: who(userId), session: session.id, name: video.name });
        sse(res, { type: 'video', url: video.url, name: video.name });
      } else if (extra?.picture) {
        const job = extra.picture;
        image = { job: job.id, orientation: job.orientation, state: 'done', prompt: job.prompt, media: job.media };
        debug('picture.spontaneous', { user: who(userId), session: session.id, job: job.id });
        sse(res, { type: 'image', job: job.id, state: 'done', ratio: job.orientation, media: job.media });
      }
    }
    if (reply.text.trim() || reply.photo || image || gifId || video) {
      appendMessage(session, 'assistant', reply.text.trim(), {
        gif: gifId,
        video,
        raw: reply.raw,
        mood: reply.mood,
        photo: reply.photo,
        image,
        proactive: kind
      });
    }
    await saveSession(session);
    if (reminder) {
      // said (or not): either way it is free again, and one she said is not said a second time
      reminderTold(user, reminder.id, Boolean(reply.text.trim()));
      reminder = null;
      debug('reminder.told', { user: who(userId), session: session.id, said: Boolean(reply.text.trim()) });
    }
    if (followUp && reply.text.trim()) {
      followUp.followedUp = Date.now(); // asked: not again
      debug('followup.asked', { user: who(userId), session: session.id, note: followUp.id });
    }
    if (!user.firstSeenAt) {
      user.firstSeenAt = (await listSessions(userId)).reduce((a, c) => (c.createdAt && c.createdAt < a ? c.createdAt : a), Date.now());
    }
    user.lastSeenAt = Date.now();
    await saveUser(user);
    if (session.messages.some((m) => m.role === 'user')) afterReply(session, userId, { timeZone: tz });

    const st = reply.stats;
    debug('chat.reply', {
      user: who(userId),
      session: session.id,
      kind: kind || 'chat',
      text: reply.text,
      raw: reply.raw,
      mood: reply.mood,
      photo: reply.photo,
      image,
      gif: gifId,
      video,
      stats: st
    });
    record('reply', {
      kind: kind || 'chat',
      ttftMs: st.ttftMs,
      totalMs: st.totalMs,
      tps: st.genPerSec,
      promptTokens: st.promptTokens,
      cachedTokens: st.cachedTokens,
      genTokens: st.genTokens,
      rounds: st.rounds
    });
    console.log(
      `[${kind || 'chat'}] ttft=${st.ttftMs ?? '-'}ms total=${st.totalMs}ms prompt=${st.promptTokens} cached=${st.cachedTokens} ` +
      `gen=${st.genTokens}@${st.genPerSec}t/s mood=${reply.mood ?? 'none'} rounds=${st.rounds}`
    );
    sse(res, { type: 'end', id: session.id, title: session.title || undefined, stats: st, text: reply.text });
  } catch (err) {
    if (err?.name === 'AbortError') {
      record('abort', { kind: kind || 'chat' });
      debug('chat.abort', { user: who(userId), session: session.id, shownSoFar: partial });
      // the person hit stop: keep what she had already said so the thread matches the screen
      if (partial.trim()) {
        appendMessage(session, 'assistant', partial.trim(), { proactive: kind });
        await saveSession(session);
      }
    } else {
      debug('chat.error', { user: who(userId), session: session.id, error: err, shownSoFar: partial });
      record('error', { where: 'chat', message: String(err?.message || 'unknown').replace(/https?:\/\/\S+/g, '<link>').slice(0, 120) });
      // the owner is told exactly what failed; anyone else is not told where the model server lives
      const message = err?.message || 'Something went wrong.';
      sse(res, { type: 'error', message: userId === OWNER ? message : message.replace(/https?:\/\/\S+/g, 'the model server') });
    }
  } finally {
    if (reminder) reminderTold(user, reminder.id, false); // stopped or failed before she said it: it can be asked for again
    if (counted) chatEnded();
    clearInterval(ping);
    res.end();
  }
}

const server = http.createServer((req, res) => {
  // nothing a request carries may stop the server: anything that escapes the handler is answered with an error
  route(req, res).catch((err) => {
    console.error('[http]', req.method, req.url, err);
    try {
      if (!res.headersSent) json(res, 500, { error: 'Something went wrong on the server.' });
      else res.end();
    } catch {
      res.destroy();
    }
  });
});

async function route(req, res) {
  let url;
  try {
    // the path never depends on the Host header, so a fixed base is used (a malformed Host or path cannot throw here)
    url = new URL(req.url || '/', 'http://localhost');
  } catch {
    res.statusCode = 400;
    return res.end('Bad request');
  }
  const pathname = url.pathname;
  // Who is this? A page load from a machine that is allowed in hands it its token (as an HttpOnly cookie)
  // before the app makes any API call, so the first few parallel calls all arrive already signed in.
  let auth = authenticate(req);
  const isPage = (req.method === 'GET' || req.method === 'HEAD') && ['/', '/index.html', '/status', '/status.html', '/chats', '/chats.html'].includes(pathname);
  if (!auth && isPage) {
    const granted = admit(req);
    if (granted) {
      res.setHeader('set-cookie', sessionCookie(granted.token, req));
      auth = { userId: granted.device.userId, device: granted.device };
    }
  }
  const userId = auth?.userId;
  req.userId = userId;

  // a page on another site must not be able to make this browser act on its behalf (the one exception: Discord's own page
  // handing fresh clip links to /api/clips/fresh, which checks its caller itself and only ever stores Discord links)
  const clipRelay = new URL(req.url, 'http://x').pathname === '/api/clips/fresh' && /^https:\/\/((ptb|canary)\.)?discord\.com$/i.test(String(req.headers.origin || ''));
  if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && req.headers.origin && !clipRelay) {
    let sameSite = false;
    try {
      sameSite = new URL(req.headers.origin).host === req.headers.host;
    } catch {
      /* malformed origin */
    }
    if (!sameSite) return json(res, 403, { error: 'Cross-site request refused.' });
  }

  try {
    // the launcher's watchdog: answers at once, whatever the model server is doing (a slow model must not get the app restarted)
    if (pathname === '/api/alive' && req.method === 'GET') return json(res, 200, { ok: true, version: appVersion() });

    // which version this is (no sign-in needed): a page that was opened before an update compares it with its own and offers a reload
    if (pathname === '/api/version' && req.method === 'GET') return json(res, 200, { name: 'rosia', version: appVersion() });

    // what the launcher is still starting (her chat model, her memory, ...), for the "getting ready" screen. No sign-in
    // needed: it names her parts and whether each is ready, nothing else. Started without the launcher, there is nothing to wait for.
    if (pathname === '/api/startup' && req.method === 'GET') {
      const status = readStartupStatus(process.env.ROSA_STARTUP_FILE);
      return json(res, 200, status ? { ready: status.ready, startedAt: status.startedAt, at: Date.now(), steps: status.steps } : { ready: true, steps: [] });
    }

    if (pathname === '/api/health' && req.method === 'GET') {
      // where the model server lives is only told to the owner
      const where = userId === OWNER ? { ollama: config.ollamaUrl } : {};
      if (!chatReady()) return json(res, 200, { ok: true, version: appVersion(), models: [], model: config.model, ...where, vision: false, drawing: true });
      let models = [];
      let model = '';
      try {
        models = await listModels();
        model = await pickModel();
      } catch {
        /* model offline is a valid state */
      }
      if (model) maybeWarm();
      return json(res, 200, { ok: true, version: appVersion(), models: userId === OWNER ? models : [], model, ...where, vision: await visionSupported() });
    }

    if (pathname === '/api/models' && req.method === 'GET') {
      if (userId !== OWNER) return json(res, 403, { error: 'Only the owner can see this.' });
      try {
        return json(res, 200, { models: await listModels() });
      } catch (err) {
        return json(res, 503, { error: err.message, models: [] });
      }
    }

    /* ---------- how the server is doing (owner only; read-only, there is nothing here that removes anything) ---------- */

    if (pathname === '/api/admin/stats' && req.method === 'GET') {
      if (!auth) return json(res, 401, { error: 'This machine has no access yet.', code: 'no_token', mode: accessMode, canSelfIssue: isDirectLocal(req) || accessMode === 'open' });
      if (userId !== OWNER) return json(res, 403, { error: 'Only the owner can see this.' });
      const hours = Math.min(168, Math.max(1, Number(url.searchParams.get('hours')) || 24));
      let model = '';
      let up = false;
      try {
        model = await pickModel();
        up = Boolean(model);
      } catch {
        /* offline is a valid state to report */
      }
      return json(res, 200, {
        ...summarise({ hours }),
        gifs: { ...gifStats(), error: indexerError() },
        videos: { ...videoCatalogStats(), error: videoIndexerError() },
        pool: poolStats(),
        llm: { up, model, vision: up ? await visionSupported() : false },
        search: searcher.health(),
        background: { queued: queuedJobs(), chatting: isBusy() },
        process: { rssMb: Math.round(process.memoryUsage().rss / 1048576), node: process.version },
        access: accessMode,
        you: await usageOf(userId)
      });
    }

    /* ---------- problems the page runs into (the voice), for the debugging log: what went wrong and in which browser, never what was said ---------- */

    if (pathname === '/api/clientlog' && req.method === 'POST') {
      if (!auth) return json(res, 401, { error: 'This machine has no access yet.', code: 'no_token', mode: accessMode, canSelfIssue: isDirectLocal(req) || accessMode === 'open' });
      const mark = clientLogs.get(userId) || { at: Date.now(), n: 0 };
      if (Date.now() - mark.at > 3600_000) Object.assign(mark, { at: Date.now(), n: 0 });
      mark.n += 1;
      clientLogs.set(userId, mark);
      if (mark.n > 30) return json(res, 429, { error: 'Too many reports.' });
      let body;
      try {
        body = await readJson(req, 4096);
      } catch (err) {
        return json(res, 400, { error: err.message });
      }
      if (body && body.kind === 'voice') {
        debug('client.voice', {
          user: who(userId),
          what: String(body.what || '').slice(0, 40),
          message: String(body.message || '').slice(0, 300),
          gpu: Boolean(body.gpu),
          secure: Boolean(body.secure),
          browser: String(req.headers['user-agent'] || '').slice(0, 160)
        });
      }
      return json(res, 200, { ok: true });
    }

    // what the page may offer this person (the "Create image" button is only shown where pictures can be drawn for them)
    // who the page is talking to, so it can show the owner's sections (updates, diagnostics) to the owner only
    if (pathname === '/api/me' && req.method === 'GET') {
      if (!auth) return json(res, 401, { error: 'This machine has no access yet.', code: 'no_token', mode: accessMode, canSelfIssue: isDirectLocal(req) || accessMode === 'open' });
      // local: the owner at this computer itself (not through a shared link), the only one who may set things up on it
      return json(res, 200, { owner: userId === OWNER, local: userId === OWNER && isDirectLocal(req), access: accessMode, version: appVersion() });
    }

    /* ---------- the models she runs on (see models.js): only the owner, at this computer ---------- */

    if (pathname === '/api/local-models' || pathname.startsWith('/api/local-models/')) {
      if (!auth) return json(res, 401, { error: 'This machine has no access yet.', code: 'no_token' });
      if (userId !== OWNER || !isDirectLocal(req)) return json(res, 403, { error: 'Only the owner, at this computer, can change her models.' });
      try {
        const hw = await hardware();
        if (pathname === '/api/local-models' && req.method === 'GET') {
          return json(res, 200, { hardware: hw, settings: resolved(), found: scan(allSearchFolders()), comfy: findComfy(), recommended: markHave(recommendations(hw)), jobs: downloadJobs(), folder: modelsDir(), running: await pickModel().then(Boolean, () => false) });
        }
        const body = await readJson(req).catch(() => ({}));
        if (pathname === '/api/local-models/use' && req.method === 'POST') {
          useSetting(String(body.setting || ''), body.path);
          debug('models.use', { setting: body.setting });
          return json(res, 200, { settings: resolved() });
        }
        if (pathname === '/api/local-models/download' && req.method === 'POST') {
          debug('models.download', { key: body.key });
          return json(res, 200, { jobs: await startDownload(String(body.key || ''), { hw, comfyModels: resolved().comfyModels.found ? resolved().comfyModels.path : '' }) });
        }
        if (pathname === '/api/local-models/cancel' && req.method === 'POST') return json(res, 200, { jobs: cancelDownload(String(body.key || '')) });
      } catch (err) {
        return json(res, err.status || 500, { error: err.message });
      }
      return json(res, 404, { error: 'Not found' });
    }

    /* ---------- the report for support (see support.js): only the owner, at this computer ---------- */

    if (pathname === '/api/support/report' && req.method === 'POST') {
      if (!auth) return json(res, 401, { error: 'This machine has no access yet.', code: 'no_token' });
      if (userId !== OWNER || !isDirectLocal(req)) return json(res, 403, { error: 'Only the owner, at this computer, can make a report.' });
      try {
        const file = await saveReport();
        revealFile(file);
        debug('support.report', {});
        return json(res, 200, { file });
      } catch (err) {
        return json(res, 500, { error: err.message });
      }
    }

    /* ---------- connecting Discord (see discord.js): only the owner, at this computer ---------- */

    if (pathname === '/api/discord' || pathname.startsWith('/api/discord/')) {
      if (!auth) return json(res, 401, { error: 'This machine has no access yet.', code: 'no_token' });
      if (userId !== OWNER || !isDirectLocal(req)) return json(res, 403, { error: 'Only the owner, at this computer, can set this up.' });
      try {
        if (pathname === '/api/discord' && req.method === 'GET') return json(res, 200, discordState());
        if (pathname === '/api/discord/plugin' && req.method === 'POST') {
          const state = installPlugin();
          debug('discord.plugin', { version: state.plugin.installed });
          return json(res, 200, state);
        }
        if (pathname === '/api/discord/betterdiscord' && req.method === 'POST') {
          const opened = await openBetterDiscordInstaller();
          debug('discord.betterdiscord', { version: opened.version });
          return json(res, 200, { ...opened, ...discordState() });
        }
      } catch (err) {
        return json(res, err.status || 502, { error: err.message });
      }
      return json(res, 404, { error: 'Not found' });
    }

    if (pathname === '/api/features' && req.method === 'GET') {
      if (!auth) return json(res, 401, { error: 'This machine has no access yet.', code: 'no_token', mode: accessMode, canSelfIssue: isDirectLocal(req) || accessMode === 'open' });
      // (the screen button is only for the owner, on the computer Rosia runs on, with a model that can see)
      return json(res, 200, { images: mayDraw(userId), screen: userId === OWNER && screenSupported() && (await visionSupported()) });
    }

    // the debugging log read back (see /chats): what was said, what the model wrote, every tool call. Owner only, read-only.
    if ((pathname === '/api/admin/chats' || pathname === '/api/admin/chat') && req.method === 'GET') {
      if (!auth) return json(res, 401, { error: 'This machine has no access yet.', code: 'no_token', mode: accessMode, canSelfIssue: isDirectLocal(req) || accessMode === 'open' });
      if (userId !== OWNER) return json(res, 403, { error: 'Only the owner can see this.' });
      if (pathname === '/api/admin/chats') {
        const hours = Math.min(24 * 14, Math.max(1, Number(url.searchParams.get('hours')) || 72));
        return json(res, 200, { chats: await listChats({ hours }), logging: process.env.ROSA_DEBUG_LOG !== '0' });
      }
      return json(res, 200, { events: await chatEvents(url.searchParams.get('session')) });
    }

    /* ---------- machines and tokens ---------- */

    // scripts: ask for a token directly (only where a cookie would also have been handed out)
    if (pathname === '/api/auth' && req.method === 'POST') {
      const granted = auth ? null : admit(req);
      if (!auth && !granted) return json(res, 401, { error: 'Ask for a pairing code from a device that is already signed in.', code: 'no_token', mode: accessMode, canSelfIssue: false });
      if (granted) {
        res.setHeader('set-cookie', sessionCookie(granted.token, req));
        return json(res, 200, { token: granted.token, label: granted.device.label });
      }
      return json(res, 200, { signedIn: true });
    }

    // a new machine uses a code made by one that is signed in
    if (pathname === '/api/devices/redeem' && req.method === 'POST') {
      return redeemLimiter(req, res, async () => {
        const body = await readJson(req).catch(() => ({}));
        const granted = redeemPairingCode(req, body.code, body.label);
        if (!granted) return json(res, 400, { error: 'That code did not work. It may have expired, or been used already.' });
        res.setHeader('set-cookie', sessionCookie(granted.token, req));
        return json(res, 200, { ok: true, token: granted.token });
      });
    }

    // the Rosia plugin, inside Discord on this computer, keeps the shipped clips' links fresh: it asks which links need a
    // new signature and hands back the ones Discord renewed (only Discord links for known clips are kept, see catalogue.js).
    // This computer only, and only Discord's own page (or no page at all) may call it.
    if (pathname === '/api/clips/stale' || pathname === '/api/clips/fresh') {
      const origin = String(req.headers.origin || '');
      const discordPage = /^https:\/\/((ptb|canary)\.)?discord\.com$/i.test(origin);
      if (!isDirectLocal(req) || (origin && !discordPage)) return json(res, 403, { error: 'Only the Rosia plugin on this computer can do this.' });
      if (discordPage) {
        res.setHeader('access-control-allow-origin', origin);
        res.setHeader('vary', 'origin');
        res.setHeader('access-control-allow-methods', 'GET, POST');
        res.setHeader('access-control-allow-headers', 'content-type');
        res.setHeader('access-control-allow-private-network', 'true');
      }
      if (req.method === 'OPTIONS') {
        res.writeHead(204);
        return res.end();
      }
      if (pathname === '/api/clips/stale' && req.method === 'GET') {
        const limit = Number(url.searchParams.get('limit')) || 200;
        return json(res, 200, { links: staleLinks(limit), ...catalogueStats() });
      }
      if (pathname === '/api/clips/fresh' && req.method === 'POST') {
        const body = await readJson(req).catch(() => ({}));
        const kept = acceptFresh(body.links);
        debug('clips.fresh', { offered: Array.isArray(body.links) ? body.links.length : 0, kept });
        return json(res, 200, { kept, ...catalogueStats() });
      }
      return json(res, 404, { error: 'Not found' });
    }

    // everything below belongs to a person
    if ((pathname.startsWith('/api/') || pathname.startsWith('/media/') || pathname.startsWith('/gif/') || pathname.startsWith('/music/') || pathname.startsWith('/video/')) && !auth) {
      return json(res, 401, { error: 'This machine has no access yet.', code: 'no_token', mode: accessMode, canSelfIssue: isDirectLocal(req) || accessMode === 'open' });
    }

    /* ---------- sharing with friends (owner only; see share.js) ---------- */

    if (pathname === '/api/share' || pathname.startsWith('/api/share/')) {
      if (userId !== OWNER) return json(res, 403, { error: 'Only the owner can see this.' });
      if (pathname === '/api/share' && req.method === 'GET') return json(res, 200, shareStatus(friendsSummary()));
      if (pathname === '/api/share/access' && req.method === 'POST') {
        const body = await readJson(req).catch(() => ({}));
        if (body.mode !== 'open' && body.mode !== 'invite') return json(res, 400, { error: 'Choose open or invite.' });
        saveAccess(body.mode);
        debug('share.access', { mode: body.mode });
        return json(res, 200, shareStatus(friendsSummary()));
      }
      if (pathname === '/api/share/tunnel' && req.method === 'POST') {
        const body = await readJson(req).catch(() => ({}));
        if (body.on) await startTunnel();
        else stopTunnel();
        debug('share.tunnel', { on: Boolean(body.on) });
        return json(res, 200, shareStatus(friendsSummary()));
      }
      return json(res, 404, { error: 'Not found' });
    }

    /* ---------- updates (owner only; see update.js) ---------- */

    if (pathname === '/api/update' || pathname.startsWith('/api/update/')) {
      if (userId !== OWNER) return json(res, 403, { error: 'Only the owner can see this.' });
      if (pathname === '/api/update' && req.method === 'GET') return json(res, 200, updateStatus());
      if (pathname === '/api/update/check' && req.method === 'POST') return json(res, 200, await checkForUpdate());
      if (pathname === '/api/update/install' && req.method === 'POST') {
        try {
          // the app leaves a moment after answering; the launcher swaps the files in and starts the new version
          return json(res, 202, await installUpdate({ flush: () => { flushNow(); flushDebug(); } }));
        } catch (err) {
          return json(res, err.status || 500, { error: err.status ? err.message : 'The update could not be installed.' });
        }
      }
    }

    if (pathname === '/api/devices' && req.method === 'GET') {
      return json(res, 200, { devices: devicesOf(userId, auth.device.id), mode: accessMode });
    }
    if (pathname === '/api/devices/pair' && req.method === 'POST') {
      return json(res, 200, createPairingCode(userId));
    }
    const deviceMatch = /^\/api\/devices\/([a-f0-9]{12})$/.exec(pathname);
    if (deviceMatch) {
      if (req.method === 'PATCH') {
        const body = await readJson(req).catch(() => ({}));
        return renameDevice(userId, deviceMatch[1], body.label) ? json(res, 200, { devices: devicesOf(userId, auth.device.id) }) : json(res, 404, { error: 'Not found' });
      }
      if (req.method === 'DELETE') {
        const result = revokeDevice(userId, deviceMatch[1]);
        if (result === 'missing') return json(res, 404, { error: 'Not found' });
        if (result === 'last') return json(res, 400, { error: "That's your only machine. Add another one first, or you would lose access to your memory." });
        return json(res, 200, { devices: devicesOf(userId, auth.device.id) });
      }
    }

    /* ---------- conversations ---------- */

    if (pathname === '/api/conversations' && req.method === 'GET') {
      const list = await listSessions(userId);
      return json(res, 200, {
        conversations: list.map(({ id, title, updatedAt, createdAt, count, preview }) => ({
          id, title: title || 'New chat', updatedAt, createdAt, count, preview
        }))
      });
    }

    if (pathname === '/api/conversations' && req.method === 'POST') {
      if (!(await conversationRoom(userId))) return json(res, 403, { error: TOO_MANY_CONVERSATIONS, code: 'quota' });
      const session = createSession(userId);
      await saveSession(session);
      return json(res, 200, { id: session.id });
    }

    const convMatch = /^\/api\/(?:conversations|session)\/([A-Za-z0-9_-]+)$/.exec(pathname);
    if (convMatch) {
      const id = normaliseId(convMatch[1]);
      if (!id) return json(res, 400, { error: 'Bad conversation id' });

      if (req.method === 'GET') {
        const session = await loadSession(id, userId);
        // an unknown id is just an empty conversation, so a stale link in the browser degrades gracefully
        return json(res, 200, { id, title: session?.title || '', messages: session ? publicMessages(session) : [] });
      }
      if (req.method === 'PATCH') {
        const body = await readJson(req).catch(() => null);
        const session = body ? await renameSession(id, userId, body.title) : null;
        return session ? json(res, 200, { id, title: session.title }) : json(res, 404, { error: 'Not found' });
      }
      if (req.method === 'DELETE') {
        return (await deleteSession(id, userId)) ? json(res, 200, { ok: true }) : json(res, 404, { error: 'Not found' });
      }
    }

    if (pathname === '/api/session' && req.method === 'POST') {
      if (!(await conversationRoom(userId))) return json(res, 403, { error: TOO_MANY_CONVERSATIONS, code: 'quota' });
      const session = createSession(userId);
      await saveSession(session);
      return json(res, 200, { id: session.id });
    }

    /* ---------- the two of you: a short history, worked out from what is already stored ---------- */

    if (pathname === '/api/history' && req.method === 'GET') {
      const list = await listSessions(userId);
      const sessions = (await Promise.all(list.map((c) => loadSession(c.id, userId)))).filter(Boolean);
      const person = await getUser(userId);
      return json(res, 200, { history: historyOf({ conversations: list, notes: person.notes, pictures: galleryOf(sessions), since: person.firstSeenAt }) });
    }

    /* ---------- gallery: her photos and the pictures she drew, across this person's conversations ---------- */

    if (pathname === '/api/gallery' && req.method === 'GET') {
      const list = await listSessions(userId);
      const sessions = (await Promise.all(list.map((c) => loadSession(c.id, userId)))).filter(Boolean);
      return json(res, 200, { pictures: galleryOf(sessions) });
    }

    /* ---------- reminders: what she is keeping for this person, and the same changes by hand ---------- */

    if (pathname === '/api/reminders' && req.method === 'GET') {
      return json(res, 200, { reminders: publicReminders(await getUser(userId)), now: Date.now() });
    }

    if (pathname === '/api/reminders' && req.method === 'POST') {
      const body = await readJson(req, 4096).catch(() => ({}));
      const user = await getUser(userId);
      const id = String(body.id || '');
      try {
        let found = true;
        switch (String(body.action || '')) {
          case 'add':
            await addReminder(user, { text: body.text, at: body.at, repeat: String(body.repeat || ''), tz: validTimezone(body.tz), by: 'hand' });
            break;
          case 'edit':
            found = Boolean(await editReminder(user, id, { text: body.text, at: body.at, repeat: body.repeat === undefined ? undefined : String(body.repeat) }));
            break;
          case 'remove':
            found = await removeReminder(user, id);
            break;
          case 'done':
            found = Boolean(await finishReminder(user, id));
            break;
          case 'snooze':
            found = Boolean(await snoozeReminder(user, id, body.minutes));
            break;
          default:
            return json(res, 400, { error: 'That is not something a reminder can do.' });
        }
        // gone already (removed in another window): the page is shown how things stand
        if (!found) return json(res, 404, { error: 'That reminder is no longer there.', reminders: publicReminders(user) });
        debug('reminder.click', { user: who(userId), action: body.action });
        return json(res, 200, { reminders: publicReminders(user) });
      } catch (err) {
        return json(res, 400, { error: err.message, reminders: publicReminders(user) });
      }
    }

    /* ---------- the two of you: running jokes and what she has learnt of their music ---------- */

    if (pathname === '/api/mind' && req.method === 'GET') {
      const user = await getUser(userId);
      return json(res, 200, { jokes: publicJokes(user), taste: publicTaste(user), games: publicGames(user) });
    }

    const jokeMatch = /^\/api\/jokes\/([a-f0-9]{12})$/.exec(pathname);
    if (jokeMatch && req.method === 'DELETE') {
      const user = await getUser(userId);
      if (!(await removeJoke(user, jokeMatch[1]))) return json(res, 404, { error: 'Not found' });
      return json(res, 200, { jokes: publicJokes(user) });
    }

    if (pathname === '/api/taste' && req.method === 'DELETE') {
      const user = await getUser(userId);
      await clearTaste(user);
      return json(res, 200, { taste: publicTaste(user) });
    }

    /* ---------- her diary: locked, and only she can give out the key ---------- */

    if (pathname === '/api/diary' && req.method === 'GET') {
      return json(res, 200, await publicDiary(userId, ''));
    }

    // the key is sent in the body, never in the address, so it stays out of logs and history
    if (pathname === '/api/diary' && req.method === 'POST') {
      const body = await readJson(req, 1024).catch(() => ({}));
      const result = await tryKey(userId, String(body.key || '').slice(0, 80));
      if (result === 'slow down') return json(res, 429, { error: 'Too many wrong keys. Try again in an hour.' });
      if (result === 'wrong') {
        debug('diary.wrong', { user: who(userId) });
        return json(res, 403, { error: 'That is not the key.' });
      }
      debug('diary.opened', { user: who(userId) });
      return json(res, 200, await publicDiary(userId, String(body.key || '')));
    }

    /* ---------- memory ---------- */

    if (pathname === '/api/memory' && req.method === 'GET') {
      const user = await getUser(userId);
      return json(res, 200, { notes: publicNotes(user), profile: user.profile, embedding: user.notes[0]?.vecKind || null });
    }

    if (pathname === '/api/memory' && req.method === 'POST') {
      const body = await readJson(req).catch(() => ({}));
      const user = await getUser(userId);
      const { note } = await addNote(user, body.text, 'user');
      if (!note) return json(res, 400, { error: 'Write a short sentence to remember.' });
      profileStale(userId);
      return json(res, 200, { notes: publicNotes(user) });
    }

    const noteMatch = /^\/api\/memory\/([a-f0-9]{12})$/.exec(pathname);
    if (noteMatch) {
      const user = await getUser(userId);
      if (req.method === 'PATCH') {
        const body = await readJson(req).catch(() => ({}));
        const note = await updateNote(user, noteMatch[1], body.text);
        if (!note) return json(res, 404, { error: 'Not found' });
        profileStale(userId);
        return json(res, 200, { notes: publicNotes(user) });
      }
      if (req.method === 'DELETE') {
        if (!(await deleteNote(user, noteMatch[1]))) return json(res, 404, { error: 'Not found' });
        profileStale(userId);
        return json(res, 200, { notes: publicNotes(user) });
      }
    }

    /* ---------- your data: export and import (there is deliberately no "delete everything") ---------- */

    if (pathname === '/api/export' && req.method === 'GET') {
      return heavyLimiter(req, res, async () => {
        const day = new Date().toISOString().slice(0, 10);
        res.writeHead(200, {
          'content-type': 'application/json; charset=utf-8',
          'content-disposition': `attachment; filename="rosia-export-${day}.json"`,
          'cache-control': 'no-store'
        });
        await writeExport(userId, (chunk) => res.write(chunk), { pictures: url.searchParams.get('pictures') !== '0' });
        res.end();
      });
    }

    if (pathname === '/api/import' && req.method === 'POST') {
      return heavyLimiter(req, res, async () => {
        // an import is read whole into memory, so only one runs at a time, and only the owner may send a really big one
        if (importing) return json(res, 429, { error: 'Another import is running. Try again in a minute.' });
        importing = true;
        try {
          let data;
          try {
            data = await readJson(req, (userId === OWNER ? 150 : 40) * 1024 * 1024);
          } catch (err) {
            return json(res, 400, { error: err.message });
          }
          try {
            const result = await importData(userId, data);
            if (result.notes) profileStale(userId);
            return json(res, 200, result);
          } catch (err) {
            return json(res, err.status || 500, { error: err.status ? err.message : 'The import failed.' });
          }
        } finally {
          importing = false;
        }
      });
    }

    /* ---------- her voice ---------- */

    if (pathname === '/api/voice' && req.method === 'GET') {
      if (!voiceEnabled()) return json(res, 200, { enabled: false });
      try {
        return json(res, 200, { enabled: true, voices: await voiceList(), default: config.tts.voice });
      } catch {
        return json(res, 200, { enabled: false });
      }
    }

    if (pathname === '/api/tts' && req.method === 'POST') {
      if (!voiceEnabled()) return json(res, 404, { error: 'Voice is not set up on this server.' });
      return ttsLimiter(req, res, async () => {
        const body = await readJson(req, 32 * 1024).catch(() => ({}));
        try {
          const wav = await speak({ text: body.text, voice: body.voice, speed: body.speed });
          res.writeHead(200, { 'content-type': 'audio/wav', 'content-length': wav.length, 'cache-control': 'private, max-age=3600', 'x-content-type-options': 'nosniff' });
          res.end(wav);
        } catch (err) {
          json(res, err.status || 502, { error: err.status ? err.message : "I couldn't say that out loud just now." });
        }
      });
    }

    /* ---------- pictures she is drawing ---------- */

    const imageMatch = /^\/api\/images\/([a-f0-9]{16})$/.exec(pathname);
    if (imageMatch && req.method === 'GET') {
      const job = getJob(imageMatch[1], userId);
      return job ? json(res, 200, jobView(job)) : json(res, 404, { error: 'Not found' });
    }

    /* ---------- her GIFs: the files stay in the collection folder and are streamed from there ---------- */

    const gifMatch = /^\/gif\/([a-f0-9]{12})$/.exec(pathname);
    if (gifMatch && (req.method === 'GET' || req.method === 'HEAD')) {
      const item = gifItem(gifMatch[1]);
      const file = item && item.status === 'ok' ? gifFile(item) : null;
      let stat = null;
      try {
        stat = file ? fs.statSync(file) : null;
      } catch {
        stat = null;
      }
      if (!stat) return json(res, 404, { error: 'Not found' });
      const type = GIF_MIME[item.ext] || 'application/octet-stream';
      // video needs byte ranges (Safari will not play it otherwise)
      const range = /^bytes=(\d*)-(\d*)$/.exec(String(req.headers.range || ''));
      let start = 0;
      let end = stat.size - 1;
      if (range && (range[1] || range[2])) {
        if (range[1]) start = Number(range[1]);
        if (range[2]) end = Math.min(end, Number(range[2]));
        if (!range[1]) {
          start = Math.max(0, stat.size - Number(range[2]));
          end = stat.size - 1;
        }
        if (start > end || start >= stat.size) {
          res.writeHead(416, { 'content-range': `bytes */${stat.size}` });
          return res.end();
        }
        res.writeHead(206, { 'content-type': type, 'content-length': end - start + 1, 'content-range': `bytes ${start}-${end}/${stat.size}`, 'accept-ranges': 'bytes', 'cache-control': 'private, max-age=86400', 'x-content-type-options': 'nosniff' });
      } else {
        res.writeHead(200, { 'content-type': type, 'content-length': stat.size, 'accept-ranges': 'bytes', 'cache-control': 'private, max-age=86400', 'x-content-type-options': 'nosniff' });
      }
      if (req.method === 'HEAD') return res.end();
      return fs.createReadStream(file, { start, end }).pipe(res);
    }

    /* ---------- music: each person's own player, and the owner's songs streamed from their folder ---------- */

    if (pathname === '/api/music' && req.method === 'GET') {
      await syncMusic().catch(() => 0);
      return json(res, 200, {
        player: publicPlayer(userId),
        // where her music comes from; the folder's place on the disk is only told to the owner
        folder: { ready: musicFolderReady(), songs: songCount(), ...(userId === OWNER ? { path: config.music.dir } : {}) },
        online: musicOnline(),
        // YouTube Music: on, and whether yt-dlp (what plays it) is in place yet
        youtube: { on: config.music.youtube, ready: youtubeReady(), ...(userId === OWNER ? { ytdlp: ytdlpState.version, error: ytdlpState.error } : {}) }
      });
    }

    // a click on the player (or the browser saying where a song has got to): the same changes her tools make
    if (pathname === '/api/music' && req.method === 'POST') {
      const body = await readJson(req, 4096).catch(() => ({}));
      const change = {
        pause: { type: 'pause', position: body.position },
        resume: { type: 'resume' },
        next: { type: 'next' },
        ended: { type: 'next', auto: true },
        previous: { type: 'previous' },
        restart: { type: 'restart' },
        stop: { type: 'stop' },
        volume: { type: 'volume', value: body.value },
        report: { type: 'report', position: body.position, paused: typeof body.paused === 'boolean' ? body.paused : undefined }
      }[String(body.action || '')];
      if (!change) return json(res, 400, { error: 'The player does not know how to do that.' });
      try {
        const { did } = musicAct(userId, change);
        if (change.type !== 'report') debug('music.click', { user: who(userId), action: body.action, did });
        return json(res, 200, { did, player: publicPlayer(userId) });
      } catch (err) {
        // nothing to act on (the player was closed elsewhere, or that was the last song): the page is shown how things stand
        return json(res, 409, { error: err.message, player: publicPlayer(userId) });
      }
    }

    /* ---------- watching a video together: the window's state, its buttons, and the video passed on ---------- */

    if (pathname === '/api/watch' && req.method === 'GET') {
      return json(res, 200, { video: publicWatching(userId), ready: watchReady() });
    }

    if (pathname === '/api/watch' && req.method === 'POST') {
      const body = await readJson(req, 2048).catch(() => ({}));
      const type = String(body.action || '');
      if (!['pause', 'resume', 'stop', 'report', 'ended', 'seek'].includes(type)) return json(res, 400, { error: 'The video window cannot do that.' });
      try {
        changeWatching(userId, { type, position: body.position, paused: typeof body.paused === 'boolean' ? body.paused : undefined });
        return json(res, 200, { video: publicWatching(userId) });
      } catch (err) {
        return json(res, 409, { error: err.message, video: null });
      }
    }

    const vidMatch = /^\/video\/yt\/([A-Za-z0-9_-]{11})$/.exec(pathname);
    if (vidMatch && (req.method === 'GET' || req.method === 'HEAD')) {
      if (!watchReady()) return json(res, 404, { error: 'Not found' });
      if (await streamYoutube(req, res, vidMatch[1], userId, { kind: 'video' })) return undefined;
      return json(res, 404, { error: 'Not found' });
    }

    const ytMatch = /^\/music\/yt\/([A-Za-z0-9_-]{11})$/.exec(pathname);
    if (ytMatch && (req.method === 'GET' || req.method === 'HEAD')) {
      if (!youtubeReady()) return json(res, 404, { error: 'Not found' });
      if (await streamYoutube(req, res, ytMatch[1], userId)) return undefined;
      return json(res, 404, { error: 'Not found' });
    }

    const songMatch = /^\/music\/([a-f0-9]{12})$/.exec(pathname);
    if (songMatch && SONG_ID.test(songMatch[1]) && (req.method === 'GET' || req.method === 'HEAD')) {
      const song = getSong(songMatch[1]);
      const file = song ? songFile(song) : null;
      // byte ranges are what let the player's bar jump to any point in the song
      if (!file || !(await streamFile(req, res, file, AUDIO[song.ext] || 'application/octet-stream'))) return json(res, 404, { error: 'Not found' });
      return undefined;
    }

    /* ---------- pictures people sent ---------- */

    const mediaMatch = /^\/media\/([^/]+)$/.exec(pathname);
    if (mediaMatch && !MEDIA_ID.test(mediaMatch[1])) return json(res, 404, { error: 'Not found' });
    if (mediaMatch && req.method === 'GET') {
      const buf = await readMedia(userId, mediaMatch[1]);
      if (!buf) return json(res, 404, { error: 'Not found' });
      res.statusCode = 200;
      res.setHeader('content-type', mediaMime(mediaMatch[1]));
      res.setHeader('content-length', buf.length);
      res.setHeader('cache-control', 'private, max-age=86400');
      res.setHeader('x-content-type-options', 'nosniff');
      return res.end(buf);
    }

    /* ---------- chat ---------- */

    if (pathname === '/api/chat' && req.method === 'POST') {
      return limiter(req, res, () => handleChat(req, res, userId));
    }

    if (req.method === 'GET' || req.method === 'HEAD') {
      const file = pathname === '/' ? '/index.html' : pathname === '/status' ? '/status.html' : pathname === '/chats' ? '/chats.html' : pathname;
      const served = await serveStatic(config.publicDir, file, res, req.headers);
      if (served) return;
    }

    json(res, 404, { error: 'Not found' });
  } catch (err) {
    console.error('[http]', req.method, pathname, err);
    if (!res.headersSent) json(res, 500, { error: 'Something went wrong on the server.' });
    else res.end();
  }
}

const shutdown = () => {
  stopTunnel(); // a link never outlives the app
  flushNow();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 2000).unref();
};
process.on('exit', () => stopTunnel());
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

// data from an older version is brought up to date (after a backup) before anything reads it
const migrated = await migrate();
if (migrated.ran.length) console.log(`[data] updated to schema ${migrated.to}: ${migrated.ran.join(', ')}`);
if (migrated.newer) console.log('[data] this data was written by a newer version; running without changing it');
await initAuth();
initShare(); // who a link lets in, as last chosen in Settings
loadHistory();
const movedMedia = await migrateFlatMedia();
if (movedMedia) console.log(`[media] moved ${movedMedia} older pictures into the owner's folder`);

// notes that older versions kept inside each conversation become part of her long-term memory
const legacy = await takeLegacyMemory();
if (legacy.length) {
  const user = await getUser('local');
  for (const text of legacy) await addNote(user, text, 'auto');
  console.log(`[memory] moved ${legacy.length} older notes into long-term memory`);
}

// if the last run stopped while a picture was being drawn, the chat model may still be off the card
if (swapAvailable()) gpuControl('/gpu/chat').catch((err) => console.log(`[images] could not check the model: ${err.message}`));

// anything that escapes everything else is written down, then the process stops as it always did (the supervisor restarts it)
for (const kind of ['uncaughtException', 'unhandledRejection']) {
  process.on(kind, (err) => {
    debug('crash', { kind, error: err });
    flushDebug();
    console.error(`[${kind}]`, err);
    process.exit(1);
  });
}

debug('server.start', { port: config.port, access: accessMode, model: config.model || 'auto' });
await loadGifs();
syncMusic().then((n) => { if (n) console.log(`[music] ${n} songs in ${config.music.dir}`); }).catch(() => {});
keepYtdlpUpdated(); // YouTube Music: yt-dlp is installed if missing, then checked for a newer one every 6 hours
watchTaste(); // what they play, skip and go back to teaches her their music taste
startDiary(); // her diary: an entry after each day they talked
warmRouter(); // the router's example phrases, made now so the first message does not wait for them
setTimeout(warmModel, 20_000).unref(); // and its model reads its instructions once, after the launcher has started it
// her notes tidied while things are quiet: copies merged, out-of-date ones put away
if (!process.env.NODE_TEST_CONTEXT) startTidying({ listUsers: async () => (await fs.promises.readdir(config.usersDir).catch(() => [])).filter((f) => f.endsWith('.json')).map((f) => f.slice(0, -5)) });
await loadVideoCatalog();
await loadPool();
startPool();
startBackups();
startIndexer();
startUpdates({ quiet: () => isQuiet() && chatReady() && queuedJobs() === 0, msSinceActivity, flush: () => { flushNow(); flushDebug(); } });

server.listen(config.port, config.host, () => {
  console.log(`Rosia is up → http://127.0.0.1:${config.port}`);
  console.log(`Model endpoint: ${config.ollamaUrl}`);
  console.log(`Access: ${accessMode === 'open' ? 'open (any machine that can reach this gets its own private space)' : 'invite (this computer, plus machines paired with a code)'}`);
  if (!config.model) console.log('Model: auto-detect on first message');
  setTimeout(maybeWarm, 1500).unref();
});
