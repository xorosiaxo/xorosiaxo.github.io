// Keeps the model server and the app running: starts them, restarts either if it exits or stops
// answering, and shuts both down cleanly on Ctrl+C.
//
//   node scripts/supervisor.js            start everything (what start.bat does)
//   node scripts/supervisor.js --no-model leave the model alone (it is already running, or remote)
//
// Settings: defaults below match start.bat; override any of them in rosia.local.json (not committed) or
// with the environment variables named in the file.
import { spawn, execFile } from 'node:child_process';
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createUpdateWatcher } from './apply-update.js';
import { createStartupStatus, fileWriter } from './startup-status.js';

/* ---------- reusable: one supervised process ---------- */

export function supervise({
  name,
  command,
  args = [],
  cwd,
  env = process.env,
  log = () => {},
  health = null, // { url, intervalMs, failures, graceMs }
  backoff = { minMs: 1000, maxMs: 30_000, stableMs: 60_000 },
  onStart = () => {},
  // called when the process has exited by itself: may return { restartNow: true } (an update was put in place, or taken out
  // again) to start it again at once instead of with the usual growing wait
  onExit = () => null,
  autostart = true
}) {
  let child = null;
  let stopped = false;
  let paused = !autostart; // paused: deliberately not running (the GPU is lent to something else), so nothing restarts it
  let restarts = 0;
  let delay = backoff.minMs;
  let startedAt = 0;
  let timer = 0;
  let watchdog = 0;
  let misses = 0;
  let healthy = false;

  // gone: it exited, or was ended by a signal (which leaves no exit code)
  const gone = (proc) => !proc || proc.exitCode !== null || proc.signalCode !== null;

  const killTree = (proc) => {
    if (gone(proc)) return;
    if (process.platform === 'win32') {
      // taskkill also stops what it started; on a busy machine it can take several seconds to even begin, so the
      // process itself is ended directly if it is still there a moment later
      execFile('taskkill', ['/PID', String(proc.pid), '/T', '/F'], () => {});
      const late = setTimeout(() => { if (!gone(proc)) proc.kill(); }, 1500);
      late.unref?.();
      proc.once('exit', () => clearTimeout(late));
    } else proc.kill('SIGKILL');
  };

  function start() {
    if (stopped || paused) return;
    startedAt = Date.now();
    misses = 0;
    healthy = false;
    child = spawn(command, args, { cwd, env, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    onStart(child);
    const pipe = (stream, tag) => {
      let buf = '';
      stream.on('data', (chunk) => {
        buf += chunk.toString('utf8');
        let i;
        while ((i = buf.indexOf('\n')) !== -1) {
          log(tag, buf.slice(0, i).replace(/\r$/, ''));
          buf = buf.slice(i + 1);
        }
      });
      stream.on('end', () => {
        if (buf.trim()) log(tag, buf.trimEnd());
        buf = '';
      });
    };
    pipe(child.stdout, 'out');
    pipe(child.stderr, 'err');
    child.on('error', (err) => log('sup', `could not start ${name}: ${err.message}`));
    child.on('exit', (code, signal) => {
      clearInterval(watchdog);
      if (stopped || paused) return;
      Promise.resolve()
        .then(() => onExit(code, signal))
        .catch((err) => {
          log('sup', `${name}: ${err.message}`);
          return null;
        })
        .then((verdict) => {
          if (stopped || paused) return;
          restarts += 1;
          if (verdict?.restartNow) {
            delay = backoff.minMs;
            log('sup', `${name} stopped (${signal || `code ${code}`}); starting it again`);
            timer = setTimeout(start, 300);
            return;
          }
          // a run that lasted a while was healthy, so the next wait starts short again
          if (Date.now() - startedAt > backoff.stableMs) delay = backoff.minMs;
          log('sup', `${name} stopped (${signal || `code ${code}`}); restarting in ${Math.round(delay / 1000)}s`);
          timer = setTimeout(start, delay);
          delay = Math.min(backoff.maxMs, delay * 2);
        });
    });

    if (health) {
      watchdog = setInterval(async () => {
        if (gone(child) || stopped) return;
        try {
          const res = await fetch(health.url, { signal: AbortSignal.timeout(5000) });
          if (!res.ok) throw new Error(`status ${res.status}`);
          misses = 0;
          healthy = true;
        } catch {
          // while it is still starting up, not answering is normal
          if (!healthy && Date.now() - startedAt < (health.graceMs ?? 120_000)) return;
          misses += 1;
          if (misses >= (health.failures ?? 3)) {
            log('sup', `${name} is not answering; restarting it`);
            misses = 0;
            killTree(child);
          }
        }
      }, health.intervalMs ?? 20_000);
    }
  }

  start();

  const running = () => !gone(child);

  return {
    stop() {
      stopped = true;
      clearTimeout(timer);
      clearInterval(watchdog);
      killTree(child);
    },
    /** Stops it and keeps it stopped until resume(). Resolves once the process has really gone (and let go of the GPU). */
    async pause() {
      paused = true;
      clearTimeout(timer);
      clearInterval(watchdog);
      healthy = false;
      const proc = child;
      if (gone(proc)) return;
      const exited = new Promise((resolve) => proc.once('exit', resolve));
      killTree(proc);
      await Promise.race([exited, new Promise((r) => setTimeout(r, 15_000))]);
    },
    /** Stops the process so that the ordinary restart starts it again. */
    restart() {
      killTree(child);
    },
    resume() {
      if (stopped || !paused) return;
      paused = false;
      delay = backoff.minMs;
      if (!running()) start();
    },
    status: () => ({ name, running: running(), paused, restarts, healthy })
  };
}

/** Waits until a URL answers (or gives up). */
export async function waitForHealth(url, timeoutMs, intervalMs = 1000) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    try {
      if ((await fetch(url, { signal: AbortSignal.timeout(2000) })).ok) return true;
    } catch {
      /* not yet */
    }
    await new Promise((r) => setTimeout(r, intervalMs));
  }
  return false;
}

/** Does this address answer right now? Asked once: something that is not running refuses at once. */
export async function answers(url, timeoutMs = 1200) {
  try {
    return (await fetch(url, { signal: AbortSignal.timeout(timeoutMs) })).ok;
  } catch {
    return false;
  }
}

/**
 * The flags a program does not know, remembered in a small file so a slow program is asked once, not at every start.
 * The answer is kept for as long as the program's file and the flags stay the same. ask() resolves to { unknown: [...] }.
 */
export async function rememberedFlags(cacheFile, programFile, flags, ask) {
  let key = '';
  try {
    key = `${fs.statSync(programFile).mtimeMs}|${flags.join(' ')}`;
    const kept = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
    if (kept.key === key && Array.isArray(kept.unknown)) return kept.unknown;
  } catch {
    /* nothing kept yet */
  }
  const result = await ask();
  // an answer that could not be had (the program did not run) is not kept: it is asked again next time
  if (key && !result.error) {
    try {
      fs.mkdirSync(path.dirname(cacheFile), { recursive: true });
      fs.writeFileSync(cacheFile, JSON.stringify({ key, unknown: result.unknown }));
    } catch {
      /* asked again next time */
    }
  }
  return result.unknown;
}


/* ---------- lending the GPU: chat model <-> image generator ---------- */

/*
 * The graphics card is too small to hold the chat model and the image model at once, so they take turns:
 * toImage() stops the chat model (and waits until it has really let go of the card) and starts ComfyUI;
 * toChat() does the reverse. Calls are queued, so two never overlap.
 */
/*
 * Standby (opt-in, `comfyStandby` in rosia.local.json): ComfyUI is started with the launcher and stays running, so a picture
 * does not wait for it to start (about 20-45 s). The chat model still steps off the card while a picture is drawn, because
 * the drawing needs about 2.3 GiB; what changes is that ComfyUI itself is never stopped. Between pictures it holds only
 * its own small footprint (release() asks it to unload its models first), and the chat model is started with
 * `standbyModelArgs` (the vision projector on the processor instead of the card) to leave room for that.
 */
export function createGpuControl({ model, comfy, modelHealth, comfyHealth, waitMs = { model: 180_000, comfy: 240_000 }, standby = false, release = async () => {}, log = () => {} }) {
  let chain = Promise.resolve();
  let mode = 'chat';
  const turn = (job) => {
    const run = chain.then(job);
    chain = run.catch(() => {});
    return run;
  };
  const refuse = (message) => Object.assign(new Error(message), { status: 409 });

  return {
    state: () => ({ mode, standby, model: model?.status() ?? null, comfy: comfy?.status() ?? null }),

    toImage: () => turn(async () => {
      if (!comfy) throw refuse('Image generation is not set up (no ComfyUI folder in rosia.local.json).');
      if (!model) throw refuse('The chat model was not started by this launcher, so it cannot be moved off the graphics card.');
      if (mode === 'image' && comfy.status().healthy) return;
      log('gpu', 'handing the graphics card to the image generator');
      await model.pause();
      mode = 'image';
      if (!standby) comfy.resume(); // on standby it is already running: only the chat model steps aside
      if (!(await waitForHealth(comfyHealth, waitMs.comfy, 1000))) {
        // never leave the card empty: the chat model goes back before the failure is reported
        log('gpu', 'the image generator did not start; giving the card back to the chat model');
        if (!standby) await comfy.pause();
        mode = 'chat';
        model.resume();
        await waitForHealth(modelHealth, waitMs.model, 1000);
        throw new Error('The image generator did not start.');
      }
    }),

    toChat: () => turn(async () => {
      if (!model) return;
      log('gpu', 'handing the graphics card back to the chat model');
      if (comfy && standby) {
        // ComfyUI stays up: it is only asked to let go of its models, so the card is empty again before the chat model returns
        await Promise.resolve(release()).catch((err) => log('gpu', `could not ask the image generator to unload: ${err.message}`));
      } else if (comfy) {
        await comfy.pause();
      }
      mode = 'chat';
      model.resume();
      if (!(await waitForHealth(modelHealth, waitMs.model, 1000))) throw new Error('The chat model did not come back.');
    })
  };
}

/** Whether a command-line flag appears in a program's `--help` text (so a flag this build does not know is never passed to it). */
export function helpMentions(helpText, flag) {
  const escaped = String(flag).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(?:^|[\\s,|\\[])${escaped}(?=[\\s,|\\]=]|$)`, 'm').test(String(helpText));
}

/** Runs `program --help` and checks it knows each flag. Resolves to { known: [...], unknown: [...] }; never throws. */
export function checkFlags(program, flags, { run = execFile, timeoutMs = 15_000, prefix = [], cwd } = {}) {
  return new Promise((resolve) => {
    run(program, [...prefix, '--help'], { timeout: timeoutMs, windowsHide: true, maxBuffer: 4 * 1024 * 1024, cwd }, (err, stdout, stderr) => {
      const text = `${stdout || ''}\n${stderr || ''}`;
      if (!text.trim()) return resolve({ known: [], unknown: [...flags], error: err ? String(err.message) : 'no help text' });
      resolve({ known: flags.filter((f) => helpMentions(text, f)), unknown: flags.filter((f) => !helpMentions(text, f)) });
    });
  });
}

/*
 * How much of the chat model goes on the graphics card, when the settings do not say.
 *
 * It used to be "all of it" (-ngl 99). On a card the model does not quite fit on, Windows then keeps the overflow in ordinary
 * memory and the model crawls: measured on a 4 GB card beside the idle image generator, it read a prompt at about 95 tokens a
 * second. Letting llama.cpp put on the card only what fits, with 512 MB left free for everything else that draws on it,
 * read the same prompt at about 870 a second and wrote just as fast. With several people talking to her every reply
 * re-reads a few thousand tokens, so that is the difference between a 3 second wait and half a minute.
 * The room left is 1 GB, not 512 MB: what is free is only measured once, when the model loads, and her own window (about
 * 600 MB of the card) and the desktop itself take theirs afterwards. With 512 MB the card was over-full and, measured on the
 * same 4 GB card, a prompt was read at 54 to 72 tokens a second; with 1 GB, at 730 to 850, and replies were written just as fast.
 * A llama.cpp too old to fit by itself gets the old setting.
 */
export function gpuLayerArgs(extraArgs, knownFlags) {
  const given = extraArgs.some((a) => /^(-ngl|--gpu-layers|--n-gpu-layers|-fit|--fit|-fitt|--fit-target)$/.test(a));
  if (given) return [];
  return knownFlags.includes('--fit-target') ? ['--fit-target', '1024'] : ['-ngl', '99'];
}

const truthy = (v) => v === true || /^(1|true|yes|on)$/i.test(String(v ?? ''));
export { truthy as isTruthy };

/** A small local-only HTTP API for the app: POST /gpu/image, POST /gpu/chat, GET /gpu. Needs the shared token. */
export function createControlServer({ gpu, token }) {
  return http.createServer(async (req, res) => {
    const reply = (status, body) => {
      res.writeHead(status, { 'content-type': 'application/json' });
      res.end(JSON.stringify(body));
    };
    if (req.headers['x-rosia-control'] !== token) return reply(401, { error: 'no' });
    try {
      if (req.method === 'GET' && req.url === '/gpu') return reply(200, gpu.state());
      if (req.method === 'POST' && req.url === '/gpu/image') return await gpu.toImage(), reply(200, { ok: true });
      if (req.method === 'POST' && req.url === '/gpu/chat') return await gpu.toChat(), reply(200, { ok: true });
      reply(404, { error: 'not found' });
    } catch (err) {
      reply(err.status || 500, { error: err.message });
    }
  });
}


/* ---------- why the chat model is not running, said plainly ---------- */

/** What the chat model's start depends on: a change in any of these means it is started again. */
export const chatKey = (c, exists = fs.existsSync) => JSON.stringify([c.server, c.model, c.mmproj, c.extraArgs, exists(c.server), exists(c.model)]);

/** The chat model's files that are not there: [{ what, path, given }]. */
export function missingModelFiles(c, exists = fs.existsSync) {
  const out = [];
  if (!exists(c.server)) out.push({ what: 'the model runner (llama-server.exe)', path: c.server, given: Boolean(c.given?.server) });
  if (!exists(c.model)) out.push({ what: 'the chat model', path: c.model, given: Boolean(c.given?.model) });
  return out;
}

/** For the startup screen: never set up, or set up and gone since (most often taken by an antivirus). */
export function missingNote(c, missing) {
  const gone = missing.filter((m) => m.given);
  if (!gone.length) return 'not set up yet: open Settings, then Models';
  const what = gone.map((m) => m.what).join(' and ');
  return `${what} ${gone.length > 1 ? 'are' : 'is'} no longer where it was set up. An antivirus may have removed it: check its quarantine and allow it, or download it again in Settings, then Models`;
}

/** For a model runner that could not even be started. */
export function startFailureNote(err) {
  const code = String(err?.code || '');
  if (code === 'ENOENT') return 'the model runner (llama-server.exe) is missing. An antivirus may have removed it: download it again in Settings, then Models';
  if (['EPERM', 'EACCES', 'UNKNOWN', 'EBUSY'].includes(code)) return 'Windows or an antivirus stopped the model runner (llama-server.exe) from starting. Allow it in your antivirus, then quit Rosia from the tray and open it again';
  return `the model runner could not be started: ${err?.message || err}`;
}

/** For a model runner Windows ended at once, by its exit code ('' when the code says nothing in particular). */
export function exitNote(code) {
  const n = Number(code) >>> 0; // Windows' status codes can arrive as negative numbers
  if (n === 0xC0000135) return 'a file the model runner needs (a .dll next to llama-server.exe) is missing. An antivirus may have removed it: download the model runner again in Settings, then Models';
  if (n === 0xC0000022) return 'Windows or an antivirus refused to let the model runner run. Allow llama-server.exe in your antivirus, then quit Rosia from the tray and open it again';
  if (n === 0xC000001D) return 'this processor cannot run this build of the model runner';
  return '';
}

/* ---------- the command line ---------- */

function settings(root) {
  let local = {};
  let unreadable = '';
  try {
    local = JSON.parse(fs.readFileSync(path.join(root, 'rosia.local.json'), 'utf8'));
  } catch (err) {
    // optional; but one that is there and cannot be read means every setting in it is ignored, which the log must say
    if (err.code !== 'ENOENT') unreadable = err.message;
  }
  const pick =(envName, key, fallback) => process.env[envName] || local[key] || fallback;
  const llamaDir = pick('LLAMA_DIR', 'llamaDir', 'C:\\AI\\llama-b11057-bin-win-cuda-13.4-x64');
  const modelDir = pick('ROSA_MODEL_DIR', 'modelDir', 'C:\\AI\\models\\gemma4-e4b-uncensored');
  const model = pick('ROSA_MODEL_FILE', 'model', path.join(modelDir, 'model.gguf'));
  const comfyDir = pick('ROSA_COMFY_DIR', 'comfyDir', '');
  return {
    unreadable,
    // whether a path was chosen (in the settings or the environment) rather than left to the defaults: a chosen file that is
    // missing was most likely removed (an antivirus), a default one was never there
    given: {
      server: Boolean(process.env.LLAMA_SERVER || local.llamaServer || process.env.LLAMA_DIR || local.llamaDir),
      model: Boolean(process.env.ROSA_MODEL_FILE || local.model || process.env.ROSA_MODEL_DIR || local.modelDir)
    },
    server: pick('LLAMA_SERVER', 'llamaServer', path.join(llamaDir, process.platform === 'win32' ? 'llama-server.exe' : 'llama-server')),
    model,
    // a vision projector sits next to the model by default; "mmproj": "" in rosia.local.json means a text-only model
    mmproj: 'mmproj' in local ? local.mmproj : process.env.ROSA_MMPROJ_FILE || path.join(path.dirname(model), 'mmproj.gguf'),
    modelPort: Number(pick('ROSA_MODEL_PORT', 'modelPort', 8080)),
    appPort: Number(pick('PORT', 'port', 8787)),
    alias: pick('ROSA_MODEL', 'alias', 'rosia'),
    // how much of the model goes on the graphics card is added when it is started (see gpuLayerArgs), unless given here
    extraArgs: local.modelArgs || ['-c', '8192', '-np', '1', '--jinja'],
    // optional small embedding model for "meaning" search in memory. It runs on the CPU, next to the chat model
    // on the GPU, so it costs the chat nothing. e.g. embeddinggemma-300M-Q8_0.gguf with style "embeddinggemma"
    embedFile: pick('ROSA_EMBED_FILE', 'embedModel', ''),
    embedStyle: pick('ROSA_EMBED_STYLE', 'embedStyle', 'none'),
    embedPort: Number(pick('ROSA_EMBED_PORT', 'embedPort', 8081)),
    // optional small model that decides what a message wants (server/router.js, step 2), on the CPU like the memory model
    routerFile: pick('ROSA_ROUTER_FILE', 'routerModel', ''),
    routerPort: Number(pick('ROSA_ROUTER_PORT', 'routerPort', 8082)),
    // voice: Kokoro on the CPU (scripts/tts-server.py)
    ttsModel: pick('ROSA_TTS_MODEL', 'ttsModel', ''),
    ttsVoices: pick('ROSA_TTS_VOICES', 'ttsVoices', ''),
    ttsPython: pick('ROSA_TTS_PYTHON', 'ttsPython', 'python'),
    ttsPort: Number(pick('ROSA_TTS_PORT', 'ttsPort', 8082)),
    // images: ComfyUI (its own folder with main.py and a .venv), borrowing the GPU from the chat model while it works
    comfyDir,
    comfyPython: pick('ROSA_COMFY_PYTHON', 'comfyPython', comfyDir ? path.join(comfyDir, '.venv', 'Scripts', 'python.exe') : ''),
    comfyModels: pick('ROSA_COMFY_MODELS', 'comfyModels', ''),
    comfyPort: Number(pick('ROSA_COMFY_PORT', 'comfyPort', 8188)),
    // only these custom nodes are loaded (ComfyUI starts much faster): GGUF models, KJNodes for sage attention, and RES4LYF,
    // which is what adds the res_2s sampler and bong_tangent scheduler the saved workflow uses
    comfyNodes: local.comfyNodes || ['ComfyUI-GGUF', 'comfyui-kjnodes', 'RES4LYF'],
    comfyWorkflow: pick('ROSA_IMAGE_WORKFLOW', 'comfyWorkflow', comfyDir ? path.join(comfyDir, 'user', 'default', 'workflows', 'rosia.json') : ''),
    comfyArgs: local.comfyArgs || [],
    // standby: ComfyUI stays running between pictures (see createGpuControl). Off unless asked for.
    comfyStandby: truthy(process.env.ROSA_COMFY_STANDBY ?? local.comfyStandby),
    // what the chat model is started with in standby, to leave room on the card for the idle image generator:
    // the vision projector goes on the processor (it only slows reading pictures, not chat)
    standbyModelArgs: local.standbyModelArgs || ['--no-mmproj-offload'],
    // ComfyUI's flags in standby: nothing is kept in memory between pictures
    standbyComfyArgs: local.standbyComfyArgs || ['--cache-none'],
    controlPort: Number(pick('ROSA_CONTROL_PORT', 'controlPort', 8790)),
    // "invite" (default): other machines need a pairing code and join YOUR space; "open": anyone with the link gets their own private space
    access: pick('ROSA_ACCESS', 'access', ''),
    // her GIF collection: a Python that has Pillow (for the frames), and the folder if it is not Rosia-GIFs in the user folder
    gifPython: pick('ROSA_GIF_PYTHON', 'gifPython', ''),
    gifsDir: pick('ROSA_GIFS_DIR', 'gifsDir', ''),
    // her music: the folder of the owner's own songs, if it is not Rosia-Music in the user folder
    musicDir: pick('ROSA_MUSIC_DIR', 'musicDir', ''),
    // YouTube Music for famous songs (played through yt-dlp, kept up to date by the app): on unless "youtubeMusic": false
    youtubeMusic: (process.env.ROSA_YOUTUBE ?? local.youtubeMusic) === undefined ? true : truthy(process.env.ROSA_YOUTUBE ?? local.youtubeMusic),
    // updates: where the signed release list is, and whether a new version installs itself ('auto'), waits to be told ('notify') or never ('off')
    updateUrl: pick('ROSA_UPDATE_URL', 'updateUrl', ''),
    updateMode: pick('ROSA_UPDATE_MODE', 'updateMode', '')
  };
}

export function comfyPathsYaml(modelsDir) {
  const base = String(modelsDir).replace(/\\/g, '/');
  return [
    'rosia:',
    `  base_path: ${base}`,
    '  checkpoints: checkpoints',
    '  diffusion_models: diffusion_models',
    '  unet: unet',
    '  text_encoders: text_encoders',
    '  clip: text_encoders',
    '  vae: vae',
    '  loras: loras',
    ''
  ].join('\n');
}

async function main() {
  const here = path.dirname(fileURLToPath(import.meta.url));
  const root = path.resolve(here, '..');
  // the person's own files (rosia.local.json, data/) live in "home": this folder, or the one the desktop app names
  const home = process.env.ROSIA_HOME ? path.resolve(process.env.ROSIA_HOME) : root;
  const cfg = settings(home);
  const dataDir = process.env.ROSA_DATA_DIR || path.join(home, 'data');
  const logDir = path.join(dataDir, 'logs');
  fs.mkdirSync(logDir, { recursive: true });

  const log = (name) => (tag, line) => {
    const text = `[${name}] ${line}`;
    if ((tag !== 'out' || process.env.ROSA_VERBOSE) && (process.stdout.isTTY || tag === 'sup')) console.log(text);
    const file = path.join(logDir, `${name}.log`);
    try {
      if (fs.existsSync(file) && fs.statSync(file).size > 5 * 1024 * 1024) fs.renameSync(file, `${file}.old`);
      fs.appendFileSync(file, `${new Date().toISOString()} ${tag} ${line}\n`);
    } catch {
      /* logging must never take the app down */
    }
  };

  const parts = [];
  const modelUrl = `http://127.0.0.1:${cfg.modelPort}/health`;
  const appUrl = `http://127.0.0.1:${cfg.appPort}/api/alive`; // answers at once: a slow model must not get the app restarted
  const comfyUrl = `http://127.0.0.1:${cfg.comfyPort}`;
  const embedUrl = `http://127.0.0.1:${cfg.embedPort}`;
  const ttsUrl = `http://127.0.0.1:${cfg.ttsPort}`;
  let gpuControl = null;

  console.log('\n  R O S I A\n');
  console.log(`  ${new Date().toISOString()}  launcher started (Node ${process.version}, ${process.platform} ${os.release()}, app folder ${root})`);
  console.log(`  home: ${home}${fs.existsSync(path.join(home, 'rosia.local.json')) ? '' : ' (no rosia.local.json yet)'}`);
  if (cfg.unreadable) console.log(`  [!] rosia.local.json could not be read, so none of its settings are used: ${cfg.unreadable}`);
  for (const [what, file] of [['model runner', cfg.server], ['chat model', cfg.model], ['vision', cfg.mmproj], ['memory model', cfg.embedFile], ['router model', cfg.routerFile]]) {
    if (file) console.log(`  ${what}: ${file}${fs.existsSync(file) ? '' : '  [not found]'}`);
  }

  /*
   * Everything is started at once and nothing waits for anything it does not need: the app is up in a second or two and
   * shows what the rest is doing; the chat model, her memory and her voice load side by side; the image generator (standby)
   * starts once the chat model is on the card and never holds the window up. Before this the parts were started one after
   * another, each waited for in turn, and the window stayed on "getting ready" for over two minutes, most of it the image
   * generator, which nothing needs until she draws.
   */
  const noModel = process.argv.includes('--no-model');
  const serverThere = fs.existsSync(cfg.server);
  const comfyInstalled = Boolean(cfg.comfyDir && fs.existsSync(path.join(cfg.comfyDir, 'main.py')) && fs.existsSync(cfg.comfyPython));
  const wantEmbed = Boolean(cfg.embedFile && fs.existsSync(cfg.embedFile) && serverThere);
  const routerUrl = `http://127.0.0.1:${cfg.routerPort}`;
  const wantRouter = Boolean(cfg.routerFile && fs.existsSync(cfg.routerFile) && serverThere);
  const wantVoice = Boolean(cfg.ttsModel && fs.existsSync(cfg.ttsModel) && fs.existsSync(cfg.ttsVoices));
  const flagsOf = (list) => list.filter((a) => /^-[A-Za-z-]/.test(a));

  const startupFile = path.join(logDir, 'startup.json');
  const startup = createStartupStatus({
    steps: [
      { id: 'app', label: 'Her app', needed: true },
      { id: 'model', label: 'Her chat model', needed: true },
      ...(wantEmbed ? [{ id: 'memory', label: 'Her memory' }] : []),
      ...(wantRouter ? [{ id: 'router', label: 'Understanding requests' }] : []),
      ...(wantVoice ? [{ id: 'voice', label: 'Her voice' }] : []),
      ...(comfyInstalled ? [{ id: 'images', label: 'The image generator' }] : [])
    ],
    write: fileWriter(startupFile)
  });
  const said = new Set();
  const step = (id, state, note, line) => {
    startup.set(id, state, note);
    if (line && !said.has(line)) {
      said.add(line);
      console.log(`  ${line}`);
    }
  };

  // what is already running, and what this llama.cpp understands: asked together, each once
  const [modelUp, embedUp, voiceUp, llamaHelp] = await Promise.all([
    noModel ? false : answers(modelUrl),
    wantEmbed ? answers(`${embedUrl}/health`) : false,
    wantVoice ? answers(`${ttsUrl}/health`) : false,
    serverThere ? checkFlags(cfg.server, [...flagsOf(cfg.standbyModelArgs), '--device', '--fit-target']) : { known: [], unknown: [] }
  ]);

  // standby (ComfyUI kept running between pictures) only goes ahead where it is safe: the launcher starts the chat model itself,
  // with the trimmed settings, and both programs know every flag it would pass them. Otherwise it is switched off and says why.
  let standby = cfg.comfyStandby;
  if (standby) {
    const why = [];
    if (!comfyInstalled) why.push('ComfyUI is not set up');
    if (noModel) why.push('the chat model is not started by this launcher (--no-model)');
    else if (modelUp) why.push('the chat model is already running, with its full settings, so there would be no room for ComfyUI beside it');
    else if (serverThere) {
      const unknown = llamaHelp.unknown.filter((f) => f !== '--device' && f !== '--fit-target');
      if (unknown.length) why.push(`this llama.cpp does not know ${unknown.join(', ')}`);
      const comfyFlags = flagsOf(cfg.standbyComfyArgs);
      if (!why.length && comfyInstalled && comfyFlags.length) {
        // asking ComfyUI takes several seconds (it is a Python program), so the answer is kept until ComfyUI or the flags change
        const unknownComfy = await rememberedFlags(path.join(dataDir, 'comfy', 'flags.json'), path.join(cfg.comfyDir, 'main.py'), comfyFlags, () =>
          checkFlags(cfg.comfyPython, comfyFlags, { prefix: ['main.py'], cwd: cfg.comfyDir, timeoutMs: 90_000 }));
        if (unknownComfy.length) why.push(`this ComfyUI does not know ${unknownComfy.join(', ')}`);
      }
    }
    if (why.length) {
      standby = false;
      console.log(`  images: standby is OFF: ${why.join('; ')}. Pictures work as before (ComfyUI starts when she draws).`);
    }
  }

  /*
   * ---------- the chat model, her memory and the request model ----------
   *
   * Started now when their files are there, and started (or started again) whenever their settings change: a model
   * downloaded in Settings or during setup is used within seconds. Before, they were only read here at start, and closing
   * the window only hides her in the tray, so people who had just downloaded everything saw her stay offline.
   */

  const settingsFile = path.join(home, 'rosia.local.json');
  const launcherOwnsModel = !noModel && !modelUp;
  const modelSlot = { handle: null, key: '' };
  // what the GPU hand-over and the shutdown hold on to: whichever chat model is running at the time
  const modelProxy = {
    pause: async () => modelSlot.handle?.pause(),
    resume: () => modelSlot.handle?.resume(),
    restart: () => modelSlot.handle?.restart(),
    stop: () => modelSlot.handle?.stop(),
    status: () => modelSlot.handle?.status() ?? { name: 'model', running: false, paused: false, restarts: 0, healthy: false }
  };
  let help = { server: cfg.server, flags: llamaHelp };
  const helpFor = async (c) => {
    if (help.server !== c.server) {
      help = { server: c.server, flags: fs.existsSync(c.server) ? await checkFlags(c.server, [...flagsOf(c.standbyModelArgs), '--device', '--fit-target']) : { known: [], unknown: [] } };
    }
    return help.flags;
  };

  /** Starts the chat model with these settings, or says (on the startup screen and in the log) why it cannot. */
  async function startChat(c) {
    modelSlot.key = chatKey(c);
    const missing = missingModelFiles(c);
    if (missing.length) {
      step('model', 'failed', missingNote(c, missing));
      console.log(`  [x] model: cannot start, ${missing.map((m) => `${m.what} not found at ${m.path}`).join('; ')}`);
      return false;
    }
    const flags = await helpFor(c);
    if (flags.error) console.log(`  [!] model: the model runner did not answer when asked what it supports (${flags.error})`);
    step('model', 'working', 'loading', `model: starting${standby ? ` (standby settings: ${c.standbyModelArgs.join(' ')})` : ''} ...`);
    const args = ['-m', c.model, ...(c.mmproj && fs.existsSync(c.mmproj) ? ['--mmproj', c.mmproj] : []), '--host', '127.0.0.1', '--port', String(c.modelPort), '--alias', c.alias, ...c.extraArgs, ...gpuLayerArgs(c.extraArgs, flags.known), ...(standby ? c.standbyModelArgs : [])];
    console.log(`  model: ${c.server} ${args.join(' ')}`);
    const began = Date.now();
    const handle = supervise({
      name: 'model', command: c.server, args, log: log('model'),
      health: { url: modelUrl, intervalMs: 20_000, failures: 3, graceMs: 180_000 },
      onStart: (child) => child.once('error', (err) => {
        if (modelSlot.handle === handle) step('model', 'failed', startFailureNote(err));
        console.log(`  [x] model: ${startFailureNote(err)} (${err.code || err.message})`);
      }),
      onExit: (code) => {
        // it stopped by itself while loading: the reason is in model.log; the screen says so rather than "loading" for minutes
        const note = exitNote(code);
        if (modelSlot.handle === handle && (note || Date.now() - began < 120_000)) step('model', 'failed', note || `the model runner stopped while loading (code ${code}); it is being tried again. Details are in model.log`);
        console.log(`  [x] model: the model runner stopped (code ${code})${note ? `: ${note}` : ''}`);
        return null;
      }
    });
    modelSlot.handle = handle;
    return waitForHealth(modelUrl, 180_000, 500).then((ok) => {
      if (modelSlot.handle !== handle) return ok;
      if (ok) step('model', 'done', '', 'model: ready');
      else step('model', 'failed', 'taking longer than usual: she will answer once it is loaded', 'model: not ready yet (the app picks it up when it is)');
      return ok;
    });
  }

  let modelReady = Promise.resolve(modelUp);
  if (noModel) {
    step('model', 'skipped', 'left alone', 'model: left alone (--no-model)');
  } else if (modelUp) {
    step('model', 'done', 'already running', `model: already running on :${cfg.modelPort}, not starting another`);
  } else {
    parts.push(modelProxy);
    modelReady = startChat(cfg);
  }

  const env = { ...process.env, PORT: String(cfg.appPort), OLLAMA_URL: `http://127.0.0.1:${cfg.modelPort}`, ROSA_MODEL: cfg.alias };
  if (cfg.access) env.ROSA_ACCESS = cfg.access;
  if (cfg.gifPython) env.ROSA_GIF_PYTHON = cfg.gifPython;
  if (cfg.gifsDir) env.ROSA_GIFS_DIR = cfg.gifsDir;
  if (cfg.musicDir) env.ROSA_MUSIC_DIR = cfg.musicDir;
  env.ROSA_YOUTUBE = cfg.youtubeMusic ? '1' : '0';
  if (cfg.updateUrl) env.ROSA_UPDATE_URL = cfg.updateUrl;
  if (cfg.updateMode) env.ROSA_UPDATE_MODE = cfg.updateMode;
  env.ROSA_SUPERVISED = '1'; // the app may ask for an update to be installed: only this launcher can replace its files
  env.ROSA_STARTUP_FILE = startupFile; // what is being set up, for the "getting ready" screen
  // the chat model's vision projector is on the processor (standby): looking at a picture is slow, so background cataloguing waits longer
  if (standby) env.ROSA_SLOW_VISION = '1';

  /* her memory (the embedding model) and the request model: small, on the processor, same runner */

  const helperDefs = {
    memory: {
      name: 'embed', label: 'memory model', file: (c) => c.embedFile, port: (c) => c.embedPort,
      // "--device none" keeps it off the graphics card altogether. "-ngl 0" alone still opened the card and held over 100 MB
      // of it, which on a small card is enough to push the chat model out of the card's own memory and make it crawl.
      args: (c, offCard) => ['-m', c.embedFile, '--host', '127.0.0.1', '--port', String(c.embedPort), '--embeddings', ...offCard, '-c', '2048', '-b', '2048', '-ub', '2048', '-t', '4', '--alias', 'embed'],
      env: (c) => ({ ROSA_EMBED_URL: `http://127.0.0.1:${c.embedPort}`, ROSA_EMBED_MODEL: 'embed', ROSA_EMBED_STYLE: c.embedStyle }),
      waiting: 'not answering yet: the built-in word matcher is used meanwhile'
    },
    router: {
      name: 'router', label: 'router model', file: (c) => c.routerFile, port: (c) => c.routerPort,
      // --jinja: its own chat template, so it can be told not to think out loud; answers are held to JSON by the request
      args: (c, offCard) => ['-m', c.routerFile, '--host', '127.0.0.1', '--port', String(c.routerPort), ...offCard, '-c', '2048', '-t', '4', '--jinja', '--alias', 'router'],
      env: (c) => ({ ROSA_ROUTER_URL: `http://127.0.0.1:${c.routerPort}` }),
      waiting: 'not answering yet: requests are worked out by meaning alone meanwhile'
    }
  };
  const helpers = { memory: { handle: null, key: '' }, router: { handle: null, key: '' } };
  const helperKey = (def, c) => JSON.stringify([c.server, def.file(c), def.port(c), fs.existsSync(c.server), Boolean(def.file(c)) && fs.existsSync(def.file(c))]);

  /** Starts (or leaves alone) one of the small models. Returns true when the app's settings for it changed. */
  async function startHelper(id, c, { first = false } = {}) {
    const def = helperDefs[id];
    const slot = helpers[id];
    const key = helperKey(def, c);
    if (key === slot.key) return false;
    slot.key = key;
    if (slot.handle) {
      const old = slot.handle;
      slot.handle = null;
      await old.pause();
      old.stop();
    }
    const file = def.file(c);
    const url = `http://127.0.0.1:${def.port(c)}`;
    const before = Object.keys(def.env(c)).map((k) => env[k]).join('|');
    if (!file || !fs.existsSync(file) || !fs.existsSync(c.server)) {
      if (file) console.log(`  ${def.label}: ${!fs.existsSync(file) ? `file not found (${file})` : `the model runner is not there (${c.server})`}; ${def.waiting.replace(/^not answering yet: /, '')}`);
      for (const k of Object.keys(def.env(c))) delete env[k];
      return before !== Object.keys(def.env(c)).map((k) => env[k]).join('|');
    }
    Object.assign(env, def.env(c));
    if (first && (await answers(`${url}/health`))) {
      step(id, 'done', 'already running', `${def.label}: already running on :${def.port(c)}`);
    } else {
      const flags = await helpFor(c);
      const offCard = flags.known.includes('--device') ? ['--device', 'none'] : ['-ngl', '0'];
      step(id, 'working', 'loading', `${def.label}: starting (CPU) ...`);
      const handle = supervise({ name: def.name, command: c.server, args: def.args(c, offCard), log: log(def.name), health: { url: `${url}/health`, intervalMs: 30_000, failures: 3, graceMs: 120_000 } });
      slot.handle = handle;
      waitForHealth(`${url}/health`, 60_000, 500).then((ok) => {
        if (slot.handle === handle) step(id, ok ? 'done' : 'failed', ok ? '' : def.waiting, ok ? `${def.label}: ready` : `${def.label}: not answering yet`);
      });
    }
    return before !== Object.keys(def.env(c)).map((k) => env[k]).join('|');
  }
  parts.push({ stop: () => { for (const slot of Object.values(helpers)) slot.handle?.stop(); } });
  if (wantEmbed || cfg.embedFile) await startHelper('memory', cfg, { first: true });
  if (wantRouter || cfg.routerFile) await startHelper('router', cfg, { first: true });

  /* ---------- her voice ---------- */

  if (wantVoice) {
    if (voiceUp) {
      step('voice', 'done', 'already running', `voice: already running on :${cfg.ttsPort}`);
    } else {
      step('voice', 'working', 'loading', 'voice: starting (CPU) ...');
      const script = path.join(root, 'scripts', 'tts-server.py');
      parts.push(supervise({
        name: 'voice', command: cfg.ttsPython, args: [script, '--model', cfg.ttsModel, '--voices', cfg.ttsVoices, '--port', String(cfg.ttsPort)],
        log: log('voice'), health: { url: `${ttsUrl}/health`, intervalMs: 30_000, failures: 3, graceMs: 120_000 }
      }));
      waitForHealth(`${ttsUrl}/health`, 60_000, 500).then((ok) => step('voice', ok ? 'done' : 'failed', ok ? '' : 'not answering yet', ok ? 'voice: ready' : 'voice: not answering yet'));
    }
    env.ROSA_TTS_URL = ttsUrl;
  } else if (cfg.ttsModel) {
    console.log(`  voice: files not found (${cfg.ttsModel}); voice is off`);
  }

  /* ---------- pictures (ComfyUI) ---------- */

  if (comfyInstalled) {
    const comfyDataDir = path.join(dataDir, 'comfy');
    fs.mkdirSync(comfyDataDir, { recursive: true });
    const yaml = path.join(comfyDataDir, 'extra_model_paths.yaml');
    if (cfg.comfyModels) fs.writeFileSync(yaml, comfyPathsYaml(cfg.comfyModels));
    const args = [
      'main.py', '--listen', '127.0.0.1', '--port', String(cfg.comfyPort), '--disable-auto-launch',
      '--disable-all-custom-nodes', '--whitelist-custom-nodes', ...cfg.comfyNodes,
      ...(cfg.comfyModels ? ['--extra-model-paths-config', yaml] : []),
      ...cfg.comfyArgs,
      ...(standby ? cfg.standbyComfyArgs : [])
    ];
    // normally not started now: it only runs while an image is being made, because it needs the card to itself.
    // In standby it is started below, once the chat model has the card, and stays up.
    const comfy = supervise({
      name: 'images', command: cfg.comfyPython, args, cwd: cfg.comfyDir, autostart: false, log: log('images'),
      backoff: { minMs: 2000, maxMs: 30_000, stableMs: 60_000 },
      health: { url: `${comfyUrl}/system_stats`, intervalMs: 20_000, failures: 3, graceMs: 240_000 }
    });
    parts.push(comfy);
    // between pictures ComfyUI is asked to let go of its models, so the card is empty again before the chat model comes back
    const release = async () => {
      try {
        await fetch(`${comfyUrl}/free`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ unload_models: true, free_memory: true }), signal: AbortSignal.timeout(10_000) });
      } catch {
        /* it may be busy or restarting: the chat model comes back anyway */
      }
      await new Promise((r) => setTimeout(r, 2000));
    };
    const token = crypto.randomBytes(24).toString('hex');
    const gpu = gpuControl = createGpuControl({
      model: launcherOwnsModel ? modelProxy : null, comfy, modelHealth: modelUrl, comfyHealth: `${comfyUrl}/system_stats`, standby, release,
      log: (_, line) => log('gpu')('sup', line)
    });
    const control = createControlServer({ gpu, token }).listen(cfg.controlPort, '127.0.0.1');
    control.on('error', (err) => console.log(`  images: control port ${cfg.controlPort} unavailable (${err.message})`));
    parts.push({ stop: () => control.close() });
    env.ROSA_COMFY_URL = comfyUrl;
    if (cfg.comfyWorkflow && fs.existsSync(cfg.comfyWorkflow)) env.ROSA_IMAGE_WORKFLOW = cfg.comfyWorkflow;
    else console.log(`  images: no saved workflow found at ${cfg.comfyWorkflow}; the built-in one will be used`);
    env.ROSA_CONTROL_URL = `http://127.0.0.1:${cfg.controlPort}`;
    env.ROSA_CONTROL_TOKEN = token;
    if (standby) {
      // after the chat model, so the chat model has the card first; in the background, so nothing waits for it
      step('images', 'waiting', 'after her chat model');
      modelReady.then(async () => {
        step('images', 'working', 'starting in the background','images: starting in the background ...');
        comfy.resume();
        const up = await waitForHealth(`${comfyUrl}/system_stats`, 240_000, 1000);
        step('images', up ? 'done' : 'failed', up ? 'on standby' : 'not answering yet',
          up ? 'images: ready, on standby (the image generator stays running; only the chat model steps aside while she draws)' : 'images: standby started; the image generator is not answering yet');
      });
    } else {
      step('images', 'done', 'starts when she draws', 'images: ready (the image generator starts when she draws something)');
    }
  } else if (cfg.comfyDir) {
    console.log(`  images: ComfyUI not found in ${cfg.comfyDir}; drawing is off`);
  }

  /* ---------- the app ---------- */

  step('app', 'working', 'starting', `app:   starting on :${cfg.appPort} ...`);
  // an update the app has staged is swapped in here, after the app has left; a new version that does not come up is taken out again
  let appHandle = null;
  const recent = []; // the app's last lines, kept so a failed update can say what the new version printed before it died
  const appLog = log('app');
  const updates = createUpdateWatcher({
    tail: () => recent.slice(),
    root, dataDir, log: (line) => log('update')('sup', line),
    isHealthy: () => Boolean(appHandle?.status().healthy),
    stopApp: () => appHandle?.restart()
  });
  appHandle = supervise({
    name: 'app', command: process.execPath, args: [path.join(root, 'server', 'index.js')], cwd: root, env,
    log: (tag, line) => {
      appLog(tag, line);
      if (tag === 'err' || tag === 'out') {
        recent.push(line);
        if (recent.length > 20) recent.shift();
      }
    },
    health: { url: appUrl, intervalMs: 20_000, failures: 3, graceMs: 30_000 },
    // if the app dies while a picture is being drawn, nobody is left to hand the card back, so do it here
    onStart: (child) => child.once('exit', () => gpuControl?.toChat().catch(() => {})),
    onExit: (code) => updates.onAppExit(code)
  });
  parts.push(appHandle, { stop: () => updates.stop() });
  updates.resume();

  // a model downloaded or chosen in Settings (rosia.local.json changes): what changed is started at once
  if (!noModel) {
    let queue = Promise.resolve();
    const onSettings = () => {
      queue = queue.then(async () => {
        const next = settings(home);
        if (next.unreadable) {
          console.log(`  [!] rosia.local.json changed but could not be read, so nothing was changed: ${next.unreadable}`);
          return;
        }
        if (launcherOwnsModel && chatKey(next) !== modelSlot.key) {
          console.log('  model: its settings changed; starting it with them');
          const old = modelSlot.handle;
          modelSlot.handle = null;
          if (old) {
            await old.pause();
            old.stop();
          }
          startChat(next).catch((err) => console.log(`  [x] model: ${err.message}`));
        }
        const memory = await startHelper('memory', next);
        const router = await startHelper('router', next);
        if (memory || router) {
          console.log('  app: restarting so it uses the models that just changed');
          appHandle.restart();
        }
      }).catch((err) => console.log(`  [!] after a settings change: ${err.message}`));
    };
    fs.watchFile(settingsFile, { interval: 2000 }, onSettings);
    parts.push({ stop: () => fs.unwatchFile(settingsFile, onSettings) });
  }

  const began = Date.now();
  const appUp = await waitForHealth(appUrl, 30_000, 250);
  step('app', appUp ? 'done' : 'failed', appUp ? '' : 'did not answer');
  if (appUp) {
    // the page is opened as soon as the app answers: it shows what is still loading, and lets her be talked to when she is ready
    if (process.platform === 'win32' && !process.argv.includes('--no-browser')) execFile('cmd', ['/c', 'start', '', `http://127.0.0.1:${cfg.appPort}`], () => {});
    modelReady.then((ok) => console.log(ok
      ? `\n  ready: http://127.0.0.1:${cfg.appPort}  (${Math.round((Date.now() - began) / 1000)}s)\n  (Ctrl+C stops everything; logs are in data/logs)\n`
      : `\n  the app is up at http://127.0.0.1:${cfg.appPort}, but her chat model is not running (see above); it starts by itself once it is set up\n  (Ctrl+C stops everything; logs are in data/logs)\n`));
  }

  const shutdown = () => {
    console.log('\n  stopping ...');
    for (const p of parts) p.stop();
    setTimeout(() => process.exit(0), 800);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
  watchParent(process.env.ROSIA_PARENT_PID, shutdown);
}

/**
 * Started by the desktop app, the launcher goes when the app goes, however it went (Quit, a crash, or ended from Task
 * Manager), and takes her server, her models and the picture drawer with it: nothing of hers is left running.
 */
export function watchParent(pid, onGone, { everyMs = 2000, alive = isRunning } = {}) {
  const id = Number(pid);
  if (!Number.isInteger(id) || id <= 0) return null;
  const timer = setInterval(() => {
    if (alive(id)) return;
    clearInterval(timer);
    console.log('[launcher] the Rosia app has closed, so everything of hers is stopped');
    onGone();
  }, everyMs);
  timer.unref?.();
  return timer;
}

function isRunning(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (err) {
    return err.code === 'EPERM'; // there, just not ours to signal
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) main();
