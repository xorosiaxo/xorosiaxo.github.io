import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { config } from './config.js';
import { readZip } from './zip.js';

/*
 * The models she runs on, for the Models section of Settings (owner at this computer only, see index.js):
 *
 *  - what this computer has: the graphics card and its memory, RAM, free disk;
 *  - what she is set to use (rosia.local.json in the home folder, which the launcher reads at start);
 *  - model files already on this computer, so the person can point her at what they have;
 *  - what to download for this computer, from the publishers' own pages, and the download itself: never without the
 *    person pressing the button, every file checked against the checksum its publisher lists, into <home>/models.
 *
 * A change takes effect the next time Rosia starts (the launcher starts the model).
 */

const GB = 1024 ** 3;
const HF = 'https://huggingface.co';
const CHAT_REPO = 'HauhauCS/Gemma-4-E4B-Uncensored-HauhauCS-Aggressive';
const CHAT_PREFIX = 'Gemma-4-E4B-Uncensored-HauhauCS-Aggressive';

const configFile = () => path.join(config.home, 'rosia.local.json');
export const modelsDir = () => path.join(config.home, 'models');

/* ---------- this computer ---------- */

function run(cmd, args, ms = 6000) {
  return new Promise((resolve) => {
    execFile(cmd, args, { timeout: ms, windowsHide: true }, (err, stdout) => resolve(err ? '' : String(stdout || '')));
  });
}

/** "NVIDIA GeForce RTX 3050 Laptop GPU, 4096 MiB" lines from nvidia-smi, as [{ name, vramGb }]. */
export function parseNvidia(text) {
  return String(text || '').split(/\r?\n/).map((line) => {
    const m = /^(.+?),\s*(\d+)\s*MiB/i.exec(line.trim());
    return m ? { name: m[1].trim(), vramGb: Math.round((Number(m[2]) / 1024) * 10) / 10 } : null;
  }).filter(Boolean);
}

let hwCache = null;
export async function hardware() {
  if (hwCache) return hwCache;
  let gpus = parseNvidia(await run('nvidia-smi', ['--query-gpu=name,memory.total', '--format=csv,noheader']));
  if (!gpus.length && process.platform === 'win32') {
    // other cards: Windows reports their memory capped at 4 GB, so the figure is only a floor
    const out = await run('powershell', ['-NoProfile', '-Command', 'Get-CimInstance Win32_VideoController | ForEach-Object { "$($_.Name)|$($_.AdapterRAM)" }']);
    gpus = out.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((l) => {
      const [name, ram] = l.split('|');
      return { name, vramGb: Math.round((Number(ram) / GB) * 10) / 10 || 0, approximate: true };
    }).filter((g) => !/basic display|remote/i.test(g.name));
  }
  const best = gpus.reduce((a, g) => (!a || g.vramGb > a.vramGb ? g : a), null);
  let freeGb = null;
  try {
    const st = fs.statfsSync(config.home);
    freeGb = Math.round(((st.bavail * st.bsize) / GB) * 10) / 10;
  } catch { /* unknown */ }
  hwCache = { gpu: best, ramGb: Math.round((os.totalmem() / GB) * 10) / 10, freeGb };
  return hwCache;
}

/* ---------- what to download, for this computer ---------- */

/** The chat model build that suits a card with `vramGb` of memory (all include vision through the same projector). */
export function chatBuild(vramGb) {
  const v = Number(vramGb) || 0;
  if (v >= 12) return { quant: 'Q8_K_P', sizeGb: 7.57, feel: 'the sharpest she gets' };
  if (v >= 8) return { quant: 'Q6_K_P', sizeGb: 5.82, feel: 'sharp and quick' };
  if (v >= 6) return { quant: 'Q4_K_M', sizeGb: 4.97, feel: 'quick, with room to spare' };
  return { quant: 'IQ4_XS', sizeGb: 4.72, feel: v ? 'the lightest build; part of it runs on the processor, so replies take a few seconds' : 'runs on the processor: replies take a while' };
}

/** Everything that can be downloaded for this computer, as items the page can show and ask about. */
export function recommendations(hw) {
  const vram = hw?.gpu?.vramGb || 0;
  const chat = chatBuild(vram);
  const small = vram > 0 && vram < 6;
  return [
    { key: 'runner', label: 'Model runner (llama.cpp, Vulkan build)', source: 'github', sizeGb: 0.04, setting: 'llamaServer', note: 'Runs the chat model on any graphics card.' },
    { key: 'chat', label: `Chat model: Gemma 4 E4B Uncensored, ${chat.quant}`, source: 'hf', repo: CHAT_REPO, file: `${CHAT_PREFIX}-${chat.quant}.gguf`, sizeGb: chat.sizeGb, setting: 'model', note: `Picked for ${vram ? `your ${vram} GB card` : 'a computer without a suitable graphics card'}: ${chat.feel}.` },
    { key: 'vision', label: 'Vision (so she can see pictures you send)', source: 'hf', repo: CHAT_REPO, file: `mmproj-${CHAT_PREFIX}-f16.gguf`, sizeGb: 0.92, setting: 'mmproj', note: 'Goes with the chat model.' },
    { key: 'memory', label: 'Memory model (EmbeddingGemma 300M)', source: 'hf', repo: 'ggml-org/embeddinggemma-300M-GGUF', file: 'embeddinggemma-300M-Q8_0.gguf', sizeGb: 0.31, setting: 'embedModel', note: 'Lets her find memories and clips by meaning. Runs on the processor.' },
    { key: 'router', label: 'Request model (Qwen3 0.6B)', source: 'hf', repo: 'Qwen/Qwen3-0.6B-GGUF', file: 'Qwen3-0.6B-Q8_0.gguf', sizeGb: 0.64, setting: 'routerModel', note: 'Optional. Helps work out the few requests she is unsure of (about 2 in 100 more understood). Uses about 1.1 GB of memory on the processor; without it she still understands requests by meaning.' },
    { key: 'picture', label: `Picture model (Z-Image Turbo, ${small ? 'Q3_K_M' : 'Q4_K_M'})`, source: 'hf', repo: 'unsloth/Z-Image-Turbo-GGUF', file: `z-image-turbo-${small ? 'Q3_K_M' : 'Q4_K_M'}.gguf`, sizeGb: small ? 2.51 : 3.59, comfy: 'unet', note: 'Draws her pictures, through ComfyUI.' },
    { key: 'encoder', label: 'Picture text encoder (Qwen3 4B, unrestricted)', source: 'hf', repo: 'mradermacher/Huihui-Qwen3-4B-Instruct-2507-abliterated-GGUF', file: 'Huihui-Qwen3-4B-Instruct-2507-abliterated.Q4_K_M.gguf', sizeGb: 2.33, comfy: 'text_encoders', note: 'Reads the picture prompt.' },
    { key: 'vae', label: 'Picture decoder (VAE)', source: 'hf', repo: 'Comfy-Org/Z-Image-Turbo', file: 'split_files/vae/ae.safetensors', sizeGb: 0.31, comfy: 'vae', note: 'Turns the drawing into an image.' },
    { key: 'lora', label: 'Picture style (Realistic Snapshot LoRA)', source: 'url', url: LORA.url, sha256: LORA.sha256, file: LORA.file, sizeGb: 0.16, comfy: 'loras', note: 'The look of her pictures: real-life snapshots.' },
    ...(comfyBuild(hw) ? [{ key: 'comfyui', label: `ComfyUI (${comfyBuild(hw)} build)`, source: 'comfy', sizeGb: 2, setting: 'comfyDir', note: 'What draws her pictures. About 2 GB to download and 6 GB on disk; your picture workflow comes with it.' }] : [])
  ];
}

// the style her pictures are drawn in; its creator allows sharing it. Hosted with the website's releases, and checked against
// the SHA-256 its creator published on Civitai
const LORA = {
  file: 'RealisticSnapshot-Zimage-Turbov5.safetensors',
  url: 'https://github.com/xorosiaxo/xorosiaxo.github.io/releases/download/models/RealisticSnapshot-Zimage-Turbov5.safetensors',
  sha256: '182d7f92475b8d7f792203127738d31270403e86e007fdc7792d324a3406e556'
};

/** Which ComfyUI portable build fits this graphics card ('nvidia' | 'amd' | 'intel'), or '' when none does. */
export function comfyBuild(hw) {
  const name = String(hw?.gpu?.name || '');
  if (/nvidia|geforce|rtx|gtx|quadro/i.test(name)) return 'nvidia';
  if (/amd|radeon/i.test(name)) return 'amd';
  if (/intel|arc/i.test(name)) return 'intel';
  return '';
}

/* ---------- what she is set to use, and what is on this computer ---------- */

export function readSettings(file = configFile()) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return {}; }
}

/** The paths she will start with, worked out the way the launcher does. */
export function resolved(local = readSettings()) {
  const llamaDir = local.llamaDir || 'C:\\AI\\llama-b11057-bin-win-cuda-13.4-x64';
  const model = local.model || path.join(local.modelDir || 'C:\\AI\\models\\gemma4-e4b-uncensored', 'model.gguf');
  const exists = (p) => Boolean(p) && fs.existsSync(p);
  const comfyDir = local.comfyDir || '';
  const comfyModels = local.comfyModels || (comfyDir ? path.join(comfyDir, 'models') : '');
  const slot = (p) => ({ path: p || '', found: exists(p) });
  return {
    runner: slot(local.llamaServer || path.join(llamaDir, 'llama-server.exe')),
    chat: slot(model),
    vision: 'mmproj' in local && !local.mmproj ? { path: '', found: false, off: true } : slot(local.mmproj || path.join(path.dirname(model), 'mmproj.gguf')),
    memory: slot(local.embedModel),
    router: slot(local.routerModel),
    comfy: { path: comfyDir, found: exists(path.join(comfyDir || '?', 'main.py')) },
    comfyModels: slot(comfyModels)
  };
}

const KIND = (name) => {
  const n = name.toLowerCase();
  if (n === 'llama-server.exe') return 'runner';
  if (!n.endsWith('.gguf')) return '';
  if (n.includes('mmproj')) return 'vision';
  if (n.includes('embed')) return 'memory';
  if (/qwen3-(?:0\.6|1\.7)b/.test(n)) return 'router';
  if (n.includes('z-image') || n.includes('z_image')) return 'picture';
  return 'chat';
};

/** Folders where people usually keep models, and this app's own. */
export function searchFolders(env = process.env) {
  const homeDir = os.homedir();
  return [
    modelsDir(), 'C:\\AI', 'D:\\AI', path.join(homeDir, 'models'), path.join(homeDir, '.lmstudio', 'models'),
    path.join(homeDir, '.cache', 'lm-studio', 'models'), path.join(homeDir, 'Downloads'), path.join(homeDir, 'llama.cpp'),
    env.LOCALAPPDATA ? path.join(env.LOCALAPPDATA, 'llama.cpp') : ''
  ].filter(Boolean);
}

/** Model files already on this computer, by kind, without looking more than a few folders deep. */
export function scan(folders = searchFolders(), depth = 4) {
  const found = { runner: [], chat: [], vision: [], memory: [], picture: [] };
  const seen = new Set();
  const walk = (dir, left) => {
    if (left < 0 || seen.has(dir)) return;
    seen.add(dir);
    let entries = [];
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        if (!/^(\.|node_modules$|\$recycle)/i.test(e.name)) walk(full, left - 1);
      } else {
        const kind = KIND(e.name);
        if (kind && found[kind].length < 30) {
          let sizeGb = 0;
          try { sizeGb = Math.round((fs.statSync(full).size / GB) * 100) / 100; } catch { /* gone */ }
          found[kind].push({ path: full, name: e.name, sizeGb });
        }
      }
    }
  };
  for (const f of folders) walk(f, depth);
  return found;
}

/** The usual folders, plus where ComfyUI keeps its models (picture models live there). */
export function allSearchFolders() {
  const r = resolved();
  return [...searchFolders(), ...(r.comfyModels.found ? [r.comfyModels.path] : [])];
}

/** ComfyUI folders on this computer (a folder with main.py and a models folder). */
export function findComfy(roots = [os.homedir(), 'C:\\', 'D:\\', config.home], depth = 3) {
  const out = new Set();
  const look = (dir, left) => {
    if (left < 0) return;
    let entries = [];
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      if (!e.isDirectory() || /^(\.|node_modules$|\$recycle|windows$|program files|programdata$|appdata$)/i.test(e.name)) continue;
      const full = path.join(dir, e.name);
      // a folder whose name mentions ComfyUI and holds its main.py; such folders are also looked into further
      if (/comfy/i.test(e.name) && fs.existsSync(path.join(full, 'main.py'))) out.add(full);
      if (/comfy/i.test(e.name) || left > 1) look(full, left - 1);
    }
  };
  for (const r of roots) look(r, depth);
  return [...out].slice(0, 10);
}

/* ---------- changing what she uses ---------- */

const SETTABLE = {
  llamaServer: (p) => /llama-server(\.exe)?$/i.test(p),
  model: (p) => /\.gguf$/i.test(p),
  mmproj: (p) => p === '' || /\.gguf$/i.test(p),
  embedModel: (p) => p === '' || /\.gguf$/i.test(p),
  routerModel: (p) => p === '' || /\.gguf$/i.test(p),
  comfyDir: (p) => fs.existsSync(path.join(p, 'main.py')),
  comfyPython: (p) => /python(\.exe)?$/i.test(p),
  comfyModels: (p) => fs.existsSync(p) && fs.statSync(p).isDirectory()
};

/** Points one setting at a file or folder (which must exist), keeping everything else in rosia.local.json as it was. */
export function useSetting(key, value, file = configFile()) {
  if (!Object.hasOwn(SETTABLE, key)) throw Object.assign(new Error('That is not a model setting.'), { status: 400 });
  const p = String(value ?? '').trim();
  if (p && !fs.existsSync(p)) throw Object.assign(new Error('That file or folder is not on this computer.'), { status: 400 });
  if (!SETTABLE[key](p)) throw Object.assign(new Error('That does not look like the right kind of file.'), { status: 400 });
  const local = readSettings(file);
  local[key] = p;
  if (key === 'embedModel' && p && !local.embedStyle) local.embedStyle = /embeddinggemma/i.test(p) ? 'embeddinggemma' : 'none';
  if (key === 'comfyDir' && !local.comfyModels) local.comfyModels = path.join(p, 'models');
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, `${JSON.stringify(local, null, 2)}\n`, 'utf8');
  fs.renameSync(tmp, file);
  return local;
}

/* ---------- downloads ---------- */

const jobs = new Map(); // key -> { key, label, received, total, state, error, path }
export const downloadJobs = () => [...jobs.values()].map(({ abort, ...j }) => j);

/** The SHA-256 Hugging Face lists for a file (its LFS object id), or ''. */
export async function hfChecksum(repo, file, fetchFn = fetch) {
  const dir = path.posix.dirname(file);
  const res = await fetchFn(`${HF}/api/models/${repo}/tree/main${dir === '.' ? '' : `/${dir}`}`, { signal: AbortSignal.timeout(20000) });
  if (!res.ok) return '';
  const list = await res.json();
  const entry = Array.isArray(list) ? list.find((f) => f.path === file) : null;
  return /^[a-f0-9]{64}$/.test(entry?.lfs?.oid || '') ? entry.lfs.oid : '';
}

/** A file from a GitHub release: { url, name, sha256, size } of the newest release that has an asset matching `pattern`. */
export async function githubAsset(repo, pattern, fetchFn = fetch) {
  const res = await fetchFn(`https://api.github.com/repos/${repo}/releases?per_page=6`, { headers: { accept: 'application/vnd.github+json', 'user-agent': 'rosia-app' }, signal: AbortSignal.timeout(20000) });
  if (!res.ok) throw new Error(`${repo}'s release page answered ${res.status}.`);
  for (const r of await res.json()) {
    const a = (r.assets || []).find((x) => pattern.test(x.name));
    if (a) return { url: a.browser_download_url, name: a.name, sha256: String(a.digest || '').replace(/^sha256:/, ''), size: a.size };
  }
  throw new Error(`No download was found in ${repo}'s recent releases.`);
}

function runFor(cmd, args, { cwd, ms }) {
  return new Promise((resolve, reject) => {
    execFile(cmd, args, { cwd, timeout: ms, windowsHide: true, maxBuffer: 64 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) reject(new Error(String(stderr || err.message).trim().split(/\r?\n/).slice(-2).join(' ').slice(0, 200)));
      else resolve(String(stdout || ''));
    });
  });
}

/**
 * Installs ComfyUI for this computer: the official portable build for its graphics card (checked against the checksum
 * GitHub lists), unpacked with 7-Zip's own extractor (checked the same way), then the GGUF node the workflow needs with its
 * Python packages, and the picture workflow. Everything goes in the home folder; nothing outside it is touched.
 */
async function installComfy(job, hw, fetchFn) {
  const build = comfyBuild(hw);
  if (!build) throw new Error('ComfyUI has no build for this graphics card.');
  const home = config.home;
  const tools = path.join(home, 'tools');

  job.phase = 'Getting the unpacker (7-Zip)…';
  const sevenZ = await githubAsset('ip7z/7zip', /^7zr\.exe$/, fetchFn);
  const extractor = path.join(tools, '7zr.exe');
  const got7 = await fetchToFile(sevenZ.url, extractor, { ...job, received: 0, abort: job.abort }, fetchFn);
  if (sevenZ.sha256 && got7.sha256 !== sevenZ.sha256) throw new Error('7-Zip did not match its checksum, so it was deleted.');
  fs.renameSync(got7.part, extractor);

  job.phase = 'Downloading ComfyUI…';
  const comfy = await githubAsset('Comfy-Org/ComfyUI', new RegExp(`^ComfyUI_windows_portable_${build}\\.7z$`), fetchFn);
  job.total = comfy.size || job.total;
  const archive = path.join(home, comfy.name);
  const got = await fetchToFile(comfy.url, archive, job, fetchFn);
  if (!comfy.sha256 || got.sha256 !== comfy.sha256) {
    fs.rmSync(got.part, { force: true });
    throw new Error('ComfyUI did not match its checksum, so it was deleted.');
  }
  fs.renameSync(got.part, archive);

  job.phase = 'Unpacking ComfyUI (a few minutes)…';
  await runFor(extractor, ['x', archive, `-o${home}`, '-y'], { cwd: home, ms: 30 * 60_000 });
  fs.rmSync(archive, { force: true });
  const portable = fs.readdirSync(home, { withFileTypes: true })
    .filter((e) => e.isDirectory() && /^ComfyUI_windows_portable/i.test(e.name))
    .map((e) => path.join(home, e.name))
    .find((d) => fs.existsSync(path.join(d, 'ComfyUI', 'main.py')));
  if (!portable) throw new Error('ComfyUI was unpacked but its folder was not found.');
  const comfyDir = path.join(portable, 'ComfyUI');
  const python = path.join(portable, 'python_embeded', 'python.exe');

  job.phase = 'Adding the GGUF node…';
  const nodeDir = path.join(comfyDir, 'custom_nodes', 'ComfyUI-GGUF');
  const zipRes = await fetchFn('https://github.com/city96/ComfyUI-GGUF/archive/refs/heads/main.zip', { redirect: 'follow', signal: job.abort.signal, headers: { 'user-agent': 'rosia-app' } });
  if (!zipRes.ok) throw new Error(`The GGUF node's download answered ${zipRes.status}.`);
  for (const e of readZip(Buffer.from(await zipRes.arrayBuffer()))) {
    const rel = e.name.split('/').slice(1).join('/'); // inside "ComfyUI-GGUF-main/"
    if (!rel || rel.endsWith('/')) continue;
    const dest = path.join(nodeDir, ...rel.split('/'));
    if (!dest.startsWith(nodeDir)) continue;
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, e.data);
  }

  job.phase = 'Installing the GGUF node\'s Python packages…';
  if (fs.existsSync(python) && fs.existsSync(path.join(nodeDir, 'requirements.txt'))) {
    await runFor(python, ['-s', '-m', 'pip', 'install', '--no-warn-script-location', '-r', path.join(nodeDir, 'requirements.txt')], { cwd: portable, ms: 20 * 60_000 });
  }

  job.phase = 'Adding her picture workflow…';
  const workflowDir = path.join(comfyDir, 'user', 'default', 'workflows');
  fs.mkdirSync(workflowDir, { recursive: true });
  fs.copyFileSync(path.join(config.root, 'server', 'comfy', 'rosia-workflow.json'), path.join(workflowDir, 'rosia.json'));

  useSetting('comfyDir', comfyDir);
  useSetting('comfyModels', path.join(comfyDir, 'models'));
  if (fs.existsSync(python)) useSetting('comfyPython', python);
  job.phase = '';
  return comfyDir;
}

/** The newest llama.cpp Windows Vulkan build: { url, name, sha256 }. */
export async function runnerAsset(fetchFn = fetch) {
  const res = await fetchFn('https://api.github.com/repos/ggml-org/llama.cpp/releases?per_page=8', { headers: { accept: 'application/vnd.github+json', 'user-agent': 'rosia-app' }, signal: AbortSignal.timeout(20000) });
  if (!res.ok) throw new Error(`llama.cpp's release page answered ${res.status}.`);
  for (const r of await res.json()) {
    const a = (r.assets || []).find((x) => /^llama-b\d+-bin-win-vulkan-x64\.zip$/.test(x.name));
    if (a) return { url: a.browser_download_url, name: a.name, sha256: String(a.digest || '').replace(/^sha256:/, ''), size: a.size };
  }
  throw new Error('No Windows build of llama.cpp was found in its recent releases.');
}

async function fetchToFile(url, dest, job, fetchFn) {
  const res = await fetchFn(url, { redirect: 'follow', signal: job.abort.signal, headers: { 'user-agent': 'rosia-app' } });
  if (!res.ok || !res.body) throw new Error(`The download answered ${res.status}.`);
  job.total = Number(res.headers.get('content-length')) || job.total;
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const part = `${dest}.part`;
  const out = fs.createWriteStream(part);
  const hash = crypto.createHash('sha256');
  try {
    for await (const chunk of res.body) {
      hash.update(chunk);
      job.received += chunk.length;
      if (!out.write(chunk)) await new Promise((r) => out.once('drain', r));
    }
    await new Promise((r, j) => out.end((e) => (e ? j(e) : r())));
  } catch (err) {
    out.destroy();
    fs.rmSync(part, { force: true });
    throw err;
  }
  return { part, sha256: hash.digest('hex') };
}

/**
 * Downloads one recommended item (the person pressed its button). Hugging Face files are checked against the checksum
 * Hugging Face lists; llama.cpp against the one GitHub lists. A file that does not match is deleted, never used.
 */
export async function startDownload(key, { hw, fetchFn = fetch, comfyModels } = {}) {
  const item = recommendations(hw).find((r) => r.key === key);
  if (!item) throw Object.assign(new Error('Nothing to download by that name.'), { status: 400 });
  const running = jobs.get(key);
  if (running && running.state === 'downloading') return downloadJobs();
  if (item.comfy && !comfyModels) throw Object.assign(new Error('Set your ComfyUI folder first: picture models go into it.'), { status: 409 });

  const job = { key, label: item.label, received: 0, total: Math.round(item.sizeGb * GB), state: 'downloading', error: '', path: '', abort: new AbortController() };
  jobs.set(key, job);
  (async () => {
    try {
      if (item.source === 'comfy') {
        job.path = await installComfy(job, hw, fetchFn);
      } else if (item.source === 'url') {
        const dest = path.join(comfyModels, item.comfy, item.file);
        const { part, sha256 } = await fetchToFile(item.url, dest, job, fetchFn);
        if (sha256 !== item.sha256) {
          fs.rmSync(part, { force: true });
          throw new Error('The download did not match its checksum, so it was deleted.');
        }
        fs.renameSync(part, dest);
        job.path = dest;
      } else if (item.source === 'github') {
        const asset = await runnerAsset(fetchFn);
        const folder = path.join(modelsDir(), asset.name.replace(/\.zip$/, ''));
        const { part, sha256 } = await fetchToFile(asset.url, path.join(modelsDir(), asset.name), job, fetchFn);
        if (asset.sha256 && sha256 !== asset.sha256) throw new Error('The download did not match its checksum, so it was deleted.');
        const entries = readZip(fs.readFileSync(part), { maxEntryBytes: 400 * 1024 * 1024, maxTotalBytes: 900 * 1024 * 1024 });
        for (const e of entries) {
          const dest = path.join(folder, ...e.name.split('/'));
          if (!dest.startsWith(folder)) continue;
          fs.mkdirSync(path.dirname(dest), { recursive: true });
          fs.writeFileSync(dest, e.data);
        }
        fs.rmSync(part, { force: true });
        const exe = path.join(folder, 'llama-server.exe');
        if (!fs.existsSync(exe)) throw new Error('llama-server.exe was not in the download.');
        job.path = exe;
      } else {
        const expected = await hfChecksum(item.repo, item.file, fetchFn);
        if (!expected) throw new Error('Hugging Face did not list a checksum for this file, so it was not downloaded.');
        const base = item.comfy ? path.join(comfyModels, item.comfy) : modelsDir();
        const dest = path.join(base, path.basename(item.file));
        const { part, sha256 } = await fetchToFile(`${HF}/${item.repo}/resolve/main/${item.file}`, dest, job, fetchFn);
        if (sha256 !== expected) {
          fs.rmSync(part, { force: true });
          throw new Error('The download did not match its checksum, so it was deleted.');
        }
        fs.renameSync(part, dest);
        job.path = dest;
      }
      if (item.setting && item.source !== 'comfy') useSetting(item.setting, job.path);
      job.state = 'done';
    } catch (err) {
      job.state = job.abort.signal.aborted ? 'cancelled' : 'failed';
      job.error = job.abort.signal.aborted ? '' : String(err?.message || err).slice(0, 200);
    }
  })();
  return downloadJobs();
}

export function cancelDownload(key) {
  jobs.get(key)?.abort.abort();
  return downloadJobs();
}

/** For tests. */
export function resetModels() {
  hwCache = null;
  jobs.clear();
}
