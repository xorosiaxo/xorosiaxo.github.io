/*
 * "pause", "skip this", "turn it down", "play something chill": requests that leave no doubt. A small model left to
 * choose will sometimes just say "paused it for you" without touching the player, so for these the tool is run for her
 * first (see preflight.js) and she only has to say it in her own voice.
 *
 * Deliberately narrow. "play" means many things in a chat like hers ("play with me", "play nice", "play a game"), and
 * "put on" is usually about clothes, so only wording that is plainly about music is taken; everything else is left to
 * her own judgment. Anything said to the player ("skip", "pause") only counts while this person has a player open.
 */

import { wantedWords } from './library.js';

// a few words people put in front of a request
const LEAD = '(?:(?:hey|oi|ok|okay|please|pls|rosia|babe|baby|now|and|then|just|go on|can you|could you|would you|will you|can u|could u)[\\s,]+)*';
const TAIL = '[\\s.!?]*(?:please|pls|for me|now|babe|baby)?[\\s.!?]*$';
const SONG = '(?:the |this |that |my )?(?:music|song|track|tune|player|playlist)';
const IT = `(?:it|this|that|${SONG})`;

const NEGATED = /\b(?:don'?t|dont|do not|never|no need to|not yet)\b/i;

const STOP = new RegExp(
  `\\b(?:stop|kill|cut|end)\\s+(?:${SONG}|playing)\\b|\\b(?:turn|switch|shut)\\s+${IT}\\s+off\\b|\\b(?:turn|switch|shut)\\s+off\\s+${SONG}\\b|\\bmusic off\\b|\\bno more music\\b|\\bclose\\s+(?:the\\s+)?player\\b`, 'i');
const NOW = new RegExp(
  `\\bwhat(?:'?s| is)?\\s+(?:song|track|tune)\\s+is\\s+(?:this|that|playing|on)\\b|\\bwhat(?:'?s| is)\\s+(?:this|that|the)\\s+(?:song|track|tune)\\b|` +
  `\\bwhat(?:'?s| is)\\s+(?:playing|on)${TAIL}|\\bwho(?:'?s| is)?\\s+(?:this|that|it)\\s+by\\b|\\bwho\\s+(?:sings|sang|made|is singing)\\s+(?:this|that|it)\\b|` +
  '\\bname of (?:this|that|the) (?:song|track|tune)\\b', 'i');
// "what's this?" on its own: only about the music while something is actually playing
const WHATS_THIS = new RegExp(`^\\s*${LEAD}(?:wait\\s+)?what(?:'?s| is)\\s+(?:this|that)(?:\\s+one)?${TAIL}`, 'i');
const VOLUME_TO = /\bvolume\b[^.?!\d]{0,12}(\d{1,3})\b|\b(\d{1,3})\s*(?:%|percent)\b/i;
const MUTE = new RegExp(`^\\s*${LEAD}mute(?:\\s+${IT})?${TAIL}`, 'i');
const LOUDER = new RegExp(
  `\\b(?:turn|crank|put|bring)\\s+${IT}\\s+(?:(?:way|right|a bit|a little|back)\\s+)?up\\b|\\b(?:turn|crank)\\s+up\\s+(?:the\\s+)?(?:music|volume|song|sound)\\b|` +
  '\\blouder\\b|\\bvolume up\\b|\\btoo quiet\\b|\\bcan(?:\'?t| ?not) hear (?:it|the (?:music|song))\\b', 'i');
const QUIETER = new RegExp(
  `\\b(?:turn|put|bring)\\s+${IT}\\s+(?:(?:way|right|a bit|a little|back)\\s+)?down\\b|\\b(?:turn|bring)\\s+down\\s+(?:the\\s+)?(?:music|volume|song|sound)\\b|` +
  '\\bquieter\\b|\\bvolume down\\b|\\btoo loud\\b|\\blower the (?:music|volume|sound)\\b', 'i');
const RESTART = new RegExp(
  `^\\s*${LEAD}(?:restart|replay)(?:\\s+${IT})?${TAIL}|\\b(?:restart|replay)\\s+${SONG}\\b|\\bplay\\s+(?:it|that|this|that one|${SONG})\\s+(?:again|from the (?:start|beginning|top))\\b|` +
  `\\bstart\\s+${IT}\\s+(?:again|over)\\b|\\b(?:song|track|it)\\s+from the (?:start|beginning|top)\\b`, 'i');
const PREVIOUS = new RegExp(
  `^\\s*${LEAD}previous(?:\\s+(?:song|track|tune|one))?${TAIL}|\\b(?:play|go back to|back to|put on)\\s+(?:the\\s+)?(?:previous|last)\\s+(?:song|track|tune|one)\\b|` +
  '\\bgo back\\s+(?:a|one)\\s+(?:song|track)\\b', 'i');
const SKIP = new RegExp(
  `^\\s*${LEAD}(?:skip|next)(?:\\s+(?:${IT}|song|track|tune|one))?${TAIL}|\\b(?:skip|change)\\s+(?:${SONG}|this one|that one)\\b|\\bskip\\s+(?:it|this|that)\\b|` +
  '\\bnext\\s+(?:song|track|tune)\\b|\\bplay\\s+(?:the\\s+)?next\\b|\\b(?:a\\s+)?different\\s+(?:song|track|tune)\\b', 'i');
const PAUSE = new RegExp(`^\\s*${LEAD}pause(?:\\s+${IT})?(?:\\s+(?:a|for a)\\s+(?:sec|second|minute|moment|bit))?${TAIL}|\\bpause\\s+${SONG}\\b`, 'i');
const RESUME = new RegExp(
  `^\\s*${LEAD}(?:resume|unpause|un-pause)\\b|^\\s*${LEAD}(?:play|continue|carry on with|start|keep playing|back on with)\\s+${IT}(?:\\s+again)?${TAIL}|\\b${SONG}\\s+back on\\b`, 'i');
const BARE_PLAY = new RegExp(`^\\s*${LEAD}play${TAIL}`, 'i');

// "play ..." / "put on ...": what follows decides whether it is music
const PLAY = new RegExp(`^\\s*${LEAD}(?:play|put on|stick on|throw on|queue up)\\b\\s*([\\s\\S]*)$`, 'i');
const PUT_ON = new RegExp(`^\\s*${LEAD}(?:put|stick|throw) on\\b`, 'i');
const MUSIC_WORD = /\b(?:music|songs?|tunes?|tracks?|playlist|album|beats|lo-?fi|jazz|rock|pop|rap|hip.?hop|techno|classical|metal|reggae|blues)\b/i;
// "play" that is not about music
const NOT_MUSIC = /^(?:with|along|around|about|fair|nice|dumb|dirty|rough|coy|innocent|pretend|house|doctor|chess|cards|football|tennis|golf|truth or dare|hard to get|it (?:cool|safe|by ear|straight)|(?:a |the |some |video |board |card )*(?:games?|role|part|prank|trick|victim|fool|field|guitar|piano|drums|violin|bass|instrument))\b|\b(?:games?|videos?|vids?|gifs?|clips?|movie|film|with (?:me|you|u|yourself|myself|my|your|it|them|her|him|us))\b/i;
// "i want to hear some jazz", "got any music?", "some music please"
const WANTS_MUSIC = /\b(?:play|hear|listen to|want|need|fancy|in the mood for|how about|got any|have any|give me|gimme|let'?s have)\b[^.?!]{0,40}\b(?:music|songs?|tunes?|playlist)\b|^\s*(?:some\s+)?music(?:\s+please)?[\s.!?]*$/i;
// talk about music rather than a request for it
const ABOUT_MUSIC = /\b(?:what|which|who|why|how|do you|did you|have you|are you|were you|favou?rite|kind of|type of|taste)\b/i;

const control = (action, extra = {}) => ({ name: 'music_control', args: { action, ...extra } });

/** The part of a request that says what to play: "play some taylor swift please" gives "some taylor swift". */
export function playQuery(rest) {
  return String(rest || '')
    .replace(/[\s.!?]+$/g, '')
    .replace(/\s+(?:please|pls|for me|for us|now|babe|baby)$/gi, '')
    .replace(/^(?:me|us)\s+/i, '')
    .replace(/^some\s+/i, '')
    .replace(/[\s.!?]+$/g, '')
    .trim()
    .slice(0, 200);
}

/**
 * Which music tool a message plainly calls for, as { name, args }, or null. `state` is this person's player:
 * 'playing', 'paused', or '' when they have none. Pure: easy to test.
 */
export function musicIntent(text, { state = '' } = {}) {
  const t = String(text || '').trim();
  if (!t || NEGATED.test(t)) return null; // "don't stop the music" is left to her
  const words = t.split(/\s+/).length;

  if (state && words <= 12) {
    if (STOP.test(t)) return control('stop');
    if (NOW.test(t) || (state === 'playing' && words <= 6 && WHATS_THIS.test(t))) return control('now_playing');
    if (MUTE.test(t)) return control('volume', { volume: 0 });
    const to = /\bvolume\b/i.test(t) || /%|percent/i.test(t) ? VOLUME_TO.exec(t) : null;
    if (to) return control('volume', { volume: Math.min(100, Number(to[1] ?? to[2])) });
    if (LOUDER.test(t)) return control('louder');
    if (QUIETER.test(t)) return control('quieter');
    if (RESTART.test(t)) return control('restart');
    if (PREVIOUS.test(t)) return control('previous');
    // in a few words, with music on, the bare word is the request: "nah skip", "ok pause it"
    if (SKIP.test(t) || (words <= 6 && /\bskip\b/i.test(t))) return control('skip');
    if (PAUSE.test(t) || (words <= 6 && /\bpause\b/i.test(t))) return control('pause');
    if (RESUME.test(t) || (state === 'paused' && BARE_PLAY.test(t))) return control('resume');
  }

  if (words > 20) return null;
  const play = PLAY.exec(t);
  if (play) {
    const rest = play[1].trim();
    if (!rest) return null; // a bare "play" with nothing paused says too little
    if (NOT_MUSIC.test(rest)) return null;
    if (PUT_ON.test(t) && !MUSIC_WORD.test(rest)) return null; // "put on something sexy" is about clothes
    return { name: 'play_music', args: { query: playQuery(rest) } };
  }
  // (only the words that say what to play are passed on: "i want to hear some jazz" asks for "jazz")
  if (WANTS_MUSIC.test(t) && !ABOUT_MUSIC.test(t)) return { name: 'play_music', args: { query: wantedWords(t).join(' ') } };
  return null;
}

/*
 * She says she did it ("paused.", "turned it down for you") without touching the player. When what they wrote asked for
 * exactly that, it is done for her, so what she said is true. Each row: the action, how she claims it, and the word in
 * their message that shows they asked.
 */
const CLAIMS = [
  ['pause', /\bpaus(?:ed|ing)\b/i, /\bpause\b/i],
  ['skip', /\bskipp(?:ed|ing)\b|\bnext (?:one|song|track) (?:it is|coming|then)\b/i, /\b(?:skip|next)\b/i],
  ['restart', /\brestart(?:ed|ing)\b|\b(?:from|back to) the (?:top|start|beginning)\b/i, /\b(?:restart|again|replay|start over)\b/i],
  ['quieter', /\b(?:turn(?:ed|ing)|brought|taken) (?:it |that |the music |the volume )?(?:right |a bit |way )?down\b|\bquieter now\b|\blower(?:ed|ing) (?:it|the)\b/i, /\b(?:down|quieter|lower|loud)\b/i],
  ['louder', /\b(?:turn(?:ed|ing)|crank(?:ed|ing)) (?:it |that |the music |the volume )?(?:right |a bit |way )?up\b|\blouder now\b/i, /\b(?:up|louder|quiet)\b/i],
  ['stop', /\b(?:turned|switched) (?:it |the music )?off\b|\bstopped (?:it|the music)\b|\bmusic'?s off\b/i, /\b(?:stop|off)\b/i],
  ['resume', /\b(?:resum(?:ed|ing)|unpaus(?:ed|ing))\b|\b(?:it'?s|music'?s) back on\b/i, /\b(?:resume|unpause|continue|back on|play)\b/i]
];

/** The player action her words claim and their words asked for, as { name, args }, or null. Only while a player is open. */
export function claimedMusic(raw, userText, { state = '' } = {}) {
  const said = String(raw || '');
  const user = String(userText || '');
  if (!state || NEGATED.test(user) || user.split(/\s+/).length > 14) return null;
  for (const [action, claim, ask] of CLAIMS) {
    if (claim.test(said) && ask.test(user)) return control(action);
  }
  return null;
}
