import { mountDiscord } from './discord.js';

/* Settings: the controls that used to be scattered, in one view. Most are wired where they always were (voice.js,
   panel.js); this file wires the rest and shows the owner's sections to the owner. */

const on = (key) => localStorage.getItem(key) !== '0';
const set = (key, value) => (value ? localStorage.removeItem(key) : localStorage.setItem(key, '0'));

function updateText(u) {
  if (!u.enabled) return u.reason || 'Updates are switched off.';
  if (u.failure) {
    const again = u.failure.autoPaused
      ? 'Automatic updates for this version are paused. Press Install now, or wait for the next release.'
      : 'It will be tried again by itself.';
    return `Version ${u.failure.version} did not start on this computer, so the previous version was put back. ${u.failure.reason || ''} ${again}`.replace(/\s+/g, ' ').trim();
  }
  if (u.stage === 'downloading') return `Downloading version ${u.latest}.`;
  if (u.ready) return `Version ${u.latest} is ready to install.`;
  if (u.available && u.latest !== u.current) return `Version ${u.latest} is available${u.required ? ' and is needed to carry on' : ''}.`;
  return `You're on the latest version, ${u.current}.`;
}

/** One sentence for the state of the link. */
function shareText(s) {
  const t = s.tunnel || {};
  if (t.starting) return 'Making the link…';
  if (t.running) {
    return s.access === 'open'
      ? 'Sharing is on. Anyone with this link can talk to her on this computer, each in their own private space.'
      : 'Sharing is on. People who open this link need a code from you (Use on my phone), and then see your chats.';
  }
  return t.error || 'Sharing is off. Nobody outside this computer can reach her.';
}

function friendsText(f = {}) {
  if (!f.count) return 'Nobody has used a link yet.';
  const people = f.count === 1 ? '1 friend has' : `${f.count} friends have`;
  return `${people} their own space here; ${f.today || 0} visited in the last day.`;
}

export { updateText, shareText, friendsText };

export function createSettings({ host, me, panel, doc = document }) {
  const $ = (id) => doc.getElementById(id);

  const texts = $('setTexts');
  const nudge = $('setNudge');
  texts.checked = on('rosia.texts');
  nudge.checked = on('rosia.nudge');
  texts.addEventListener('change', () => set('rosia.texts', texts.checked));
  nudge.addEventListener('change', () => set('rosia.nudge', nudge.checked));

  $('aboutVersion').textContent = `Rosia ${me.version}`;

  async function loadUpdates() {
    const state = $('updState');
    try {
      const u = await fetch('/api/update').then((r) => r.json());
      state.textContent = updateText(u);
      $('updNotes').hidden = !u.notes || u.latest === u.current;
      $('updNotes').textContent = u.notes || '';
      $('updLog').hidden = !u.failure?.log?.length;
      $('updLogText').textContent = (u.failure?.log || []).join('\n');
      $('updInstall').hidden = !(u.ready || u.failure || (u.available && u.latest !== u.current));
    } catch {
      state.textContent = 'The update state could not be read.';
    }
  }

  /* ---------- share with friends (owner only) ---------- */

  function showShare(s) {
    $('shareOpen').checked = s.access === 'open';
    $('shareInvite').checked = s.access !== 'open';
    $('shareState').textContent = shareText(s);
    const on = Boolean(s.tunnel?.running);
    $('shareLinkRow').hidden = !on;
    $('shareUrl').value = on ? s.tunnel.url : '';
    $('shareStart').hidden = on;
    $('shareStop').hidden = !on;
    $('shareFriends').textContent = friendsText(s.friends);
  }
  const share = async (path, body) => {
    const res = await fetch(path, body ? { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : undefined);
    if (!res.ok) throw new Error('The sharing settings could not be changed.');
    return res.json();
  };
  async function loadShare() {
    try { showShare(await share('/api/share')); } catch { $('shareState').textContent = 'The sharing state could not be read.'; }
  }

  if (me.owner) {
    $('setShare').hidden = false;
    for (const id of ['shareOpen', 'shareInvite']) {
      $(id).addEventListener('change', async (e) => {
        if (!e.target.checked) return;
        try { showShare(await share('/api/share/access', { mode: e.target.value })); } catch (err) { $('shareState').textContent = err.message; }
      });
    }
    $('shareStart').addEventListener('click', async () => {
      $('shareStart').disabled = true;
      $('shareState').textContent = 'Making the link…';
      try { showShare(await share('/api/share/tunnel', { on: true })); } catch (err) { $('shareState').textContent = err.message; }
      $('shareStart').disabled = false;
    });
    $('shareStop').addEventListener('click', async () => {
      try { showShare(await share('/api/share/tunnel', { on: false })); } catch (err) { $('shareState').textContent = err.message; }
    });
    $('shareCopy').addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText($('shareUrl').value);
      } catch {
        $('shareUrl').select();
        doc.execCommand('copy');
      }
      $('shareCopy').textContent = 'Copied';
      setTimeout(() => { $('shareCopy').textContent = 'Copy'; }, 1400);
    });
  }

  let discord = null;
  if (me.local) $('setDiscord').hidden = false;

  if (me.owner) {
    $('setUpdates').hidden = false;
    $('setDiagnostics').hidden = false;
    $('updCheck').addEventListener('click', async () => {
      $('updState').textContent = 'Checking…';
      await fetch('/api/update/check', { method: 'POST' }).catch(() => {});
      loadUpdates();
    });
    $('updInstall').addEventListener('click', async () => {
      $('updState').textContent = 'Installing. The app will restart in a moment.';
      await fetch('/api/update/install', { method: 'POST' }).catch(() => {});
    });
  }

  return {
    load() {
      panel.loadDevices();
      if (me.local) {
        if (discord) discord.refresh();
        else discord = mountDiscord($('setDiscordHost'));
      }
      if (me.owner) {
        loadUpdates();
        loadShare();
      }
    }
  };
}
