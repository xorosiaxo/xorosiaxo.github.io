// Keeps the model server and the app running: starts them, restarts either if it exits or stops
// answering, and shuts both down cleanly on Ctrl+C.
//
//   node scripts/supervisor.js            start everything (what start.bat does)
//   node scripts/supervisor.js --no-model leave the model alone (it is already running, or remote)
//
// Settings: defaults below match start.bat; override any of them in rosia.local.json (not committed) or
// with the environment variables named in the file.
import { spawn, execFile } from 'node:child_process';
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createUpdateWatcher } from './apply-update.js';

/* ---------- reusable: one supervised process ---------- */

export function supervise({
  name,
  command,
  args = [],
  cwd,
  env = process.env,
  log = () => {},
  health = null, // { url, intervalMs, failures, graceMs }
  backoff = { minMs: 1000, maxMs: 30_000, stableMs: 60_000 },
  onStart = () => {},
  // called when the process has exited by itself: may return { restartNow: true } (an update was put in place, or taken out
  // again) to start it again at once instead of with the usual growing wait
  onExit = () => null,
  autostart = true
}) {
  let child = null;
  let stopped = false;
  let paused = !autostart; // paused: deliberately not running (the GPU is lent to something else), so nothing restarts it
  let restarts = 0;
  let delay = backoff.minMs;
  let startedAt = 0;
  let timer = 0;
  let watchdog = 0;
  let misses = 0;
  let healthy = false;

  const killTree = (proc) => {
    if (!proc || proc.exitCode !== null) return;
    if (process.platform === 'win32') execFile('taskkill', ['/PID', String(proc.pid), '/T', '/F'], () => {});
    else proc.kill('SIGKILL');
  };

  function start() {
    if (stopped || paused) return;
    startedAt = Date.now();
    misses = 0;
    healthy = false;
    child = spawn(command, args, { cwd, env, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    onStart(child);
    const pipe = (stream, tag) => {
      let buf = '';
      stream.on('data', (chunk) => {
        buf += chunk.toString('utf8');
        let i;
        while ((i = buf.indexOf('\n')) !== -1) {
          log(tag, buf.slice(0, i).replace(/\r$/, ''));
          buf = buf.slice(i + 1);
        }
      });
      stream.on('end', () => {
        if (buf.trim()) log(tag, buf.trimEnd());
        buf = '';
      });
    };
    pipe(child.stdout, 'out');
    pipe(child.stderr, 'err');
    child.on('error', (err) => log('sup', `could not start ${name}: ${err.message}`));
    child.on('exit', (code, signal) => {
      clearInterval(watchdog);
      if (stopped || paused) return;
      Promise.resolve()
        .then(() => onExit(code, signal))
        .catch((err) => {
          log('sup', `${name}: ${err.message}`);
          return null;
        })
        .then((verdict) => {
          if (stopped || paused) return;
          restarts += 1;
          if (verdict?.restartNow) {
            delay = backoff.minMs;
            log('sup', `${name} stopped (${signal || `code ${code}`}); starting it again`);
            timer = setTimeout(start, 300);
            return;
          }
          // a run that lasted a while was healthy, so the next wait starts short again
          if (Date.now() - startedAt > backoff.stableMs) delay = backoff.minMs;
          log('sup', `${name} stopped (${signal || `code ${code}`}); restarting in ${Math.round(delay / 1000)}s`);
          timer = setTimeout(start, delay);
          delay = Math.min(backoff.maxMs, delay * 2);
        });
    });

    if (health) {
      watchdog = setInterval(async () => {
        if (!child || child.exitCode !== null || stopped) return;
        try {
          const res = await fetch(health.url, { signal: AbortSignal.timeout(5000) });
          if (!res.ok) throw new Error(`status ${res.status}`);
          misses = 0;
          healthy = true;
        } catch {
          // while it is still starting up, not answering is normal
          if (!healthy && Date.now() - startedAt < (health.graceMs ?? 120_000)) return;
          misses += 1;
          if (misses >= (health.failures ?? 3)) {
            log('sup', `${name} is not answering; restarting it`);
            misses = 0;
            killTree(child);
          }
        }
      }, health.intervalMs ?? 20_000);
    }
  }

  start();

  const running = () => Boolean(child && child.exitCode === null);

  return {
    stop() {
      stopped = true;
      clearTimeout(timer);
      clearInterval(watchdog);
      killTree(child);
    },
    /** Stops it and keeps it stopped until resume(). Resolves once the process has really gone (and let go of the GPU). */
    async pause() {
      paused = true;
      clearTimeout(timer);
      clearInterval(watchdog);
      healthy = false;
      const proc = child;
      if (!proc || proc.exitCode !== null) return;
      const gone = new Promise((resolve) => proc.once('exit', resolve));
      killTree(proc);
      await Promise.race([gone, new Promise((r) => setTimeout(r, 15_000))]);
    },
    /** Stops the process so that the ordinary restart starts it again. */
    restart() {
      killTree(child);
    },
    resume() {
      if (stopped || !paused) return;
      paused = false;
      delay = backoff.minMs;
      if (!running()) start();
    },
    status: () => ({ name, running: running(), paused, restarts, healthy })
  };
}

/** Waits until a URL answers (or gives up). */
export async function waitForHealth(url, timeoutMs, intervalMs = 1000) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    try {
      if ((await fetch(url, { signal: AbortSignal.timeout(2000) })).ok) return true;
    } catch {
      /* not yet */
    }
    await new Promise((r) => setTimeout(r, intervalMs));
  }
  return false;
}


/* ---------- lending the GPU: chat model <-> image generator ---------- */

/*
 * The graphics card is too small to hold the chat model and the image model at once, so they take turns:
 * toImage() stops the chat model (and waits until it has really let go of the card) and starts ComfyUI;
 * toChat() does the reverse. Calls are queued, so two never overlap.
 */
/*
 * Standby (opt-in, `comfyStandby` in rosia.local.json): ComfyUI is started with the launcher and stays running, so a picture
 * does not wait for it to start (about 20-45 s). The chat model still steps off the card while a picture is drawn, because
 * the drawing needs about 2.3 GiB; what changes is that ComfyUI itself is never stopped. Between pictures it holds only
 * its own small footprint (release() asks it to unload its models first), and the chat model is started with
 * `standbyModelArgs` (the vision projector on the processor instead of the card) to leave room for that.
 */
export function createGpuControl({ model, comfy, modelHealth, comfyHealth, waitMs = { model: 180_000, comfy: 240_000 }, standby = false, release = async () => {}, log = () => {} }) {
  let chain = Promise.resolve();
  let mode = 'chat';
  const turn = (job) => {
    const run = chain.then(job);
    chain = run.catch(() => {});
    return run;
  };
  const refuse = (message) => Object.assign(new Error(message), { status: 409 });

  return {
    state: () => ({ mode, standby, model: model?.status() ?? null, comfy: comfy?.status() ?? null }),

    toImage: () => turn(async () => {
      if (!comfy) throw refuse('Image generation is not set up (no ComfyUI folder in rosia.local.json).');
      if (!model) throw refuse('The chat model was not started by this launcher, so it cannot be moved off the graphics card.');
      if (mode === 'image' && comfy.status().healthy) return;
      log('gpu', 'handing the graphics card to the image generator');
      await model.pause();
      mode = 'image';
      if (!standby) comfy.resume(); // on standby it is already running: only the chat model steps aside
      if (!(await waitForHealth(comfyHealth, waitMs.comfy, 1000))) {
        // never leave the card empty: the chat model goes back before the failure is reported
        log('gpu', 'the image generator did not start; giving the card back to the chat model');
        if (!standby) await comfy.pause();
        mode = 'chat';
        model.resume();
        await waitForHealth(modelHealth, waitMs.model, 1000);
        throw new Error('The image generator did not start.');
      }
    }),

    toChat: () => turn(async () => {
      if (!model) return;
      log('gpu', 'handing the graphics card back to the chat model');
      if (comfy && standby) {
        // ComfyUI stays up: it is only asked to let go of its models, so the card is empty again before the chat model returns
        await Promise.resolve(release()).catch((err) => log('gpu', `could not ask the image generator to unload: ${err.message}`));
      } else if (comfy) {
        await comfy.pause();
      }
      mode = 'chat';
      model.resume();
      if (!(await waitForHealth(modelHealth, waitMs.model, 1000))) throw new Error('The chat model did not come back.');
    })
  };
}

/** Whether a command-line flag appears in a program's `--help` text (so a flag this build does not know is never passed to it). */
export function helpMentions(helpText, flag) {
  const escaped = String(flag).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(?:^|[\\s,|\\[])${escaped}(?=[\\s,|\\]=]|$)`, 'm').test(String(helpText));
}

/** Runs `program --help` and checks it knows each flag. Resolves to { known: [...], unknown: [...] }; never throws. */
export function checkFlags(program, flags, { run = execFile, timeoutMs = 15_000, prefix = [], cwd } = {}) {
  return new Promise((resolve) => {
    run(program, [...prefix, '--help'], { timeout: timeoutMs, windowsHide: true, maxBuffer: 4 * 1024 * 1024, cwd }, (err, stdout, stderr) => {
      const text = `${stdout || ''}\n${stderr || ''}`;
      if (!text.trim()) return resolve({ known: [], unknown: [...flags], error: err ? String(err.message) : 'no help text' });
      resolve({ known: flags.filter((f) => helpMentions(text, f)), unknown: flags.filter((f) => !helpMentions(text, f)) });
    });
  });
}

const truthy = (v) => v === true || /^(1|true|yes|on)$/i.test(String(v ?? ''));
export { truthy as isTruthy };

/** A small local-only HTTP API for the app: POST /gpu/image, POST /gpu/chat, GET /gpu. Needs the shared token. */
export function createControlServer({ gpu, token }) {
  return http.createServer(async (req, res) => {
    const reply = (status, body) => {
      res.writeHead(status, { 'content-type': 'application/json' });
      res.end(JSON.stringify(body));
    };
    if (req.headers['x-rosia-control'] !== token) return reply(401, { error: 'no' });
    try {
      if (req.method === 'GET' && req.url === '/gpu') return reply(200, gpu.state());
      if (req.method === 'POST' && req.url === '/gpu/image') return await gpu.toImage(), reply(200, { ok: true });
      if (req.method === 'POST' && req.url === '/gpu/chat') return await gpu.toChat(), reply(200, { ok: true });
      reply(404, { error: 'not found' });
    } catch (err) {
      reply(err.status || 500, { error: err.message });
    }
  });
}

/* ---------- the command line ---------- */

function settings(root) {
  let local = {};
  try {
    local = JSON.parse(fs.readFileSync(path.join(root, 'rosia.local.json'), 'utf8'));
  } catch {
    /* optional */
  }
  const pick = (envName, key, fallback) => process.env[envName] || local[key] || fallback;
  const llamaDir = pick('LLAMA_DIR', 'llamaDir', 'C:\\AI\\llama-b11057-bin-win-cuda-13.4-x64');
  const modelDir = pick('ROSA_MODEL_DIR', 'modelDir', 'C:\\AI\\models\\gemma4-e4b-uncensored');
  const model = pick('ROSA_MODEL_FILE', 'model', path.join(modelDir, 'model.gguf'));
  const comfyDir = pick('ROSA_COMFY_DIR', 'comfyDir', '');
  return {
    server: pick('LLAMA_SERVER', 'llamaServer', path.join(llamaDir, process.platform === 'win32' ? 'llama-server.exe' : 'llama-server')),
    model,
    // a vision projector sits next to the model by default; "mmproj": "" in rosia.local.json means a text-only model
    mmproj: 'mmproj' in local ? local.mmproj : process.env.ROSA_MMPROJ_FILE || path.join(path.dirname(model), 'mmproj.gguf'),
    modelPort: Number(pick('ROSA_MODEL_PORT', 'modelPort', 8080)),
    appPort: Number(pick('PORT', 'port', 8787)),
    alias: pick('ROSA_MODEL', 'alias', 'rosia'),
    // the flags that were benchmarked as best for this machine
    extraArgs: local.modelArgs || ['-ngl', '99', '-c', '8192', '-np', '1', '--jinja'],
    // optional small embedding model for "meaning" search in memory. It runs on the CPU, next to the chat model
    // on the GPU, so it costs the chat nothing. e.g. embeddinggemma-300M-Q8_0.gguf with style "embeddinggemma"
    embedFile: pick('ROSA_EMBED_FILE', 'embedModel', ''),
    embedStyle: pick('ROSA_EMBED_STYLE', 'embedStyle', 'none'),
    embedPort: Number(pick('ROSA_EMBED_PORT', 'embedPort', 8081)),
    // voice: Kokoro on the CPU (scripts/tts-server.py)
    ttsModel: pick('ROSA_TTS_MODEL', 'ttsModel', ''),
    ttsVoices: pick('ROSA_TTS_VOICES', 'ttsVoices', ''),
    ttsPython: pick('ROSA_TTS_PYTHON', 'ttsPython', 'python'),
    ttsPort: Number(pick('ROSA_TTS_PORT', 'ttsPort', 8082)),
    // images: ComfyUI (its own folder with main.py and a .venv), borrowing the GPU from the chat model while it works
    comfyDir,
    comfyPython: pick('ROSA_COMFY_PYTHON', 'comfyPython', comfyDir ? path.join(comfyDir, '.venv', 'Scripts', 'python.exe') : ''),
    comfyModels: pick('ROSA_COMFY_MODELS', 'comfyModels', ''),
    comfyPort: Number(pick('ROSA_COMFY_PORT', 'comfyPort', 8188)),
    // only these custom nodes are loaded (ComfyUI starts much faster): GGUF models, KJNodes for sage attention, and RES4LYF,
    // which is what adds the res_2s sampler and bong_tangent scheduler the saved workflow uses
    comfyNodes: local.comfyNodes || ['ComfyUI-GGUF', 'comfyui-kjnodes', 'RES4LYF'],
    comfyWorkflow: pick('ROSA_IMAGE_WORKFLOW', 'comfyWorkflow', comfyDir ? path.join(comfyDir, 'user', 'default', 'workflows', 'rosia.json') : ''),
    comfyArgs: local.comfyArgs || [],
    // standby: ComfyUI stays running between pictures (see createGpuControl). Off unless asked for.
    comfyStandby: truthy(process.env.ROSA_COMFY_STANDBY ?? local.comfyStandby),
    // what the chat model is started with in standby, to leave room on the card for the idle image generator:
    // the vision projector goes on the processor (it only slows reading pictures, not chat)
    standbyModelArgs: local.standbyModelArgs || ['--no-mmproj-offload'],
    // ComfyUI's flags in standby: nothing is kept in memory between pictures
    standbyComfyArgs: local.standbyComfyArgs || ['--cache-none'],
    controlPort: Number(pick('ROSA_CONTROL_PORT', 'controlPort', 8790)),
    // "invite" (default): other machines need a pairing code and join YOUR space; "open": anyone with the link gets their own private space
    access: pick('ROSA_ACCESS', 'access', ''),
    // her GIF collection: a Python that has Pillow (for the frames), and the folder if it is not Rosia-GIFs in the user folder
    gifPython: pick('ROSA_GIF_PYTHON', 'gifPython', ''),
    gifsDir: pick('ROSA_GIFS_DIR', 'gifsDir', ''),
    // updates: where the signed release list is, and whether a new version installs itself ('auto'), waits to be told ('notify') or never ('off')
    updateUrl: pick('ROSA_UPDATE_URL', 'updateUrl', ''),
    updateMode: pick('ROSA_UPDATE_MODE', 'updateMode', '')
  };
}

export function comfyPathsYaml(modelsDir) {
  const base = String(modelsDir).replace(/\\/g, '/');
  return [
    'rosia:',
    `  base_path: ${base}`,
    '  checkpoints: checkpoints',
    '  diffusion_models: diffusion_models',
    '  unet: unet',
    '  text_encoders: text_encoders',
    '  clip: text_encoders',
    '  vae: vae',
    '  loras: loras',
    ''
  ].join('\n');
}

async function main() {
  const here = path.dirname(fileURLToPath(import.meta.url));
  const root = path.resolve(here, '..');
  // the person's own files (rosia.local.json, data/) live in "home": this folder, or the one the desktop app names
  const home = process.env.ROSIA_HOME ? path.resolve(process.env.ROSIA_HOME) : root;
  const cfg = settings(home);
  const dataDir = process.env.ROSA_DATA_DIR || path.join(home, 'data');
  const logDir = path.join(dataDir, 'logs');
  fs.mkdirSync(logDir, { recursive: true });

  const log = (name) => (tag, line) => {
    const text = `[${name}] ${line}`;
    if (tag !== 'out' || process.env.ROSA_VERBOSE) console.log(text);
    const file = path.join(logDir, `${name}.log`);
    try {
      if (fs.existsSync(file) && fs.statSync(file).size > 5 * 1024 * 1024) fs.renameSync(file, `${file}.old`);
      fs.appendFileSync(file, `${new Date().toISOString()} ${tag} ${line}\n`);
    } catch {
      /* logging must never take the app down */
    }
  };

  const parts = [];
  const modelUrl = `http://127.0.0.1:${cfg.modelPort}/health`;
  const appUrl = `http://127.0.0.1:${cfg.appPort}/api/alive`; // answers at once: a slow model must not get the app restarted
  const comfyUrl = `http://127.0.0.1:${cfg.comfyPort}`;
  let modelHandle = null;
  let gpuControl = null;

  console.log('\n  R O S I A\n');

  // standby (ComfyUI kept running between pictures) only goes ahead where it is safe: the launcher starts the chat model itself,
  // with the trimmed settings, and both programs know every flag it would pass them. Otherwise it is switched off and says why.
  let standby = cfg.comfyStandby;
  const comfyInstalled = Boolean(cfg.comfyDir && fs.existsSync(path.join(cfg.comfyDir, 'main.py')) && fs.existsSync(cfg.comfyPython));
  const flagsOf = (list) => list.filter((a) => /^-[A-Za-z-]/.test(a));
  if (standby) {
    const why = [];
    if (!comfyInstalled) why.push('ComfyUI is not set up');
    if (process.argv.includes('--no-model')) why.push('the chat model is not started by this launcher (--no-model)');
    else if (await waitForHealth(modelUrl, 1500, 300)) why.push('the chat model is already running, with its full settings, so there would be no room for ComfyUI beside it');
    else if (fs.existsSync(cfg.server)) {
      const model = await checkFlags(cfg.server, flagsOf(cfg.standbyModelArgs));
      if (model.unknown.length) why.push(`this llama.cpp does not know ${model.unknown.join(', ')}`);
      const comfyFlags = flagsOf(cfg.standbyComfyArgs);
      if (!why.length && comfyInstalled && comfyFlags.length) {
        const comfy = await checkFlags(cfg.comfyPython, comfyFlags, { prefix: ['main.py'], cwd: cfg.comfyDir, timeoutMs: 90_000 });
        if (comfy.unknown.length) why.push(`this ComfyUI does not know ${comfy.unknown.join(', ')}`);
      }
    }
    if (why.length) {
      standby = false;
      console.log(`  images: standby is OFF: ${why.join('; ')}. Pictures work as before (ComfyUI starts when she draws).`);
    }
  }

  if (process.argv.includes('--no-model')) {
    console.log('  model: left alone (--no-model)');
  } else if (await waitForHealth(modelUrl, 1500, 300)) {
    console.log(`  model: already running on :${cfg.modelPort}, not starting another`);
  } else if (!fs.existsSync(cfg.server) || !fs.existsSync(cfg.model)) {
    console.log(`  [x] model files not found:\n      ${cfg.server}\n      ${cfg.model}\n  Edit rosia.local.json, or start your model server yourself and use --no-model.`);
  } else {
    console.log(`  model: starting${standby ? ' (standby settings: ' + cfg.standbyModelArgs.join(' ') + ')' : ''} ...`);
    const args = ['-m', cfg.model, ...(cfg.mmproj && fs.existsSync(cfg.mmproj) ? ['--mmproj', cfg.mmproj] : []), '--host', '127.0.0.1', '--port', String(cfg.modelPort), '--alias', cfg.alias, ...cfg.extraArgs, ...(standby ? cfg.standbyModelArgs : [])];
    modelHandle = supervise({ name: 'model', command: cfg.server, args, log: log('model'), health: { url: modelUrl, intervalMs: 20_000, failures: 3, graceMs: 180_000 } });
    parts.push(modelHandle);
    if (await waitForHealth(modelUrl, 180_000, 2000)) console.log('  model: ready');
    else console.log('  model: not ready yet (the app will start anyway and pick it up when it is)');
  }

  const env = { ...process.env, PORT: String(cfg.appPort), OLLAMA_URL: `http://127.0.0.1:${cfg.modelPort}`, ROSA_MODEL: cfg.alias };
  if (cfg.access) env.ROSA_ACCESS = cfg.access;
  if (cfg.gifPython) env.ROSA_GIF_PYTHON = cfg.gifPython;
  if (cfg.gifsDir) env.ROSA_GIFS_DIR = cfg.gifsDir;
  if (cfg.updateUrl) env.ROSA_UPDATE_URL = cfg.updateUrl;
  if (cfg.updateMode) env.ROSA_UPDATE_MODE = cfg.updateMode;
  env.ROSA_SUPERVISED = '1'; // the app may ask for an update to be installed: only this launcher can replace its files

  if (cfg.embedFile && fs.existsSync(cfg.embedFile) && fs.existsSync(cfg.server)) {
    const embedUrl = `http://127.0.0.1:${cfg.embedPort}`;
    if (await waitForHealth(`${embedUrl}/health`, 1000, 250)) {
      console.log(`  memory model: already running on :${cfg.embedPort}`);
    } else {
      console.log('  memory model: starting (CPU) ...');
      const args = ['-m', cfg.embedFile, '--host', '127.0.0.1', '--port', String(cfg.embedPort), '--embeddings', '-ngl', '0', '-c', '2048', '-b', '2048', '-ub', '2048', '-t', '4', '--alias', 'embed'];
      parts.push(supervise({ name: 'embed', command: cfg.server, args, log: log('embed'), health: { url: `${embedUrl}/health`, intervalMs: 30_000, failures: 3, graceMs: 120_000 } }));
      await waitForHealth(`${embedUrl}/health`, 60_000, 1000);
    }
    env.ROSA_EMBED_URL = embedUrl;
    env.ROSA_EMBED_MODEL = 'embed';
    env.ROSA_EMBED_STYLE = cfg.embedStyle;
  } else if (cfg.embedFile) {
    console.log(`  memory model: file not found (${cfg.embedFile}); using the built-in word matcher`);
  }

  if (cfg.ttsModel && fs.existsSync(cfg.ttsModel) && fs.existsSync(cfg.ttsVoices)) {
    const ttsUrl = `http://127.0.0.1:${cfg.ttsPort}`;
    if (await waitForHealth(`${ttsUrl}/health`, 800, 200)) {
      console.log(`  voice: already running on :${cfg.ttsPort}`);
    } else {
      console.log('  voice: starting (CPU) ...');
      const script = path.join(root, 'scripts', 'tts-server.py');
      parts.push(supervise({
        name: 'voice', command: cfg.ttsPython, args: [script, '--model', cfg.ttsModel, '--voices', cfg.ttsVoices, '--port', String(cfg.ttsPort)],
        log: log('voice'), health: { url: `${ttsUrl}/health`, intervalMs: 30_000, failures: 3, graceMs: 120_000 }
      }));
      await waitForHealth(`${ttsUrl}/health`, 60_000, 1000);
    }
    env.ROSA_TTS_URL = ttsUrl;
  } else if (cfg.ttsModel) {
    console.log(`  voice: files not found (${cfg.ttsModel}); voice is off`);
  }

  if (comfyInstalled) {
    const comfyDataDir = path.join(dataDir, 'comfy');
    fs.mkdirSync(comfyDataDir, { recursive: true });
    const yaml = path.join(comfyDataDir, 'extra_model_paths.yaml');
    if (cfg.comfyModels) fs.writeFileSync(yaml, comfyPathsYaml(cfg.comfyModels));
    const args = [
      'main.py', '--listen', '127.0.0.1', '--port', String(cfg.comfyPort), '--disable-auto-launch',
      '--disable-all-custom-nodes', '--whitelist-custom-nodes', ...cfg.comfyNodes,
      ...(cfg.comfyModels ? ['--extra-model-paths-config', yaml] : []),
      ...cfg.comfyArgs,
      ...(standby ? cfg.standbyComfyArgs : [])
    ];
    // normally not started now: it only runs while an image is being made, because it needs the card to itself.
    // In standby it starts with everything else (after the chat model, so the chat model has the card first) and stays up.
    const comfy = supervise({
      name: 'images', command: cfg.comfyPython, args, cwd: cfg.comfyDir, autostart: standby, log: log('images'),
      backoff: { minMs: 2000, maxMs: 30_000, stableMs: 60_000 },
      health: { url: `${comfyUrl}/system_stats`, intervalMs: 20_000, failures: 3, graceMs: 240_000 }
    });
    parts.push(comfy);
    // between pictures ComfyUI is asked to let go of its models, so the card is empty again before the chat model comes back
    const release = async () => {
      try {
        await fetch(`${comfyUrl}/free`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ unload_models: true, free_memory: true }), signal: AbortSignal.timeout(10_000) });
      } catch {
        /* it may be busy or restarting: the chat model comes back anyway */
      }
      await new Promise((r) => setTimeout(r, 2000));
    };
    const token = crypto.randomBytes(24).toString('hex');
    const gpu = gpuControl = createGpuControl({
      model: modelHandle, comfy, modelHealth: modelUrl, comfyHealth: `${comfyUrl}/system_stats`, standby, release,
      log: (_, line) => log('gpu')('sup', line)
    });
    const control = createControlServer({ gpu, token }).listen(cfg.controlPort, '127.0.0.1');
    control.on('error', (err) => console.log(`  images: control port ${cfg.controlPort} unavailable (${err.message})`));
    parts.push({ stop: () => control.close() });
    env.ROSA_COMFY_URL = comfyUrl;
    if (cfg.comfyWorkflow && fs.existsSync(cfg.comfyWorkflow)) env.ROSA_IMAGE_WORKFLOW = cfg.comfyWorkflow;
    else console.log(`  images: no saved workflow found at ${cfg.comfyWorkflow}; the built-in one will be used`);
    env.ROSA_CONTROL_URL = `http://127.0.0.1:${cfg.controlPort}`;
    env.ROSA_CONTROL_TOKEN = token;
    if (standby) {
      const up = await waitForHealth(`${comfyUrl}/system_stats`, 120_000, 1000);
      console.log(up ? '  images: ready, on standby (the image generator stays running; only the chat model steps aside while she draws)' : '  images: standby started; the image generator is not answering yet');
    } else {
      console.log('  images: ready (the image generator starts when she draws something)');
    }
  } else if (cfg.comfyDir) {
    console.log(`  images: ComfyUI not found in ${cfg.comfyDir}; drawing is off`);
  }

  console.log(`  app:   starting on :${cfg.appPort} ...`);
  // an update the app has staged is swapped in here, after the app has left; a new version that does not come up is taken out again
  let appHandle = null;
  const recent = []; // the app's last lines, kept so a failed update can say what the new version printed before it died
  const appLog = log('app');
  const updates = createUpdateWatcher({
    tail: () => recent.slice(),
    root, dataDir, log: (line) => log('update')('sup', line),
    isHealthy: () => Boolean(appHandle?.status().healthy),
    stopApp: () => appHandle?.restart()
  });
  appHandle = supervise({
    name: 'app', command: process.execPath, args: [path.join(root, 'server', 'index.js')], cwd: root, env,
    log: (tag, line) => {
      appLog(tag, line);
      if (tag === 'err' || tag === 'out') {
        recent.push(line);
        if (recent.length > 20) recent.shift();
      }
    },
    health: { url: appUrl, intervalMs: 20_000, failures: 3, graceMs: 30_000 },
    // if the app dies while a picture is being drawn, nobody is left to hand the card back, so do it here
    onStart: (child) => child.once('exit', () => gpuControl?.toChat().catch(() => {})),
    onExit: (code) => updates.onAppExit(code)
  });
  parts.push(appHandle, { stop: () => updates.stop() });
  updates.resume();

  if (await waitForHealth(appUrl, 30_000, 500)) {
    console.log(`\n  ready: http://127.0.0.1:${cfg.appPort}\n  (Ctrl+C stops everything; logs are in data/logs)\n`);
    if (process.platform === 'win32' && !process.argv.includes('--no-browser')) execFile('cmd', ['/c', 'start', '', `http://127.0.0.1:${cfg.appPort}`], () => {});
  }

  const shutdown = () => {
    console.log('\n  stopping ...');
    for (const p of parts) p.stop();
    setTimeout(() => process.exit(0), 800);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) main();
