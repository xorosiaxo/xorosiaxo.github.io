// Local stand-in for an OpenAI-compatible model server, so the whole pipeline
// (streaming, tool calls, persona, sessions) can be tested without Ollama.
// Usage: node scripts/mock-llm.js [port]
// MOCK_DELAY=9000 delays the first token; MOCK_WORD_MS=300 slows the stream (simulates a busy GPU).
import http from 'node:http';

const port = Number(process.argv[2] || 11500);
const t0 = Date.now();

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${port}`);

  if (url.pathname === '/api/tags') {
    res.setHeader('content-type', 'application/json');
    res.end(JSON.stringify({ models: [{ name: 'mock-model:latest' }] }));
    return;
  }

  if (url.pathname === '/v1/chat/completions') {
    let raw = '';
    for await (const chunk of req) raw += chunk;
    const body = JSON.parse(raw || '{}');
    const messages = body.messages || [];
    const last = messages.at(-1) || {};
    const hasToolResult = messages.some((m) => m.role === 'tool');

    res.writeHead(200, {
      'content-type': 'text/event-stream',
      'cache-control': 'no-cache',
      connection: 'keep-alive'
    });

    const send = (obj) => res.write(`data: ${JSON.stringify(obj)}\n\n`);
    const piece = (text) => send({ choices: [{ index: 0, delta: { content: text }, finish_reason: null }] });

    // "draw ..." in the newest message, and the drawing tool on offer: ask for a picture
    if (!hasToolResult && body.tools?.some((t) => t.function?.name === 'generate_image') && /\bdraw\b/i.test(String(last.content || ''))) {
      piece('[excited] ');
      send({ choices: [{ index: 0, delta: { tool_calls: [{ index: 0, id: 'call_mock_img', type: 'function', function: { name: 'generate_image', arguments: JSON.stringify({ prompt: 'A lighthouse at dusk, oil painting, warm light', orientation: 'landscape' }) } }] }, finish_reason: 'tool_calls' }] });
      res.write('data: [DONE]\n\n');
      res.end();
      return;
    }

    // "mockpic": the model decides on its own to send a picture of herself
    if (!hasToolResult && body.tools?.some((t) => t.function?.name === 'send_picture') && /mockpic/i.test(String(last.content || ''))) {
      piece('[flirty] ');
      send({ choices: [{ index: 0, delta: { tool_calls: [{ index: 0, id: 'call_mock_pic', type: 'function', function: { name: 'send_picture', arguments: '{}' } }] }, finish_reason: 'tool_calls' }] });
      res.write('data: [DONE]\n\n');
      res.end();
      return;
    }

    // "mockleak": the model writes its tool call out as text, in pieces, the way Gemma sometimes does
    if (!hasToolResult && body.tools?.length && /mockleak/i.test(String(last.content || ''))) {
      for (const p of ['[teasing] well, since you brought it up... ', 'i reckon you deserve a proper look.\n\nget_', 'time{}']) {
        piece(p);
        await new Promise((r) => setTimeout(r, 15));
      }
      send({ choices: [{ index: 0, delta: {}, finish_reason: 'stop' }] });
      res.write('data: [DONE]\n\n');
      res.end();
      return;
    }

    // the newest message asks for something live: narrate, then call a tool (like the real persona)
    const asked = String(last.content || '');
    if (!hasToolResult && body.tools?.length && /\b(weather|forecast|latest news|search for|look up|how (?:hot|cold) is)\b/i.test(asked)) {
      piece('[flirty] gimme a sec... '); // narration before the tool call, like the real persona
      send({
        choices: [
          {
            index: 0,
            delta: {
              tool_calls: [
                {
                  index: 0,
                  id: 'call_mock_1',
                  type: 'function',
                  function: { name: 'get_time', arguments: '' }
                }
              ]
            },
            finish_reason: null
          }
        ]
      });
      send({ choices: [{ index: 0, delta: { tool_calls: [{ index: 0, function: { arguments: '{}' } }] }, finish_reason: 'tool_calls' }] });
      res.write('data: [DONE]\n\n');
      res.end();
      return;
    }

    const reply = hasToolResult
      ? `Right, I checked — it's ${new Date().toLocaleTimeString('en-GB')} where you are. Don't you have anything better to do? 😏`
      : `Alright, mock model here — I heard "${String(last.content || '').slice(0, 40)}". Pipe's working, so plug in your real model. 💋`;

    // MOCK_REPEAT: behave like a model stuck on its own last message. It says the same thing again, and
    // only changes when it is told off for repeating — which is what the retry note is for.
    let text = reply;
    if (process.env.MOCK_REPEAT) {
      const told = /note to you, never mention it: Your previous draft repeated/i.test(String(last.content || ''));
      const previous = [...messages].reverse().find((m) => m.role === 'assistant' && m.content);
      if (!told && previous) text = String(previous.content).replace(/^\[[a-z]+\]\s*/i, '');
      else if (told) text = 'Right — different answer this time. Bus lane, mirror, signal, done.';
    }

    let closed = false;
    res.on('close', () => { closed = true; });
    await new Promise((r) => setTimeout(r, Number(process.env.MOCK_DELAY || 0)));
    // mimic the real persona: a leading mood tag and short paragraphs
    const moods = ['flirty', 'teasing', 'amused', 'curious', 'warm', 'neutral'];
    const mood = process.env.MOCK_MOOD || moods[Math.floor(Math.random() * moods.length)];
    let tagged = `[${mood}] ${text.replace('. ', '.\n\n')}`;
    // MOCK_LEAK_TAG: the tags a small model invents, in the places it invents them
    if (process.env.MOCK_LEAK_TAG) tagged = `[${process.env.MOCK_LEAK_TAG}] ${text}\n\n[feet] — sitting on the floor, knees up`;
    for (const word of tagged.split(' ')) {
      if (closed) return;
      piece(`${word} `);
      await new Promise((r) => setTimeout(r, Number(process.env.MOCK_WORD_MS || 12)));
    }
    send({ choices: [{ index: 0, delta: {}, finish_reason: 'stop' }] });
    res.write('data: [DONE]\n\n');
    res.end();
    return;
  }

  res.statusCode = 404;
  res.end('not found');
});

server.listen(port, '127.0.0.1', () => {
  console.log(`mock LLM on http://127.0.0.1:${port} (up ${Date.now() - t0}ms)`);
});
