/* The sidebar's list of conversations, and the code that draws what she remembers and the linked machines into their views. */

const $ = (id) => document.getElementById(id);

async function api(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: body ? { 'content-type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

function ago(ts) {
  const diff = Date.now() - ts;
  const min = Math.round(diff / 60_000);
  if (min < 1) return 'now';
  if (min < 60) return `${min}m`;
  const hours = Math.round(min / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.round(hours / 24);
  if (days < 7) return `${days}d`;
  return new Date(ts).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

function dayGroup(ts) {
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const day = 86_400_000;
  if (ts >= start.getTime()) return 'Today';
  if (ts >= start.getTime() - day) return 'Yesterday';
  if (ts >= start.getTime() - 7 * day) return 'Previous 7 days';
  return 'Older';
}

function icon(path) {
  return `<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
}
const ICON = {
  edit: icon('<path d="M10.5 3.2 12.8 5.5 5.6 12.7 3 13l.3-2.6z"/>'),
  trash: icon('<path d="M3.5 4.5h9M6.5 4.5V3h3v1.5M5 4.5l.5 8h5l.5-8"/>'),
  check: icon('<path d="m3.5 8.5 3 3 6-6.5"/>'),
  x: icon('<path d="m4 4 8 8M12 4l-8 8"/>')
};

export function createPanel(ctx) {
  const el = {
    drawer: $('drawer'),
    scrim: $('scrim'),
    chatList: $('chatList'),
    memList: $('memList'),
    memProfile: $('memProfile'),
    memProfileText: $('memProfileText'),
    memAdd: $('memAdd'),
    memAddInput: $('memAddInput'),
    memoryDot: $('memoryDot'),
    openMemory: $('openMemory'),
    devList: $('devList'),
    devPair: $('devPair'),
    pairBox: $('pairBox'),
    pairCode: $('pairCode'),
    pairTimer: $('pairTimer'),
    pairUrl: $('pairUrl'),
    pairCopy: $('pairCopy'),
    devMode: $('devMode')
  };

  let isOpen = false;
  const seenKey = 'rosia.memSeen';
  const seen = () => Number(localStorage.getItem(seenKey) || 0);
  const markSeen = (n) => localStorage.setItem(seenKey, String(n));

  /* ---------- open / close ---------- */

  let opener = null;
  const appShell = document.querySelector('.app');

  function open() {
    opener = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    isOpen = true;
    appShell.inert = true; // keeps keyboard focus and screen readers inside the sidebar
    el.drawer.classList.add('open');
    el.drawer.setAttribute('aria-hidden', 'false');
    el.scrim.hidden = false;
    requestAnimationFrame(() => el.scrim.classList.add('show'));
    loadChats();
    // move focus in, so a keyboard user is not left behind the sidebar
    requestAnimationFrame(() => $('newChat').focus());
  }

  function close() {
    isOpen = false;
    el.drawer.classList.remove('open');
    el.drawer.setAttribute('aria-hidden', 'true');
    el.scrim.classList.remove('show');
    appShell.inert = false;
    opener?.focus?.();
    setTimeout(() => { if (!isOpen) el.scrim.hidden = true; }, 220);
  }

  /* ---------- conversations ---------- */

  async function loadChats() {
    let list = [];
    try {
      list = (await api('GET', '/api/conversations')).conversations;
    } catch {
      el.chatList.innerHTML = '<div class="empty">Could not load your chats.</div>';
      return;
    }
    renderChats(list);
  }

  function renderChats(list) {
    el.chatList.replaceChildren();
    if (!list.length) {
      el.chatList.innerHTML = '<div class="empty">Nothing here yet. Your conversations will show up as you chat.</div>';
      return;
    }

    let group = '';
    for (const c of list) {
      const g = dayGroup(c.updatedAt);
      if (g !== group) {
        group = g;
        const h = document.createElement('div');
        h.className = 'list-group';
        h.textContent = g;
        el.chatList.appendChild(h);
      }
      el.chatList.appendChild(chatRow(c));
    }
  }

  function chatRow(c) {
    const row = document.createElement('div');
    row.className = 'chat-row';
    if (c.id === ctx.getCurrentId()) row.classList.add('current');

    const main = document.createElement('button');
    main.type = 'button';
    main.className = 'chat-main';
    const title = document.createElement('span');
    title.className = 'chat-title';
    title.textContent = c.title;
    const meta = document.createElement('span');
    meta.className = 'chat-meta';
    meta.textContent = c.preview || '';
    main.append(title, meta);
    main.addEventListener('click', () => {
      close();
      ctx.openConversation(c.id);
    });

    const time = document.createElement('span');
    time.className = 'chat-time';
    time.textContent = ago(c.updatedAt);

    const actions = document.createElement('span');
    actions.className = 'row-actions';
    const rename = actionBtn(ICON.edit, 'Rename');
    const del = actionBtn(ICON.trash, 'Delete');
    actions.append(rename, del);

    rename.addEventListener('click', (e) => {
      e.stopPropagation();
      editTitle(row, main, title, c);
    });

    let armed = 0;
    del.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!armed) {
        armed = setTimeout(() => {
          armed = 0;
          del.classList.remove('armed');
          del.innerHTML = ICON.trash;
        }, 3000);
        del.classList.add('armed');
        del.innerHTML = 'Delete?';
        return;
      }
      clearTimeout(armed);
      try {
        await api('DELETE', `/api/conversations/${c.id}`);
      } catch {
        return;
      }
      row.remove();
      if (c.id === ctx.getCurrentId()) ctx.onDeletedCurrent();
      if (!el.chatList.querySelector('.chat-row')) renderChats([]);
    });

    row.append(main, time, actions);
    return row;
  }

  function actionBtn(svg, label) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'row-btn';
    b.setAttribute('aria-label', label);
    b.title = label;
    b.innerHTML = svg;
    return b;
  }

  function editTitle(row, main, titleEl, c) {
    const input = document.createElement('input');
    input.className = 'title-edit';
    input.value = c.title;
    input.maxLength = 60;
    main.replaceChild(input, titleEl);
    row.classList.add('editing');
    input.focus();
    input.select();

    let done = false;
    const finish = async (save) => {
      if (done) return;
      done = true;
      const next = input.value.trim();
      row.classList.remove('editing');
      if (save && next && next !== c.title) {
        try {
          await api('PATCH', `/api/conversations/${c.id}`, { title: next });
          c.title = next;
        } catch {
          /* keep the old title */
        }
      }
      titleEl.textContent = c.title;
      main.replaceChild(titleEl, input);
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') finish(true);
      if (e.key === 'Escape') { e.stopPropagation(); finish(false); }
    });
    input.addEventListener('blur', () => finish(true));
  }

  /* ---------- memory ---------- */

  async function loadMemory() {
    let data;
    try {
      data = await api('GET', '/api/memory');
    } catch {
      el.memList.innerHTML = '<div class="empty">Could not load her notes.</div>';
      return;
    }
    renderMemory(data);
    markSeen(data.notes.length);
    el.memoryDot.hidden = true;
  }

  function renderMemory({ notes, profile }) {
    el.memProfile.hidden = !profile;
    el.memProfileText.textContent = profile || '';
    el.memList.replaceChildren();
    if (!notes.length) {
      el.memList.innerHTML = '<div class="empty">Nothing yet. As you talk she will note down things worth remembering, and you can add your own above.</div>';
      return;
    }
    const live = notes.filter((n) => !n.expired);
    const past = notes.filter((n) => n.expired);
    for (const n of live) el.memList.appendChild(noteRow(n));
    if (past.length) {
      const box = document.createElement('details');
      box.className = 'past';
      const head = document.createElement('summary');
      head.textContent = `Past (${past.length})`;
      const hint = document.createElement('div');
      hint.className = 'past-hint';
      hint.textContent = 'These no longer matter (a date has gone by), so she does not use them.';
      box.append(head, hint);
      for (const n of past) box.appendChild(noteRow(n));
      el.memList.appendChild(box);
    }
  }

  function noteRow(n) {
    const row = document.createElement('div');
    row.className = 'note-row';

    const text = document.createElement('span');
    text.className = 'note-text';
    text.textContent = n.text;

    const tag = document.createElement('span');
    tag.className = 'note-tag';
    tag.textContent = n.expired ? 'past' : n.updated ? 'updated' : n.source === 'user' ? 'you' : 'noticed';
    if (n.updated && n.was) tag.title = `Was: ${n.was}`;
    if (n.until && !n.expired) tag.title = `Matters until ${new Date(n.until - 86_400_000).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}`;

    const actions = document.createElement('span');
    actions.className = 'row-actions';
    const edit = actionBtn(ICON.edit, 'Edit');
    const forget = actionBtn(ICON.x, 'Forget');
    actions.append(edit, forget);

    edit.addEventListener('click', () => {
      const area = document.createElement('textarea');
      area.className = 'note-edit';
      area.value = n.text;
      area.maxLength = 200;
      area.rows = 2;
      const save = actionBtn(ICON.check, 'Save');
      const cancel = actionBtn(ICON.x, 'Cancel');
      const bar = document.createElement('span');
      bar.className = 'row-actions show';
      bar.append(save, cancel);
      row.classList.add('editing');
      row.replaceChildren(area, bar);
      area.focus();
      save.addEventListener('click', async () => {
        const value = area.value.trim();
        if (!value) return;
        try {
          renderMemory(await api('PATCH', `/api/memory/${n.id}`, { text: value }));
        } catch { /* leave as is */ }
      });
      cancel.addEventListener('click', () => loadMemory());
      area.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); save.click(); }
        if (e.key === 'Escape') { e.stopPropagation(); loadMemory(); }
      });
    });

    forget.addEventListener('click', async () => {
      try {
        const data = await api('DELETE', `/api/memory/${n.id}`);
        renderMemory({ notes: data.notes, profile: el.memProfileText.textContent });
        markSeen(data.notes.length);
      } catch { /* keep it */ }
    });

    row.append(text, tag, actions);
    return row;
  }

  el.memAdd.addEventListener('submit', async (e) => {
    e.preventDefault();
    const value = el.memAddInput.value.trim();
    if (!value) return;
    try {
      const data = await api('POST', '/api/memory', { text: value });
      el.memAddInput.value = '';
      renderMemory({ notes: data.notes, profile: el.memProfileText.textContent });
      markSeen(data.notes.length);
    } catch (err) {
      el.memAddInput.setCustomValidity(err.message);
      el.memAddInput.reportValidity();
      el.memAddInput.setCustomValidity('');
    }
  });

  /* ---------- your data ---------- */

  const dataStatus = $('dataStatus');
  const say = (text, bad = false) => {
    dataStatus.textContent = text;
    dataStatus.classList.toggle('bad', bad);
  };

  $('exportPics').addEventListener('change', (e) => {
    $('exportBtn').href = e.target.checked ? '/api/export' : '/api/export?pictures=0';
  });

  $('importFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    e.target.value = '';
    if (!file) return;
    say('Importing…');
    try {
      const res = await fetch('/api/import', { method: 'POST', headers: { 'content-type': 'application/json' }, body: await file.text() });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'The import failed.');
      const bits = [];
      if (data.conversations) bits.push(`${data.conversations} chat${data.conversations === 1 ? '' : 's'}`);
      if (data.notes) bits.push(`${data.notes} note${data.notes === 1 ? '' : 's'}`);
      if (data.pictures) bits.push(`${data.pictures} picture${data.pictures === 1 ? '' : 's'}`);
      const extra = `${data.skipped ? ` ${data.skipped} already here.` : ''}${data.noRoom ? ` ${data.noRoom} left out because you have reached the limit for chats.` : ''}`;
      say(bits.length ? `Added ${bits.join(', ')}.${extra}` : `Nothing new in that file.${extra}`);
      loadMemory();
    } catch (err) {
      say(err.message, true);
    }
  });

  /* ---------- machines ---------- */

  let pairTimer = 0;

  async function loadDevices() {
    try {
      renderDevices(await api('GET', '/api/devices'));
    } catch {
      el.devList.innerHTML = '<div class="empty">Could not load your machines.</div>';
    }
  }

  function renderDevices({ devices, mode }) {
    el.devList.replaceChildren();
    for (const d of devices) el.devList.appendChild(deviceRow(d, devices.length));
    el.devMode.textContent = mode === 'open'
      ? 'Anyone who can reach this address gets their own private space.'
      : 'Only this computer, and machines you link with a code, can use this.';
  }

  function deviceRow(d, total) {
    const row = document.createElement('div');
    row.className = 'dev-row';

    const main = document.createElement('div');
    main.className = 'dev-main';
    const name = document.createElement('span');
    name.className = 'dev-name';
    name.textContent = d.label;
    if (d.current) {
      const tag = document.createElement('span');
      tag.className = 'note-tag keep';
      tag.textContent = 'this machine';
      name.appendChild(tag);
    }
    const seen = document.createElement('span');
    seen.className = 'chat-meta';
    const when = ago(d.lastSeenAt);
    seen.textContent = d.current ? 'In use now' : when === 'now' ? 'Last used just now' : `Last used ${when} ago`;
    main.append(name, seen);

    const actions = document.createElement('span');
    actions.className = 'row-actions show';
    const rename = actionBtn(ICON.edit, 'Rename');
    actions.appendChild(rename);

    rename.addEventListener('click', () => {
      const input = document.createElement('input');
      input.className = 'title-edit';
      input.value = d.label;
      input.maxLength = 40;
      name.replaceChildren(input);
      input.focus();
      input.select();
      let done = false;
      const finish = async (save) => {
        if (done) return;
        done = true;
        if (save && input.value.trim() && input.value.trim() !== d.label) {
          try { renderDevices(await api('PATCH', `/api/devices/${d.id}`, { label: input.value.trim() })); return; } catch { /* keep */ }
        }
        loadDevices();
      };
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') finish(true);
        if (e.key === 'Escape') { e.stopPropagation(); finish(false); }
      });
      input.addEventListener('blur', () => finish(true));
    });

    if (!d.current && total > 1) {
      const remove = actionBtn(ICON.trash, 'Remove this machine');
      let armed = 0;
      remove.addEventListener('click', async () => {
        if (!armed) {
          armed = setTimeout(() => { armed = 0; remove.classList.remove('armed'); remove.innerHTML = ICON.trash; }, 3000);
          remove.classList.add('armed');
          remove.innerHTML = 'Remove?';
          return;
        }
        clearTimeout(armed);
        try { renderDevices(await api('DELETE', `/api/devices/${d.id}`)); } catch { /* keep */ }
      });
      actions.appendChild(remove);
    }

    row.append(main, actions);
    return row;
  }

  function spaced(code) {
    return code.length === 8 ? `${code.slice(0, 4)} ${code.slice(4)}` : code;
  }

  el.devPair.addEventListener('click', async () => {
    let made;
    try {
      made = await api('POST', '/api/devices/pair');
    } catch {
      return;
    }
    el.pairBox.hidden = false;
    el.pairCode.textContent = spaced(made.code);
    el.pairUrl.value = `${location.origin}/?pair=${made.code}`;
    el.devPair.textContent = 'Make a new code';
    clearInterval(pairTimer);
    const tick = () => {
      const left = Math.max(0, Math.round((made.expires - Date.now()) / 1000));
      el.pairTimer.textContent = `${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}`;
      if (!left) {
        clearInterval(pairTimer);
        el.pairBox.hidden = true;
        el.devPair.textContent = 'Link another machine';
      }
    };
    tick();
    pairTimer = setInterval(tick, 1000);
  });

  el.pairCopy.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(el.pairUrl.value);
    } catch {
      el.pairUrl.select();
      document.execCommand('copy');
    }
    el.pairCopy.textContent = 'Copied';
    setTimeout(() => { el.pairCopy.textContent = 'Copy'; }, 1400);
  });

  /* ---------- wiring ---------- */

  $('openChats').addEventListener('click', () => open());
  $('closeDrawer').addEventListener('click', close);
  el.scrim.addEventListener('click', close);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isOpen) close();
  });

  /** A dot on the heart when she has noted something you haven't looked at yet. */
  async function checkMemory() {
    try {
      const { notes } = await api('GET', '/api/memory');
      if (notes.length > seen() && ctx.currentView?.() !== 'memory') el.memoryDot.hidden = false;
      else if (!notes.length) markSeen(0);
    } catch { /* ignore */ }
  }

  return { open, close, toggle: () => (isOpen ? close() : open()), isOpen: () => isOpen, refreshChats: () => isOpen && loadChats(), checkMemory, loadMemory, loadDevices };
}
