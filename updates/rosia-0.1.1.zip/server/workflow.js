/*
 * Reads a ComfyUI workflow as saved from the editor ("workflow.json", the graph with positions) and turns it
 * into the form the HTTP API runs, then fills in what changes for each picture: the prompt, the shape and the
 * seed. Everything else (models, LoRA, sampler, steps, sage attention, negative prompt) is whatever the
 * workflow says, so changing it in ComfyUI changes what she draws.
 *
 * Pure functions: node definitions (`info`, from ComfyUI's /object_info) are passed in.
 */

const VALUE_TYPES = new Set(['INT', 'FLOAT', 'STRING', 'BOOLEAN', 'COMBO']);
const PASS_THROUGH = new Set(['Reroute', 'PrimitiveNode']);
const UI_ONLY = new Set(['Note', 'MarkdownNote']);

const isValueSpec = (spec) => Array.isArray(spec?.[0]) || VALUE_TYPES.has(spec?.[0]);

/** The widget inputs of a node type, in the order the editor stores their values. */
function widgetNames(def) {
  const order = def.input_order || { required: Object.keys(def.input?.required || {}), optional: Object.keys(def.input?.optional || {}) };
  const out = [];
  for (const group of ['required', 'optional']) {
    for (const name of order[group] || []) {
      const spec = def.input?.[group]?.[name];
      if (isValueSpec(spec)) out.push({ name, afterGenerate: Boolean(spec[1]?.control_after_generate) });
    }
  }
  return out;
}

/**
 * @param ui    the saved workflow: { nodes, links }
 * @param info  { [classType]: { input, input_order } }
 * @returns { prompt, nodes }  prompt is { [id]: { class_type, inputs } }; nodes maps id -> { type, title }
 */
export function uiToApi(ui, info) {
  const nodes = new Map((ui.nodes || []).map((n) => [n.id, n]));
  const links = new Map((ui.links || []).map(([id, from, slot, to, toSlot, type]) => [id, { from, slot, to, toSlot, type }]));

  // follow a link back through reroutes and bypassed nodes to a real node
  const resolve = (linkId, depth = 0) => {
    const link = links.get(linkId);
    if (!link || depth > 40) return null;
    const src = nodes.get(link.from);
    if (!src) return null;
    if (src.mode === 2) return null; // muted
    if (PASS_THROUGH.has(src.type) || src.mode === 4) {
      // a bypassed node hands on its first input of the same kind as the output that was asked for
      const wanted = src.outputs?.[link.slot]?.type;
      const through = (src.inputs || []).find((i) => i.link != null && (PASS_THROUGH.has(src.type) || i.type === wanted));
      return through ? resolve(through.link, depth + 1) : null;
    }
    return { id: String(src.id), slot: link.slot };
  };

  const prompt = {};
  const meta = {};
  for (const node of nodes.values()) {
    if (UI_ONLY.has(node.type) || PASS_THROUGH.has(node.type) || node.mode === 2 || node.mode === 4) continue;
    const def = info[node.type];
    if (!def) throw new Error(`The workflow uses a node (${node.type}) that the image generator does not have. Is its custom node enabled?`);

    const inputs = {};
    for (const input of node.inputs || []) {
      if (input.link == null) continue;
      const src = resolve(input.link);
      if (src) inputs[input.name] = [src.id, src.slot];
    }

    // the saved values, in the editor's order; the extra "randomize" after a seed is not an input
    const values = [...(node.widgets_values || [])];
    let i = 0;
    for (const w of widgetNames(def)) {
      if (i >= values.length) break;
      const value = values[i];
      i += 1;
      if (w.afterGenerate) i += 1;
      if (!(w.name in inputs)) inputs[w.name] = value;
    }
    prompt[String(node.id)] = { class_type: node.type, inputs };
    meta[String(node.id)] = { type: node.type, title: node.title || '' };
  }
  return { prompt, nodes: meta };
}

/* ---------- filling in what changes per picture ---------- */

/** "{prompt}" in the workflow's positive text marks where the request goes. */
export function composeText(template, request) {
  const text = String(template ?? '');
  if (text.includes('{prompt}')) return text.split('{prompt}').join(request);
  // No marker: keep only the leading style/trigger words (up to the first bracketed group), then the request.
  const lead = /^[^(]*\([^)]*\)/.exec(text)?.[0] || (text.length < 80 ? text : '');
  return [lead.trim().replace(/[,\s]+$/, ''), request].filter(Boolean).join(' ');
}

/** The picture size for a requested shape, keeping the pixel count the workflow was built for. */
export function shapeFor(width, height, orientation) {
  const round = (n) => Math.max(256, Math.round(n / 16) * 16);
  const short = Math.min(width, height);
  const long = Math.max(width, height);
  if (orientation === 'landscape') return { width: round(long), height: round(short) };
  if (orientation === 'square') {
    const side = Math.sqrt(width * height);
    return { width: round(side), height: round(side) };
  }
  return { width: round(short), height: round(long) };
}

/**
 * The picture size for a requested shape at a given long side, in multiples of 16:
 * portrait 3:4 (576x768 at 768), landscape 4:3 (768x576), square 1:1 (768x768).
 * This is the size that is actually asked for unless `longSide` is 0.
 */
export function targetSize(orientation, longSide) {
  const round = (n) => Math.max(256, Math.round(n / 16) * 16);
  const long = round(Number(longSide) || 768);
  const short = round(long * 0.75);
  if (orientation === 'landscape') return { width: long, height: short };
  if (orientation === 'square') return { width: long, height: long };
  return { width: short, height: long };
}

/**
 * Sets the prompt, shape and seed in an API prompt (in place) and swaps the saving node for a temporary preview,
 * so pictures do not pile up in ComfyUI's output folder. Returns what it needs to know: steps, size.
 */
export function fill(api, { text, orientation, seed, longSide = 0, sampling = null }) {
  const { prompt } = api;
  const entries = Object.entries(prompt);
  const sampler = entries.find(([, n]) => /^KSampler/.test(n.class_type) || n.class_type === 'SamplerCustom');
  if (!sampler) throw new Error('The workflow has no sampler.');

  // the positive prompt is whichever text node feeds the sampler's "positive" input
  const positiveRef = sampler[1].inputs.positive;
  const positive = positiveRef && prompt[positiveRef[0]];
  if (!positive || positive.class_type !== 'CLIPTextEncode') throw new Error("The workflow's positive prompt is not a plain text node.");
  positive.inputs.text = composeText(positive.inputs.text, text);

  let size = null;
  for (const [, n] of entries) {
    if (/^Empty.*LatentImage$/.test(n.class_type) && 'width' in n.inputs) {
      // a long side means a fixed size for the requested shape (portrait 576x768, landscape 768x576, square
      // 768x768 at 768); 0 keeps the shape and pixel count the workflow was built for
      const { width, height } = longSide
        ? targetSize(orientation, longSide)
        : shapeFor(Number(n.inputs.width), Number(n.inputs.height), orientation);
      n.inputs.width = width;
      n.inputs.height = height;
      size = { width, height };
    }
    if (n.class_type === 'SaveImage') {
      n.class_type = 'PreviewImage';
      delete n.inputs.filename_prefix;
    }
  }
  for (const key of ['seed', 'noise_seed']) if (key in sampler[1].inputs && !Array.isArray(sampler[1].inputs[key])) sampler[1].inputs[key] = seed;

  // A faster sampler than the one saved in the workflow, if asked: fewer model passes per picture
  // (res_2s runs the model twice per step; euler once). Only the sampler's own settings change.
  if (sampling) {
    for (const key of ['sampler_name', 'scheduler', 'steps']) if (sampling[key] !== undefined && key in sampler[1].inputs) sampler[1].inputs[key] = sampling[key];
  }

  return { steps: Number(sampler[1].inputs.steps) || 0, size };
}
