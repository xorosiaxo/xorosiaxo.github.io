import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';
import { coalescedWriter } from '../atomic.js';
import { describeItem, extractStrip, DESC_VERSION } from '../gifs/describe.js';
import { isClearedName } from '../gifs/library.js';
import { record } from '../metrics.js';
import { debug } from '../debuglog.js';
import { loadVideos, videoKey, checkLink, expiryOf } from './links.js';

/*
 * What each saved video is. The videos themselves are only links (videos.json, written by the BetterDiscord plugin), so
 * this keeps its own small catalogue beside the GIF one (data/gifs/video-library.json): a few frames are cut straight
 * from the link, the vision model describes them, and the description becomes a vector so a video can be found by meaning.
 *
 * An entry: { key, url, name, label, status, description, reaction, tags, adult, vec, vecKind, tries, why }
 * status: pending | ok (can be sent) | skip (never sent: see `why`) | error (retried, up to three times)
 */

const write = coalescedWriter('videos');
const entries = new Map();
let loaded = false;

const catalogFile = () => path.join(config.dataDir, 'gifs', 'video-library.json');

export async function loadVideoCatalog() {
  if (loaded) return;
  loaded = true;
  try {
    for (const e of JSON.parse(await fs.promises.readFile(catalogFile(), 'utf8'))) entries.set(e.key, e);
  } catch {
    /* no catalogue yet */
  }
}

export const saveVideoCatalog = () => write(catalogFile(), () => JSON.stringify([...entries.values()]));

/** Brings the catalogue in line with videos.json: new links wait to be looked at, removed ones go, renewed links replace old ones. */
export async function syncVideoCatalog() {
  await loadVideoCatalog();
  const list = loadVideos();
  const seen = new Set();
  let changed = 0;
  for (const v of list) {
    const key = videoKey(v.url);
    seen.add(key);
    const hit = entries.get(key);
    if (!hit) {
      entries.set(key, { key, url: v.url, name: v.name, label: v.label, status: 'pending', tries: 0, addedAt: Date.now() });
      changed += 1;
      continue;
    }
    if (hit.url !== v.url) {
      hit.url = v.url; // the plugin renewed it
      delete hit.upgradeFailed; // a fresh link may work where the old one did not
      // one that could not be reached may work now that its link is fresh
      if (hit.status === 'skip' && /link/.test(hit.why || '')) Object.assign(hit, { status: 'pending', why: undefined, tries: 0 });
      changed += 1;
    }
    // flagged earlier, and since cleared by a person: looked at again, and kept this time
    if (isFlaggedVideo(hit) && isClearedName(path.basename(String(hit.key).split('?')[0]))) {
      Object.assign(hit, { status: 'pending', why: undefined, tries: 0, cleared: true });
      changed += 1;
    }
    hit.name = v.name;
    hit.label = v.label;
  }
  // only drop entries when the list could be read at all, so a file being rewritten does not wipe the catalogue
  if (list.length) {
    for (const key of [...entries.keys()]) {
      if (!seen.has(key)) {
        entries.delete(key);
        changed += 1;
      }
    }
  }
  if (changed) await saveVideoCatalog();
  return changed;
}

/** Whether a link is worth trying now: a signed Discord link past its expiry waits for the plugin to renew it. */
const fresh = (e) => !expiryOf(e.url) || expiryOf(e.url) > Date.now() + 60_000;

export function nextPendingVideo() {
  for (const e of entries.values()) if ((e.status === 'pending' || (e.status === 'error' && e.tries < 3)) && fresh(e)) return e;
  return null;
}

export function videoCatalogStats() {
  const by = { pending: 0, ok: 0, skip: 0, error: 0 };
  let adult = 0;
  let fuller = 0;
  for (const e of entries.values()) {
    by[e.status] = (by[e.status] || 0) + 1;
    if (e.status === 'ok' && e.adult) adult += 1;
    if (e.status === 'ok' && (e.descVersion || 1) >= 2) fuller += 1;
  }
  return { total: entries.size, ...by, adult, fuller };
}

export const isFlaggedVideo = (e) => e.status === 'skip' && /under 18/.test(e.why || '');
export const flaggedVideos = () => [...entries.values()].filter(isFlaggedVideo);

/** The saved videos that can be sent, as the picker wants them: the link plus what was learned about it. */
export function eligibleVideos() {
  return [...entries.values()]
    .filter((e) => e.status === 'ok')
    .map((e) => ({ url: e.url, name: e.name, label: e.label, adult: Boolean(e.adult), description: [e.reaction, e.useWhen, e.description].filter(Boolean).join(' '), vec: e.vec, vecKind: e.vecKind }));
}

/** Looks at one pending video. Returns true if there was one. deps are for tests. */
export async function indexNextVideo(deps = {}) {
  const entry = nextPendingVideo();
  if (!entry) return false;
  const began = Date.now();
  try {
    const state = await (deps.check || checkLink)(entry.url);
    if (!state.ok) {
      // a link that does not answer is tried again later (the plugin renews links); three failures park it until its link changes
      entry.tries = (entry.tries || 0) + 1;
      entry.status = entry.tries >= 3 ? 'skip' : 'error';
      entry.why = entry.tries >= 3 ? `link not working: ${state.reason}` : undefined;
      return true;
    }
    const cleared = isClearedName(videoKey(entry.url).split('/').pop() || '');
    const result = await describeItem({ name: entry.label || entry.name, cleared }, { ...deps, file: entry.url, strip: deps.strip || ((link) => extractStrip(link, { video: true })) });
    Object.assign(entry, result, { cleared: cleared || undefined });
    debug('video.index', { file: String(entry.key).split('?')[0].split('/').pop(), status: entry.status, why: entry.why, reaction: entry.reaction, adult: entry.adult, ms: Date.now() - began });
    entry.tries = 0;
    delete entry.lastError;
    record('job', { name: 'video', ok: true, ms: Date.now() - began });
  } catch (err) {
    entry.tries = (entry.tries || 0) + 1;
    entry.status = entry.tries >= 3 ? 'skip' : 'error';
    entry.why = entry.tries >= 3 ? `could not be read: ${String(err.message).slice(0, 100)}` : undefined;
    entry.lastError = String(err.message || err).slice(0, 160);
    debug('video.index.failed', { file: String(entry.key).split('?')[0].split('/').pop(), tries: entry.tries, error: err });
    record('job', { name: 'video', ok: false, ms: Date.now() - began });
  }
  return true;
}

/** The next video with an older, shorter description to describe again (only while its link still works). */
export function nextVideoUpgrade() {
  if (!config.gifs.redescribe) return null;
  for (const e of entries.values()) if (e.status === 'ok' && (e.descVersion || 1) < DESC_VERSION && !e.upgradeFailed && fresh(e)) return e;
  return null;
}

/** How many videos still have an older description (and could be redone). */
export const videosToUpgrade = () => [...entries.values()].filter((e) => e.status === 'ok' && (e.descVersion || 1) < DESC_VERSION && !e.upgradeFailed && (config.gifs.redescribe && fresh(e))).length;

/** Describes one video again with the fuller prompt; the old description is kept if that fails. Returns true if there was one. */
export async function upgradeNextVideo(deps = {}) {
  const entry = nextVideoUpgrade();
  if (!entry) return false;
  const began = Date.now();
  const file = String(entry.key).split('?')[0].split('/').pop();
  try {
    const state = await (deps.check || checkLink)(entry.url);
    if (!state.ok) throw new Error(`link not working: ${state.reason}`);
    const cleared = isClearedName(videoKey(entry.url).split('/').pop() || '');
    const result = await describeItem({ name: entry.label || entry.name, cleared }, { ...deps, file: entry.url, strip: deps.strip || ((link) => extractStrip(link, { video: true })) });
    Object.assign(entry, result, { cleared: cleared || undefined });
    debug('video.redescribe', { file, status: entry.status, reaction: entry.reaction, ms: Date.now() - began });
  } catch (err) {
    entry.upgradeFailed = true;
    debug('video.redescribe.failed', { file, error: err });
  }
  return true;
}

/** Catalogued videos whose vector is not of the kind the embedding model gives now (see reembedStale in indexer.js). */
export const staleVideoVectors = (kind) => [...entries.values()].filter((e) => e.status === 'ok' && e.vec && e.vecKind !== kind);

export const videoIndexerError = () => [...entries.values()].filter((e) => e.status === 'error').map((e) => e.lastError).filter(Boolean).pop() || '';

/** For tests. */
export function resetVideoCatalog() {
  entries.clear();
  loaded = false;
}
