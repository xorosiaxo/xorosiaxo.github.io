import { defineTool } from './registry.js';
import { gifsConfigured, libraryStats, getItem, publicGif } from '../gifs/library.js';
import { pickGif, adultOk, repliesSinceGif } from '../gifs/pick.js';

/*
 * Sends a GIF from her collection as a reaction. It is offered to the model only once some clips have been catalogued.
 * When the person asks for one outright (preflight.js) the tool is run for her; on her own she is held to a gap of a few
 * replies so GIFs stay a treat rather than a habit.
 */
if (gifsConfigured()) {
  defineTool({
    name: 'send_gif',
    description:
      'Send a GIF from your collection as a reaction, instead of or as well as words. Use it RARELY: only when a GIF says it ' +
      'better than a sentence would (a smug look, an eye roll, a celebration) or when they ask for one. Describe the feeling ' +
      'you want to send in a few words, not the clip. The GIF appears under your message by itself: do not describe it.',
    parameters: {
      type: 'object',
      properties: { vibe: { type: 'string', description: 'The feeling or reaction to send, in a few words, e.g. "smug eye roll" or "celebrating".' } },
      required: ['vibe']
    },
    available: () => libraryStats().ok > 0,
    async run({ vibe, asked }, ctx) {
      const session = ctx.session;
      if (!asked && repliesSinceGif(session) < 3) throw new Error('You sent a GIF a moment ago. Just talk this time.');
      const choice = await pickGif({ vibe, session, userId: session.userId, allowAdult: adultOk(session) });
      if (!choice) throw new Error('Nothing in the collection matches that feeling.');
      const view = publicGif(choice.item.id);
      return { gif: true, id: choice.item.id, kind: view.kind, name: getItem(choice.item.id)?.reaction || '' };
    }
  });
}
