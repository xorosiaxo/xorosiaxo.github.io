/*
 * Background jobs (extracting memories, summarising, titles) share one model server with the live
 * chat. They run one at a time and only while no reply is being generated, so they never make a
 * message wait.
 */

import { record } from './metrics.js';

let waiting = 0;
let activeChats = 0;
let activeJobs = 0;
let held = false; // the graphics card is lent to the image generator: nothing may use the model
let lastActivity = 0;
let queue = Promise.resolve();

export function chatStarted() {
  activeChats += 1;
}

export function chatEnded() {
  activeChats = Math.max(0, activeChats - 1);
  lastActivity = Date.now();
}

/** Someone has just sent something (even if their reply has to wait for the graphics card): background work steps aside. */
export function noteActivity() {
  lastActivity = Date.now();
}

export function isBusy() {
  return activeChats > 0;
}

/** No reply is being written and no background job is running: the model can be taken away. */
export function isQuiet() {
  return activeChats === 0 && activeJobs === 0;
}

/** While held, background jobs wait (the model is off the card). */
export function holdModel(on) {
  held = Boolean(on);
}

export function msSinceActivity() {
  return Date.now() - lastActivity;
}

async function whenIdle() {
  const blocked = () => activeChats > 0 || held;
  // wait for the model to be free, then a short beat so a quick follow-up message wins
  for (let i = 0; i < 1200 && blocked(); i += 1) await new Promise((r) => setTimeout(r, 500));
  await new Promise((r) => setTimeout(r, 1500));
  for (let i = 0; i < 1200 && blocked(); i += 1) await new Promise((r) => setTimeout(r, 500));
}

/** Queue a background job. Errors are logged, never thrown. */
export function background(label, job) {
  waiting += 1;
  queue = queue
    .then(async () => {
      await whenIdle();
      const started = Date.now();
      activeJobs += 1;
      try {
        await job();
        record('job', { name: label, ok: true, ms: Date.now() - started });
      } catch (err) {
        record('job', { name: label, ok: false, ms: Date.now() - started });
        record('error', { where: `job:${label}`, message: String(err?.message || err).replace(/https?:\/\/\S+/g, '<link>').slice(0, 120) });
        throw err;
      } finally {
        activeJobs -= 1;
      }
    })
    .catch((err) => console.error(`[${label}] failed:`, err?.message || err))
    .finally(() => {
      waiting -= 1;
    });
  return queue;
}

/** Background jobs queued or running, for the status page. */
export function queuedJobs() {
  return waiting;
}
