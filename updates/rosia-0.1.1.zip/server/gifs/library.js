import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { coalescedWriter } from '../atomic.js';

/*
 * Her collection of GIFs and short clips. The files stay where they are (config.gifs.dir, filled by the
 * BetterDiscord export plugin: tools/betterdiscord/RosiaGifExport.plugin.js); this keeps a small catalogue of them
 * in data/gifs/library.json: what each one is, what feeling it carries, and a vector for finding it by meaning.
 *
 * An item: { id, file, name, kind: 'gif'|'video'|'image', ext, status, description, reaction, tags, adult, vec, vecKind }
 * status: pending (not looked at yet) | ok (can be sent) | skip (never sent: see `why`) | error (could not be read, retried later)
 */

const write = coalescedWriter('gifs');
const items = new Map();
let loaded = false;

const libraryFile = () => path.join(config.dataDir, 'gifs', 'library.json');
const idOf = (file) => crypto.createHash('md5').update(String(file)).digest('hex').slice(0, 12);

export const GIF_ID = /^[a-f0-9]{12}$/;
export const MIME = { '.gif': 'image/gif', '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.mp4': 'video/mp4', '.webm': 'video/webm' };

/** True when a folder of GIFs is set up and has the export plugin's list in it. */
export function gifsConfigured() {
  const dir = config.gifs.dir;
  return Boolean(dir) && fs.existsSync(path.join(dir, 'index.json'));
}

export async function loadLibrary() {
  if (loaded) return;
  loaded = true;
  try {
    const list = JSON.parse(await fs.promises.readFile(libraryFile(), 'utf8'));
    for (const item of list) items.set(item.id, item);
  } catch {
    /* no catalogue yet */
  }
}

export function saveLibrary() {
  return write(libraryFile(), () => JSON.stringify([...items.values()]));
}

/** Adds anything new from the folder's index.json, and marks files that have gone missing. Returns how many were added. */
export async function syncLibrary() {
  await loadLibrary();
  if (!gifsConfigured()) return 0;
  const dir = config.gifs.dir;
  let list = [];
  try {
    list = JSON.parse(await fs.promises.readFile(path.join(dir, 'index.json'), 'utf8'));
  } catch {
    return 0; // being written right now: next time
  }
  let added = 0;
  for (const entry of list) {
    const file = path.basename(String(entry.file || ''));
    const ext = path.extname(file).toLowerCase();
    if (!file || !MIME[ext]) continue;
    const id = idOf(file);
    if (items.has(id)) continue;
    items.set(id, {
      id,
      file,
      name: String(entry.name || '').slice(0, 120),
      kind: entry.kind === 'video' ? 'video' : entry.kind === 'image' ? 'image' : 'gif',
      ext,
      status: entry.kind === 'image' ? 'skip' : 'pending',
      ...(entry.kind === 'image' ? { why: 'a still picture, not a clip' } : {}),
      tries: 0,
      addedAt: Date.now()
    });
    added += 1;
  }
  const cleared = await applyCleared(); // before the check below, so a clip brought back is not taken for a missing one
  for (const item of items.values()) {
    // a file that is not in the main folder but is in flagged/ was moved there (by the app, or by hand): it is not missing
    if (!item.quarantined && !fs.existsSync(fileFor(item)) && fs.existsSync(path.join(flaggedDir(), path.basename(item.file)))) item.quarantined = true;
    const missing = !fs.existsSync(fileFor(item));
    if (missing && item.status !== 'skip') Object.assign(item, { status: 'skip', why: 'file missing' });
  }
  if (added || cleared) await saveLibrary();
  return added;
}

export const allItems = () => [...items.values()];
export const getItem = (id) => items.get(id);

/** The next item that still needs looking at (never one that has failed three times). */
export function nextPending() {
  for (const item of items.values()) if (item.status === 'pending' || (item.status === 'error' && item.tries < 3)) return item;
  return null;
}

/** The next `count` items that still need looking at, in order. */
export function pendingItems(count = 2) {
  const out = [];
  for (const item of items.values()) {
    if (item.status === 'pending' || (item.status === 'error' && item.tries < 3)) out.push(item);
    if (out.length >= count) break;
  }
  return out;
}

export function fileFor(item) {
  const dir = config.gifs.dir;
  if (!dir || !item) return null;
  // never anything outside the folder; clips that were flagged live in its "flagged" subfolder
  return path.join(item.quarantined ? path.join(dir, 'flagged') : dir, path.basename(item.file));
}

/* ---------- clips flagged as possibly showing someone under 18 are moved into a "flagged" folder ---------- */

export const flaggedDir = () => (config.gifs.dir ? path.join(config.gifs.dir, 'flagged') : '');
export const isFlagged = (item) => item.status === 'skip' && /under 18/.test(item.why || '') && !item.cleared;

/*
 * Clips a person has looked at themselves and cleared. Their file names are listed in data/gifs/cleared.json (a JSON
 * array). A cleared clip is described again and can be sent even if the model still thinks it might show a minor, and if
 * it had been moved into flagged/ it is moved back.
 */
function clearedNames() {
  try {
    return new Set(JSON.parse(fs.readFileSync(path.join(config.dataDir, 'gifs', 'cleared.json'), 'utf8')).map((n) => path.basename(String(n))));
  } catch {
    return new Set();
  }
}

/** True when a person has cleared this file name (a saved video's name is the last part of its link). */
export const isClearedName = (name) => clearedNames().has(path.basename(String(name)));

/** Moves a clip's file back out of the flagged folder. */
export async function restore(item) {
  const dir = config.gifs.dir;
  const name = path.basename(item.file);
  const from = path.join(flaggedDir(), name);
  const to = path.join(dir, name);
  if (fs.existsSync(from) && !fs.existsSync(to)) await fs.promises.rename(from, to);
  item.quarantined = false;
}

async function applyCleared() {
  const cleared = clearedNames();
  let changed = 0;
  for (const item of items.values()) {
    if (!cleared.has(item.file)) continue;
    // the file may be in flagged/ whether or not the library knew it had been moved (it can be moved by hand or by the report script)
    const inFlagged = fs.existsSync(path.join(flaggedDir(), path.basename(item.file)));
    const needsWork = !item.cleared || item.quarantined || inFlagged || (item.status === 'skip' && /under 18|file missing/.test(item.why || ''));
    if (!needsWork) continue;
    item.cleared = true;
    if (inFlagged || item.quarantined) await restore(item);
    if (item.status === 'skip' && /under 18|file missing/.test(item.why || '')) {
      Object.assign(item, { status: 'pending', why: undefined, tries: 0 });
      delete item.dupOf;
    }
    changed += 1;
  }
  return changed;
}

/** Moves a flagged clip's file into the flagged folder (nothing is deleted). Safe to repeat. */
export async function quarantine(item) {
  const dir = config.gifs.dir;
  if (!dir) return false;
  const name = path.basename(item.file);
  const from = path.join(dir, name);
  const to = path.join(flaggedDir(), name);
  await fs.promises.mkdir(flaggedDir(), { recursive: true });
  if (fs.existsSync(from) && !fs.existsSync(to)) await fs.promises.rename(from, to);
  if (fs.existsSync(to)) item.quarantined = true;
  return Boolean(item.quarantined);
}

/** Moves every flagged clip that is not in the flagged folder yet. Returns how many were moved. */
export async function sweepFlagged() {
  let moved = 0;
  for (const item of items.values()) {
    if (isFlagged(item) && !item.quarantined) {
      try {
        if (await quarantine(item)) moved += 1;
      } catch {
        /* the file is open or locked: next time */
      }
    }
  }
  if (moved) await saveLibrary();
  return moved;
}

/** What the page needs to show one: no file names, no descriptions. */
export function publicGif(id) {
  const item = items.get(id);
  if (!item) return undefined;
  return { id: item.id, kind: item.ext === '.mp4' || item.ext === '.webm' ? 'video' : 'image' };
}

export function libraryStats() {
  const by = { pending: 0, ok: 0, skip: 0, error: 0 };
  let adult = 0;
  let fuller = 0; // described with the fuller (version 2) prompt
  for (const item of items.values()) {
    by[item.status] = (by[item.status] || 0) + 1;
    if (item.status === 'ok' && item.adult) adult += 1;
    if (item.status === 'ok' && (item.descVersion || 1) >= 2) fuller += 1;
  }
  return { enabled: gifsConfigured(), total: items.size, ...by, adult, fuller };
}

/** For tests. */
export function resetLibrary() {
  items.clear();
  loaded = false;
}
