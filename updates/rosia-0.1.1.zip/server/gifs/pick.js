import { embed } from '../embed.js';
import { config } from '../config.js';
import { allItems, getItem } from './library.js';
import { matchFloor, pickByMeaning, noteSent, sentLately, SENT_STRICT } from '../media-match.js';

/*
 * Choosing a GIF: by meaning (the feeling she wants to send against what each clip was catalogued as; see media-match.js),
 * never one she has sent this person lately (in any of their chats, across restarts) nor a copy of it, and never an adult
 * one unless the conversation has already gone that way.
 */

/** Two copies of one clip (the same GIF saved from two places) count as one. */
export const gifKey = (item) => item.dupOf || item.id;

/** Remembers that a GIF was sent to this person. */
export function remember(userId, id) {
  const item = getItem(id);
  noteSent(userId, 'gif', item ? gifKey(item) : id);
}

/** How many of her replies have gone by since the last GIF in this conversation (Infinity if none was sent). */
export function repliesSinceGif(session) {
  let count = 0;
  for (let i = session.messages.length - 1; i >= 0; i -= 1) {
    const m = session.messages[i];
    if (m.role !== 'assistant') continue;
    if (m.gif) return count;
    count += 1;
  }
  return Infinity;
}

// "hard" and "wet" only count in a sexual phrase ("this exam is so hard" and "it's wet outside" are not), and "ass" not in
// "kick ass", "smart ass", "lazy ass" and the like
const SPICY_WORDS = /\b(fuck|fucking|cock|dick|pussy|cum|horny|naked|nude|nudes|sex|sexy|tits|boobs|moan|moaning|slut|blowjob|porn)\b|\blick (?:me|my|it|you|your)\b|\bsuck (?:my|me|it|on)\b|\b(?:make me|making me|got me|gets me|getting me|i'?m|im|you'?re|ur|you are)\s+(?:so+\s+|really\s+)?(?:hard|wet)\b|\brock hard\b|\bdripping\b|(?<!\b(?:kick|smart|lazy|bad|dumb|half|jack|wise|hard|pain in the|big)[- ]?)\bass\b/i;

/**
 * Adult clips, videos and pictures are only offered once the PERSON has taken the conversation there, in their own words in one of
 * their last three messages. Her mood alone does not count: a small model tags "gimme a kiss" as [aroused], and that is how a
 * tester asking for a kiss was sent explicit porn.
 */
export function adultOk(session) {
  const theirs = session.messages.filter((m) => m.role === 'user').slice(-3);
  return theirs.some((m) => SPICY_WORDS.test(String(m.content || '')));
}

/** How similar a clip's catalogue entry must be to the feeling asked for (depends on the embedding model). */
export const floorFor = (kind, purpose = 'ask') => matchFloor(kind, purpose);

/**
 * The clip that best matches `vibe`, or null.
 * { vibe, session, userId, allowAdult, purpose ('ask' | 'react'), rng } -> { item, score }
 */
export async function pickGif({ vibe, session, userId, allowAdult = false, purpose = 'ask', margin = 0, rng = Math.random }) {
  const pool = allItems().filter((i) => i.status === 'ok' && i.vec && (allowAdult || !i.adult));
  if (!pool.length || !String(vibe || '').trim()) return null;

  const query = await embed(String(vibe).slice(0, 400), 'query');
  const items = pool.filter((i) => i.vecKind === query.kind);
  // this chat's own GIFs count as sent too (also from before sends were remembered per person)
  const inChat = session.messages.filter((m) => m.gif).map((m) => getItem(m.gif)).filter(Boolean).map(gifKey);
  const recent = [...new Set([...inChat, ...(await sentLately(userId, 'gif'))])];
  const choice = pickByMeaning({
    items,
    query,
    keyOf: gifKey,
    vecOf: (i) => i.vec,
    recent,
    floor: floorFor(query.kind, purpose) + margin,
    strict: SENT_STRICT.gif,
    rng
  });
  if (choice) remember(userId, choice.item.id);
  return choice;
}

const REACTS_TO = new Set(['flirty', 'teasing', 'amused', 'ecstatic', 'smitten', 'aroused', 'surprised', 'warm']);

/**
 * After a reply: now and then, when her mood is strong and it has been a while, a clip that fits what she just said.
 * Never in a reply that already has a photo or a picture, and never twice in quick succession.
 */
export async function maybeReact({ session, userId, text, mood, photo, image, gif, rng = Math.random }) {
  if (photo || image || gif || !config.gifs.dir) return null;
  if (!String(text || '').trim() || !REACTS_TO.has(mood)) return null;
  if (repliesSinceGif(session) < config.gifs.minGap) return null;
  if (rng() >= config.gifs.chance) return null;
  return pickGif({ vibe: `${mood}. ${String(text).slice(0, 240)}`, session, userId, allowAdult: adultOk(session), purpose: 'react', rng });
}
