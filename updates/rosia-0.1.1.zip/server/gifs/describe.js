import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { config } from '../config.js';
import { complete as modelComplete } from '../llm.js';
import { embed } from '../embed.js';
import { fileFor } from './library.js';

/*
 * Looking at one clip: a few frames are cut out and laid side by side in one picture (scripts/gif_frames.py), the
 * vision model says what it is and what feeling it carries, and that sentence is turned into a vector so the clip can
 * later be found by meaning ("eye roll", "annoyed" and "unimpressed" all find the same one).
 */

const SCRIPT = path.resolve(import.meta.dirname, '..', '..', 'scripts', 'gif_frames.py');

/** A JPEG strip of frames from the file, as bytes. Throws with a readable reason. */
export function extractStrip(file, { video = false } = {}) {
  const out = path.join(os.tmpdir(), `rosia-strip-${crypto.randomBytes(6).toString('hex')}.jpg`);
  return new Promise((resolve, reject) => {
    execFile(config.gifs.python, [SCRIPT, file, out, '--frames', String(config.gifs.frames), ...(video ? ['--video'] : [])], { timeout: 90_000, windowsHide: true }, async (err, stdout, stderr) => {
      try {
        if (err && !stdout) {
          const missing = /No module named 'PIL'|ModuleNotFoundError/.test(String(stderr));
          throw new Error(missing ? 'Pillow is not installed for this Python (pip install pillow, or set ROSA_GIF_PYTHON)' : `could not run ${config.gifs.python}: ${String(err.message).slice(0, 80)}`);
        }
        let info;
        try {
          info = JSON.parse(String(stdout).trim().split('\n').pop());
        } catch {
          throw new Error('the frame cutter gave no answer');
        }
        if (!info.ok) throw new Error(info.error || 'no frames');
        resolve({ bytes: await fs.readFile(out), info });
      } catch (e) {
        reject(e);
      } finally {
        fs.rm(out, { force: true }).catch(() => {});
      }
    });
  });
}

/*
 * Version 2 of the catalogue entry. Version 1 was a one-line description under 15 words and a 3-to-6 word feeling, which
 * left hundreds of clips described alike ("A woman with blonde hair smiles seductively", reaction "Sultry, confident and
 * alluring"), so a request could not tell them apart and the same few kept coming back. Version 2 says who, wearing what,
 * where, doing what, how it is filmed, the exact message it sends, and the moment in a chat it suits. Clips described
 * with version 1 are described again in the background (see indexer.js).
 */
export const DESC_VERSION = 2;
const MOODS = ['funny', 'flirty', 'sexy', 'cute', 'happy', 'sad', 'angry', 'shocked', 'smug', 'bored', 'awkward', 'loving', 'sleepy', 'excited', 'other'];

const SYSTEM =
  'You catalogue short clips (GIFs and videos) for a chat companion who sends them as reactions in chat. You are shown up to 3 ' +
  'frames of ONE clip side by side, in time order. The frames are only how the clip is shown to you: never mention frames, panels, ' +
  'shots, a sequence or "first/second/third"; describe it as one moving clip ("she starts by..., then..."). No emoji. ' +
  'Reply with ONLY a JSON object:\n' +
  '{"description": "2 or 3 plain sentences, 30 to 60 words: who is in it (apparent gender, hair, clothing or lack of it), where they ' +
  'are, what they do from start to end, their facial expression, and how it is filmed (close-up, full body, selfie, from behind)",\n' +
  ' "reaction": "the exact feeling or message it sends in a chat, 3 to 8 words, specific: \'smug told-you-so smirk\', not \'playful vibe\'",\n' +
  ' "use_when": "one sentence: the moment in a conversation it is the perfect reply to, e.g. \'when they finally admit you were right\'",\n' +
  ` "mood": one of ${MOODS.join(', ')},\n` +
  ' "intensity": a number from 1 (mild, everyday) to 5 (over the top, or very explicit),\n' +
  ' "tags": ["6 to 10 lowercase words or short phrases: actions, emotions, people, clothing, setting"],\n' +
  ' "text": "any caption words that can be read in it, else empty",\n' +
  ' "adult": true if it shows nudity or sexual activity, else false,\n' +
  ' "young": true ONLY if someone shown clearly looks like a child or young teenager (a minor), including drawn or animated characters ' +
  'who are clearly children. Adults who simply look youthful, and adults in any clothing or costume, are NOT young: false for those}\n' +
  'Be literal and specific: two different clips should never get the same description or reaction. Do not moralise, refuse or add ' +
  'anything outside the JSON.';

/** Pulls the JSON object out of whatever the model wrote, and tidies it. Returns null when it is not usable. */
export function parseDescription(text) {
  const m = /\{[\s\S]*\}/.exec(String(text || ''));
  if (!m) return null;
  let raw;
  try {
    raw = JSON.parse(m[0]);
  } catch {
    return null;
  }
  const clean = (v, n) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, n);
  // "in three frames", "across the frames": how it was shown, not what it shows
  const unframe = (t) => t
    .replace(/\s*,?\s*\b(?:in|across|over|through(?:out)?)\s+(?:the\s+)?(?:three|two|3|2|several|multiple|these)?\s*(?:sequential\s+|consecutive\s+|close-up\s+)?(?:frames?|panels?|shots?)\b/gi, '')
    .replace(/\s*,?\s*\bin the (?:first|second|third|last|final|next) (?:frame|panel|shot)\b/gi, '')
    .replace(/\s+([.,])/g, '$1')
    .trim();
  const noEmoji = (t) => t.replace(/[\p{Extended_Pictographic}\u{FE0F}\u{200D}]/gu, '').replace(/\s{2,}/g, ' ').trim();
  const description = noEmoji(unframe(clean(raw.description, 500)));
  const reaction = noEmoji(clean(raw.reaction, 80));
  if (description.length < 8 && reaction.length < 3) return null;
  const tags = (Array.isArray(raw.tags) ? raw.tags : String(raw.tags || '').split(/[,;]/))
    .map((t) => clean(t, 30).toLowerCase())
    .filter(Boolean)
    .slice(0, 10);
  const mood = MOODS.includes(String(raw.mood || '').toLowerCase()) ? String(raw.mood).toLowerCase() : '';
  const intensity = Math.min(5, Math.max(0, Math.round(Number(raw.intensity) || 0)));
  return {
    description,
    reaction,
    useWhen: unframe(clean(raw.use_when ?? raw.useWhen, 200)),
    mood,
    intensity,
    tags,
    text: clean(raw.text, 120),
    adult: raw.adult === true || raw.adult === 'true',
    young: raw.young === true || raw.young === 'true'
  };
}

/** The text that is turned into a vector: the feeling and the moment it suits first, because that is what a reaction is looked up by. */
export function searchText(d) {
  return [d.reaction, d.useWhen, d.description, d.mood && `mood: ${d.mood}`, (d.tags || []).join(' '), d.text]
    .map((p) => String(p || '').trim().replace(/[.!?]+$/, ''))
    .filter(Boolean)
    .join('. ');
}

/**
 * Looks at one library item and returns the fields to store on it.
 * deps are for tests: { strip(file) -> {bytes}, complete(args), embedText(text) -> {vec, kind} }.
 */
export async function describeItem(item, deps = {}) {
  const strip = deps.strip || extractStrip;
  const ask = deps.complete || modelComplete;
  const vector = deps.embedText || ((t) => embed(t, 'document'));

  const file = deps.file ?? fileFor(item); // a saved video is a link, not a file in the folder
  const { bytes } = await strip(file);
  const url = `data:image/jpeg;base64,${bytes.toString('base64')}`;
  const answer = await ask({
    messages: [
      { role: 'system', content: SYSTEM },
      { role: 'user', content: [{ type: 'text', text: `Catalogue this clip${item.name ? ` (it was saved as "${item.name}")` : ''}.` }, { type: 'image_url', image_url: { url } }] }
    ],
    maxTokens: 420,
    temperature: 0.2
  });
  const d = parseDescription(answer);
  if (!d) throw new Error('the model did not describe it');

  // anyone who looks like a minor is never kept, whatever else the clip is (unless a person has looked at it and cleared it)
  if (d.young && !item.cleared) return { status: 'skip', why: 'might show someone under 18', adult: d.adult, descVersion: DESC_VERSION };
  const { vec, kind } = await vector(searchText(d));
  return { status: 'ok', description: d.description, reaction: d.reaction, useWhen: d.useWhen, mood: d.mood, intensity: d.intensity, tags: d.tags, text: d.text, adult: d.adult, vec, vecKind: kind, descVersion: DESC_VERSION };
}
