import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from './config.js';
import { embed, embedMany, hashEmbed, cosine, currentKind } from './embed.js';
import { coalescedWriter } from './atomic.js';

/*
 * Everything she remembers about a person, across all their conversations.
 * One file per person in data/users/ (see auth.js for who a request belongs to).
 *
 * A note is { id, text, at, source, vec, vecKind } plus, when relevant:
 *   expires  a time after which it no longer matters ("driving test on Friday"); it is kept but stops
 *            being used and is shown under "Past"
 *   prev     what it said before she corrected it (newest first), so a change is never silent
 */

const users = new Map();

function safeUserId(raw) {
  const id = String(raw || 'local').trim();
  return /^[A-Za-z0-9_-]{1,64}$/.test(id) ? id : 'local';
}

function fileFor(id) {
  return path.join(config.usersDir, `${id}.json`);
}

const loading = new Map(); // id -> the first read in progress: two loads at once must give the same object

export async function getUser(rawId = 'local') {
  const id = safeUserId(rawId);
  if (users.has(id)) return users.get(id);
  if (loading.has(id)) return loading.get(id);

  const job = (async () => {
    let data = {};
    try {
      data = JSON.parse(await fs.readFile(fileFor(id), 'utf8'));
    } catch {
      /* new user */
    }
    const sent = data.sent && typeof data.sent === 'object' ? data.sent : {};
    const user = {
      id,
      notes: Array.isArray(data.notes) ? data.notes : [],
      profile: typeof data.profile === 'string' ? data.profile : '',
      profileCount: data.profileCount || 0, // how many notes the profile was written from
      profileAt: data.profileAt || 0,
      lastSeenAt: data.lastSeenAt || 0,
      firstSeenAt: data.firstSeenAt || 0, // when they first talked to her (set by the chat route the first time it is missing)
      adultAt: data.adultAt || 0, // when they said they are 18 or over (see the age gate in index.js)
      // what she has sent them lately, newest last, across all their chats (see media-match.js), so nothing comes round again soon
      sent: { gif: list(sent.gif), video: list(sent.video), picture: list(sent.picture) }
    };
    users.set(id, user);
    return user;
  })().finally(() => loading.delete(id));
  loading.set(id, job);
  return job;
}

/** For tests: forgets what was sent to everyone loaded so far. */
export function clearSentForTests() {
  for (const u of users.values()) u.sent = { gif: [], video: [], picture: [] };
}

const list = (v) => (Array.isArray(v) ? v.filter((x) => typeof x === 'string').slice(-200) : []);

const write = coalescedWriter('user');

export function saveUser(user) {
  return write(fileFor(user.id), () => JSON.stringify(user));
}

/* ---------- reading ---------- */

export const isExpired = (note, now = Date.now()) => Boolean(note.expires && note.expires <= now);

/** The notes still in use. */
export function activeNotes(user, now = Date.now()) {
  return user.notes.filter((n) => !isExpired(n, now));
}

/** What the memory panel shows: no vectors. */
export function publicNotes(user, now = Date.now()) {
  return user.notes
    .map((n) => ({
      id: n.id,
      text: n.text,
      at: n.at,
      source: n.source,
      updated: Boolean(n.prev?.length),
      was: n.prev?.[0]?.text,
      until: n.expires || undefined,
      expired: isExpired(n, now)
    }))
    .sort((a, b) => b.at - a.at);
}

function duplicateThreshold(kind) {
  return kind === 'hash' ? 0.8 : 0.92;
}

// How similar a note must be to count as relevant. Models differ: EmbeddingGemma's related pairs score about
// 0.2 to 0.4 and unrelated ones stay under 0.08 (measured), where nomic-style models score everything higher.
const FLOORS = { embeddinggemma: 0.15, nomic: 0.45, bge: 0.5 };

function relevanceThreshold(kind) {
  if (kind === 'hash') return 0.17;
  if (config.embedFloor) return config.embedFloor;
  return FLOORS[config.embedStyle] ?? 0.35;
}

// Hash vectors are cheap and made on the spot, so they are only kept in memory: a moment when the embedding model is down
// must never overwrite the model's vectors stored on the notes (that used to mean re-embedding every note, one request
// at a time, before the next reply could start).
const hashOf = new WeakMap(); // note -> { text, vec }

function hashVector(note) {
  if (note.vecKind === 'hash' && note.vec) return note.vec;
  const hit = hashOf.get(note);
  if (hit && hit.text === note.text) return hit.vec;
  const vec = hashEmbed(note.text);
  hashOf.set(note, { text: note.text, vec });
  return vec;
}

/**
 * The vectors of `notes` in the embedding `kind`, in order. Notes that do not have one yet are embedded together in one
 * batch and keep it. Returns null when the embedding model cannot give that kind right now (the caller uses hash instead).
 */
async function vectorsFor(user, notes, kind) {
  if (kind === 'hash') return notes.map(hashVector);
  const missing = notes.filter((n) => !(n.vecKind === kind && n.vec));
  if (missing.length) {
    const { vecs, kind: madeBy } = await embedMany(missing.map((n) => n.text), 'document');
    if (madeBy !== kind) return null;
    missing.forEach((n, i) => {
      n.vec = vecs[i];
      n.vecKind = kind;
    });
    saveUser(user); // so they are not made again after a restart
  }
  return notes.map((n) => n.vec);
}

/** Vectors for the query and the notes in the same kind: the model's when it answers, otherwise hash for both. */
async function scoredSpace(user, notes, text, role) {
  const q = await embed(text, role);
  const vecs = await vectorsFor(user, notes, q.kind);
  if (vecs) return { query: q.vec, kind: q.kind, vecs };
  return { query: hashEmbed(text), kind: 'hash', vecs: notes.map(hashVector) };
}

const clean = (raw) => String(raw || '').replace(/\s+/g, ' ').trim().slice(0, 200);

/* ---------- writing ---------- */

/** `until` (a timestamp) marks a fact that stops mattering after that moment. */
export async function addNote(user, rawText, source = 'auto', { until } = {}) {
  const text = clean(rawText);
  if (text.length < 3) return { note: null, created: false };

  // a near-copy of something already known only refreshes it
  const existingNotes = [...user.notes];
  const space = await scoredSpace(user, existingNotes, text, 'document');
  const { query: vec, kind } = space;
  for (const [i, existing] of existingNotes.entries()) {
    if (cosine(vec, space.vecs[i]) >= duplicateThreshold(kind)) {
      existing.at = Date.now();
      if (source === 'user') existing.source = 'user';
      if (text.length > existing.text.length && existing.source !== 'user') {
        existing.text = text;
        existing.vec = vec;
        existing.vecKind = kind;
        hashOf.delete(existing);
      }
      if (until) existing.expires = until;
      else if (isExpired(existing)) delete existing.expires; // said again: it is current again
      await saveUser(user);
      return { note: existing, created: false };
    }
  }

  const note = { id: crypto.randomBytes(6).toString('hex'), text, at: Date.now(), source, vec, vecKind: kind };
  if (until) note.expires = until;
  user.notes.push(note);

  // keep the store bounded: the oldest automatic notes go first. Never the note just added, and never a note the person
  // wrote themselves (if only those are left, the store is allowed to grow past the limit).
  while (user.notes.length > config.memoryMax) {
    const candidates = user.notes.filter((n) => n.source !== 'user' && n !== note);
    if (!candidates.length) break;
    const oldest = candidates.reduce((a, b) => (b.at < a.at ? b : a));
    user.notes.splice(user.notes.indexOf(oldest), 1);
  }
  await saveUser(user);
  return { note, created: true };
}

/**
 * Changes a note. A person's own edit makes it theirs ("you"); a correction she makes herself
 * (`system: true`) keeps what it said before in `prev` and never touches notes written by the person.
 */
export async function updateNote(user, id, rawText, { system = false } = {}) {
  const note = user.notes.find((n) => n.id === id);
  const text = clean(rawText);
  if (!note || text.length < 3) return null;
  if (system && note.source === 'user') return null;
  const { vec, kind } = await embed(text, 'document');
  if (system) {
    note.prev = [{ text: note.text, at: note.at }, ...(note.prev || [])].slice(0, 3);
    Object.assign(note, { text, vec, vecKind: kind, at: Date.now() });
  } else {
    Object.assign(note, { text, vec, vecKind: kind, at: Date.now(), source: 'user' });
    delete note.expires; // they have said what is true now
  }
  await saveUser(user);
  return note;
}

export async function deleteNote(user, id, { system = false } = {}) {
  const note = user.notes.find((n) => n.id === id);
  if (!note || (system && note.source === 'user')) return false;
  user.notes = user.notes.filter((n) => n.id !== id);
  await saveUser(user);
  return true;
}

/** Folds near-identical notes into one. Notes written by the person always win. Returns how many were dropped. */
export async function mergeDuplicates(user) {
  let kind = currentKind();
  const notes = activeNotes(user);
  const drop = new Set();
  let vecs = await vectorsFor(user, notes, kind);
  if (!vecs) {
    kind = 'hash';
    vecs = notes.map(hashVector);
  }

  for (let i = 0; i < notes.length; i += 1) {
    if (drop.has(notes[i].id)) continue;
    for (let j = i + 1; j < notes.length; j += 1) {
      if (drop.has(notes[j].id)) continue;
      if (cosine(vecs[i], vecs[j]) < duplicateThreshold(kind)) continue;
      const [a, b] = [notes[i], notes[j]];
      // keep the person's own note, otherwise the newer one
      const keep = a.source === 'user' && b.source !== 'user' ? a : b.source === 'user' && a.source !== 'user' ? b : a.at >= b.at ? a : b;
      const lose = keep === a ? b : a;
      if (lose.source === 'user') continue; // two of their own: leave both
      drop.add(lose.id);
    }
  }
  if (drop.size) {
    user.notes = user.notes.filter((n) => !drop.has(n.id));
    await saveUser(user);
  }
  return drop.size;
}

/* ---------- finding ---------- */

/** The notes most related to `query`, best first. Empty when nothing is relevant. Past notes are not used. */
export async function searchNotes(user, query, k = config.recallTopK) {
  const q = String(query || '').trim();
  const pool = activeNotes(user);
  if (!q || !pool.length) return [];
  const { query: vec, kind, vecs } = await scoredSpace(user, pool, q, 'query');
  const floor = relevanceThreshold(kind);

  const scored = [];
  pool.forEach((note, i) => {
    const score = cosine(vec, vecs[i]);
    if (score >= floor) scored.push({ note, score });
  });
  scored.sort((a, b) => b.score - a.score || b.note.at - a.note.at);
  return scored.slice(0, k).map((s) => ({ ...s.note, score: Math.round(s.score * 100) / 100 }));
}

export function recentNotes(user, k = 3) {
  return [...activeNotes(user)].sort((a, b) => b.at - a.at).slice(0, k);
}

export { currentKind };
