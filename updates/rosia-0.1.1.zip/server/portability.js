import crypto from 'node:crypto';
import { config } from './config.js';
import { listSessions, loadSession, createSession, saveSession, appendMessage } from './sessions.js';
import { getUser, addNote, publicNotes } from './users.js';
import { saveImage, readImageDataUrl } from './media.js';
import { conversationRoom } from './quota.js';

/*
 * Your data, as one file you can keep: conversations (with pictures, optionally) and what she remembers.
 * Importing merges: nothing already there is replaced or removed, and importing the same file twice
 * changes nothing the second time.
 *
 * Never included: access tokens, machines, anything about other people.
 */

const FORMAT = 'rosia';
const VERSION = 1;
const LIMITS = { conversations: 2000, messages: config.quota.messagesPerConversation, content: 20_000, notes: 1000, pictures: 1000, title: 60 };

const cleanText = (v, max) => String(v ?? '').slice(0, max);
const finite = (v, fallback) => (Number.isFinite(Number(v)) ? Number(v) : fallback);

/** The same conversation exported and imported again must be recognised, so identity comes from its content. */
export function fingerprint(conv) {
  const first = conv.messages.find((m) => m.content)?.content || '';
  return crypto
    .createHash('sha1')
    .update(`${conv.createdAt}|${conv.messages.length}|${first.slice(0, 200)}|${conv.messages.at(-1)?.at ?? ''}`)
    .digest('hex');
}

/* ---------- export ---------- */

async function pictureOf(userId, id) {
  const url = await readImageDataUrl(userId, id);
  const m = url && /^data:([^;]+);base64,(.+)$/.exec(url);
  return m ? { mime: m[1], data: m[2] } : null;
}

async function exportMessage(userId, m, pictures) {
  const out = { role: m.role, content: m.content, at: m.at };
  for (const k of ['raw', 'mood', 'photo', 'proactive']) if (m[k]) out[k] = m[k];
  if (pictures && m.images?.length) {
    out.images = (await Promise.all(m.images.map((id) => pictureOf(userId, id)))).filter(Boolean);
  }
  // a picture she drew for them (only finished ones: one still being drawn cannot be carried over)
  if (m.image?.state === 'done' && m.image.media) {
    out.drawn = { orientation: m.image.orientation, prompt: m.image.prompt || '' };
    if (pictures) out.drawn.picture = await pictureOf(userId, m.image.media);
  }
  // a GIF from her collection (by its catalogue id: it is shown again on a machine with the same collection) and a video link
  if (m.gif) out.gif = m.gif;
  if (m.video?.url) out.video = { url: m.video.url, name: m.video.name || '' };
  if (m.links?.length) {
    out.links = [];
    for (const l of m.links) {
      const link = { url: l.url, kind: l.kind, title: l.title, description: l.description, site: l.site, text: l.text, ok: l.ok, error: l.error };
      if (pictures && l.image) link.image = await pictureOf(userId, l.image);
      out.links.push(link);
    }
  }
  return out;
}

/** Calls write(chunk) with the export as JSON, one conversation at a time so a big history never sits in memory whole. */
export async function writeExport(userId, write, { pictures = true } = {}) {
  const user = await getUser(userId);
  const notes = publicNotes(user).map((n) => ({ text: n.text, at: n.at, source: n.source, until: n.until }));
  write(`{"app":"${FORMAT}","version":${VERSION},"exportedAt":${Date.now()},"pictures":${pictures},`);
  write(`"memory":${JSON.stringify({ notes, profile: user.profile })},"conversations":[`);

  const metas = (await listSessions(userId)).sort((a, b) => a.createdAt - b.createdAt);
  let first = true;
  for (const meta of metas) {
    const session = await loadSession(meta.id, userId);
    if (!session) continue;
    const messages = [];
    for (const m of session.messages) {
      if (m.role === 'user' || m.role === 'assistant') messages.push(await exportMessage(userId, m, pictures));
    }
    const conv = { title: session.title, createdAt: session.createdAt, updatedAt: session.updatedAt, summary: session.summary?.text || '', messages };
    write(`${first ? '' : ','}${JSON.stringify(conv)}`);
    first = false;
  }
  write(']}');
}

/* ---------- import ---------- */

function invalid(message) {
  const err = new Error(message);
  err.status = 400;
  return err;
}

export async function importData(userId, data) {
  if (!data || data.app !== FORMAT || data.version !== VERSION) throw invalid('That is not a Rosia export file.');
  const convs = Array.isArray(data.conversations) ? data.conversations : [];
  const notes = Array.isArray(data.memory?.notes) ? data.memory.notes : [];
  if (convs.length > LIMITS.conversations) throw invalid('That file has too many conversations.');
  if (notes.length > LIMITS.notes) throw invalid('That file has too many notes.');

  const result = { conversations: 0, skipped: 0, notes: 0, pictures: 0 };

  // what is already here, so importing twice (or restoring a backup) adds nothing twice
  const known = new Set();
  for (const meta of await listSessions(userId)) {
    const s = await loadSession(meta.id, userId);
    if (!s) continue;
    known.add(fingerprint({ createdAt: s.createdAt, messages: s.messages }));
    if (s.importedFrom) known.add(s.importedFrom);
  }

  for (const c of convs) {
    if (!c || !Array.isArray(c.messages) || !c.messages.length) continue;
    if (c.messages.length > LIMITS.messages) throw invalid('One conversation in that file is too long.');

    const messages = [];
    for (const m of c.messages) {
      if (!m || (m.role !== 'user' && m.role !== 'assistant')) continue;
      messages.push({
        role: m.role,
        content: cleanText(m.content, LIMITS.content),
        at: finite(m.at, Date.now()),
        raw: m.raw ? cleanText(m.raw, LIMITS.content) : undefined,
        mood: m.mood ? cleanText(m.mood, 20) : undefined,
        photo: m.photo ? cleanText(m.photo, 20) : undefined,
        proactive: m.proactive === 'greet' || m.proactive === 'nudge' ? m.proactive : undefined,
        gif: typeof m.gif === 'string' && /^[a-f0-9]{12}$/.test(m.gif) ? m.gif : undefined,
        video: m.video && /^https?:\/\//i.test(String(m.video.url || '')) ? { url: cleanText(m.video.url, 2000), name: cleanText(m.video.name, 120) } : undefined,
        _images: Array.isArray(m.images) ? m.images : [],
        _links: Array.isArray(m.links) ? m.links : [],
        _drawn: m.drawn && typeof m.drawn === 'object' ? m.drawn : null
      });
    }
    if (!messages.length) continue;

    const createdAt = finite(c.createdAt, messages[0].at);
    // the fingerprint of the file's conversation is kept on the imported one, so importing the same file again is
    // recognised even if the conversation has grown since
    const print = fingerprint({ createdAt, messages });
    if (known.has(print)) {
      result.skipped += 1;
      continue;
    }

    if (!(await conversationRoom(userId))) {
      result.noRoom = (result.noRoom || 0) + 1; // over the limit: left out, nothing else is touched
      continue;
    }

    const session = createSession(userId);
    session.createdAt = createdAt;
    session.importedFrom = print;
    session.title = cleanText(c.title, LIMITS.title);
    session.titleByUser = Boolean(session.title);
    session.summary = { text: cleanText(c.summary, 900), upTo: 0 };

    for (const m of messages) {
      const extra = {};
      for (const k of ['raw', 'mood', 'photo', 'proactive', 'gif', 'video']) if (m[k]) extra[k] = m[k];

      const drawn = m._drawn;
      if (drawn?.picture?.mime && drawn.picture.data && result.pictures < LIMITS.pictures) {
        try {
          const media = (await saveImage(userId, `data:${drawn.picture.mime};base64,${drawn.picture.data}`)).id;
          extra.image = { job: crypto.randomBytes(8).toString('hex'), orientation: ['portrait', 'landscape', 'square'].includes(drawn.orientation) ? drawn.orientation : 'portrait', state: 'done', prompt: cleanText(drawn.prompt, 1800), media };
          result.pictures += 1;
        } catch {
          /* a bad picture is skipped, the message stays */
        }
      }

      const ids = [];
      for (const pic of m._images) {
        if (result.pictures >= LIMITS.pictures || !pic?.mime || !pic?.data) continue;
        try {
          ids.push((await saveImage(userId, `data:${pic.mime};base64,${pic.data}`)).id);
          result.pictures += 1;
        } catch {
          /* a bad picture is skipped, the message stays */
        }
      }
      if (ids.length) extra.images = ids;

      const links = [];
      for (const l of m._links.slice(0, 3)) {
        if (!l || !/^https?:\/\//i.test(String(l.url || ''))) continue;
        const link = {
          url: cleanText(l.url, 2000), kind: cleanText(l.kind, 12), title: cleanText(l.title, 300),
          description: cleanText(l.description, 600), site: cleanText(l.site, 100), text: cleanText(l.text, 2500),
          ok: Boolean(l.ok), error: cleanText(l.error, 200), image: null
        };
        if (l.image?.mime && l.image?.data && result.pictures < LIMITS.pictures) {
          try {
            link.image = (await saveImage(userId, `data:${l.image.mime};base64,${l.image.data}`)).id;
            result.pictures += 1;
          } catch {
            /* skip the picture, keep the link */
          }
        }
        links.push(link);
      }
      if (links.length) extra.links = links;

      appendMessage(session, m.role, m.content, extra);
      session.messages.at(-1).at = m.at; // keep when it was really said
    }

    session.updatedAt = finite(c.updatedAt, session.messages.at(-1).at);
    session.extractedUpTo = session.messages.length; // already lived through: don't mine it for notes again
    await saveSession(session, { touch: false }); // keep the original times
    known.add(print);
    result.conversations += 1;
  }

  const user = await getUser(userId);
  for (const n of notes) {
    const text = cleanText(n?.text, 200).trim();
    if (text.length < 3) continue;
    const source = ['auto', 'user', 'tool'].includes(n.source) ? n.source : 'user';
    const { created } = await addNote(user, text, source, { until: Number.isFinite(n.until) ? n.until : undefined });
    if (created) result.notes += 1;
  }

  return result;
}
