import { IDENTITY } from './persona.js';
import { historyForModel } from './sessions.js';
import { readImageDataUrl } from './media.js';
import { visionSupported } from './llm.js';
import { relevantNotes } from './memory.js';
import { recentNotes } from './users.js';
import { config } from './config.js';
import { followUpLine } from './followups.js';

/*
 * Builds the prompt for one reply.
 *
 * Layout is chosen for the model server's prefix cache: llama.cpp only reuses work for the part of
 * the prompt that is identical to the previous request. So the system prompt is constant, the
 * slow-changing background (profile, summary) sits on the *first* message of the window, and only
 * the things that change every turn (the clock, which notes are relevant) go on the very end.
 */

export function validTimezone(tz) {
  if (!tz || typeof tz !== 'string') return config.timezone;
  try {
    new Intl.DateTimeFormat('en-GB', { timeZone: tz });
    return tz;
  } catch {
    return config.timezone;
  }
}

function partOfDay(date, timeZone) {
  const hour = Number(new Intl.DateTimeFormat('en-GB', { timeZone, hour: 'numeric', hour12: false }).format(date)) % 24;
  if (hour >= 5 && hour < 12) return 'morning';
  if (hour >= 12 && hour < 17) return 'afternoon';
  if (hour >= 17 && hour < 22) return 'evening';
  if (hour >= 22 || hour === 0) return 'late at night';
  return 'the small hours';
}

export function humanGap(ms) {
  const min = Math.round(ms / 60_000);
  if (min < 2) return 'a moment';
  if (min < 60) return `${min} minutes`;
  const hours = Math.round(min / 60);
  if (hours < 24) return hours === 1 ? 'about an hour' : `about ${hours} hours`;
  const days = Math.round(hours / 24);
  if (days === 1) return 'about a day';
  if (days < 14) return `${days} days`;
  return `about ${Math.round(days / 7)} weeks`;
}

/** The date and time for them. For a greeting the part of the day is left out unless it is night: a small model given "afternoon" opens with "this late afternoon" every time. */
function clockLine(timeZone, { greeting = false } = {}) {
  const now = new Date();
  const part = partOfDay(now, timeZone);
  if (greeting) {
    const day = now.toLocaleDateString('en-GB', { timeZone, weekday: 'long' });
    void day; // (the weekday is left out too: it was the next thing a greeting latched on to)
    return /night|small hours/.test(part) ? `It is ${part} for them.` : '';
  }
  const stamp = now.toLocaleString('en-GB', { timeZone, dateStyle: 'full', timeStyle: 'short' });
  return `It is ${stamp} for them (${timeZone}), ${part}.`;
}

/** "They last wrote 3 hours ago." Only when the gap is worth mentioning. */
function gapLine(session, user) {
  const msgs = session.messages;
  // the newest user message is the one being answered; look at the one before it
  const userIdx = msgs.map((m, i) => (m.role === 'user' ? i : -1)).filter((i) => i >= 0);
  const previous = userIdx.length >= 2 ? msgs[userIdx.at(-2)] : null;
  const thisMsg = userIdx.length ? msgs[userIdx.at(-1)] : null;

  if (previous && thisMsg && thisMsg.at - previous.at > 30 * 60_000) {
    return `They last wrote to you ${humanGap(thisMsg.at - previous.at)} ago.`;
  }
  if (!previous && thisMsg && user.lastSeenAt && thisMsg.at - user.lastSeenAt > 30 * 60_000) {
    return `This is a new conversation; they were last here ${humanGap(thisMsg.at - user.lastSeenAt)} ago.`;
  }
  return '';
}

/** True when the message being answered is their first after a break of half an hour or more. */
export function isReturning(session, user) {
  return Boolean(gapLine(session, user));
}

const HOT = new Set(['aroused', 'smitten', 'ecstatic']);
const PLAYFUL = new Set(['flirty', 'teasing', 'amused']);

/**
 * How she is feeling right now, from how the conversation has been going: a mood that carries on from one message to the
 * next instead of starting fresh each time. Plain sentences for the model, or '' when there is nothing worth saying.
 */
export function vibeLine(session, timeZone, now = new Date()) {
  const replies = session.messages.filter((m) => m.role === 'assistant' && m.mood).slice(-5);
  const moods = replies.map((m) => m.mood);
  const hot = moods.filter((m) => HOT.has(m)).length;
  const playful = moods.filter((m) => PLAYFUL.has(m)).length;
  const lines = [];

  if (hot >= 3) lines.push('You are deep in an intimate, sexual mood with them right now. Stay in it and keep it moving; do not snap back to small talk unless they change the subject.');
  else if (hot + playful >= 3) lines.push('You are in a playful, flirty mood with them. Keep that going; a bit of tension builds if they keep it up.');
  else if (moods.length >= 3 && moods.slice(-3).every((m) => m === 'neutral' || m === 'worried')) lines.push('You are a bit flat and quiet today. Keep it low-key and short until they bring you round.');

  // late at night she is sleepier and quieter, unless things have already heated up
  const hour = Number(new Intl.DateTimeFormat('en-GB', { timeZone, hour: 'numeric', hour12: false }).format(now)) % 24;
  if (hot < 3 && (hour >= 23 || hour < 5)) lines.push('It is very late and you are getting sleepy: softer, slower, fewer words, maybe a yawn.');

  // one-word replies: stop interviewing them, carry the conversation yourself
  const theirs = session.messages.filter((m) => m.role === 'user').slice(-3);
  if (theirs.length === 3 && theirs.every((m) => String(m.content || '').trim().length <= 12 && !/\?/.test(m.content || ''))) {
    lines.push('They have only sent a few words in a row. Do not ask them anything: carry it yourself with a tease, a thought, or what you would do next.');
  }
  return lines.join(' ');
}

function backgroundHeader({ user, session, preface }) {
  const parts = [];
  // only once it is a real stretch of time: in the first week it is not worth saying. A date, not a count of days, so the
  // text is the same every time and the model server's cached prompt prefix is kept.
  if (user.firstSeenAt && Date.now() - user.firstSeenAt > 7 * 86_400_000) {
    parts.push(`You first talked to them on ${new Date(user.firstSeenAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}.`);
  }
  if (user.profile) parts.push(`What you know about them: ${user.profile}`);
  if (session.summary.text) parts.push(`Earlier in this chat (scrolled out of view): ${session.summary.text}`);
  if (preface) parts.push(`You opened this chat by saying: "${preface.replace(/^\[[a-z]+\]\s*/i, '').slice(0, 400)}"`);
  if (!parts.length) return '';
  return `[background for you only, never mention it directly:\n${parts.join('\n')}]`;
}

// Greetings were the weakest part of a first chat. A tester's opener was "hey. wasn't expecting to see you popping up this late
// afternoon... just scrolling through your phone like a proper bored git?": familiar with a stranger, guessing what they were doing,
// and odd about the time. So a first meeting and a return get different notes. Both say only what TO write: listing the phrases to
// avoid ("popped up", "this afternoon") made a 4B model use them in most greetings, so no example of a bad phrase appears here.
const GREET_SHAPE =
  'Write one short paragraph on a single line, lowercase, warm with a little edge, under 25 words. Talk only about the two of you right ' +
  'now: no guesses about what they are up to, nothing about the day, the time or the weekday, nothing about your own day.';

export const INSTRUCTIONS = {
  // they have never talked to her: someone new who has just opened the chat
  greetFirst: () =>
    '[note to you, never mention it: this is the first time this person has ever messaged you. You are meeting them now. ' +
    'Say hello, say your name as "i\'m rosia", and either ask their name or say something playful about meeting someone new. ' +
    `${GREET_SHAPE}]`,
  // they have talked before: a friend picking the thread back up
  greet: (extra) =>
    '[note to you, never mention it: this person is a friend you have talked to before. Say hello like a friend who is ' +
    'pleased to hear from them. Use something from the notes or recap below only if it is really there; otherwise just say hello and ' +
    `ask how they are. ${GREET_SHAPE} ${extra}]`,
  nudge: (extra) =>
    '[note to you, never mention it: it has been quiet for a few minutes since your last message and they have ' +
    'not replied. Send one short nudge in your own voice, a line at most: playful or curious, never needy or ' +
    'guilt-tripping, and different from anything you have already said. Do not ask "where did you go" or "you there". ' +
    `Make it something that moves things on: a tease, a thought, or something from what you know about them. ${extra || ''}]`
};

/** Up to two things she knows about them, picked from the newest notes, for a message she starts herself. */
function pickCallbacks(user, count = 2) {
  const pool = recentNotes(user, 5).map((n) => String(n.text || '').slice(0, 140)).filter(Boolean);
  for (let i = pool.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, count);
}

/** A short account of the previous conversation, for greetings that pick up where it left off. */
export function recapOf(lastConversation) {
  if (!lastConversation) return '';
  const bits = [];
  if (lastConversation.title) bits.push(`Last time you talked about: ${lastConversation.title}.`);
  if (lastConversation.summary?.text) bits.push(lastConversation.summary.text);
  const tail = lastConversation.messages
    .filter((m) => (m.role === 'user' || m.role === 'assistant') && m.content)
    .slice(-4)
    .map((m) => `${m.role === 'user' ? 'Them' : 'You'}: ${m.content.replace(/\s+/g, ' ').slice(0, 140)}`)
    .join(' / ');
  if (tail) bits.push(`The end of that chat: ${tail}`);
  return bits.join(' ').slice(0, 700);
}

// Small models drift into long, essay-like replies over a conversation; the newest message is where they listen most.
const STYLE_REMINDER = 'Reply the way a real 20-year-old texts: casual, mostly lowercase, and VARY the length (sometimes just a few words, usually under 40, rarely more). React to what they actually said with something specific, without praising it or repeating it back. Do not end on a question unless you really need the answer. No offering two options, no narration in brackets, no poetic scene-setting, no made-up details about your morning or flat unless they matter, no lists.';

/**
 * @returns the messages array for the model
 * @param kind  undefined for a normal reply, or 'greet' | 'nudge' for something she starts herself
 */
export async function buildMessages({ session, user, tz, kind, lastConversation, followUp }) {
  const timeZone = validTimezone(tz);
  const { messages: history, preface } = historyForModel(session);
  const messages = history.map((m) => ({ role: m.role, content: m.content, images: m.images }));

  // slow-changing background rides on the first message of the window
  const header = backgroundHeader({ user, session, preface });
  if (header && messages[0]?.role === 'user') messages[0].content = `${header}\n\n${messages[0].content}`;

  // volatile tail: the clock, the gap, and whichever notes relate to what was just said
  const lastUser = [...messages].reverse().find((m) => m.role === 'user');
  const recalled = kind ? [] : await relevantNotes(user, lastUser?.content || '');
  const tail = [
    kind ? '' : STYLE_REMINDER,
    clockLine(timeZone, { greeting: kind === 'greet' }),
    kind ? '' : gapLine(session, user),
    kind ? '' : vibeLine(session, timeZone),
    kind ? '' : followUpLine(followUp),
    recalled.length ? `Things you remember about them that may matter here (do not recite them): ${recalled.join(' | ')}` : ''
  ]
    .filter(Boolean)
    .join(' ');
  const context = `[context for you only, never mention it: ${tail}]`;

  if (kind) {
    const gap = user.lastSeenAt ? `You last talked ${humanGap(Date.now() - user.lastSeenAt)} ago.` : 'You have not spoken before.';
    // something real she knows about them, to bring up if it fits (a text from someone who remembers you)
    const known = pickCallbacks(user);
    // something they told her about has just happened: she asks about that, in place of the usual callback, so it is one thing and not two
    const asking = kind === 'greet' ? followUpLine(followUp) : '';
    const callback = !asking && known.length ? `Things you know about them (you may bring up ONE of these if it fits naturally, never recite them, never add details): ${known.join(' | ')}.` : '';
    let extra = kind === 'greet' ? [gap, recapOf(lastConversation), callback, asking].filter(Boolean).join(' ') : callback;
    // never here before and no earlier chat: a first meeting, not a friend coming back
    const first = kind === 'greet' && !user.lastSeenAt && !lastConversation;
    // with nothing to call back to, say so outright: otherwise a small model invents "you were saying how dull tuesday was"
    const recap = kind === 'greet' ? recapOf(lastConversation) : '';
    if (kind === 'greet' && !first && !recap && !known.length && !user.profile && !asking) {
      extra += ' You have no notes and no recap about them here, so mention nothing from before: just say hello.';
    }
    let note = `${(first ? INSTRUCTIONS.greetFirst : INSTRUCTIONS[kind])(extra)}\n\n${context}`;
    // an opening message has no history to hang the background on, so it goes here
    if (!messages.length && header) note = `${header}\n\n${note}`;
    messages.push({ role: 'user', content: note });
  } else {
    const last = messages.at(-1);
    if (last?.role === 'user') last.content = `${last.content}\n\n${context}`;
  }

  // pictures: only the newest user message carries real image data
  const out = [{ role: 'system', content: IDENTITY }];
  const canSee = await visionSupported();
  for (const m of messages) {
    if (m.images?.length && canSee) {
      const urls = (await Promise.all(m.images.map((id) => readImageDataUrl(session.userId, id)))).filter(Boolean);
      const text = m.content || 'They sent this picture.';
      out.push({
        role: m.role,
        content: [{ type: 'text', text }, ...urls.map((url) => ({ type: 'image_url', image_url: { url } }))]
      });
    } else {
      out.push({ role: m.role, content: m.content });
    }
  }
  return out;
}
