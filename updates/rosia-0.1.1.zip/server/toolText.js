/*
 * Gemma sometimes writes a tool call as plain text instead of making a real one, e.g.
 *
 *     well, since you brought it up... i reckon you deserve a proper look.
 *     send_photo{pose:<|"|>front<|"|>}
 *
 * (also seen as `call:send_photo{...}`, or wrapped in <|tool_call> ... <tool_call|>). The server never saw a call, so
 * nothing was sent and the person was shown the raw text. Two things here fix that:
 *   - CallGuard sits on the stream and keeps such text from being shown;
 *   - extractTextCalls reads the call out of what the model wrote, so it can be run as if it had been made properly.
 */

const OPEN = '(?:<\\|?tool_call\\|?>\\s*)?(?:call:)?';
const MAX_CALL_CHARS = 800;

const escape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const startOf = (names) => new RegExp(`${OPEN}(?<![A-Za-z0-9_])(${names.map(escape).join('|')})\\s*\\{`);

/** Index just after the brace that closes the one at `open`, or -1 if it is not closed yet. Quotes are respected. */
function closeOf(text, open) {
  let depth = 0;
  let quote = '';
  for (let i = open; i < text.length; i += 1) {
    const c = text[i];
    if (quote) {
      if (c === quote) quote = '';
      continue;
    }
    if (c === '"' || c === "'") quote = c;
    else if (c === '{') depth += 1;
    else if (c === '}') {
      depth -= 1;
      if (depth === 0) return i + 1;
    }
  }
  return -1;
}

const TRAILER = /^\s*(?:<tool_call\|?>|<\|tool_call_end\|?>|<\|tool_call\|>)?/;

/** The arguments between a call's braces, however the model wrote them. */
export function parseArgs(body) {
  const s = String(body || '').replace(/<\|"\|>/g, '"').replace(/<\|'\|>/g, "'").trim();
  if (!s) return {};
  try {
    return JSON.parse(`{${s}}`);
  } catch {
    /* not JSON as written */
  }
  try {
    return JSON.parse(`{${s.replace(/(^|[,{]\s*)([A-Za-z_]\w*)\s*:/g, '$1"$2":')}}`);
  } catch {
    /* keys without quotes and still not JSON */
  }
  const out = {};
  for (const m of s.matchAll(/([A-Za-z_]\w*)\s*:\s*(?:"([^"]*)"|'([^']*)'|([^,}\s][^,}]*))/g)) {
    const v = m[2] ?? m[3] ?? String(m[4]).trim().replace(/^["']|["']$/g, '');
    out[m[1]] = v === 'true' ? true : v === 'false' ? false : v;
  }
  return out;
}

/**
 * Finds the tool calls written as text. Returns { calls: [{ name, args }], text } where text is what is left without them.
 * A call that was cut off (no closing brace) is still read, and removed.
 */
export function extractTextCalls(input, names) {
  let text = String(input || '');
  const calls = [];
  if (!names?.length) return { calls, text };
  const re = startOf(names);
  for (let guard = 0; guard < 4; guard += 1) {
    const m = re.exec(text);
    if (!m) break;
    const open = m.index + m[0].length - 1;
    let end = closeOf(text, open);
    const body = text.slice(open + 1, end === -1 ? text.length : end - 1);
    calls.push({ name: m[1], args: parseArgs(body) });
    end = end === -1 ? text.length : end + TRAILER.exec(text.slice(end))[0].length;
    text = `${text.slice(0, m.index)}${text.slice(end)}`;
  }
  return { calls, text: text.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim() };
}

/** Keeps text that looks like a tool call off the screen while it streams, and lets everything else through at once. */
export class CallGuard {
  constructor(names) {
    this.names = names || [];
    this.re = this.names.length ? startOf(this.names) : null;
    this.starts = [...this.names, ...this.names.map((n) => `call:${n}`), '<|tool_call>', '<tool_call>', '<|tool_call|>'];
    this.buf = '';
    this.inCall = false;
    this.hid = 0; // how many calls were kept off the screen
  }

  push(text) {
    if (!this.re) return text;
    this.buf += text;
    let out = '';
    for (;;) {
      if (!this.inCall) {
        const m = this.re.exec(this.buf);
        if (m) {
          out += this.buf.slice(0, m.index);
          this.buf = this.buf.slice(m.index);
          this.inCall = true;
          continue;
        }
        // a few trailing characters that could still turn into the start of a call are held back for the next piece
        const tail = /[<|A-Za-z_:]{1,30}\s*$/.exec(this.buf);
        const word = tail ? tail[0].trim() : '';
        const hold = word && this.starts.some((s) => s.startsWith(word)) ? tail[0].length : 0;
        out += this.buf.slice(0, this.buf.length - hold);
        this.buf = this.buf.slice(this.buf.length - hold);
        return out;
      }
      const m = this.re.exec(this.buf);
      const open = m.index + m[0].length - 1;
      const end = closeOf(this.buf, open);
      if (end === -1) {
        if (this.buf.length > MAX_CALL_CHARS) {
          // far too long to be a call: it was ordinary text after all
          out += this.buf;
          this.buf = '';
          this.inCall = false;
        }
        return out;
      }
      this.hid += 1;
      this.buf = this.buf.slice(end + TRAILER.exec(this.buf.slice(end))[0].length);
      this.inCall = false;
    }
  }

  /** End of the stream: whatever is still held is shown, unless it is a call that never closed. */
  flush() {
    const rest = this.inCall ? '' : this.buf;
    if (this.inCall) this.hid += 1;
    this.buf = '';
    this.inCall = false;
    return rest;
  }
}
