# Rosia

A chat companion with a face. Playful, teasing, Gen-Z British, third-year CSE (AIML) student.
Runs entirely on your machine against a local model, streams replies, searches the web, remembers
things about you, and animates her face while she replies.

No framework bloat: a small Node server (no dependencies) and a vanilla front end.

---

## Quick start

```powershell
# 1. start your local model server (any OpenAI-compatible one; Ollama is the default)
ollama serve
ollama pull llama3.1        # or qwen2.5, mistral, gemma, whatever you've got

# 2. start Rosia
npm start                   # http://127.0.0.1:8787
```

If `ROSA_MODEL` is unset, she auto-detects the first model Ollama reports.

### Using a local .gguf file with llama.cpp

`start.bat` does all of this for you. To run it by hand, start `llama-server` first and point Rosia
at it:

```powershell
# terminal 1 — the model
C:\AI\llama-b11057-bin-win-cuda-13.4-x64\llama-server.exe `
  -m "C:\AI\models\gemma4-e4b-uncensored\model.gguf" `
  --mmproj "C:\AI\models\gemma4-e4b-uncensored\mmproj.gguf" `
  --host 127.0.0.1 --port 8080 --alias rosia `
  -ngl 99 -c 8192 -np 1 --jinja

# terminal 2 — Rosia
$env:OLLAMA_URL='http://127.0.0.1:8080'
$env:ROSA_MODEL='rosia'
npm start
```

Flag notes:

- `-ngl 99` pushes every layer to the GPU. On a 4 GB card with a ~5 GB model this overcommits and
  llama.cpp spills to system RAM; it still runs, just slower. Drop to `-ngl 20`–`24` if you hit
  driver stalls, or `-ngl 0` for CPU-only.
- `-c 8192` is the context window. Each slot gets `-c / -np`, so `-np 1` gives Rosia the full 8k.
- `--mmproj` loads the vision projector. Only needed for image input; drop it to save ~0.9 GB.
- `--alias rosia` gives the server a short name, which is what `ROSA_MODEL` matches.
- `--jinja` uses the model's own chat template — needed for correct tool calling.

### Share it with a Cloudflare tunnel

```powershell
npm run tunnel
```

That prints a `https://…trycloudflare.com` URL anyone can open. Messages are rate-limited per machine
(40/min). There is **no password by default** — anyone with the link can talk to her. Treat the
URL like a key and stop the tunnel when you're done.

---

## Configuration

| Variable | Default | What it does |
| --- | --- | --- |
| `PORT` | `8787` | HTTP port |
| `HOST` | `127.0.0.1` | Bind address (`0.0.0.0` to let other machines on your network in) |
| `OLLAMA_URL` | `http://127.0.0.1:11434` | Base URL of the model server |
| `ROSA_MODEL` | first available | Model name, e.g. `qwen2.5:14b` |
| `ROSA_TEMPERATURE` | `0.9` | Sampling temperature (users cannot change it) |
| `ROSA_MAX_TOKENS` | `1024` | Max tokens per reply |
| `ROSA_TZ` | system zone | Time zone used for `get_time` and the prompt |
| `ROSA_HISTORY` | `40` | Messages sent to the model per turn |
| `ROSA_MAX_TOOL_ROUNDS` | `2` | Tool-call rounds before she's told to answer |
| `ROSA_DATA_DIR` | `./data` | Where chat sessions are stored (a test run always gets a throwaway one of its own) |
| `ROSA_MATCH_FLOOR` | per model | How close in meaning a GIF, video or stocked picture must be to what was asked (0.40 for EmbeddingGemma) |
| `ROSA_GIF_REDESCRIBE` | `1` | Describe clips catalogued with the older one-line descriptions again, in the background; `0` keeps them |

### Other backends

Anything speaking the OpenAI chat-completions API works. Point `OLLAMA_URL` at it:

```powershell
# LM Studio
$env:OLLAMA_URL='http://127.0.0.1:1234'; $env:ROSA_MODEL='local-model'; npm start

# llama.cpp server
$env:OLLAMA_URL='http://127.0.0.1:8080'; $env:ROSA_MODEL='model'; npm start
```

---

## What's in the box

```
server/
  index.js        HTTP + SSE, routes, rate limit
  chat.js         prompt assembly, streaming, tool-call loop
  persona.js      Rosia's character sheet  ← edit this to change her
  llm.js          OpenAI-compatible streaming client, tool-call merging
  sessions.js     per-browser sessions on disk, rolling memory
  tools/
    registry.js   tool definitions + dispatcher
    search.js     web search: your SearXNG or a Brave key if given, then DuckDuckGo, Yahoo, Bing and Wikipedia (no key)
    basic.js      get_time, remember, recall
    photos.js     send_photo
public/
  index.html      layout
  styles.css      dark rose-neon theme
  app.js          SSE client, streaming UI, avatar expressions, photos
  assets/avatar/  source PNGs; web/ holds the generated WebP versions the page loads
scripts/
  mock-llm.js     fake model server used for testing without Ollama
```

### Tools she can call

| Tool | Purpose |
| --- | --- |
| `web_search` | SearXNG / Brave if set up, otherwise DuckDuckGo, Yahoo, Bing and Wikipedia. She calls it for anything live or uncertain |
| `get_time` | Current local date/time |
| `remember` | Store a fact about the person in session memory |
| `recall` | Look through those notes |

Adding a tool is one file: call `defineTool({ name, description, parameters, run })` and import it
in `server/index.js`. The schema is generated for the model automatically.

### The avatar

The avatar is a set of **static, pre-made expression images** in `public/assets/avatar/web/`. The
model starts each reply with a mood tag (flirty, teasing, amused...), the server strips it, and the
page crossfades to the matching expression. She can also send photos in the chat through a
`send_photo` tool. See [AVATAR.md](AVATAR.md) for the file list, the mood table, how to add images and
how to rebuild the web versions with `python scripts/build-avatar.py`.

---

## Running it

`start.bat` runs `scripts/supervisor.js`: it starts your model server (if one isn't already answering on :8080) and
the app, restarts either one if it exits or stops answering (waiting 1 s, then 2, 4 ... up to 30 s), writes logs to
`data/logs`, opens the browser, and stops everything on Ctrl+C. `--no-model` leaves the model alone, `--no-browser`
doesn't open a page. Everything optional is switched on by `rosia.local.json` (not committed). This is the
setup that was built and tested here (Gemma 4 E4B for chat; Qwen3-4B abliterated is only the Z-Image text encoder inside ComfyUI, EmbeddingGemma for memory, Kokoro for
voice, Z-Image Turbo through ComfyUI for pictures):

```json
{
  "model": "C:\\AI\\models\\gemma4-e4b-uncensored\\model.gguf",
  "mmproj": "C:\\AI\\models\\gemma4-e4b-uncensored\\mmproj.gguf",
  "modelArgs": ["-ngl", "99", "-c", "8192", "-np", "1", "--jinja"],
  "embedModel": "C:\\AI\\models\\embeddinggemma\\embeddinggemma-300M-Q8_0.gguf",
  "embedStyle": "embeddinggemma",
  "ttsPython": "C:\\Python311\\python.exe",
  "ttsModel": "C:\\AI\\models\\kokoro\\kokoro-v1.0.onnx",
  "ttsVoices": "C:\\AI\\models\\kokoro\\voices-v1.0.bin",
  "comfyDir": "C:\\ComfyUI\\ComfyUI",
  "comfyModels": "C:\\Users\\me\\ComfyUI-Shared\\models"
}
```

| Key | What it does |
| --- | --- |
| `model`, `mmproj` | The chat model. `"mmproj": ""` means a text-only model (no picture input). Defaults to a vision projector beside the model if there is one. |
| `modelArgs` | Flags for `llama-server` |
| `access` | `"open"` lets anyone with your link (e.g. a Cloudflare tunnel) in with their own private space; the default `"invite"` makes other machines enter a pairing code and share *your* chats and memory |
| `embedModel`, `embedStyle` | Optional small model that gives memory real meaning-matching ("puppy" finds "dog"); runs on the CPU |
| `ttsPython`, `ttsModel`, `ttsVoices` | Optional server-side Kokoro (needs `pip install kokoro-onnx soundfile`); the default voice runs in the browser and needs none of this |
| `comfyDir`, `comfyModels`, `comfyWorkflow` | Pictures: a ComfyUI folder (with `main.py` and a `.venv`), the models folder it should read, and the saved workflow (defaults to `user/default/workflows/rosia.json`) |

`npm test` runs the tests (Node's built-in runner, no dependencies).

## Drawing pictures

Ask her to draw something ("draw me a lighthouse at dusk", "make me a wallpaper of mountains") and she does, through
ComfyUI over its HTTP API (`server/comfy.js`).

- **Your workflow decides how it looks.** The app runs the workflow you saved in ComfyUI as `rosia`
  (`<ComfyUI>/user/default/workflows/rosia.json`, saved with the editor's Save, not Export (API)): its models, LoRA,
  sage attention, sampler, steps, negative prompt and resolution are all used as they are, and edits take effect on
  the next picture. Per picture the app only sets the **prompt**, the **shape** and the **seed**, and swaps Save Image
  for a temporary preview so ComfyUI's output folder does not fill up. (`server/workflow.js` turns the saved graph into
  an API prompt using ComfyUI's own node definitions; a node ComfyUI doesn't have is reported by name.)
  - Put `{prompt}` in the *Positive Prompt* node to say where the request goes ("... of {prompt}, shot on iPhone ...").
    Without it, only the leading style words (up to the first bracketed group, e.g. `framegrid, IMG_1018.CR2, (... :1.3)`)
    are kept and the request follows them.
  - **Speed:** by default the sampler is swapped for `euler` / `simple` at 8 steps (`ROSA_IMAGE_STEPS`), which is what Z-Image
    Turbo was designed for. The saved workflow's `res_2s` runs the model twice per step, so it took about 2.5x as long
    (about 135 s of a 4-minute picture on a 4 GB card). Everything else (models, LoRA, sage attention, prompts) is still the
    workflow's. `ROSA_IMAGE_FAST=0` goes back to the sampler, scheduler and steps saved in the workflow.
  - Size: fixed per shape — portrait 576x768, landscape 768x576, square 768x768 — so a 4 GB card draws in well
    under a minute instead of being asked for the workflow's 2 megapixels. `ROSA_IMAGE_SIZE` changes the long side
    (1024 gives 768x1024 / 1024x768 / 1024x1024, 640 for speed, 0 to use the workflow's own shape and size).
  - **She writes the prompt from your examples**, whichever way the picture was asked for. Put your prompts in
    `image-prompts.txt` (not committed; `image-prompts.example.txt` is the placeholder), separated by `---` lines:
    either just the prompt, or `Request:` / `Prompt:` pairs so she also learns how a short request becomes a full
    prompt. For each picture the three examples closest to the request are shown to her and she writes one new prompt
    in the same style, keeping everything the person asked for. The file is re-read whenever it changes.
  - **A base prompt for every picture:** `image-base-prompt.txt` (next to `package.json`, not committed). It is a template
    with slots in capitals in square brackets (`[OUTFIT]`, `[POSE]`, `[FRAMING]`, `[CLOSE DETAILS]`, `[MIDGROUND]`,
    `[BACKGROUND]`, `[LIGHTING DESCRIPTION]`, `[COLOR TONE]`, or any name you like). For each picture the chat model fills the
    slots to match the request (the request is never passed to the image model on its own), and the filled template is the
    prompt sent to ComfyUI; a slot the model leaves empty gets a fallback, so no bracket ever reaches the generator. Because
    the template is about her, every picture shows her, even "a lighthouse" (she is in front of it). With no slots the
    text is simply put in front of the prompt she writes, or where `{prompt}` is. Lines starting with `#` are notes. Saving
    the file is enough, no restart. The debug log (`image.start`) shows the full prompt that was sent.
  - Only `ComfyUI-GGUF`, `comfyui-kjnodes` (sage attention) and `RES4LYF` (the `res_2s` sampler and `bong_tangent` scheduler)
    are loaded, so ComfyUI starts quickly. If your workflow uses a node or sampler from another custom node, add its folder name
    to `comfyNodes`; ComfyUI otherwise refuses with "Value not in list", and the page now says which input and value. Add more in
    `rosia.local.json` under `comfyNodes`. With no saved workflow the built-in plain Z-Image Turbo one is used.
- **The "Create image" button:** by the message box (shown wherever pictures can be drawn for the person), like the one in
  ChatGPT and Gemini. Switch it on, type what you want, and that message is a picture request: the picture tool is run
  for it directly, with no guessing from the model. A picture drawn ahead of time that fits is shown at once; otherwise it
  is drawn as usual. It switches itself off after that one message, and does nothing if a picture is attached.
- **Pictures drawn ahead of time (instant photos):** while nobody has chatted for 15 minutes the server lends the card to
  the image generator and draws a few pictures (scenes written by the chat model, filled into your template), keeping up to
  `ROSA_POOL_SIZE` (6) in `data/pool`. It tops up only once the stock is down to the low-water mark (the size minus a
  batch, so 3 of 6), by at most `ROSA_POOL_BATCH` (3) at a time and not more than once in 20 minutes, so using a picture or
  two does not take the card away from chat. When someone asks for a picture of her, a stocked one that **really fits** is
  copied into their own pictures and shown at once: the scene it was drawn for and the request are compared by meaning
  (vectors, see "How things are matched" below), and only a close match counts (0.45 with EmbeddingGemma; a beach towel at
  sunset fits "in a towel on the beach at sunset" at 0.62, while "a red dress at a party" scores 0.29 against every stocked
  scene and is drawn instead). "A pic of you" takes any; and a new one is drawn later to replace it. A request nothing fits is drawn as usual, and a person's
  picture always goes ahead of stocking up. A stocked picture is used once. It only happens when the launcher can lend the
  card, never while someone is chatting (a job is dropped if someone turns up, including someone whose message is waiting for
  the card), and `ROSA_POOL_SIZE=0` turns it off. The
  status page shows how full the stock is.
  - **Names:** each picture is named for what it is, `pool-20261111-1317-lace-bra-and-shorts-balcony-9a280b.png` (when it
    was drawn, what for, a short id), so the folder can be read at a glance. `pool.json` lists them.
  - **A restart changes nothing:** the stock is read back as it was, pictures from older versions are renamed once, an
    entry whose picture has gone is removed from the list (the debugging log says `pool.missing`), and the time of the last
    top-up is remembered (`state.json`), so a restart never starts another one straight away. `pool.load` says what was found.
- **The card is shared.** A 4 GB card cannot hold the chat model and the image model together, so they take
  turns: when a picture is requested, replies in progress finish, the launcher stops the chat model, starts ComfyUI,
  draws, then stops ComfyUI and brings the chat model back (`scripts/supervisor.js`, a small token-protected control
  port that only the app can use). A message sent meanwhile waits and is answered as soon as the model is back; the
  page says so. Back-to-back pictures do not swap the card in between. If the app dies mid-picture, the launcher
  puts the chat model back.
  - **Standby (opt-in):** add `"comfyStandby": true` to `rosia.local.json` (or `ROSA_COMFY_STANDBY=1`) and ComfyUI is
    started with everything else and **stays running**, so a picture no longer waits for it to start (about 20-45 s
    saved). The chat model still steps off the card while a picture is drawn, because drawing needs about 2.3 GiB and the
    chat model fills about 3.8 of the card's 4. What changes is that ComfyUI is never stopped: between pictures it is asked
    to unload its models and keeps only its small idle footprint (about 0.4 GiB; not measured here). To leave room for that,
    in standby the chat model is started with `standbyModelArgs` (default `["--no-mmproj-offload"]`: the vision projector,
    about 0.9 GiB, runs on the processor, which only slows reading pictures, such as ones people send and GIF/video
    cataloguing; chat speed is unchanged), and ComfyUI with `standbyComfyArgs` (default `["--cache-none"]`, so it does not
    keep models in your RAM between pictures). Every flag is checked against the program's own `--help` first, and standby
    switches itself off, saying why, if a flag is unknown, if ComfyUI is not set up, or if the chat model was already running
    (started by hand, with its full settings, so there would be no room). Remove the line to go back to the old behaviour.
    The launcher's first lines say whether standby is on.
- **In the page:** a shimmering placeholder in the shape of the picture (soft drifting colour, a sweep of light,
  "Creating image", progress) that comes into focus when the picture arrives. It follows the job by polling, so it
  survives a reload and shows on every machine you have linked. A picture that was interrupted shows as such.
- **Who can ask:** everyone. Because a picture takes the card away from chat for a while, there are limits: two
  pending per person, `ROSA_IMAGES_PER_HOUR` (20) per person, and a queue of `ROSA_IMAGES_MAX_QUEUE` (8) overall.
  `ROSA_IMAGES_FOR_GUESTS=0` makes it owner-only. Pictures are kept in the person's own folder and count towards their
  picture space.
- **Reliable tool use:** when a request is plain ("draw...", "search for...", the weather somewhere), the tool is run
  first and the model only says the result (`server/preflight.js`), because a small model left to choose sometimes
  invents the answer. For drawings the chat model first writes the image prompt.

## Voice

**Her voice is made in your own browser.** Kokoro (82M parameters) runs on the visitor's device in a web worker
(`public/kokoro-worker.js`, via kokoro-js and ONNX Runtime, on WebGPU), so the words are turned into sound locally, nothing about
what is said is sent anywhere, there is no content filter, and the server does no work. **It is fetched in the background
as soon as the page opens** (nothing to press, nothing to agree to): the model (about 330 MB the first time; the browser
keeps it, so later visits take seconds) comes from public CDNs (jsDelivr and Hugging Face), and is then "warmed up" with a
sentence nobody hears, because a graphics card spends about ten seconds preparing its code for the first one. After that her
first reply starts speaking about a second after it is written. It runs on the visitor's graphics card (WebGPU) and
there is no setting for that. A browser with no WebGPU gets a slower processor version, so it still has a voice, and so does
a graphics card that drops out part-way (it is shared with other programs): she carries on from the processor rather than
going quiet. Voice problems are reported to the debugging log (`client.voice` lines: what went wrong, whether the browser
has a graphics card, which browser; never what was said), so they can be found.

- A speaker button in the top bar turns on "read her replies aloud" and opens the voice (15 female English Kokoro voices, US and UK; Heart is the default)
  and speed choices; every one of her messages has a listen button (on a phone, one under her last text, reading the whole
  reply). Replies are read sentence by sentence with the next
  sentence prepared while one plays; mood nudges the speed a little; mood tags, markdown, `*stage directions*`, emoji
  and web addresses are not spoken. The portrait glows and swells with the sound.
- If the machine running the server has its own Kokoro (`scripts/tts-server.py`, `ttsModel` in `rosia.local.json`) the
  panel also offers "On the server" as an alternative.
- Browsers only allow sound after a click or key press, so the first reply after a page load is read once you have
  clicked or sent a message.

**Talking to her.** The microphone button next to the message box uses the browser's speech recognition (the Web Speech
API). In Chrome and Edge that is Google's speech service, so your voice goes to Google while it is listening; Safari uses
Apple's; Firefox has none, so the button is hidden. It fills the message box as you talk and, by default, sends when you
stop ("Send when I stop talking" in the voice panel turns that off). Her voice stops when you start talking. It needs
microphone permission and `https` or `localhost`.

## Her GIFs

She can send GIFs from your own collection, as reactions. The collection is a folder (`Rosia-GIFs` in your user folder, or
`ROSA_GIFS_DIR` / `gifsDir` in `rosia.local.json`) filled by the BetterDiscord plugin in
`tools/betterdiscord/RosiaGifExport.plugin.js`, which saves your Discord favourites (renewing the expired Discord links
through the client) and keeps adding new ones. Nothing is copied: the files stay where they are.

- **Cataloguing** (`server/gifs/`): in the background, one clip at a time and only while nobody is chatting, a few frames
  of each clip (GIF, animated WebP, MP4, picture) are cut out by `scripts/gif_frames.py` (needs Pillow, and ffmpeg for
  video; set `gifPython` in `rosia.local.json` if the default `python` has no Pillow) and laid side by side in one picture.
  The chat model (it needs its vision projector) writes a full description (who is in it, wearing what, where, doing what,
  how it is filmed: 30 to 60 words), the exact feeling it sends, the moment in a chat it suits ("when they finally admit
  you were right"), a mood, an intensity from 1 to 5, a few tags, and whether it is adult or shows anyone who might be under
  18. That text becomes a vector (the memory embedding model), so a clip can be found by meaning. About 7 seconds per clip on
  a 4 GB card.
- **Older descriptions are redone:** clips catalogued before were given one short line ("A blonde woman smiles while sitting
  and looking upwards", feeling "Happy, sweet, and charming"), which left hundreds of them alike. They are described again
  with the fuller prompt in the background, only while nobody is chatting, after any new clips; the old description is used
  until the new one is ready (about four hours of idle time for 1,900 clips). The status page shows how far it has got.
  `ROSA_GIF_REDESCRIBE=0` keeps the old ones.
  It carries on after a restart and picks up new files. The status page shows how many are ready.
- **Kept quick:** the next clip's frames are cut while the model is still reading this one; the model's answer is kept short;
  a clip that is a byte-for-byte copy of one already looked at (the same GIF saved from two places) is copied, not looked
  at again; and the still pictures among your favourites (JPG/PNG) are left out, since they are not reactions.
- **Never sent:** anything the model thinks shows someone who might be under 18, files that have gone missing, and clips it
  could not read after three tries.
- **Adult clips** are only offered once the conversation is already heading there (her last few moods, or the person's own
  words).
- **When she sends one:** on request ("send me a gif", "got a gif of someone facepalming?": the tool is run for her, no
  guessing), when she chooses to (`send_gif`, held to a gap of three replies), and now and then on her own when her mood is
  warm or strong and it has been a few replies (`ROSA_GIF_CHANCE`, 0.3; `ROSA_GIF_GAP`, 3 replies). It is picked by meaning (see
  "How things are matched") and never one she sent that person lately, in any of their chats, nor a copy of one; if nothing
  matches well enough, nothing is sent. A reply with a GIF stays to a line.
- **In the page:** the GIF plays under her message (clips loop silently). Files are streamed from the folder through
  `/gif/<id>` to signed-in people only; the page is never told a file name or description.

## How things are matched

GIFs, saved videos and stocked pictures of her are all chosen the same way (`server/media-match.js`):

- What was asked for ("got a gif of someone facepalming?"), or for something she sends on her own, what she just said and
  her mood, becomes a vector and is compared with the vector of each item's description.
- Only items scoring at least a floor count. The floors were measured on the real catalogue with EmbeddingGemma: a right
  match scores about 0.42 to 0.65, while a typical item scores 0.2 to 0.3 against any request, so the floor is 0.40 for a
  request, 0.44 for a reaction to her own reply and 0.45 for a stocked picture. `ROSA_MATCH_FLOOR` moves them.
- Of those, the ones close to the best are the candidates and one is picked, usually the best.
- Nothing she has sent that person lately comes round again: the last 80 GIFs and 40 videos are remembered per person (on
  disk, across all their chats and restarts), and a near-identical copy of one counts as the same. Only when the only GIFs
  that fit were all sent before is the one sent longest ago used again, and never one of the last 20.
- Requests like "stop sending gifs", "don't send me any more videos" or "I'll send you the link" never send anything.

## What she sends on her own

She does not wait to be asked. After a reply, now and then, `server/spontaneous.js` may add one thing to it, never two and
never to a reply that already has a photo, picture, GIF or video:

| | how often | needs |
|---|---|---|
| a GIF that fits what she just said | `ROSA_GIF_CHANCE` (0.3), at least `ROSA_GIF_GAP` (3) replies apart | a warm, flirty, teasing, amused, surprised or smitten mood |
| one of her saved videos | `ROSA_VIDEO_CHANCE` (0.12), `ROSA_VIDEO_GAP` (10) | the conversation already heading that way, and a flirty or heated mood |
| a picture of herself | `ROSA_PIC_CHANCE` (0.1), `ROSA_PIC_GAP` (10) | the same, and one in the picture stock |

The model can also choose to send these itself (`send_gif`, `send_video`, and `send_picture`), held to gaps of its own.
"Heading that way" is the rule the adult GIFs already follow: the person's own words, or her recent mood. A picture is
only ever taken from the stock drawn ahead of time, so she never makes anyone wait for the graphics card because she felt
like sending one; with nothing in stock she just talks. Videos are checked first like any other. Set a chance to 0 to turn
one kind off.

## Her favourite videos

Videos work differently from GIFs: nothing is downloaded or catalogued, only **links** are kept, and the person's own
browser plays them.

- **Saving them** (BetterDiscord plugin 1.4+): the GIF picker gets a **Videos** tab beside GIFs. Paste links there (any
  number at once, one per line), or right-click any message that has a video and choose "Favourite this video for Rosia".
  The links go in `Rosia-GIFs/videos.json` (`{ url, name, label, addedAt }`). Nothing needs naming: the name box is an
  optional extra for finding a specific one.
  Links to files on Discord's servers expire after about a day, so the plugin renews them in the background (every few
  hours while Discord is open; the Renew button does it at once).
- **Looked at** (`server/videos/catalog.js`): like the GIFs, in the background and only while nobody is chatting, a few
  frames are cut straight from each link (ffmpeg reads the link itself; nothing is downloaded to disk) and the chat model
  describes them. The description becomes a vector, kept in `data/gifs/video-library.json`, so a video can be found by what
  it shows. It carries on after a restart and picks up new links; a Discord link past its expiry waits for the plugin to
  renew it. The same narrow check as the GIFs applies: a video is left out only if someone in it clearly looks like a
  child. If that is a false alarm, put the link's file name in `data/gifs/cleared.json` and it is looked at again and kept.
- **Sending:** when someone asks for a video ("send me a video", "got any funny cat videos?") the `send_video` tool is run
  for her; she can also send one on her own (see "What she sends on her own" below). A request for something specific is matched against what each video was
  found to show; "any video" gets a random one. None she sent that person lately comes round again. Adult videos follow the same rule as
  adult GIFs: only once the conversation is already heading that way.
- **Checked first:** before a link is sent the server asks for its first 2 KB. An expired Discord link (its `ex=`), a
  non-200 answer, or something that is not a video file is skipped and the next saved video is tried (up to six). If none
  works she says so. The server will not look at private or local addresses, including through redirects. Results are
  remembered for a few minutes.
- **In the page:** a normal video player under her message, loading straight from the link. If it fails to load (the link
  died after the check), the player is replaced with "open the video in a new tab".

## Machines and keys

Every machine (browser profile) gets its own long random key the first time it is let in. Chats, memory and
pictures are stored under the person that key belongs to, so two machines never see each other's data.

- The key is an HttpOnly cookie. Only a hash of it is stored on the server (`data/auth.json`). Scripts can
  use it as `Authorization: Bearer <key>`; `POST /api/auth` hands one out where a page load would.
- **Who gets a key without a code** (`ROSA_ACCESS`):
  - `invite` (default): only someone using the computer the server runs on (a direct connection, not via a
    tunnel or proxy). That person is the owner, and everything saved before keys existed is theirs. Anyone else
    sees a lock screen and needs a code.
  - `open`: anyone who can reach the address gets their own private space. Handy for sharing a tunnel link, but
    it means anyone with the link can use your model.
- **Link another machine** (drawer, Devices tab): the signed-in machine makes a one-time code (8 characters,
  valid 10 minutes). On the other machine open `/?pair=CODE`, or type the code on the lock screen, and it gets
  its own key for the same person, with the same chats and memory.
- Machines can be renamed and removed (a removed key stops working at once). A person's last machine can't be
  removed. If every machine is lost the data is still in `data/` but no key reaches it.
- Cross-site requests are refused, and pairing guesses are rate limited.
- This is not a login system: there are no passwords, and whoever holds a machine's key is that person.

## Conversations and memory

- **Chats** (the list icon, top left): every conversation is kept whole (a conversation stops taking new messages at
  `ROSA_MAX_MESSAGES`, 3000, instead of losing old ones). Rename or delete from the list. Deleting a chat removes it and the
  pictures sent in it; the pictures she drew in it and the debugging log are kept. "New
  chat" starts a fresh one without losing the old one; she opens it with a hello that picks up from last time.
- **Memory** (the heart): what she knows about you, across all chats. Every few messages she notes durable
  facts in the background (name, where you live, people, plans, tastes). You can see them, edit them,
  add your own or forget one at a time (there is deliberately no "forget everything" button). She also keeps a short "picture of you" written from those notes, and
  a rolling summary of each long chat so old turns are not lost.
- **Corrections.** When something she is told contradicts a note ("we moved to Bristol" vs "lives in Leeds"), each new
  fact is checked against the closest existing note with one small question (same / replaces / unrelated); a note that
  is out of date is corrected in place and its old wording is kept ("updated" tag, hover to see what it was).
  Notes you wrote or edited yourself are never changed behind your back. Facts about an event ("driving test on Friday")
  get an end date (worked out in code, not by the model) and move to **Past** afterwards; near-duplicates are merged.
- Notes are found by similarity, not exact words. Out of the box this uses a local hashed n-gram embedding
  (it handles plurals, tenses and everyday topics such as "movies" finding "horror films", but it does not
  know that "puppy" means "dog"). For true semantic matching run an embedding model and point at it:
  ```
  llama-server -m nomic-embed-text.gguf --embeddings --port 8081
  set ROSA_EMBED_URL=http://127.0.0.1:8081
  ```
- Background jobs (notes, summaries, titles) only run while no reply is being generated.

## She speaks first

- Opening the app: a greeting if the chat is blank or you have been away 45+ minutes (a new conversation after 6+ hours).
- If you go quiet after her message for about 5-7 minutes she may send one nudge. One per quiet spell.
- She is told the time of day (in your time zone) and how long it has been since you last wrote.
- A greeting or nudge can pick up something real she knows about you (one of your newest notes, at most one, never invented).

## Sounding like a person

- **Separate texts:** her reply is written in short paragraphs, and the page shows each as its own message, after a typing
  pause that matches its length (the reply is held until it is whole, then arrives text by text). A GIF, video, picture or
  note that came with it sits under the last text. Saved conversations show the same split. People who ask their system
  for less motion get every text at once. Off with `localStorage.setItem('rosia.texts', '0')` in the browser console.
- **Mood that carries on:** `vibeLine` (`server/context.js`) tells her how the conversation has been going: deep in an
  intimate mood after several hot replies, playful after flirting, flat after a run of flat ones, sleepy very late at night,
  and, when they have only sent a few words in a row, to carry the conversation herself instead of asking more questions.
- **Her persona** says not to end every message with a question, not to praise or echo what they said, not to offer
  "X or Y?" menus, not to narrate in brackets, and to vary her length. A narrated "(you send a GIF of ...)" is stripped, and
  if she says she is sending a GIF or video and had been asked for one, it is sent.
- **Measuring it:** `node scripts/chat-eval.js [--since 2026-11-11] [--session id]` reads the debugging log and reports how
  often she ends on a question, offers two options, uses assistant phrases or narrates, and how much her lengths vary, each
  with a target. Run it before and after changing the persona.

## Pictures and links

- **Pictures:** attach, paste or drag in up to three. They are shrunk in the browser and shown to the model
  (needs a vision-capable model; with llama.cpp that means `--mmproj`).
- **Links:** paste any web link. The server opens it and gives her the page's title, description and text; a link
  to a picture or GIF (direct, or a Tenor / Giphy / Imgur page) gives her the picture itself. A GIF is seen as one
  frame plus its caption. Pages that can't be opened (login, JavaScript-only, dead link) are reported honestly.
- Link fetching only accepts http/https, refuses private, loopback and link-local addresses (also after redirects),
  and is limited in time and size.

## Status page and limits

- **Status page** (`/status`, owner only, read-only): how fast replies are (time to first word and whole-reply, typical
  and slowest 1 in 20), tokens per second, how much of each prompt the model already had cached, replies over time,
  which search engines are up or paused, tool and background-job failure rates, queued background work and recent
  errors. Only timings, counts and short error notes are recorded (never what anyone said, and links are masked);
  they are kept for about a week in `data/logs/metrics.jsonl`. The owner is the person at the computer the server
  runs on, and any machine they have paired. `GET /api/admin/stats?hours=24` is the same data as JSON.
- **Debugging log** (`server/debuglog.js`, `data/logs/debug.jsonl`): the one place that DOES record what was said. For
  every message it keeps what the person wrote, what the model wrote round by round (including any tool call it wrote out as
  text), each tool call with its arguments and result, what was finally sent, picture jobs with their prompts, video and GIF
  cataloguing failures, and crashes. One JSON object per line with a time and a short user id, so a conversation can be
  followed from the first line to the last (`grep` for the `session` id). Pictures, sign-in tokens and link signatures are
  left out. It is never served over the web and is capped at about 50 MB (`debug.jsonl` + `debug.1.jsonl`). Anyone who
  chats with your server is being recorded in it, so tell them. `ROSA_DEBUG_LOG=0` turns it off;
  `ROSA_DEBUG_PROMPTS=1` also writes the whole prompt sent to the model each round (large).
- **Chats page** (`/chats`, owner only, read-only): the debugging log read back as a list of conversations (with problems
  marked) and, for one, every step in order: what they wrote, what the model wrote (and what was actually shown, so a tool
  call written out as text is plain to see), each tool call with its arguments and result, and what she sent.
  `/api/admin/chats` and `/api/admin/chat?session=` are the same as JSON. A friend gets a 403.
- **Age:** there is no age screen (the owner's decision, taken with legal advice). Rosia is for adults; the website and
  the Terms say so.
- **Backups** (`server/backup.js`): about two minutes after start-up, then every half hour, a backup is made if the last
  one is more than a day old. Chats, memory, who is signed in and the GIF/video catalogues go in a dated folder in
  `Rosia-Backups` (your user folder, or `ROSA_BACKUP_DIR`); pictures go in a shared `Rosia-Backups/media` that only ever
  gains files. The newest `ROSA_BACKUP_KEEP` (7) nights are kept, and only folders named `rosia-YYYY-MM-DD-HHMM` are ever
  removed. `node scripts/backup.js` makes one now. To restore, close Rosia and copy a night's `users`, `sessions`,
  `auth.json` and `gifs` back into `data` (and `media` next to them). `ROSA_BACKUP=0` turns it off.
- **Limits per person** (for chats and pictures they only ever refuse something new; no conversation or picture is
  deleted to make room, and there is no admin route that removes anyone's data): `ROSA_MAX_CONVERSATIONS` (500),
  `ROSA_MAX_MESSAGES` per conversation (3000), `ROSA_MAX_MEDIA_MB` of pictures (1024). A person over a limit sees a
  plain message; an import skips what does not fit and says so. The one exception is memory: at 300 notes the
  oldest note she wrote herself is retired to make room for a new one (notes you wrote yourself are never retired).

## Performance notes

- **Wire:** text files and big API answers are compressed (Brotli or gzip) and cached in memory; `app.js` goes
  from 42 KB to 12 KB on the wire and `styles.css` from 35 KB to 7 KB.
- **Saves:** sessions and memory are written once per burst of changes (not once per call), compactly, and
  atomically.
- **Pages from links** are parsed on a small pool of worker threads (one per couple of CPU cores), so a big page
  never stalls chat, several links parse in parallel, and a hostile page that sends the parser into a spin is
  stopped after 4 s instead of freezing the server.
- **Model slots:** if the model server runs more than one slot (`llama-server -np 2` or more) chat uses slot 0 and
  background jobs (notes, summaries, titles) use the last one, so a background job never throws away the cached
  prompt of the conversation. It is detected from `/props`; `ROSA_SLOTS` overrides it.
- **Browser:** only her resting face loads up front (the other eleven, about 2.7 MB, load when the browser is idle);
  off-screen messages in a long chat are not laid out (`content-visibility`); animation is paused while the tab is
  hidden; pictures are shrunk and encoded off the main thread.

## Speed

- The persona and tool definitions are kept constant at the top of the prompt and anything that changes per message (clock, saved notes) is appended to the newest message, so llama.cpp's prefix cache is reused. The server log prints `prompt=` (tokens processed) and `cached=` (tokens reused) per reply.
- Hidden model "thinking" is off by default (`ROSA_THINKING=on` turns it back on). On the test setup it cut a reply from ~10 s to ~2 s.
- A one-token warm-up request primes the cache at start-up and after quiet spells.

## Versions and updates

The version is `"version"` in `package.json` (semantic: 0.1.0 -> 0.1.1 fixes, 0.2.0 features, 1.0.0 big changes). Every install checks a signed release list every
six hours and, when there is a newer version, downloads it and installs it once nobody has chatted for ten minutes. Chats, memory and settings are never part of an
update and are never touched by one.

**Publishing (you):**

```bash
node scripts/release.js --init-key        # once: makes the signing key. The private part goes to ~/.rosia-release-key.pem (back it up!)
node scripts/release.js patch --notes "What is new"   # or minor / major / 1.2.0; runs the tests first, then builds dist/
```

That makes `dist/rosia-<version>.zip` and `dist/latest.json`. Upload both to the same place on any static host (a GitHub release, a bucket, your site), commit,
tag, and make `"rosia": { "updateUrl": "<address of latest.json>" }` in `package.json` the address installs look at (it ships inside every release, so set it once
before the first release you give to anyone). `--min-version x.y.z` marks older installs as "update required"; `--dry-run` builds without changing the project.

**Installs:** `updateMode` in `rosia.local.json` (or `ROSA_UPDATE_MODE`): `auto` (default), `notify` (downloaded, installed when the owner presses the button) or `off`.
`updateUrl` overrides the packaged address. The owner can see the state at `GET /api/update` and press `POST /api/update/install`.

**Why it is safe:** the release list is signed (Ed25519) with your private key and every install holds only the public key (`server/update-key.pub`), so the host cannot
hand out anything you did not sign; the zip's SHA-256 and size are part of what is signed; the zip is unpacked strictly (no paths that leave the folder); only the launcher
(`start.bat`) can replace files, and it keeps a copy of everything it replaces. After an update the new version is on trial for two minutes: if it stops or does not
answer, the previous version is put back automatically, the owner is told what happened (the reason and what the new version printed before it died, in `GET /api/update` under `failure`, in the launcher window and in `data/logs/update.log`), and that version **stays on offer**: it is tried again by itself after 24 hours, at most 3 times in all, so a crash loop cannot happen, and the owner can install it again at any moment. A newer release is a fresh start.

**Changing how data is stored:** add a migration to `server/migrate.js` (it runs once, in order, after a backup). It must only add or fill in, never delete or rename what the
previous version reads, so a version that is taken out again can still read the data.

## Notes

- Sessions live in `data/sessions/*.json`. Delete that folder to wipe every conversation.
- Nothing is sent anywhere except your model server and the search providers (only when she searches) and link
  previews (only for links someone pastes).
- The debugging log (`data/logs/debug.jsonl`, on by default) records what everyone says, guests included, and is kept
  when a chat is deleted. Tell the people you share a link with.
- The front end and back end are both plain files — no build step, no bundler, no dependency tree.
