import { IDENTITY } from './persona.js';
import { toolSchemas, runTool, toolNames } from './tools/registry.js';
import { CallGuard, extractTextCalls } from './toolText.js';
import { debug, debugPrompts, who } from './debuglog.js';
import { StageGuard, stripStage } from './stage.js';
import { streamCompletion, parseStream, mergeToolCalls } from './llm.js';
import { MoodFilter, MOOD_TAGS, stripBracketTags } from './mood.js';
import { routeToolCall } from './routing.js';
import { preflightCall, asksToSeeHer, poseFor, REFUSAL } from './preflight.js';
import { REPEAT_NOTE, isRepetitive, dedupeParagraphs, dropLeadingFiller, limitSentences, sentenceKeys, isKnownSentence, firstSentenceEnd } from './replytext.js';
import { PHOTO_POSES } from './tools/photos.js';
import { config } from './config.js';

// She says she is sending a GIF or video by name ("(you send a GIF of ...)", "here's a video for you", "(calls the tool)") ...
const SENT_CLAIM = /\(\s*(?:you |i )?(?:send|sent|sending)\b[^)]*\b(?:gifs?|vid(?:eo)?s?|clips?)\b[^)]*\)|\(\s*the (?:gif|video)\b[^)]*\)|\(\s*(?:calls?|calling)\b[^)]*\btool\b[^)]*\)|\b(?:sending|here'?s|here are|here you go)\b[^.!?\n]{0,60}\b(?:gifs?|vid(?:eo)?s?|clips?)\b/i;
// ... or vaguely ("here you go", "here's another"), which only counts when the person had plainly asked for something.
// ("here's the thing" and "here's your answer" are just talk.)
const VAGUE_CLAIM = /\bhere you go\b|\bhere'?s (?:one|another|a little something|something for you)\b|\b(?:try|trying) that again\b|\bgive me (?:one|a) (?:sec|second|moment)\b/i;
// the person named a GIF or a video
const MEDIA_ASK = /\b(?:gifs?|vid(?:eo)?s?|clips?)\b/i;
// or asked, in a few words, for more of what was just sent ("another one", "keep sending", "mmm mroe")
const MORE_ASK = /\b(?:more|moar|mroe|another|again|next one|one more|keep (?:them |em |it )?(?:coming|sending|going))\b/i;

/**
 * She said she was sending something ("here you go", "(calls the tool)", "(you send a GIF ...)") and made no call: which tool
 * the person's own words call for, as { name, args }, or null when what they said did not ask for any (so ordinary talk is left alone).
 * `recentMedia` is what she sent in her last reply or two ('gif' | 'video' | 'photo' | ''), so "another one" means more of that.
 */
export function claimedTool(raw, userText, { recentMedia = '' } = {}) {
  const user = String(userText || '');
  if (REFUSAL.test(user)) return null; // "stop sending gifs" is never a request for one
  const named = SENT_CLAIM.exec(raw);
  const vague = named ? null : VAGUE_CLAIM.exec(raw);
  if (!named && !vague) return null;
  const words = user.trim().split(/\s+/).filter(Boolean).length;
  const wantsMore = MORE_ASK.test(user) && words <= 6 && (Boolean(recentMedia) || words <= 3);
  const asked = MEDIA_ASK.test(user) || asksToSeeHer(user) || /\b(?:pics?|photos?|pictures?|selfies?)\b/i.test(user) || wantsMore;
  if (vague && !asked) return null; // "here you go" after "tell me more about your day" is just talk
  const mention = (named || vague)[0];
  const video = /\b(?:vid(?:eo)?s?|clips?)\b/i;
  if (video.test(mention) || video.test(user)) return { name: 'send_video', args: { about: '', asked: true } };
  const vibe = stripStage(raw).replace(/^\s*\[[a-z]+\]\s*/i, '').slice(0, 200) || 'playful tease';
  if (/\bgifs?\b/i.test(mention) || /\bgifs?\b/i.test(user)) return { name: 'send_gif', args: { vibe, asked: true } };
  const wantsPhoto = asksToSeeHer(user) || (/\b(?:pics?|photos?|pictures?|selfies?)\b/i.test(user) && /\b(?:send|show|gimme|give|see|want|get|got|didn'?t|didnt)\b/i.test(user));
  if (wantsPhoto) return { name: 'send_photo', args: poseFor(user) ? { pose: poseFor(user) } : {} };
  if (wantsMore) {
    // "more", "another one", "keep sending": more of what she just sent
    if (recentMedia === 'video') return { name: 'send_video', args: { about: '', asked: true } };
    if (recentMedia === 'photo') return { name: 'send_photo', args: {} };
    return { name: 'send_gif', args: { vibe, asked: true } };
  }
  return null;
}

export { SENT_CLAIM, VAGUE_CLAIM, MEDIA_ASK, MORE_ASK }; // for tests

/** Adds a note to a chat message, whether its content is plain text or a list of parts (text plus pictures). */
export function appendNote(message, note) {
  if (Array.isArray(message.content)) {
    const part = message.content.find((p) => p?.type === 'text');
    if (part) part.text = `${part.text}\n\n${note}`;
    else message.content.unshift({ type: 'text', text: note });
  } else {
    message.content = `${message.content ?? ''}\n\n${note}`;
  }
  return message;
}

/** What kind of thing she sent in her last couple of replies ('gif' | 'video' | 'photo' | 'image'), or ''. */
function lastMediaKind(session) {
  const recent = session.messages.filter((m) => m.role === 'assistant').slice(-2).reverse();
  const m = recent.find((r) => r.gif || r.video || r.photo || r.image);
  return m ? (m.gif ? 'gif' : m.video ? 'video' : m.photo ? 'photo' : 'image') : '';
}

// Every bracket word that could leak: mood tags, invented moods, and photo poses.
const TAG_WORDS = new Set([...MOOD_TAGS, ...Object.keys(PHOTO_POSES)]);

function toolNote(name, ok, payload) {
  if (!ok) {
    return `TOOL ${name} FAILED: ${payload}. Tell them plainly that it didn't work. Do not make anything up to cover for it; if you answer at all, say you are going from memory and may be out of date.`;
  }

  let parsed = null;
  try {
    parsed = JSON.parse(payload);
  } catch {
    /* plain text result */
  }

  if (parsed && Array.isArray(parsed.results)) {
    if (!parsed.results.length) {
      return `WEB SEARCH for "${parsed.query}" returned no results. Tell them you couldn't find anything.`;
    }
    const lines = parsed.results.map((r, i) => {
      const bits = [`${i + 1}. ${r.title}`];
      if (r.snippet) bits.push(`   ${r.snippet}`);
      if (r.excerpt) bits.push(`   page excerpt: ${r.excerpt}`);
      if (r.url) bits.push(`   source: ${r.url}`);
      return bits.join('\n');
    });
    return [
      `WEB SEARCH RESULTS for "${parsed.query}":`,
      ...lines,
      '',
      'RULES FOR USING THESE RESULTS:',
      '- The snippets and page excerpts above are the only facts you have. Answer from them.',
      '- Do NOT quote, paraphrase or describe any text that does not appear above.',
      '- If the snippets disagree or are unclear, say so plainly.',
      '- Say the answer the snippets actually give, even if it surprises you.',
      "- The lookup is finished. Do not say 'gimme a sec', 'checking' or anything about searching: just answer, starting with a mood tag in square brackets as always."
    ].join('\n');
  }

  if (parsed && parsed.weather) {
    const w = parsed.now;
    const days = parsed.days.map((d) => `${d.date}: ${d.summary}, ${d.low} to ${d.high} C, ${d.rainChance ?? '?'}% chance of rain`).join(' | ');
    return [
      `WEATHER for ${parsed.place} (observed ${parsed.observedAt}):`,
      `now: ${w.summary}, ${w.temperatureC} C (feels like ${w.feelsLikeC} C), wind ${w.windKmh} km/h, humidity ${w.humidityPct}%, rain ${w.rainMm} mm`,
      `next days: ${days}`,
      'Answer from this, in your own words, starting with a mood tag in square brackets as always. The lookup is finished; do not mention searching.'
    ].join('\n');
  }

  if (parsed && parsed.queued && parsed.ready && parsed.job) {
    return 'PICTURE SENT: it is already showing in the chat, they can see it right now. Do not describe what it looks like, do not say you are drawing it or that it will take a while. React to them in a line or two, in character. Start with a mood tag in square brackets, as always.';
  }

  if (parsed && parsed.queued && parsed.job) {
    return 'PICTURE STARTED. It is being drawn right now and will appear in the chat by itself in a minute or two. In a line or two, in character, tell them you are on it (a little teasing about the wait is fine). Do NOT describe what the picture looks like as if it exists, and do not say it is done. Start with a mood tag in square brackets, as always.';
  }

  if (parsed && parsed.gif && parsed.id) {
    return 'GIF ALREADY SENT: it is showing under your message right now. Do not describe it or say you are sending it. Reply with one short line in character, or just let it say it.';
  }

  if (parsed && parsed.video && parsed.url) {
    return 'VIDEO ALREADY SENT: it is showing under your message right now and they can play it. Do not describe it, guess what is in it or say you are sending it. Reply with one short line in character.';
  }

  if (parsed && parsed.sent && parsed.pose) {
    const wearing = parsed.wearing ? ` In it you are wearing ${parsed.wearing}. That is what you have on right now: if they ask what you are wearing, or you mention your clothes, say exactly that and never anything else (no other colours or clothes).` : '';
    return `PHOTO ALREADY SHOWN: the photo is on their screen right now, in place of your face next to the chat.${wearing} Do not describe the photo itself, do not name it and do not say you are getting ready or about to send it. Just react to them in a line or two, in character.`;
  }

  if (parsed && parsed.notes) {
    return `SAVED NOTES: ${parsed.notes.length ? parsed.notes.join(' | ') : '(none match)'}`;
  }
  if (parsed && parsed.local) {
    return `CURRENT DATE AND TIME: ${parsed.local} (${parsed.timezone})`;
  }

  return `TOOL ${name} RESULT: ${payload}`;
}

/*
 * Small models sometimes say "gimme a sec..." and then answer from thin air without ever calling the
 * search tool, which means made-up facts. If a reply claims a lookup but made no tool call, it is
 * thrown away and the search is run for her, using what the person asked as the query. (Asking the
 * model again with the tool "required" was tried first; this server's template ignores that.)
 *
 * This only applies when the person actually asked for a lookup. Her personality says "gimme a sec"
 * as a conversational tic, and treating every one of those as a failed search sent a real web search
 * off on "send me a sexy picture of yourself".
 */
const LOOKUP_CLAIM = /^\s*(\[[a-zA-Z]+\]\s*)?((gimme|give me) a (sec|second|moment|minute)|(hold on|hang on|one (sec|second|moment))\b|let me (look|check|search|google|find|see)\b)/i;
const WANTS_LOOKUP = /\b(search|look ?up|google|find out|what(?:'s| is) the (?:latest|news)|latest news|news (?:about|on)|current(?:ly)?|today'?s|right now|weather|score|scores|price|prices|who won|when did|how much is|is .+ still)\b/i;

/** The person's last message with the "search the web:" style lead-in removed. */
function searchQueryFrom(session) {
  const last = [...session.messages].reverse().find((m) => m.role === 'user')?.content || '';
  const query = last.replace(/^\s*(please\s+)?(can you\s+)?(search( the web| online| for)?|look ?up|google|find out)\b[:,]?\s*/i, '');
  return (query || last).trim().slice(0, 200);
}

/** Her last few replies, greeting and nudges included: repeating one of those is the same loop. */
function recentReplies(session, count = 4) {
  return session.messages
    .filter((m) => m.role === 'assistant' && typeof m.content === 'string' && m.content.trim())
    .slice(-count)
    .map((m) => m.content);
}

/**
 * Runs one reply (including any tool rounds).
 * Returns { text, raw, mood, stats }:
 *   text  what the person sees (mood tag stripped)
 *   raw   exactly what the model wrote, tag included, kept so next turn's prompt matches the cache
 */
export async function runChat({ session, user, tz, kind, mode, messages, model, temperature, onEvent, signal }) {
  // `signal` lets a slow tool (writing an image prompt) give up when the person hits stop
  const toolContext = { session, user, timezone: tz, signal };

  let text = '';
  let raw = '';
  let mood = null;
  let photo = null; // pose of the photo sent with this reply, if any
  let drawRequested = false;
  let gif = null; // the GIF sent with this reply, if any: { id, kind }
  let video = null; // the video sent with this reply, if any: { url, name }
  let image = null; // the picture being drawn for this reply, if any: { job, orientation, state }
  let narration = { text: '', raw: '' }; // what she said before a tool call ("gimme a sec...")
  let rounds = 0;
  let replaceNext = false; // the next text to arrive replaces what is on screen
  let searchedForHer = false;
  let retriedForRepeat = false;
  const previous = recentReplies(session);
  const schemas = kind ? [] : toolSchemas(toolContext); // greetings and nudges are just talk: no tools
  const stats = { ttftMs: null, promptTokens: 0, cachedTokens: 0, genTokens: 0, genPerSec: 0, rounds: 0 };
  const t0 = Date.now();

  /** Runs the tool calls (together, since they are independent) and adds the results for the model to read. */
  async function runCalls(calls, assistantContent) {
    messages.push({
      role: 'assistant',
      content: assistantContent || null,
      tool_calls: calls.map((c) => ({ id: c.id, type: 'function', function: { ...c.function } }))
    });

    for (const call of calls) {
      onEvent({ type: 'tool', name: call.function.name, status: 'start' });
    }

    // Calls within one round are independent, so run them together.
    const outcomes = await Promise.all(
      calls.map(async (call) => {
        // one picture per message: a second request in the same reply is turned down before it is queued
        const isPicture = call.function.name === 'generate_image' || call.function.name === 'send_picture';
        const pictureAlready = isPicture && (image || drawRequested);
        if (isPicture) drawRequested = true;
        // one photo per message too: a second one would just push the first out of view
        const photoAlready = (call.function.name === 'send_photo' && Boolean(photo)) || (call.function.name === 'send_gif' && Boolean(gif)) || (call.function.name === 'send_video' && Boolean(video));
        const outcome = pictureAlready || photoAlready
          ? { ok: false, error: 'Only one picture per message, and one was already sent with this reply.' }
          : await runTool(call.function.name, call.function.arguments, toolContext);
        // a picture call that failed did not use up this reply's picture: a later round may try again
        if (isPicture && !pictureAlready && !outcome.ok && !image) drawRequested = false;
        onEvent({
          type: 'tool',
          name: call.function.name,
          status: outcome.ok ? 'done' : 'error',
          detail: outcome.ok ? undefined : outcome.error
        });
        if (call.function.name === 'remember' && outcome.ok) {
          try {
            const saved = JSON.parse(outcome.result);
            if (saved.saved && saved.new) onEvent({ type: 'memory', text: saved.text });
          } catch {
            /* nothing to announce */
          }
        }
        if ((call.function.name === 'generate_image' || call.function.name === 'send_picture') && outcome.ok && !image) {
          try {
            const queued = JSON.parse(outcome.result);
            // one drawn ahead of time is already done and is shown at once
            image = { job: queued.job, orientation: queued.orientation, state: queued.ready ? 'done' : 'pending', prompt: queued.prompt, media: queued.ready ? queued.media : undefined };
            onEvent({ type: 'image', job: queued.job, state: queued.ready ? 'done' : 'queued', ratio: queued.orientation, media: queued.ready ? queued.media : undefined });
          } catch {
            /* malformed result: nothing to show */
          }
        }
        if (call.function.name === 'send_gif' && outcome.ok && !gif) {
          try {
            const sent = JSON.parse(outcome.result);
            gif = { id: sent.id, kind: sent.kind };
            onEvent({ type: 'gif', id: sent.id, kind: sent.kind, url: sent.url });
          } catch {
            /* malformed result: nothing to show */
          }
        }
        if (call.function.name === 'send_video' && outcome.ok && !video) {
          try {
            const sent = JSON.parse(outcome.result);
            video = { url: sent.url, name: sent.name || '' };
            onEvent({ type: 'video', url: video.url, name: video.name });
          } catch {
            /* malformed result: nothing to show */
          }
        }
        if (call.function.name === 'send_photo' && outcome.ok) {
          try {
            const { pose } = JSON.parse(outcome.result);
            if (!photo) {
              photo = pose;
              onEvent({ type: 'photo', pose });
            }
          } catch {
            /* malformed result: nothing to show */
          }
        }
        return { call, outcome };
      })
    );

    for (const { call, outcome } of outcomes) {
      messages.push({
        role: 'tool',
        tool_call_id: call.id,
        content: toolNote(call.function.name, outcome.ok, outcome.ok ? outcome.result : outcome.error)
      });
    }
  }

  // Where the person's words leave no doubt (weather somewhere, "search for", "draw me", "show me you"), the
  // tool is run for her first. A small model that is left to choose will sometimes just make the answer up.
  const forced = kind ? null : await preflightCall({ session, schemas, model, signal, mode });
  if (forced) {
    debug('preflight', { user: who(session.userId), session: session.id, name: forced.function.name, args: forced.function.arguments });
    await runCalls([forced], '');
  }

  const knownSentences = sentenceKeys(previous);
  // the names she may actually call in this reply (greetings and nudges have none)
  const offered = new Set(schemas.map((t) => t.function.name));
  let toolsLeft = schemas.length > 0; // once the tool budget is spent, the last round is offered no tools and must answer
  let toolRounds = 0;
  // every tool round, the answer after them, and one restart for a repeated opening
  const maxCalls = config.maxToolRounds + 2;

  while (rounds < maxCalls) {
    rounds += 1;
    stats.rounds = rounds;
    const finalRound = !toolsLeft;
    // Each round has its own abort handle, so a repeated sentence can stop the stream early while the person's own
    // stop button still works.
    const roundCtl = new AbortController();
    const forwardAbort = () => roundCtl.abort();
    signal?.addEventListener('abort', forwardAbort, { once: true });

    debug('model.request', { user: who(session.userId), session: session.id, round: rounds, messages: messages.length, tools: schemas.map((t) => t.function.name), prompt: debugPrompts() ? messages : undefined });
    // with a photo or picture on its way a line is all the reply needs: anything more is her describing it
    const stream = await streamCompletion({ model, messages, tools: toolsLeft ? schemas : [], signal: roundCtl.signal, temperature, maxTokens: photo || image || gif || video ? 90 : undefined });
    const filter = new MoodFilter({ stripLead: replaceNext, inlineWords: TAG_WORDS });
    const guard = new CallGuard(toolNames()); // a tool call the model wrote out as text is never shown
    const stage = new StageGuard(); // nor a narrated "(you send a GIF of ...)"
    let content = '';
    let roundRaw = '';
    let announced = false;
    let resetSent = false;
    const calls = [];
    mood = null; // a mood only counts if it belongs to the reply that is actually kept

    /*
     * Repeats are caught while the reply is still arriving, so the person never sees a reply appear, vanish and
     * start again:
     *  - the start of a reply is held back until its first sentence is whole; if that sentence is one she has
     *    already said, the stream is stopped and restarted before anything was shown;
     *  - a later sentence that repeats an old one ends the reply there (the saved text drops it).
     */
    const canRetry = !retriedForRepeat && previous.length > 0 && !replaceNext;
    let held = '';
    let released = !canRetry;
    let stopReason = '';
    let checked = 0; // how much of `content` has been looked at for repeated sentences
    let cutAt = -1;

    const show = (piece) => {
      content += piece;
      onEvent({ type: 'delta', text: piece });
      for (;;) {
        const rest = content.slice(checked);
        const end = firstSentenceEnd(rest);
        if (end === -1) break;
        if (isKnownSentence(rest.slice(0, end), knownSentences)) {
          stopReason = 'repeat-later';
          cutAt = checked;
          roundCtl.abort();
          break;
        }
        checked += end;
      }
    };

    const emit = (shown) => {
      // After a tool call the answer replaces her "gimme a sec" line on screen instead of piling up
      // under it, which is how she used to say the same filler twice in one reply.
      if (replaceNext && !resetSent && (shown || filter.mood)) {
        resetSent = true;
        onEvent({ type: 'reset' });
      }
      if (filter.mood && !announced) {
        announced = true;
        mood = filter.mood;
        onEvent({ type: 'mood', mood });
      }
      if (!shown || stopReason) return;
      if (!released) {
        held += shown;
        const end = firstSentenceEnd(held);
        if (end === -1 && held.length < 90) return;
        if (end !== -1 && isKnownSentence(held.slice(0, end), knownSentences)) {
          stopReason = 'repeat-start';
          roundCtl.abort();
          return;
        }
        released = true;
        const out = held;
        held = '';
        show(out);
        return;
      }
      show(shown);
    };

    try {
      for await (const chunk of parseStream(stream)) {
        if (chunk.content) {
          if (stats.ttftMs === null) stats.ttftMs = Date.now() - t0;
          roundRaw += chunk.content;
          emit(stage.push(guard.push(filter.push(chunk.content))));
        }
        if (chunk.toolCalls) mergeToolCalls(calls, chunk.toolCalls);
        if (chunk.timings) {
          stats.promptTokens += chunk.timings.prompt_n || 0;
          stats.cachedTokens += chunk.timings.cache_n || 0;
          stats.genTokens += chunk.timings.predicted_n || 0;
          stats.genPerSec = Math.round((chunk.timings.predicted_per_second || 0) * 10) / 10;
        }
      }
    } catch (err) {
      // stopping the stream ourselves is not an error; the person hitting stop still is
      if (!(err?.name === 'AbortError' && stopReason && !signal?.aborted)) throw err;
    } finally {
      signal?.removeEventListener('abort', forwardAbort);
    }
    if (!stopReason) emit(stage.push(guard.push(filter.flush()) + guard.flush()) + stage.flush());

    // a short reply that ended before its first sentence was whole: the same check, still before anything is shown
    if (held && !stopReason) {
      if (!calls.length && isRepetitive(content + held, previous)) stopReason = 'repeat-start';
      else {
        released = true;
        const out = held;
        held = '';
        show(out);
      }
    }

    if (stopReason === 'repeat-start') {
      retriedForRepeat = true;
      // Appended to the person's message rather than sent as a system turn: several chat templates
      // (Gemma's included) reject a conversation that is not strictly alternating.
      const last = [...messages].reverse().find((m) => m.role === 'user');
      if (last) appendNote(last, `[note to you, never mention it: ${REPEAT_NOTE}]`);
      continue;
    }
    // the last round was offered no tools: whatever it wrote is the answer, even if it tried to call something
    if (finalRound) calls.length = 0;
    if (stopReason === 'repeat-later') {
      // she started repeating herself part-way: the reply ends just before the repeated sentence
      content = content.slice(0, cutAt).trim();
      roundRaw = `${filter.mood ? `[${filter.mood}] ` : ''}${content}`;
      calls.length = 0;
    }

    const lastUserText = [...session.messages].reverse().find((m) => m.role === 'user')?.content || '';

    // the model wrote a call as text (`send_photo{pose:"front"}`) instead of making one: it was kept off the screen, and is run now
    const nativeCalls = calls.map((c) => c.function.name);
    const nativeArgs = calls.map((c) => c.function.arguments);
    const rawBefore = roundRaw;
    let textCalls = [];
    if (!calls.length && !finalRound && offered.size) {
      // only tools that were actually offered for this reply are run (the guard above still hides any tool text)
      const written = extractTextCalls(roundRaw, toolNames().filter((n) => offered.has(n)));
      if (written.calls.length) {
        textCalls = written.calls;
        written.calls.slice(0, 1).forEach((c, i) => calls.push({ id: `call_text_${rounds}_${i}`, type: 'function', function: { name: c.name, arguments: JSON.stringify(c.args) } }));
        roundRaw = written.text;
      }
    }
    // she wrote "(you send a GIF of ...)" or "here's a video" but made no call, and they had asked for one: it is sent for her
    const claimed = !calls.length && !finalRound && !gif && !video && !photo && !image ? claimedTool(rawBefore, lastUserText, { recentMedia: lastMediaKind(session) }) : null;
    if (claimed && offered.has(claimed.name)) {
      calls.push({ id: `call_claim_${rounds}`, type: 'function', function: { name: claimed.name, arguments: JSON.stringify(claimed.args) } });
      roundRaw = stripStage(rawBefore);
      textCalls = [{ name: claimed.name, args: claimed.args, why: 'said it was sending one, made no call' }];
    }
    debug('model.round', { user: who(session.userId), session: session.id, kind: kind || 'chat', round: rounds, raw: rawBefore, shown: content, nativeCalls, nativeArgs, textCalls, stop: stopReason || undefined });

    if (!calls.length && !searchedForHer && offered.has('web_search')) {
      // claimed a lookup, made none, and the person actually asked for one: search for her so the answer
      // rests on real results. Her "gimme a sec" in ordinary chat is not a claim and must not trigger this.
      if (!finalRound && LOOKUP_CLAIM.test(content) && WANTS_LOOKUP.test(lastUserText)) {
        searchedForHer = true;
        calls.push({
          id: 'call_search_for_her',
          type: 'function',
          function: { name: 'web_search', arguments: JSON.stringify({ query: searchQueryFrom(session) }) }
        });
        roundRaw = ''; // the made-up narration is not replayed to the model
      } else if (LOOKUP_CLAIM.test(content) && !photo && !image) {
        // no lookup was asked for: the filler is dropped instead of being shown as a promise
        const cleaned = dropLeadingFiller(content);
        if (cleaned !== content) {
          // shown again from the start, straight to the screen: going through emit() would drop it when the reply had
          // already been cut short for repeating itself (stopReason set), leaving nothing at all
          roundRaw = dropLeadingFiller(roundRaw);
          onEvent({ type: 'reset' });
          content = cleaned;
          checked = cleaned.length;
          if (cleaned) onEvent({ type: 'delta', text: cleaned });
        }
      }
    }

    if (!calls.length) {
      // Only the final answer is kept: it is what gets saved and replayed to the model next turn.
      raw = roundRaw;
      text = content;
      break;
    }

    // where the right tool is obvious (weather), run it instead of a web search
    calls.forEach((c, i) => { calls[i] = routeToolCall(c, lastUserText); });

    narration = { text: content, raw: roundRaw };
    replaceNext = true;

    await runCalls(calls, roundRaw);
    toolRounds += 1;

    if (toolRounds >= config.maxToolRounds || rounds >= maxCalls - 1) {
      // The budget is spent: the next round is offered no tools and answers from what came back. The instruction rides on
      // the last tool result rather than a system turn, which Gemma's template refuses in the middle of a conversation.
      toolsLeft = false;
      const lastTool = messages.at(-1);
      if (lastTool?.role === 'tool') lastTool.content += '\n\nYou have used your tool budget. Answer now with what you have; if the info was thin, say so briefly.';
    }
  }

  // tool budget ran out before a clean answer: fall back to whatever she last said
  if (!text.trim() && narration.text.trim()) {
    text = narration.text;
    raw = narration.raw;
  }

  // The last word on anything that leaked through the stream: tag tokens the splitter could not rule out
  // (written mid-reply, inside a paragraph) and a paragraph said twice in one go.
  text = stripStage(stripBracketTags(dedupeParagraphs(text), TAG_WORDS));
  const brief = (t) => (gif || video ? limitSentences(t, 1) : photo || image ? limitSentences(t, 2) : t);
  text = brief(text);

  // `raw` is replayed next turn, so it must not carry the stray tags the person never saw either:
  // otherwise the model is taught that they are fine. Its opening tag is kept, because the next turn's
  // prompt has to look like the replies it is being asked for — but written as a tag that really exists,
  // so an invented one is not reinforced either.
  const tag = /^\s*(\[[a-zA-Z][a-zA-Z' -]{0,20}\])\s*/.exec(raw);
  const opening = tag && mood ? `[${mood}]` : '';
  const body = stripStage(stripBracketTags(dedupeParagraphs(tag ? raw.slice(tag[0].length) : raw), TAG_WORDS));
  raw = opening ? `${opening}\n${brief(body)}` : brief(body);

  stats.totalMs = Date.now() - t0;
  return { text, raw: raw.trim(), mood, photo, image, gif, video, stats };
}
