import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
// "home": the folder with the person's own files (rosia.local.json, the image prompt files, data/). The program's own folder
// when run from source; the desktop app points it elsewhere, so an installed copy never keeps anyone's data beside the program.
const home = process.env.ROSIA_HOME ? path.resolve(process.env.ROSIA_HOME) : root;

function num(value, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

// A test run never touches the real data folder: without ROSA_DATA_DIR it gets a throwaway one of its own.
const dataDir = process.env.ROSA_DATA_DIR
  || (process.env.NODE_TEST_CONTEXT ? fs.mkdtempSync(path.join(os.tmpdir(), 'rosia-test-data-')) : path.join(home, 'data'));

export const config = {
  root,
  home,
  publicDir: path.join(root, 'public'),
  dataDir,
  usersDir: path.join(dataDir, 'users'),
  mediaDir: path.join(dataDir, 'media'),
  // loopback by default: the persona is unfiltered, so don't expose it to the LAN unless asked (HOST=0.0.0.0)
  host: process.env.HOST || '127.0.0.1',
  // how close in meaning a GIF, video or stocked picture must be to what was asked for (see media-match.js); unset uses
  // the value measured for the embedding model in use
  matchFloor: num(process.env.ROSA_MATCH_FLOOR, 0),
  port: num(process.env.PORT, 8787),
  ollamaUrl: (process.env.OLLAMA_URL || 'http://127.0.0.1:11434').replace(/\/+$/, ''),
  model: process.env.ROSA_MODEL || '',
  // 0.9 suits Gemma 4 (Google suggests 1.0): livelier and less samey than the 0.65 it had. Lower it if she gets silly.
  temperature: num(process.env.ROSA_TEMPERATURE, 0.9),
  // extra sampling settings sent with every reply (llama.cpp understands top_k, top_p, min_p, presence_penalty, repeat_penalty).
  // These are Gemma's recommended top_k / top_p with a small min_p to cut the silly tail the higher temperature opens up.
  // ROSA_SAMPLING takes JSON to override any of them. (A high presence penalty pushed a 4B model onto new topics, so it is
  // kept tiny; repeats are caught in code.)
  sampling: (() => {
    const base = { top_p: 0.95, top_k: 64, min_p: 0.05, presence_penalty: 0.1, repeat_penalty: 1.05 };
    try {
      return { ...base, ...JSON.parse(process.env.ROSA_SAMPLING || '{}') };
    } catch {
      return base;
    }
  })(),
  // a nightly copy of chats, memory and the catalogues (see backup.js); not during test runs unless asked
  backup: (() => {
    const home = process.env.USERPROFILE || process.env.HOME || '';
    return {
      enabled: !/^(0|off|false|no)$/i.test(process.env.ROSA_BACKUP || '1') && !(process.env.NODE_TEST_CONTEXT && !process.env.ROSA_BACKUP),
      dir: process.env.ROSA_BACKUP_DIR || (home ? path.join(home, 'Rosia-Backups') : ''),
      keep: num(process.env.ROSA_BACKUP_KEEP, 7)
    };
  })(),
  timezone: process.env.ROSA_TZ || Intl.DateTimeFormat().resolvedOptions().timeZone || 'Europe/London',
  maxTokens: num(process.env.ROSA_MAX_TOKENS, 1024),
  // Hidden "thinking" tokens were ~80% of every reply on this setup (≈450 thinking vs ≈80 spoken tokens,
  // ~10 s extra per message), so it is off by default. ROSA_THINKING=on restores it.
  thinking: /^(1|on|true|yes)$/i.test(process.env.ROSA_THINKING || ''),
  reasoningEffort: process.env.ROSA_REASONING_EFFORT || '',
  maxToolRounds: num(process.env.ROSA_MAX_TOOL_ROUNDS, 2),
  historyForModel: num(process.env.ROSA_HISTORY, 40),
  historyStep: 12,
  sessionCacheMax: 50,
  keepAliveMs: 15_000,
  maxMessageChars: 8000,

  // optional real embedding model (OpenAI-style /v1/embeddings), e.g. `llama-server --embeddings` on
  // another port. Without it, a local hashed n-gram embedding is used.
  embedUrl: (process.env.ROSA_EMBED_URL || '').replace(/\/+$/, ''),
  embedModel: process.env.ROSA_EMBED_MODEL || 'embed',
  // which prefix the embedding model expects: nomic | embeddinggemma | bge | none
  embedStyle: process.env.ROSA_EMBED_STYLE || 'none',
  // minimum similarity for a note to count as relevant; leave unset to use the model's usual value
  embedFloor: num(process.env.ROSA_EMBED_FLOOR, 0),

  // Model server slots (llama-server -np N). Detected from the server; set ROSA_SLOTS to force a number.
  // With 2 or more, chat uses slot 0 and background jobs (notes, summaries, titles) use the last one, so a
  // background job never throws away the chat's cached prompt.
  slots: num(process.env.ROSA_SLOTS, 0),

  // web search. Own SearXNG or a Brave key are used first if given; the rest need no key.
  search: {
    searxngUrl: (process.env.ROSA_SEARXNG_URL || '').replace(/\/+$/, ''),
    braveKey: process.env.ROSA_BRAVE_KEY || '',
    duckUrl: process.env.ROSA_DDG_URL || 'https://html.duckduckgo.com/html/',
    yahooUrl: process.env.ROSA_YAHOO_URL || 'https://search.yahoo.com/search',
    bingUrl: process.env.ROSA_BING_URL || 'https://www.bing.com/search',
    wikipediaUrl: process.env.ROSA_WIKI_URL || 'https://en.wikipedia.org/w/api.php',
    geocodeUrl: process.env.ROSA_GEOCODE_URL || 'https://geocoding-api.open-meteo.com/v1/search',
    forecastUrl: process.env.ROSA_FORECAST_URL || 'https://api.open-meteo.com/v1/forecast'
  },

  // her voice: a local Kokoro server (scripts/tts-server.py). Off unless ROSA_TTS_URL is set; start.bat sets it.
  tts: {
    url: (process.env.ROSA_TTS_URL || '').replace(/\/+$/, ''),
    voice: process.env.ROSA_TTS_VOICE || 'af_heart',
    perMinute: num(process.env.ROSA_TTS_PER_MINUTE, 90)
  },

  // her collection of GIFs (see server/gifs/): the folder the BetterDiscord export plugin fills. Found by itself when it is
  // in the user folder as Rosia-GIFs; ROSA_GIFS_DIR points somewhere else.
  gifs: (() => {
    const home = process.env.USERPROFILE || process.env.HOME || '';
    // (a test run never goes looking in the real collection: the test runner marks its processes)
    const dir = process.env.ROSA_GIFS_DIR || (home && !process.env.NODE_TEST_CONTEXT ? path.join(home, 'Rosia-GIFs') : '');
    return {
      dir,
      // Pillow and ffmpeg cut the frames; the Python that has Pillow can be named here
      python: process.env.ROSA_GIF_PYTHON || 'python',
      frames: num(process.env.ROSA_GIF_FRAMES, 3),
      // clips catalogued with the older, one-line descriptions are described again in the background, while nobody is
      // chatting (about 5 s each); ROSA_GIF_REDESCRIBE=0 keeps the old ones
      redescribe: !/^(0|off|false|no)$/i.test(process.env.ROSA_GIF_REDESCRIBE || '1'),
      // she sends one on her own at most this often (replies between two GIFs), and only this share of the time
      minGap: num(process.env.ROSA_GIF_GAP, 3),
      chance: Math.min(1, Math.max(0, num(process.env.ROSA_GIF_CHANCE, 0.3)))
    };
  })(),

  // the videos and pictures she sends on her own (server/spontaneous.js): replies that must pass between two of the same
  // kind, and the share of the time she does, when the conversation is already heading that way
  spontaneous: {
    videoGap: num(process.env.ROSA_VIDEO_GAP, 10),
    videoChance: Math.min(1, Math.max(0, num(process.env.ROSA_VIDEO_CHANCE, 0.12))),
    pictureGap: num(process.env.ROSA_PIC_GAP, 10),
    pictureChance: Math.min(1, Math.max(0, num(process.env.ROSA_PIC_CHANCE, 0.1)))
  },

  // pictures she draws (text to image through ComfyUI). Off unless ROSA_COMFY_URL is set; start.bat sets it.
  images: {
    url: (process.env.ROSA_COMFY_URL || '').replace(/\/+$/, ''),
    unet: process.env.ROSA_IMAGE_UNET || 'z-image-turbo-Q4_K_M.gguf',
    clip: process.env.ROSA_IMAGE_CLIP || 'Huihui-Qwen3-4B-Instruct-2507-abliterated.Q4_K_M.gguf',
    clipType: process.env.ROSA_IMAGE_CLIP_TYPE || 'lumina2',
    vae: process.env.ROSA_IMAGE_VAE || 'ae.safetensors',
    steps: num(process.env.ROSA_IMAGE_STEPS, 8),
    // euler / simple at `steps` steps instead of the saved workflow's sampler (res_2s takes about 2.5x as long per picture).
    // ROSA_IMAGE_FAST=0 uses the workflow's own sampler, scheduler and steps.
    fast: !/^(0|off|false|no|workflow)$/i.test(process.env.ROSA_IMAGE_FAST || '1'),
    // the workflow saved in ComfyUI (the editor's "Save", not "Export (API)"); it decides models, LoRA, sampler and steps.
    // Without one, a built-in plain Z-Image Turbo workflow is used. Put {prompt} in its positive prompt to say where
    // the request goes; without it only the leading style words are kept.
    workflow: process.env.ROSA_IMAGE_WORKFLOW || '',
    // long side in pixels: the shapes are fixed at portrait 576x768, landscape 768x576, square 768x768. That is about
    // a third of a megapixel, so a 4 GB card draws in well under a minute instead of being asked for 2 megapixels.
    // Raise it for sharper pictures that take longer (1024 gives 768x1024/1024x768/1024x1024), lower it (640) for speed.
    longSide: num(process.env.ROSA_IMAGE_SIZE, 768),
    // where her image-prompt examples live (see image-prompts.example.txt)
    promptExamples: process.env.ROSA_IMAGE_PROMPTS || '',
    timeoutMs: num(process.env.ROSA_IMAGE_TIMEOUT_S, 600) * 1000,
    // the launcher's local control port, used to lend the graphics card to the image generator
    controlUrl: (process.env.ROSA_CONTROL_URL || '').replace(/\/+$/, ''),
    controlToken: process.env.ROSA_CONTROL_TOKEN || '',
    // everyone can ask for pictures; ROSA_IMAGES_FOR_GUESTS=0 makes it owner-only (they block everyone's chat while made)
    guests: !/^(0|off|false|no)$/i.test(process.env.ROSA_IMAGES_FOR_GUESTS || '1'),
    maxQueue: num(process.env.ROSA_IMAGES_MAX_QUEUE, 8),
    // pictures drawn ahead of time while nobody is chatting, so a request is answered at once (0 turns it off)
    pool: process.env.NODE_TEST_CONTEXT && !process.env.ROSA_POOL_SIZE ? 0 : num(process.env.ROSA_POOL_SIZE, 6),
    poolBatch: num(process.env.ROSA_POOL_BATCH, 3),
    poolIdleMs: num(process.env.ROSA_POOL_IDLE_MIN, 15) * 60_000,
    poolCheckMs: num(process.env.ROSA_POOL_CHECK_S, 60) * 1000,
    perHour: num(process.env.ROSA_IMAGES_PER_HOUR, 20),
    pendingPerPerson: 2
  },

  // pictures people send
  maxImages: 3,
  maxImageBytes: 6 * 1024 * 1024,

  // long-term memory
  memoryMax: 300,
  recallTopK: 5,
  extractEveryTurns: 3,

  // Per-person limits, so one machine cannot fill the disk or bury the rest. They only ever refuse new
  // things; nothing is ever deleted to make room.
  quota: {
    conversations: num(process.env.ROSA_MAX_CONVERSATIONS, 500),
    messagesPerConversation: num(process.env.ROSA_MAX_MESSAGES, 3000),
    mediaBytes: num(process.env.ROSA_MAX_MEDIA_MB, 1024) * 1024 * 1024
  },

  // updates (see update.js): where the signed list of releases lives ("rosia.updateUrl" in package.json unless overridden), whether a
  // new version is installed by itself when nobody is chatting ('auto'), only when the owner says so ('notify'), or never ('off')
  update: (() => {
    let packaged = '';
    try {
      packaged = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')).rosia?.updateUrl || '';
    } catch {
      /* no package.json: nothing to update from */
    }
    const mode = String(process.env.ROSA_UPDATE_MODE || 'auto').toLowerCase();
    return {
      // a test run never reaches out to the real release list: only an address a test gives itself is used
      url: String(process.env.ROSA_UPDATE_URL || (process.env.NODE_TEST_CONTEXT ? '' : packaged) || '').trim(),
      mode: ['auto', 'notify', 'off'].includes(mode) ? mode : 'auto',
      checkMs: num(process.env.ROSA_UPDATE_CHECK_H, 6) * 3600_000,
      keyFile: process.env.ROSA_UPDATE_KEY_FILE || path.join(root, 'server', 'update-key.pub'),
      supervised: process.env.ROSA_SUPERVISED === '1', // started by the launcher, which is what installs an update
      insecure: process.env.ROSA_UPDATE_INSECURE === '1' // lets the tests use a local http server; never set otherwise
    };
  })(),

  maxToolChars: 6000,
  rate: { windowMs: 60_000, max: 40 }
};
