/*
 * The newest release of a project on GitHub, found the way a browser finds it: github.com/<repo>/releases/latest sends you
 * on to .../releases/tag/<version>. Not through GitHub's API, which allows 60 questions an hour per internet address
 * without an account and then answers 403 (people on a shared connection, or who pressed a button a few times, got that
 * instead of a download). Downloads then use the ordinary links, .../releases/download/<version>/<file>.
 */

/** The tag in a release address: '.../releases/tag/v2.0.0' -> 'v2.0.0', or ''. */
export function tagFromLocation(location) {
  const m = /\/releases\/tag\/([^/?#]+)/.exec(String(location || ''));
  return m ? decodeURIComponent(m[1]) : '';
}

/** The tag of `repo`'s newest release ('owner/name'). Throws with a plain reason when it cannot be found. */
export async function latestTag(repo, fetchFn = fetch) {
  const res = await fetchFn(`https://github.com/${repo}/releases/latest`, { redirect: 'manual', headers: { 'user-agent': 'rosia-app' }, signal: AbortSignal.timeout(20_000) });
  const tag = tagFromLocation(res.headers.get('location'));
  if (!tag) throw new Error(`${repo}'s latest release could not be found (GitHub answered ${res.status}).`);
  return tag;
}

/** The ordinary download link of a file in a release. */
export const releaseFile = (repo, tag, file) => `https://github.com/${repo}/releases/download/${encodeURIComponent(tag)}/${encodeURIComponent(file)}`;
