import { latestTag, releaseFile } from '../github.com.js';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { config } from '../config.js';

/*
 * yt-dlp: the open-source tool that finds where a YouTube song's sound is. Rosia uses it only for that (the search
 * itself is in youtube.js); the sound is then passed on to the listener's browser by the app, a piece at a time.
 *
 * It is fetched from yt-dlp's own GitHub releases into the tools folder the first time it is needed, checked against
 * the checksum GitHub lists, and checked for a newer version every few hours (6 unless ROSA_YTDLP_UPDATE_H says
 * otherwise): YouTube changes often, and an old yt-dlp is the usual reason a song stops playing. A yt-dlp the person
 * pointed at themselves (ROSA_YTDLP) is used as it is and never replaced.
 */

const REPO = 'yt-dlp/yt-dlp';
const ASSET = { win32: 'yt-dlp.exe', darwin: 'yt-dlp_macos', linux: 'yt-dlp_linux' }[process.platform] || 'yt-dlp';
export const VIDEO_ID = /^[A-Za-z0-9_-]{11}$/;

const own = () => !config.music.ytdlp; // ours to install and update
export const ytdlpPath = () => config.music.ytdlp || path.join(config.home, 'tools', ASSET);
export const ytdlpInstalled = () => fs.existsSync(ytdlpPath());

/** A stand-in written in JavaScript (the tests use one) is run with this same Node. */
function command(args) {
  const file = ytdlpPath();
  return /\.m?js$/i.test(file) ? [process.execPath, [file, ...args]] : [file, args];
}

/* The Windows yt-dlp unpacks itself into a temporary folder every time it runs. The usual one can be locked (by an
   antivirus, or a sandbox), and then it stops before doing anything, so it gets a folder of its own beside it. */
function tempDir() {
  const dir = path.join(config.home, 'tools', 'yt-dlp-tmp');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function run(args, ms) {
  const [cmd, list] = command(args);
  const tmp = tempDir();
  const env = { ...process.env, TEMP: tmp, TMP: tmp, TMPDIR: tmp };
  return new Promise((resolve, reject) => {
    execFile(cmd, list, { env, timeout: ms, windowsHide: true, maxBuffer: 32 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) reject(new Error(String(stderr || err.message).trim().split(/\r?\n/).filter((l) => /error/i.test(l)).slice(-1)[0]?.slice(0, 240) || 'yt-dlp did not answer.'));
      else resolve(String(stdout || ''));
    });
  });
}

/* ---------- install and keep up to date ---------- */

/** "2026.10.26" against "2026.11.2.1", part by part: positive when a is newer. */
export function newer(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i += 1) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d;
  }
  return 0;
}

export async function installedVersion() {
  if (!ytdlpInstalled()) return '';
  return (await run(['--version'], 30_000).catch(() => '')).trim();
}

/** The newest release: its version and the download for this computer, with GitHub's checksum. */
export async function latestRelease(fetchFn = fetch) {
  // through GitHub's ordinary links, not its API (see github.com.js); the checksum is from yt-dlp's own published list
  const tag = await latestTag(REPO, fetchFn);
  const res = await fetchFn(releaseFile(REPO, tag, 'SHA2-256SUMS'), { redirect: 'follow', headers: { 'user-agent': 'rosia-app' }, signal: AbortSignal.timeout(20_000) });
  if (!res.ok) throw new Error(`yt-dlp's checksum list answered ${res.status}.`);
  const line = (await res.text()).split(/\r?\n/).map((l) => /^([a-f0-9]{64})\s+\*?(.+)$/i.exec(l.trim())).find((m) => m && m[2].trim() === ASSET);
  if (!line) throw new Error('yt-dlp has no download for this computer.');
  return { version: tag.replace(/^v/, ''), url: releaseFile(REPO, tag, ASSET), sha256: line[1].toLowerCase() };
}

/** Downloads a release next to where it goes, checks it, then swaps it in (the old one is kept until the next swap). */
async function put(release, fetchFn) {
  if (!release.sha256) throw new Error('GitHub gave no checksum for yt-dlp, so it was not installed.');
  const dest = ytdlpPath();
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const res = await fetchFn(release.url, { redirect: 'follow', headers: { 'user-agent': 'rosia-app' }, signal: AbortSignal.timeout(10 * 60_000) });
  if (!res.ok) throw new Error(`The yt-dlp download answered ${res.status}.`);
  const body = Buffer.from(await res.arrayBuffer());
  if (crypto.createHash('sha256').update(body).digest('hex') !== release.sha256) throw new Error('yt-dlp did not match its checksum, so it was not installed.');
  const part = `${dest}.part`;
  fs.writeFileSync(part, body, { mode: 0o755 });
  // a running copy cannot be overwritten on Windows, but it can be moved aside
  if (fs.existsSync(dest)) {
    fs.rmSync(`${dest}.old`, { force: true });
    fs.renameSync(dest, `${dest}.old`);
  }
  fs.renameSync(part, dest);
}

export const updateState = { checking: false, version: '', checkedAt: 0, error: '' };

/** Installs yt-dlp if it is missing and replaces it if a newer one is out. Never throws: it says what went wrong. */
export async function checkForUpdate({ fetchFn = fetch } = {}) {
  if (!own() && ytdlpInstalled()) {
    updateState.version = await installedVersion();
    return { did: 'kept', version: updateState.version };
  }
  if (updateState.checking) return { did: 'busy' };
  updateState.checking = true;
  try {
    const have = await installedVersion();
    const latest = await latestRelease(fetchFn);
    let did = 'current';
    if (!have || newer(latest.version, have) > 0) {
      await put(latest, fetchFn);
      did = have ? 'updated' : 'installed';
      console.log(`[music] yt-dlp ${did}: ${have ? `${have} -> ` : ''}${latest.version}`);
      resolved.clear(); // a newer yt-dlp may find better links
    }
    Object.assign(updateState, { version: did === 'current' ? have : latest.version, checkedAt: Date.now(), error: '' });
    return { did, version: updateState.version };
  } catch (err) {
    Object.assign(updateState, { checkedAt: Date.now(), error: err.message });
    if (!ytdlpInstalled()) console.warn(`[music] yt-dlp could not be installed: ${err.message}`);
    return { did: 'failed', error: err.message };
  } finally {
    updateState.checking = false;
  }
}

let timer = null;
/** Installs it now if needed, then looks for a newer one every few hours. */
export function keepUpdated({ fetchFn = fetch } = {}) {
  if (timer || !config.music.youtube) return;
  checkForUpdate({ fetchFn });
  timer = setInterval(() => checkForUpdate({ fetchFn }), config.music.ytdlpUpdateHours * 3600_000);
  timer.unref();
}

/* ---------- where a song's sound is ---------- */

// videoId -> { url, headers, type, size, until } ; a link works for some hours, so it is kept until shortly before then
const resolved = new Map();
const pending = new Map();
const KEEP = 300;

function fromInfo(info) {
  const f = info?.requested_downloads?.[0] || info;
  if (!f?.url) throw new Error('yt-dlp found no sound for that song.');
  const expire = Number(new URL(f.url).searchParams.get('expire')) * 1000;
  const ext = String(f.ext || info.ext || '');
  return {
    url: f.url,
    headers: f.http_headers || info.http_headers || {},
    type: ext === 'webm' ? 'audio/webm' : ext === 'mp3' ? 'audio/mpeg' : 'audio/mp4',
    size: Number(f.filesize || f.filesize_approx) || 0,
    until: Number.isFinite(expire) && expire > 0 ? expire - 15 * 60_000 : Date.now() + 2 * 3600_000
  };
}

/** The English captions in a yt-dlp answer (made by the uploader, else YouTube's automatic ones), as a json3 link, or ''. */
export function captionsLink(info) {
  for (const set of [info?.subtitles, info?.automatic_captions]) {
    const lang = Object.keys(set || {}).find((l) => /^en(?:-|$)/.test(l));
    const json3 = lang && set[lang].find((c) => c.ext === 'json3');
    if (json3?.url) return json3.url;
  }
  return '';
}

const KINDS = {
  // a song: the best sound on its own, in a form every browser plays
  audio: { format: 'bestaudio[ext=m4a]/bestaudio[acodec^=mp4a]/bestaudio', site: 'https://music.youtube.com/watch?v=' },
  // a video to watch together: picture and sound in one mp4 file, so it plays straight in the page
  video: { format: '18/b[ext=mp4][height<=720]/b[ext=mp4]/b', site: 'https://www.youtube.com/watch?v=' }
};

/**
 * Where one song's sound (or one video) is: a link and what to send with the request, plus captions for a video.
 * Asked for once at a time for each.
 */
export function audioFor(videoId, { fresh = false, kind = 'audio' } = {}) {
  if (!VIDEO_ID.test(String(videoId))) return Promise.reject(new Error('That is not a song or a video.'));
  const key = `${kind}:${videoId}`;
  const have = resolved.get(key);
  if (!fresh && have && have.until > Date.now()) return Promise.resolve(have);
  if (pending.has(key)) return pending.get(key);
  if (!ytdlpInstalled()) return Promise.reject(new Error('yt-dlp is not installed yet.'));
  const args = [
    '-J', '--no-warnings', '--no-playlist', '--no-progress',
    '-f', KINDS[kind].format,
    // YouTube now needs a JavaScript runtime to give links that work: this same Node is one
    '--js-runtimes', `node:${process.execPath}`,
    ...(config.music.ytdlpCookies ? ['--cookies', config.music.ytdlpCookies] : []),
    `${KINDS[kind].site}${videoId}`
  ];
  const job = run(args, 60_000)
    .then((out) => {
      const info = JSON.parse(out);
      const found = fromInfo(info);
      if (kind === 'video') {
        found.type = 'video/mp4';
        found.captions = captionsLink(info);
        found.title = String(info.title || '');
        found.channel = String(info.channel || info.uploader || '');
        found.duration = Math.round(Number(info.duration) || 0);
      }
      resolved.set(key, found);
      while (resolved.size > KEEP) resolved.delete(resolved.keys().next().value);
      return found;
    })
    .finally(() => pending.delete(key));
  pending.set(key, job);
  return job;
}

export const videoFor = (videoId, opts = {}) => audioFor(videoId, { ...opts, kind: 'video' });

/** Starts finding the sound of songs about to be played, so they start sooner. */
export function warm(videoIds) {
  for (const id of videoIds) if (VIDEO_ID.test(String(id))) audioFor(id).catch(() => {});
}

export function forget(videoId, kind = 'audio') {
  resolved.delete(`${kind}:${videoId}`);
}
