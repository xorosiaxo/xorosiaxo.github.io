/* What the ring around her photo and the word beside it show. */

const RING = { ok: 'ok', busy: 'busy', offline: 'off' };

export function ringState(text, tone) {
  const ring = RING[tone] || 'off';
  // grey says "offline", except "not set up": that one tells the owner what to do (the notice above the message box)
  return { ring, word: ring === 'off' ? (text === 'not set up' ? text : 'offline') : String(text || 'online') };
}
