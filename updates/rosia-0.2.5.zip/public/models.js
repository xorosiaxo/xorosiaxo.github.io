/* Settings, Models: what she runs on. Point her at files already on this computer, or download what suits it. Nothing
   is downloaded until the person has seen what, how big and from where, and said yes. */

const SLOTS = [
  { key: 'runner', title: 'Model runner', setting: 'llamaServer', found: 'runner', help: 'The program that runs the chat model (llama.cpp).' },
  { key: 'chat', title: 'Chat model', setting: 'model', found: 'chat', help: 'Who she is when she talks. Unrestricted models only.' },
  { key: 'vision', title: 'Vision', setting: 'mmproj', found: 'vision', help: 'Lets her see the pictures you send. Goes with the chat model.' },
  { key: 'memory', title: 'Memory model', setting: 'embedModel', found: 'memory', help: 'Lets her find memories and clips by meaning.' }
];
const PICTURE_ITEMS = ['picture', 'encoder', 'vae', 'lora'];

const gb = (n) => `${Number(n).toFixed(n < 1 ? 2 : 1)} GB`;
// an amount downloaded so far: MB below a gigabyte, so a small download does not read "0.00 GB of 0.04 GB"
const amount = (bytes) => (bytes < 1073741824 ? `${Math.round(bytes / 1048576)} MB` : gb(bytes / 1073741824));
// a file in a list of choices: its name, and the folder it is in, so two copies of llama-server.exe can be told apart
const where = (p) => {
  const parts = String(p || '').split(/[\\/]/).filter(Boolean);
  return parts.length > 1 ? `${parts.at(-1)} (in ${parts.at(-2)})` : parts.at(-1) || '';
};
const base = (p) => String(p || '').split(/[\\/]/).pop();
const sourceHost = (r) => (r.source === 'github' ? 'github.com' : 'huggingface.co');

async function call(method, url, body) {
  const res = await fetch(url, body ? { method, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : { method });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'That did not work.');
  return data;
}

export function hardwareLine(hw) {
  const g = hw?.gpu;
  const card = g ? `${g.name}, ${g.approximate ? 'at least ' : ''}${gb(g.vramGb)}` : 'no graphics card found';
  return `This computer: ${card} · ${gb(hw?.ramGb || 0)} memory${hw?.freeGb != null ? ` · ${gb(hw.freeGb)} free` : ''}`;
}

/** What a download looks like while it runs, or after. */
export function jobLine(job) {
  if (!job) return '';
  if (job.state === 'downloading') {
    const pct = job.total ? Math.min(99, Math.floor((job.received / job.total) * 100)) : 0;
    const got = `${pct}% (${amount(job.received)} of ${amount(job.total)})`;
    // a longer install says which step it is on; the amount only while something is downloading
    if (job.phase) return /^Downloading/.test(job.phase) ? `${job.phase} ${got}` : job.phase;
    return `Downloading… ${got}`;
  }
  if (job.state === 'done') return `Downloaded and checked: ${base(job.path)}. She starts using it in a few seconds.`;
  if (job.state === 'cancelled') return 'Download stopped.';
  return job.error || 'The download failed.';
}

export function mountModels(host) {
  let data = null;
  let timer = 0;
  host.innerHTML = '<p class="md-hw"></p><div class="md-slots"></div><p class="md-note">She starts using a change by herself within a few seconds of it finishing.</p><p class="md-error" role="alert"></p>';
  const hwEl = host.querySelector('.md-hw');
  const slotsEl = host.querySelector('.md-slots');
  const errEl = host.querySelector('.md-error');

  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  };
  const btn = (label, solid, run) => {
    const b = el('button', `pill-btn${solid ? ' solid' : ''}`, label);
    b.type = 'button';
    b.addEventListener('click', async () => {
      errEl.textContent = '';
      b.disabled = true;
      try { await run(); } catch (err) { errEl.textContent = err.message; }
      b.disabled = false;
    });
    return b;
  };

  const hasJob = (rec) => (data.jobs || []).some((j) => j.key === rec.key);

  /** The download button for one recommended item: first a question, then the download. */
  function downloadRow(rec) {
    const row = el('div', 'md-dl');
    const job = (data.jobs || []).find((j) => j.key === rec.key);
    if (job && job.state === 'downloading') {
      row.append(el('span', 'md-state', jobLine(job)), btn('Stop', false, async () => { data.jobs = (await call('POST', '/api/local-models/cancel', { key: rec.key })).jobs; draw(); }));
      return row;
    }
    if (job) row.append(el('span', 'md-state', jobLine(job)));
    // finished: just the line saying so, not the same download offered again
    if (job?.state === 'done') return row;
    const ask = btn(`Download ${rec.label} (${gb(rec.sizeGb)})`, false, async () => {
      row.replaceChildren(
        el('span', 'md-state', `Download ${gb(rec.sizeGb)} from ${sourceHost(rec)} into ${rec.comfy ? 'your ComfyUI models folder' : data.folder}?`),
        btn('Download', true, async () => {
          data.jobs = (await call('POST', '/api/local-models/download', { key: rec.key })).jobs;
          draw();
          poll();
        }),
        btn('Cancel', false, async () => draw())
      );
    });
    row.append(ask, el('span', 'md-help', rec.note));
    return row;
  }

  /** A choice of what is already on this computer. */
  function useRow(setting, options, current) {
    if (!options.length) return null;
    const row = el('div', 'md-use');
    const select = el('select');
    select.setAttribute('aria-label', `Choose a file for ${setting}`);
    for (const o of options.filter((x, i, all) => all.findIndex((y) => y.path === x.path) === i)) {
      const opt = el('option', null, `${where(o.path)}${o.sizeGb ? `, ${gb(o.sizeGb)}` : ''}`);
      opt.value = o.path;
      if (o.path === current) opt.selected = true;
      select.append(opt);
    }
    row.append(select, btn('Use this', false, async () => {
      data.settings = (await call('POST', '/api/local-models/use', { setting, path: select.value })).settings;
      draw();
    }));
    return row;
  }

  function draw() {
    hwEl.textContent = hardwareLine(data.hardware);
    slotsEl.replaceChildren();
    for (const slot of SLOTS) {
      const now = data.settings[slot.key] || {};
      const box = el('div', 'md-slot');
      box.append(el('h3', null, slot.title));
      box.append(el('p', `md-now ${now.found ? 'ok' : 'missing'}`, now.off ? 'Switched off.' : now.found ? `Using ${base(now.path)}` : now.path ? `Not found: ${base(now.path)}` : 'Not set.'));
      box.append(el('p', 'md-help', slot.help));
      const found = (data.found[slot.found] || []).filter((f) => f.path !== now.path || !now.found);
      const use = useRow(slot.setting, now.found ? [{ path: now.path }, ...found] : found, now.path);
      if (use) box.append(use);
      // a download only for what is missing: nothing that is set up and working is offered again (one already running shows)
      const rec = data.recommended.find((r) => r.key === slot.key);
      if (rec && (!rec.have || hasJob(rec))) box.append(downloadRow(rec));
      slotsEl.append(box);
    }

    // pictures: ComfyUI, and the three model files that go into its models folder
    const comfy = data.settings.comfy || {};
    const box = el('div', 'md-slot');
    box.append(el('h3', null, 'Pictures'));
    box.append(el('p', `md-now ${comfy.found ? 'ok' : 'missing'}`, comfy.found ? `Using ComfyUI in ${comfy.path}` : 'ComfyUI is not set up.'));
    box.append(el('p', 'md-help', comfy.found ? 'She draws pictures through ComfyUI on your graphics card.' : 'She draws pictures through ComfyUI. Choose a ComfyUI folder you already have, or install it here.'));
    const comfyUse = useRow('comfyDir', data.comfy.map((p) => ({ path: p })), comfy.path);
    if (comfyUse) box.append(comfyUse);
    const install = data.recommended.find((r) => r.key === 'comfyui');
    if (!comfy.found && install) box.append(downloadRow(install));
    if (data.settings.comfyModels?.found) {
      const missing = PICTURE_ITEMS.map((key) => data.recommended.find((r) => r.key === key)).filter((rec) => rec && (!rec.have || hasJob(rec)));
      for (const rec of missing) box.append(downloadRow(rec));
      if (comfy.found && !missing.length) box.append(el('p', 'md-now ok', 'Her picture models are all there.'));
    }
    slotsEl.append(box);
  }

  function poll() {
    clearTimeout(timer);
    if (!(data.jobs || []).some((j) => j.state === 'downloading')) return;
    timer = setTimeout(async () => {
      try { data = await call('GET', '/api/local-models'); draw(); } catch { /* try again */ }
      poll();
    }, 1000);
  }

  async function load() {
    try {
      data = await call('GET', '/api/local-models');
      draw();
      poll();
    } catch (err) {
      errEl.textContent = err.message;
    }
  }

  load();
  return { load };
}

/** Does she still need setting up: no chat model answering, and her chat model or its runner missing from this computer? */
export function needsSetup(data) {
  return Boolean(data) && !data.running && !(data.settings?.chat?.found && data.settings?.runner?.found);
}

/** Whether she needs setting up, asked of the server; false when it cannot say (not the owner here, or offline). */
export async function setupNeeded() {
  try {
    return needsSetup(await call('GET', '/api/local-models'));
  } catch {
    return false;
  }
}

let open = null; // the setup card's promise while it is showing

/** Opens the setup card (the Models choices) and resolves when the person closes it. Opening it twice shows it once. */
export function openSetup({ doc = document } = {}) {
  if (open) return open;
  const card = doc.getElementById('modelsStep');
  card.hidden = false;
  mountModels(doc.getElementById('modelsStepHost'));
  doc.getElementById('modelsLater').focus();
  open = new Promise((resolve) => {
    doc.getElementById('modelsLater').addEventListener('click', () => {
      card.hidden = true;
      open = null;
      resolve();
    }, { once: true });
  });
  return open;
}

/**
 * Every start, for the owner at this computer: while she has no chat model or no model runner, the setup card opens, so
 * nobody lands in a chat that cannot answer. "Done for now" closes it; until she is set up, a notice above the message box
 * opens it again (see app.js), and Settings has the same controls.
 */
export async function askModels({ doc = document } = {}) {
  if (await setupNeeded()) await openSetup({ doc });
}
