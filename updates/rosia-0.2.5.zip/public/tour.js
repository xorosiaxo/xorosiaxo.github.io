/* A short tour of the app, once, the first time someone gets to the chat (after setup), and again from Settings, About.
   Each step lights up one control and says what it is for; the rest of the page is dimmed and cannot be clicked until the
   tour ends. A step whose control is not on the page (hidden for this person, or on a small screen) is skipped. */

const DONE = 'rosia.toured';

/** The steps. `drawer`: the sidebar is opened for it. `owner`: only shown to the owner (others do not have it). */
export const STEPS = [
  { target: 'input', title: 'Talk to her here', text: 'Type and press Enter. The microphone lets you talk instead, and the picture button sends her a photo.' },
  { target: 'openChats', title: 'Your conversations', text: 'Every chat you have had with her: go back to one, or start a new one.' },
  { target: 'openReminders', title: 'Reminders', text: 'Ask her to remind you of anything ("remind me to call mum at 6"). They wait here.' },
  { target: 'openMemory', title: 'What she remembers', text: 'Everything she knows about you. You can correct it or delete any of it.' },
  { target: 'navGallery', drawer: true, title: 'Gallery', text: 'The pictures she has sent you, all in one place.' },
  { target: 'navDiary', drawer: true, title: 'Her diary', text: 'What she writes about her days, and about you.' },
  { target: 'navSettings', drawer: true, title: 'Settings', text: 'Her voice, her models, Discord GIFs, your phone, updates and your data. If something is not working, Diagnostics there makes a report for support.' },
  { target: 'edge', title: 'The sidebar', text: 'Everything above lives here. Open it from this edge, or with Ctrl and B, any time. That is the tour: say hello to her.' }
];

const visible = (el) => Boolean(el) && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';

/** Whether the tour has been seen in this browser (it never fails: storage may be off). */
export function toured(storage = globalThis.localStorage) {
  try { return storage.getItem(DONE) === '1'; } catch { return true; }
}

/**
 * Runs the tour; resolves when it ends (finished, skipped, or Esc). drawer: { open(), close() } for the sidebar steps.
 * Marks it seen at the start, so a reload part-way through does not start it over.
 */
export function startTour({ doc = document, drawer, storage = globalThis.localStorage } = {}) {
  try { storage.setItem(DONE, '1'); } catch { /* shown again next time */ }
  const shade = doc.createElement('div');
  shade.className = 'tour';
  shade.innerHTML = '<div class="tour-hole" aria-hidden="true"></div><div class="tour-card" role="dialog" aria-modal="true" aria-labelledby="tourTitle"><div class="tour-count"></div><div class="tour-title" id="tourTitle"></div><p class="tour-text"></p><div class="tour-actions"><button class="pill-btn" type="button" data-act="skip">Skip tour</button><button class="pill-btn" type="button" data-act="back">Back</button><button class="pill-btn solid" type="button" data-act="next">Next</button></div></div>';
  doc.body.append(shade);
  const hole = shade.querySelector('.tour-hole');
  const card = shade.querySelector('.tour-card');
  const steps = STEPS.slice();
  let at = -1;
  let finish;
  const ended = new Promise((resolve) => { finish = resolve; });

  const place = () => {
    const step = steps[at];
    if (!step) return;
    // the sidebar can be closed under the tour (a hover leaving it, the page tidying up): opened again for its steps
    if (step.drawer && drawer && !drawer.isOpen?.()) drawer.open();
    const el = doc.getElementById(step.target);
    const r = el.getBoundingClientRect();
    const pad = 6;
    Object.assign(hole.style, { left: `${r.left - pad}px`, top: `${r.top - pad}px`, width: `${r.width + pad * 2}px`, height: `${r.height + pad * 2}px` });
    // the card beside the control: below it when there is room, otherwise above; kept inside the window
    const cw = Math.min(340, innerWidth - 24);
    card.style.width = `${cw}px`;
    const ch = card.offsetHeight;
    let top = r.bottom + 14;
    if (top + ch > innerHeight - 12) top = Math.max(12, r.top - ch - 14);
    let left = r.left + r.width / 2 - cw / 2;
    if (step.target === 'edge') left = r.right + 14;
    left = Math.max(12, Math.min(innerWidth - cw - 12, left));
    Object.assign(card.style, { left: `${left}px`, top: `${top}px` });
  };

  const show = (to) => {
    // move on (or back) to the next step whose control is there; the sidebar is opened only for the steps inside it
    let i = to;
    const dir = to >= at ? 1 : -1;
    for (; i >= 0 && i < steps.length; i += dir) {
      if (steps[i].drawer) drawer?.open(); else if (drawer?.isOpen?.()) drawer.close();
      if (visible(doc.getElementById(steps[i].target))) break;
    }
    if (i < 0 || i >= steps.length) return end();
    at = i;
    const shown = steps.filter((s) => visible(doc.getElementById(s.target)) || s.drawer);
    card.querySelector('.tour-count').textContent = `${shown.indexOf(steps[at]) + 1} of ${shown.length}`;
    card.querySelector('.tour-title').textContent = steps[at].title;
    card.querySelector('.tour-text').textContent = steps[at].text;
    card.querySelector('[data-act="back"]').hidden = at === 0;
    card.querySelector('[data-act="next"]').textContent = steps.slice(at + 1).some((s) => s.drawer || visible(doc.getElementById(s.target))) ? 'Next' : 'Done';
    // the sidebar slides in: placed again once it has
    place();
    setTimeout(() => { if (shade.isConnected) place(); }, 260);
    card.querySelector('[data-act="next"]').focus();
  };

  function end() {
    clearInterval(keep);
    removeEventListener('resize', onResize);
    doc.removeEventListener('keydown', onKey, true);
    if (drawer?.isOpen?.()) drawer.close();
    shade.remove();
    finish();
  }
  const onResize = () => place();
  const onKey = (e) => {
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); end(); }
    // Enter moves on wherever the focus is (a tour button handles its own Enter)
    else if (e.key === 'ArrowRight' || (e.key === 'Enter' && !card.contains(e.target))) { e.preventDefault(); e.stopPropagation(); show(at + 1); }
    else if (e.key === 'ArrowLeft' && at > 0) { e.preventDefault(); show(at - 1); }
  };
  addEventListener('resize', onResize);
  doc.addEventListener('keydown', onKey, true);
  // kept on its control while the page moves under it (the sidebar sliding, the chat filling in)
  const keep = setInterval(() => { if (shade.isConnected) place(); }, 300);
  card.addEventListener('click', (e) => {
    const act = e.target.closest('button')?.dataset.act;
    if (act === 'skip') end();
    if (act === 'back') show(at - 1);
    if (act === 'next') show(at + 1);
  });
  show(0);
  return ended;
}
