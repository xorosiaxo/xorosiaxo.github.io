// What the launcher is setting up, written to a small file as it goes, so the "she's getting ready" screen can show each
// part (her chat model, her memory, her voice, the image generator) and whether it is ready yet, instead of only a dot.
import fs from 'node:fs';

/** The states a part can be in. 'waiting' and 'working' are not finished; the rest are. */
export const SETTLED = new Set(['done', 'skipped', 'failed']);

/**
 * steps: [{ id, label, needed }]. `needed` parts must be finished before she can be talked to; the others carry on in
 * the background after the window has opened. write(text) is given the JSON each time something changes.
 */
export function createStartupStatus({ steps = [], write = () => {}, now = Date.now } = {}) {
  const startedAt = now();
  const list = steps.map((s) => ({ id: s.id, label: s.label, needed: Boolean(s.needed), state: 'waiting', note: '', ms: 0 }));
  const began = new Map();

  const snapshot = () => ({
    startedAt,
    at: now(),
    // nothing she needs is still on its way
    ready: list.every((s) => !s.needed || SETTLED.has(s.state)),
    steps: list.map((s) => ({ ...s }))
  });

  const save = () => {
    try {
      write(JSON.stringify(snapshot()));
    } catch {
      /* the screen falls back to its plain message: starting must never fail over this */
    }
  };

  save();
  return {
    /** Moves a part on: set('model', 'working', 'loading onto the graphics card'). Unknown parts are ignored. */
    set(id, state, note = '') {
      const step = list.find((s) => s.id === id);
      if (!step) return;
      if (state === 'working' && !began.has(id)) began.set(id, now());
      if (SETTLED.has(state) && !SETTLED.has(step.state)) step.ms = now() - (began.get(id) ?? now());
      step.state = state;
      step.note = String(note || '');
      save();
    },
    snapshot
  };
}

/** A writer that replaces the file in one step, so a reader never sees half of it. */
export function fileWriter(file) {
  return (text) => {
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, text);
    fs.renameSync(tmp, file);
  };
}

/** Reads what the launcher wrote. null when there is no launcher (the server was started by itself) or the file is unreadable. */
export function readStartupStatus(file) {
  if (!file) return null;
  try {
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    return data && Array.isArray(data.steps) ? data : null;
  } catch {
    return null;
  }
}
