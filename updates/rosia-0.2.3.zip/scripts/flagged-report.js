// Lists the clips that were left out of her GIF collection because the model thought they might show someone under 18,
// so they can be checked by hand.
//
//   node scripts/flagged-report.js          writes flagged.txt and prints the same list. Changes nothing else.
//   node scripts/flagged-report.js --move   also moves those clips' files into a "flagged" folder inside the GIF folder
//                                           (nothing is deleted; the app does the same for any clip flagged from now on)
//
// The list has, for each clip, the file name, the name it was saved under, and where it came from (the link with its
// signature removed), so it can be opened from the folder or found again in Discord.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dataDir = process.env.ROSA_DATA_DIR || path.join(root, 'data');
const home = process.env.USERPROFILE || process.env.HOME || '';
const gifsDir = process.env.ROSA_GIFS_DIR || path.join(home, 'Rosia-GIFs');
const flaggedFolder = path.join(gifsDir, 'flagged');

const read = (file, fallback) => {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
};

const library = read(path.join(dataDir, 'gifs', 'library.json'), []);
const index = read(path.join(gifsDir, 'index.json'), []);
const sourceOf = new Map(index.map((e) => [path.basename(String(e.file || '')), String(e.source || e.url || '').split('?')[0]]));

const flagged = library.filter((i) => i.status === 'skip' && /under 18/.test(i.why || '') && !i.cleared);
const looked = library.filter((i) => i.status === 'ok' || i.status === 'skip').length;

if (process.argv.includes('--move')) {
  fs.mkdirSync(flaggedFolder, { recursive: true });
  let moved = 0;
  for (const item of flagged) {
    const from = path.join(gifsDir, path.basename(item.file));
    const to = path.join(flaggedFolder, path.basename(item.file));
    if (fs.existsSync(from) && !fs.existsSync(to)) {
      fs.renameSync(from, to);
      moved += 1;
    }
  }
  console.log(`Moved ${moved} file${moved === 1 ? '' : 's'} into ${flaggedFolder}\n`);
}

const lines = [
  `Clips the model thought might show someone under 18: ${flagged.length} of ${library.length} in the collection (${looked} looked at so far).`,
  'They are left out of what she can send. To check one, open it from the folder below.',
  `Folder: ${fs.existsSync(flaggedFolder) ? flaggedFolder : gifsDir}`,
  ''
];
flagged.forEach((item, n) => {
  lines.push(`${String(n + 1).padStart(3)}. ${item.file}`);
  if (item.name && item.name !== item.file) lines.push(`     saved as: ${item.name}`);
  const src = sourceOf.get(item.file);
  if (src) lines.push(`     from: ${src}`);
});

// saved videos (links, not files) the model thought might show someone under 18: the link is what you open to check
const videoLibrary = read(path.join(dataDir, 'gifs', 'video-library.json'), []);
const flaggedVideos = videoLibrary.filter((e) => e.status === 'skip' && /under 18/.test(e.why || ''));
if (videoLibrary.length) {
  lines.push('', `Saved videos the model thought might show someone under 18: ${flaggedVideos.length} of ${videoLibrary.length}. To keep one, add its file name to data/gifs/cleared.json.`);
  flaggedVideos.forEach((e, n) => {
    lines.push(`${String(n + 1).padStart(3)}. ${path.basename(String(e.key).split('?')[0])}`);
    lines.push(`     link: ${String(e.url).split('?')[0]}`);
  });
}

const text = lines.join('\n');
const out = fs.existsSync(flaggedFolder) ? path.join(flaggedFolder, 'flagged.txt') : path.join(gifsDir, 'flagged.txt');
try {
  fs.writeFileSync(out, `${text}\n`);
  if (out !== path.join(gifsDir, 'flagged.txt')) fs.rmSync(path.join(gifsDir, 'flagged.txt'), { force: true }); // the list lives beside the clips now
  console.log(`${text}\n\n(written to ${out})`);
} catch (err) {
  console.log(text);
  console.log(`\n(could not write flagged.txt: ${err.message})`);
}
