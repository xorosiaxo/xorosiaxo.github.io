// Publishes a new version: builds the release zip and the signed release list that every install checks.
//
//   node scripts/release.js --init-key              once: make the signing key (private part stays on this machine)
//   node scripts/release.js patch                   0.1.0 -> 0.1.1   (or: minor, major, or an exact version like 1.0.0)
//   node scripts/release.js minor --notes "What is new, in a line or two"
//   node scripts/release.js patch --dry-run         build and check everything, change nothing in the project
//
// Other options: --notes-file <path>, --min-version <x.y.z> (installs older than this are told the update is required),
// --skip-tests, --out <folder> (default dist).
//
// It makes two files in dist/: rosia-<version>.zip (the program) and latest.json (the release list: the newest version, the
// zip's SHA-256 and size, and a signature over those). Put both in the same place on any web host that serves static files
// (a GitHub release, an S3 bucket, a folder on your site), and make "rosia.updateUrl" in package.json the address of latest.json.
// Installs verify the signature with the public key in server/update-key.pub, so the host cannot hand them anything you did not sign.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createZip } from '../server/zip.js';
import { bump, isVersion, isNewer } from '../server/version.js';
import { signedText } from '../server/update-protocol.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const flag = (name) => args.includes(name);
const value = (name) => (args.includes(name) ? args[args.indexOf(name) + 1] : undefined);

const keyPath = process.env.ROSIA_RELEASE_KEY || path.join(os.homedir(), '.rosia-release-key.pem');
const pubPath = process.env.ROSIA_RELEASE_PUB || path.join(root, 'server', 'update-key.pub');

function fail(message) {
  console.error(`\n  ${message}\n`);
  process.exit(1);
}

/* ---------- the signing key ---------- */

if (flag('--init-key')) {
  if (fs.existsSync(keyPath)) fail(`There is already a signing key at ${keyPath}. Replacing it would stop every install from accepting your updates, so this will not do it.`);
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  fs.writeFileSync(keyPath, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
  fs.writeFileSync(pubPath, publicKey.export({ type: 'spki', format: 'pem' }));
  console.log(`\n  Signing key made.\n    private: ${keyPath}   (back this up somewhere safe; if it is lost, no install can be updated again)\n    public:  ${pubPath}   (commit this; it ships inside every install)\n`);
  process.exit(0);
}

/* ---------- which files go in ---------- */

const INCLUDE_DIRS = ['server', 'scripts', 'public', 'tools'];
const INCLUDE_FILES = ['package.json', 'README.md', 'AVATAR.md', 'start.bat', 'image-prompts.example.txt'];

// not part of a release: her art (it ships with the installer and an update never removes it, since it was never in a
// release; and the release files sit on a public website), logs and scratch files
// the clip catalogue too: it describes adult clips, and ships with the installer instead
// (yt-dlp is fetched by each install itself and kept up to date there: tools/yt-dlp.exe and its temporary folder never ship)
const skip = (rel) => rel.startsWith('public/assets/avatar/') || rel === 'server/clips/catalogue.json' || rel.startsWith('tools/yt-dlp') || /\.(log|tmp|rosia-new)$/.test(rel);

function walk(dir, base = '') {
  const out = [];
  for (const entry of fs.readdirSync(path.join(dir, base), { withFileTypes: true })) {
    const rel = base ? `${base}/${entry.name}` : entry.name;
    if (entry.isDirectory()) out.push(...walk(dir, rel));
    else if (entry.isFile() && !skip(rel)) out.push(rel);
  }
  return out;
}

/* ---------- the release ---------- */

const pkgFile = path.join(root, 'package.json');
const pkg = JSON.parse(fs.readFileSync(pkgFile, 'utf8'));
const request = args.find((a) => !a.startsWith('--') && a !== value('--notes') && a !== value('--notes-file') && a !== value('--min-version') && a !== value('--out'));
if (!request) fail('Say which version: patch, minor, major, or an exact one like 1.2.0. (First time? node scripts/release.js --init-key)');
const version = isVersion(request) ? request : (() => {
  try {
    return bump(pkg.version, request);
  } catch {
    return fail(`"${request}" is not patch, minor, major or a version like 1.2.0.`);
  }
})();
if (!isNewer(version, pkg.version)) fail(`${version} is not newer than the current ${pkg.version}.`);
const minVersion = value('--min-version') || '';
if (minVersion && !isVersion(minVersion)) fail(`--min-version ${minVersion} is not a version.`);
const notes = (value('--notes-file') ? fs.readFileSync(value('--notes-file'), 'utf8') : value('--notes') || '').trim().slice(0, 4000);

if (!fs.existsSync(keyPath)) fail(`No signing key at ${keyPath}. Make one first: node scripts/release.js --init-key`);
const privateKey = crypto.createPrivateKey(fs.readFileSync(keyPath, 'utf8'));
if (!fs.existsSync(pubPath)) fail(`${pubPath} is missing: every install needs it to check updates.`);
const published = crypto.createPublicKey(fs.readFileSync(pubPath, 'utf8')).export({ type: 'spki', format: 'der' });
if (!crypto.createPublicKey(privateKey).export({ type: 'spki', format: 'der' }).equals(published)) fail('The signing key does not match server/update-key.pub: installs would reject this release.');

if (!flag('--skip-tests')) {
  console.log('\n  running the tests ...');
  const run = spawnSync(process.execPath, ['--test'], { cwd: root, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
  const summary = /ℹ (pass|fail) \d+/g;
  const lines = (run.stdout || '').match(summary) || [];
  if (run.status !== 0) fail(`The tests do not pass, so nothing was released.\n  ${lines.join('  ')}`);
  console.log(`  ${lines.join('  ')}`);
}

const nextPkg = { ...pkg, version };
const files = [...INCLUDE_FILES.filter((f) => fs.existsSync(path.join(root, f))), ...INCLUDE_DIRS.flatMap((d) => (fs.existsSync(path.join(root, d)) ? walk(root, d) : []))].sort();
const entries = files.map((name) => ({ name, data: name === 'package.json' ? Buffer.from(`${JSON.stringify(nextPkg, null, 2)}\n`) : fs.readFileSync(path.join(root, name)) }));
const zip = createZip(entries);

const sha256 = crypto.createHash('sha256').update(zip).digest('hex');
const manifest = {
  app: 'rosia',
  version,
  publishedAt: new Date().toISOString(),
  notes,
  ...(minVersion ? { minVersion } : {}),
  url: `rosia-${version}.zip`, // relative to latest.json, so the pair can live anywhere
  sha256,
  size: zip.length
};
manifest.signature = crypto.sign(null, Buffer.from(signedText(manifest)), privateKey).toString('base64');

const out = path.resolve(root, value('--out') || 'dist');
fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(path.join(out, `rosia-${version}.zip`), zip);
fs.writeFileSync(path.join(out, 'latest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
if (!flag('--dry-run')) fs.writeFileSync(pkgFile, `${JSON.stringify(nextPkg, null, 2)}\n`);

console.log(`
  ${flag('--dry-run') ? 'Checked (nothing in the project was changed)' : 'Released'}: ${pkg.version} -> ${version}
    ${path.join(out, `rosia-${version}.zip`)}   ${(zip.length / 1048576).toFixed(1)} MB, ${files.length} files
    ${path.join(out, 'latest.json')}
${flag('--dry-run') ? '' : `
  Next:
    1. git commit -am "Release ${version}" && git tag v${version}
    2. upload both files from ${path.relative(root, out) || '.'} to the same place (the address in "rosia.updateUrl" must serve latest.json)
`}`);
