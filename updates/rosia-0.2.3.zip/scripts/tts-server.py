"""A tiny local text-to-speech server around Kokoro (kokoro-onnx), running on the CPU.

    python scripts/tts-server.py --model kokoro-v1.0.onnx --voices voices-v1.0.bin --port 8082

    GET  /health   -> {"ok": true}
    GET  /voices   -> {"voices": ["af_heart", ...]}
    POST /speak    {"text": "...", "voice": "af_heart", "speed": 1.0}  -> audio/wav (16-bit mono)

Everything stays on this machine and nothing is filtered: the model reads whatever text it is given.
Requires: pip install kokoro-onnx soundfile
"""
import argparse
import io
import json
import threading
import wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument("--model", required=True)
parser.add_argument("--voices", required=True)
parser.add_argument("--port", type=int, default=8082)
parser.add_argument("--host", default="127.0.0.1")
args = parser.parse_args()

from kokoro_onnx import Kokoro  # noqa: E402  (imported late so --help is instant)

kokoro = Kokoro(args.model, args.voices)
VOICES = sorted(kokoro.get_voices())
lock = threading.Lock()  # one sentence at a time: the model is not thread safe
MAX_CHARS = 1200


def to_wav(samples: np.ndarray, rate: int) -> bytes:
    pcm = (np.clip(samples, -1.0, 1.0) * 32767).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.tobytes())
    return buf.getvalue()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def reply(self, status, body, kind="application/json"):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(status)
        self.send_header("content-type", kind)
        self.send_header("content-length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/health":
            return self.reply(200, {"ok": True})
        if self.path == "/voices":
            return self.reply(200, {"voices": VOICES})
        self.reply(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/speak":
            return self.reply(404, {"error": "not found"})
        try:
            size = int(self.headers.get("content-length") or 0)
            body = json.loads(self.rfile.read(min(size, 64 * 1024)) or b"{}")
            text = str(body.get("text", "")).strip()[:MAX_CHARS]
            voice = body.get("voice") if body.get("voice") in VOICES else "af_heart"
            speed = min(1.4, max(0.7, float(body.get("speed", 1.0))))
            if not text:
                return self.reply(400, {"error": "no text"})
            with lock:
                samples, rate = kokoro.create(text, voice=voice, speed=speed, lang="en-us")
            self.reply(200, to_wav(samples, rate), "audio/wav")
        except Exception as err:  # noqa: BLE001 - report, never crash the server
            self.reply(500, {"error": str(err)[:200]})


if __name__ == "__main__":
    print(f"kokoro ready on http://{args.host}:{args.port} ({len(VOICES)} voices)", flush=True)
    ThreadingHTTPServer((args.host, args.port), Handler).serve_forever()
