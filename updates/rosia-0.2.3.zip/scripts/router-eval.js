// Measures the router (server/router.js) on its test set (test/router-cases.js): how many messages it gets right,
// what it mixes up, how long it takes. Uses whatever is configured: the memory model (ROSA_EMBED_URL) for step 1,
// and the router model (ROSA_ROUTER_URL) for step 2 if set.
//
//   node scripts/router-eval.js            step 1 and step 2 as configured
//   node scripts/router-eval.js --sweep    step 1 only, trying different lines, to choose them
//   node scripts/router-eval.js --misses   also list every message it got wrong
//   node scripts/router-eval.js --implicit  the harder set: requests only hinted at (test/router-implicit-cases.js)
//   node scripts/router-eval.js --model-only [--zero-shot]   the router model alone on every message (no word rules,
//                                          no example phrases; --zero-shot: not even its worked examples)

import { decide, scoreLabels, resetRouter, askModel } from '../server/router.js';
import { detectIntent } from '../server/preflight.js';
import { embed } from '../server/embed.js';
import { config } from '../server/config.js';
import { CASES as PLAIN } from '../test/router-cases.js';
import { IMPLICIT } from '../test/router-implicit-cases.js';
import { ROUTED } from '../server/router-examples.js';

const args = process.argv.slice(2);
const ALL = [...ROUTED];
// what is on while it is asked, so "skip" or "pause the video" have something to work
// (--implicit: the harder set of hinted requests, where each message says what is on, and nothing is on otherwise)
const IMPLICIT_SET = process.argv.includes('--implicit');
const CASES = IMPLICIT_SET ? IMPLICIT : PLAIN;
const onFor = (on) => (IMPLICIT_SET ? { ...(on || {}) } : { music: 'playing', watching: true, gameOn: true });

async function main() {
  console.log(`step 1: ${config.embedUrl ? `memory model at ${config.embedUrl}` : 'built-in word matcher'}; step 2: ${config.router.url || 'none'}`);

  if (args.includes('--sweep')) {
    const { EXAMPLES } = await import('../server/router-examples.js');
    const { embedMany } = await import('../server/embed.js');
    const items = Object.entries(EXAMPLES).flatMap(([label, list]) => list.map((text) => ({ label, text })));
    const { vecs, kind } = await embedMany(items.map((i) => i.text), 'query');
    const bank = items.map((i, n) => ({ label: i.label, vec: vecs[n] }));
    const scored = [];
    for (const [text, want] of CASES) scored.push({ want, scores: scoreLabels((await embed(text, 'query')).vec, bank) });
    console.log(`kind ${kind}`);
    for (const maybe of [0.3, 0.35, 0.4, 0.45, 0.5, 0.55]) {
      for (const over of [0, 0.03, 0.06, 0.1]) {
        let right = 0;
        let falseAlarms = 0;
        for (const s of scored) {
          const top = s.scores[0];
          const none = s.scores.find((x) => x.label === 'none').score;
          const got = !top || top.label === 'none' || top.score < maybe || top.score - none < over ? 'none' : top.label;
          if (got === s.want) right += 1;
          else if (s.want === 'none') falseAlarms += 1;
        }
        console.log(`maybe ${maybe} over ${over}: ${right}/${scored.length} right, ${falseAlarms} false alarms`);
      }
    }
    return;
  }

  resetRouter();
  let right = 0;
  let falseAlarms = 0;
  let missed = 0;
  const misses = [];
  const times = [];
  for (const [text, want, on] of CASES) {
    const context = onFor(on);
    const t0 = Date.now();
    // as in the app: the word rules first (certain when they fire), then the router
    const ruled = args.includes('--router-only') ? null : detectIntent(text, ALL, context);
    // --model-only: the router model on every message, nothing hand-written before it (--zero-shot: not even its examples)
    if (args.includes('--model-only')) {
      const m = await askModel(text, context, { shots: !args.includes('--zero-shot') });
      const got = m?.tool || 'none';
      times.push(Date.now() - t0);
      if (got === want) right += 1;
      else {
        if (want === 'none') falseAlarms += 1;
        else if (got === 'none') missed += 1;
        misses.push(`${JSON.stringify(text)}: wanted ${want}, got ${got}`);
      }
      continue;
    }
    const got = ruled?.name || (args.includes('--rules-only') ? 'none' : (await decide(text, context))?.label || 'none');
    times.push(Date.now() - t0);
    if (got === want) right += 1;
    else {
      if (want === 'none') falseAlarms += 1;
      else if (got === 'none') missed += 1;
      misses.push(`${JSON.stringify(text)}: wanted ${want}, got ${got}`);
    }
  }
  times.sort((a, b) => a - b);
  console.log(`${right}/${CASES.length} right (${Math.round((right / CASES.length) * 100)}%): ${falseAlarms} false alarms, ${missed} missed, ${misses.length - falseAlarms - missed} mixed up`);
  console.log(`time: median ${times[Math.floor(times.length / 2)]} ms, slowest ${times.at(-1)} ms`);
  if (args.includes('--misses')) for (const m of misses) console.log(`  ${m}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
