// Puts a staged update in place, and takes it out again if the new version does not come up. This is the launcher's half of
// updating (the app's half is server/update.js): only the launcher can replace the files of an app that is running.
//
// The person's own things are never touched: data/, rosia.local.json, node_modules, image-prompts.txt, ... (see PROTECTED).
// Before a file is replaced the old one is copied to data/updates/backup/<from>-to-<to>/, so putting it back is exact.
import fs from 'node:fs';
import path from 'node:path';
import { FILES, UPDATE_EXIT_CODE, isProtected, updatesDir, updateFile, recordFailure, clearFailure } from '../server/update-protocol.js';
import { safeName } from '../server/zip.js';

const readJson = (file, fallback) => {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
};
const writeJson = (file, value) => {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2), 'utf8');
  fs.renameSync(tmp, file);
};

/** Windows can hold a file for a moment (antivirus, search indexer): a few quick retries before giving up. */
function retrying(fn, tries = 8) {
  for (let attempt = 1; ; attempt += 1) {
    try {
      return fn();
    } catch (err) {
      if (attempt >= tries || !['EPERM', 'EACCES', 'EBUSY'].includes(err.code)) throw err;
      const until = Date.now() + Math.min(600, 25 * 2 ** attempt);
      while (Date.now() < until) { /* a short wait: this runs while no app is running, so nothing else is waiting on us */ }
    }
  }
}

function place(from, to) {
  fs.mkdirSync(path.dirname(to), { recursive: true });
  const tmp = `${to}.rosia-new`;
  fs.copyFileSync(from, tmp);
  retrying(() => fs.renameSync(tmp, to));
}

export const pendingUpdate = (dataDir) => readJson(updateFile(dataDir, FILES.pending), null);
export const activeTrial = (dataDir) => readJson(updateFile(dataDir, FILES.trial), null);


/** Only the newest few backups are kept. */
function pruneBackups(dataDir, keep = 2) {
  const root = path.join(updatesDir(dataDir), 'backup');
  let names = [];
  try {
    names = fs.readdirSync(root).map((name) => ({ name, at: fs.statSync(path.join(root, name)).mtimeMs })).sort((a, b) => b.at - a.at);
  } catch {
    return;
  }
  for (const old of names.slice(keep)) fs.rmSync(path.join(root, old.name), { recursive: true, force: true });
}

/**
 * Swaps the staged update in. Returns { ok: true, version, from, backup } or { ok: false, error } (then nothing is changed:
 * whatever was half-done is put back, and that version is never offered again on this machine).
 */
export function applyStaged({ root, dataDir }) {
  const pending = pendingUpdate(dataDir);
  if (!pending) return { ok: false, error: 'nothing is staged' };
  const finish = (result) => {
    fs.rmSync(updateFile(dataDir, FILES.pending), { force: true });
    if (result.ok && pending.dir) fs.rmSync(pending.dir, { recursive: true, force: true });
    return result;
  };

  const names = (pending.files || []).map(safeName);
  if (!pending.dir || !fs.existsSync(pending.dir) || names.some((n) => !n || isProtected(n))) {
    recordFailure(dataDir, { version: pending.version, from: pending.from, reason: 'the downloaded update was not usable' });
    return finish({ ok: false, error: 'the staged update is not usable' });
  }
  for (const n of names) {
    if (!fs.existsSync(path.join(pending.dir, ...n.split('/')))) {
      recordFailure(dataDir, { version: pending.version, from: pending.from, reason: `the downloaded update was missing ${n}` });
      return finish({ ok: false, error: `the staged update is missing ${n}` });
    }
  }

  const backup = path.join(updatesDir(dataDir), 'backup', `${pending.from}-to-${pending.version}`);
  fs.rmSync(backup, { recursive: true, force: true });
  const previous = readJson(updateFile(dataDir, FILES.installed), { version: pending.from, files: [] });
  const keep = new Set(names);
  const removed = (previous.files || []).filter((n) => !keep.has(n) && safeName(n) && !isProtected(n) && fs.existsSync(path.join(root, ...n.split('/'))));
  const record = { from: pending.from, to: pending.version, replaced: [], added: [], removed: [], previousInstalled: previous, at: Date.now() };

  try {
    for (const n of names) {
      const target = path.join(root, ...n.split('/'));
      if (fs.existsSync(target)) {
        const saved = path.join(backup, 'files', ...n.split('/'));
        fs.mkdirSync(path.dirname(saved), { recursive: true });
        fs.copyFileSync(target, saved);
        record.replaced.push(n);
      } else {
        record.added.push(n);
      }
    }
    for (const n of removed) {
      const target = path.join(root, ...n.split('/'));
      const saved = path.join(backup, 'files', ...n.split('/'));
      fs.mkdirSync(path.dirname(saved), { recursive: true });
      fs.copyFileSync(target, saved);
      record.removed.push(n);
    }
    writeJson(path.join(backup, 'backup.json'), record); // written before anything is replaced, so a crash half-way can still be undone
    for (const n of names) place(path.join(pending.dir, ...n.split('/')), path.join(root, ...n.split('/')));
    for (const n of removed) fs.rmSync(path.join(root, ...n.split('/')), { force: true });
  } catch (err) {
    try {
      restore({ root, dataDir, backup });
    } catch {
      /* best effort: the error below is what matters */
    }
    recordFailure(dataDir, { version: pending.version, from: pending.from, reason: `it could not be put in place: ${err.message}` });
    return finish({ ok: false, error: `could not put the update in place: ${err.message}` });
  }

  writeJson(updateFile(dataDir, FILES.installed), { version: pending.version, files: names });
  writeJson(updateFile(dataDir, FILES.trial), { version: pending.version, from: pending.from, backup, startedAt: Date.now() });
  pruneBackups(dataDir);
  return finish({ ok: true, version: pending.version, from: pending.from, backup });
}

/** Puts the files back from a backup folder. */
function restore({ root, dataDir, backup }) {
  const record = readJson(path.join(backup, 'backup.json'), null);
  if (!record) throw new Error('the backup has no record');
  for (const n of [...record.replaced, ...record.removed]) {
    const saved = path.join(backup, 'files', ...n.split('/'));
    if (fs.existsSync(saved)) place(saved, path.join(root, ...n.split('/')));
  }
  for (const n of record.added) fs.rmSync(path.join(root, ...n.split('/')), { force: true });
  writeJson(updateFile(dataDir, FILES.installed), record.previousInstalled || { version: record.from, files: [] });
  return record;
}

/**
 * The new version did not come up: the old files go back and the reason is written down for the owner (failed.json). The version is
 * not given up on: it stays on offer (see autoInstallAllowed for how often it is tried again by itself).
 */
export function rollback({ root, dataDir, reason = 'it did not start', tail = [] }) {
  const trial = activeTrial(dataDir);
  if (!trial) return { ok: false, error: 'no update is on trial' };
  try {
    restore({ root, dataDir, backup: trial.backup });
  } catch (err) {
    return { ok: false, error: err.message, version: trial.version };
  } finally {
    recordFailure(dataDir, { version: trial.version, from: trial.from, reason, tail });
    fs.rmSync(updateFile(dataDir, FILES.trial), { force: true });
  }
  return { ok: true, version: trial.version, from: trial.from, reason };
}

/**
 * The launcher's side of an update, as two questions it asks whenever the app has stopped:
 *   onAppExit(code)  an update is staged: swap it in and start the app again at once; a new version just put in place died
 *                    within trialMs: put the old one back and start again; otherwise nothing special (null).
 *   afterStart()     call once the app has been started after an update: after trialMs the new version is kept if it is
 *                    healthy, and rolled back (and the app stopped, to be started again) if it is not.
 */
export function createUpdateWatcher({ root, dataDir, log = () => {}, isHealthy = () => true, stopApp = () => {}, tail = () => [], trialMs = 120_000, now = Date.now }) {
  let check = null;

  const arm = () => {
    clearTimeout(check);
    check = setTimeout(() => {
      const trial = activeTrial(dataDir);
      if (!trial) return;
      if (isHealthy()) {
        fs.rmSync(updateFile(dataDir, FILES.trial), { force: true });
        clearFailure(dataDir, trial.version); // it works now: an earlier failed try is forgotten
        log(`update to ${trial.version} is healthy and stays`);
        return;
      }
      log(`version ${trial.version} is not answering; putting ${trial.from} back`);
      const r = rollback({ root, dataDir, reason: `it started but did not answer within ${Math.round(trialMs / 1000)} seconds`, tail: tail() });
      log(r.ok ? `back on ${r.from}. The owner is told why; ${trial.version} stays on offer` : `could not put the old version back: ${r.error}`);
      stopApp(); // it exits, and is started again by the ordinary restart
    }, trialMs);
    check.unref?.();
  };

  return {
    onAppExit(code) {
      if (pendingUpdate(dataDir)) {
        const done = applyStaged({ root, dataDir });
        if (done.ok) {
          log(`updated ${done.from} -> ${done.version}`);
          arm();
        } else {
          log(`update not installed: ${done.error}`);
        }
        return { restartNow: true };
      }
      const trial = activeTrial(dataDir);
      if (trial && code !== UPDATE_EXIT_CODE && now() - trial.startedAt < trialMs) {
        const secs = Math.round((now() - trial.startedAt) / 1000);
        log(`version ${trial.version} stopped (code ${code}) ${secs} s after the update; putting ${trial.from} back`);
        clearTimeout(check);
        const r = rollback({ root, dataDir, reason: `it stopped with code ${code} ${secs} seconds after starting`, tail: tail() });
        log(r.ok ? `back on ${r.from}. The owner is told why; ${trial.version} stays on offer` : `could not put the old version back: ${r.error}`);
        return { restartNow: true };
      }
      return null;
    },
    /** Picks up a trial that was running when the launcher itself was restarted. */
    resume() {
      if (activeTrial(dataDir)) arm();
    },
    stop() {
      clearTimeout(check);
    }
  };
}
