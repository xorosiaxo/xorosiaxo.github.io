"""
Builds the web-ready avatar images from the source PNGs in public/assets/avatar/.

    python scripts/build-avatar.py

Expressions (face/bust images that crossfade on the avatar):
  The sources are opaque PNGs on a pure black background. They are resized and the black is turned
  into real transparency (a black-matte "unpremultiply": alpha comes from the brightest channel, and
  the colour is scaled back up to match). Composited on black the result is pixel-identical to the
  source; on the page's rose glow it lets the glow show around her instead of a black rectangle.

Photos (full-body shots she can send in the chat):
  Resized and re-encoded as plain WebP, background left black.

Outputs go to public/assets/avatar/web/. The originals are never modified.
"""
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent / "public" / "assets" / "avatar"
OUT = ROOT / "web"

# output name -> source file
EXPRESSIONS = {
    "neutral": "neutral.png",
    "happy": "happy.png",
    "laughing": "happy laughing.png",
    "winking": "winking.png",
    "love": "love.png",
    "thinking": "thinking.png",
    "worried": "worried.png",
    "sleepy": "sleepy.png",
    "surprised": "Surprised.png",
    "smitten": "licking lips.png",
    "aroused": "horny.png",
    "ecstatic": "ahegao.png",
}

PHOTOS = {
    "bikini": "bikini.png",
    "front": "full pic front.png",
    "back": "full pic back.png",
    "feet": "feet.png",
    "kneeling": "knees with mouth open.png",
    "gymwear": "gymwear.png",
    "swimsuit": "swimsuit-front.png",
    "swimsuit-back": "swimsuit-back.png",
}

EXPR_WIDTH = 840      # shown at most ~560 CSS px tall, so this stays sharp on 2x screens
PHOTO_WIDTH = 800
FULL_OPAQUE_AT = 48   # brightness at which a pixel is treated as fully opaque


def key_black(img: Image.Image) -> Image.Image:
    """Opaque-on-black RGB -> RGBA with the black matte removed."""
    rgb = img.convert("RGB")
    out = []
    for r, g, b in rgb.getdata():
        m = max(r, g, b)
        if m >= FULL_OPAQUE_AT:
            out.append((r, g, b, 255))
        elif m == 0:
            out.append((0, 0, 0, 0))
        else:
            a = m * 255 // FULL_OPAQUE_AT
            k = 255 / a
            out.append((min(255, int(r * k)), min(255, int(g * k)), min(255, int(b * k)), a))
    result = Image.new("RGBA", rgb.size)
    result.putdata(out)
    return result


def flatten_on_black(img: Image.Image) -> Image.Image:
    if img.mode == "RGBA":
        base = Image.new("RGB", img.size, (0, 0, 0))
        base.paste(img, mask=img.getchannel("A"))
        return base
    return img.convert("RGB")


def resized(img: Image.Image, width: int) -> Image.Image:
    height = round(img.height * width / img.width)
    return img.resize((width, height), Image.LANCZOS)


def main() -> None:
    OUT.mkdir(exist_ok=True)
    total = 0

    for name, src in EXPRESSIONS.items():
        img = resized(flatten_on_black(Image.open(ROOT / src)), EXPR_WIDTH)
        keyed = key_black(img)
        dest = OUT / f"{name}.webp"
        keyed.save(dest, "WEBP", quality=86, alpha_quality=92, method=6)
        total += dest.stat().st_size
        print(f"expression {name:10} {dest.stat().st_size // 1024:5} KB  {keyed.size}")

    for name, src in PHOTOS.items():
        img = resized(flatten_on_black(Image.open(ROOT / src)), PHOTO_WIDTH)
        dest = OUT / f"photo-{name}.webp"
        img.save(dest, "WEBP", quality=86, method=6)
        total += dest.stat().st_size
        print(f"photo      {name:10} {dest.stat().st_size // 1024:5} KB  {img.size}")

    print(f"total {total // 1024} KB")


if __name__ == "__main__":
    main()
