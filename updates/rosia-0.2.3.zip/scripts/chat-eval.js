// How "chatbot-like" are her replies? Reads the debugging log (data/logs/debug.jsonl) and measures the habits that give it
// away, so a change to her prompt can be judged by numbers instead of by feel.
//
//   node scripts/chat-eval.js                      all replies in the log
//   node scripts/chat-eval.js --since 2026-11-11   only replies from then on (ISO date or time)
//   node scripts/chat-eval.js --session <id>       one conversation
//   node scripts/chat-eval.js --file <path>        another log file
//   node scripts/chat-eval.js --json               machine-readable
//
// Compare a run from before a change with one from after it (--since). Nothing here changes any data.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const PRAISE = /\b(?:you absolute legend|you(?:'re| are) (?:so|such a) (?:dramatic|sweet|bad|naughty|cheeky|keen)|ambitious for|good taste|i love that|love that for|honestly,|absolutely|brilliant|sounds like a plan|totally game|that'?s the sweetest|i have to say|wonderfully)\b/i;
const MENU = /\b(?:or|either)\b[^?.!]{3,60}\?\s*(?:[\p{Extended_Pictographic}\s]*)$/iu;
const STAGE = /\((?:you|she|rosia|i send|sending|the gif|the video)[^)]{8,}\)|\*[a-z][^*]{6,}\*/i;

const words = (t) => (String(t).trim().match(/\S+/g) || []).length;
const pct = (n, d) => (d ? Math.round((1000 * n) / d) / 10 : 0);
const quantile = (sorted, q) => (sorted.length ? sorted[Math.min(sorted.length - 1, Math.floor(q * sorted.length))] : 0);

/** The measurements for a list of reply texts. */
export function measure(replies) {
  const texts = replies.map((r) => String(r.text || '').trim()).filter(Boolean);
  const n = texts.length;
  const lengths = texts.map(words).sort((a, b) => a - b);
  const mean = lengths.reduce((a, b) => a + b, 0) / (n || 1);
  const sd = Math.sqrt(lengths.reduce((a, b) => a + (b - mean) ** 2, 0) / (n || 1));
  const openings = new Map();
  for (const t of texts) {
    const w = (t.toLowerCase().match(/[a-z']+/) || [''])[0];
    if (w) openings.set(w, (openings.get(w) || 0) + 1);
  }
  const top = [...openings.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3);
  const count = (re) => texts.filter((t) => re.test(t)).length;
  return {
    replies: n,
    endsInQuestion: pct(texts.filter((t) => /\?\s*[\p{Extended_Pictographic}\s]*$/u.test(t)).length, n),
    offersTwoOptions: pct(count(MENU), n),
    praiseOrAssistantWords: pct(count(PRAISE), n),
    bracketNarration: pct(count(STAGE), n),
    avgWords: Math.round(mean * 10) / 10,
    lengthSpread: Math.round(sd * 10) / 10, // standard deviation: a person varies, a bot does not
    shortReplies: pct(lengths.filter((l) => l <= 6).length, n),
    longReplies: pct(lengths.filter((l) => l > 60).length, n),
    medianWords: quantile(lengths, 0.5),
    p90Words: quantile(lengths, 0.9),
    paragraphsPerReply: Math.round((texts.reduce((a, t) => a + t.split(/\n\s*\n/).length, 0) / (n || 1)) * 10) / 10,
    commonestOpening: top.map(([w, c]) => `"${w}" ${pct(c, n)}%`).join(', ')
  };
}

// what a person-like texter looks like on each measure (a guide, not a pass mark)
export const TARGETS = {
  endsInQuestion: 'under 30%',
  offersTwoOptions: 'under 5%',
  praiseOrAssistantWords: 'under 5%',
  bracketNarration: '0%',
  lengthSpread: 'over 15 (varied lengths)',
  shortReplies: 'over 10% (some are just a few words)',
  longReplies: 'under 5%'
};

export function readReplies({ files, since, session }) {
  const out = [];
  for (const file of files) {
    let text = '';
    try {
      text = fs.readFileSync(file, 'utf8');
    } catch {
      continue;
    }
    for (const line of text.split('\n')) {
      if (!line.includes('"chat.reply"')) continue;
      let e;
      try {
        e = JSON.parse(line);
      } catch {
        continue;
      }
      if (e.event !== 'chat.reply' || (e.kind && e.kind !== 'chat')) continue;
      if (since && e.t < since) continue;
      if (session && e.session !== session) continue;
      out.push(e);
    }
  }
  return out;
}

function main() {
  const args = process.argv.slice(2);
  const get = (name) => {
    const i = args.indexOf(name);
    return i === -1 ? undefined : args[i + 1];
  };
  const dataDir = process.env.ROSA_DATA_DIR || path.join(root, 'data');
  const file = get('--file');
  const files = file ? [file] : [path.join(dataDir, 'logs', 'debug.1.jsonl'), path.join(dataDir, 'logs', 'debug.jsonl')];
  const since = get('--since') ? new Date(get('--since')).toISOString() : '';
  const replies = readReplies({ files, since, session: get('--session') });
  const m = measure(replies);
  if (args.includes('--json')) return console.log(JSON.stringify(m, null, 1));
  if (!m.replies) return console.log('No replies in the log yet (the debugging log records them from the moment Rosia was last restarted).');
  console.log(`${m.replies} replies${since ? ` since ${since.slice(0, 16)}` : ''}\n`);
  for (const [k, v] of Object.entries(m)) {
    if (k === 'replies') continue;
    const unit = ['endsInQuestion', 'offersTwoOptions', 'praiseOrAssistantWords', 'bracketNarration', 'shortReplies', 'longReplies'].includes(k) ? '%' : '';
    console.log(`${k.padEnd(24)} ${String(v)}${unit}${TARGETS[k] ? `   (aim: ${TARGETS[k]})` : ''}`);
  }
}

if (process.argv[1] && import.meta.url === new URL(`file:///${process.argv[1].replace(/\\/g, '/')}`).href) main();
