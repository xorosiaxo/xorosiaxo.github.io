// Makes a backup right now (the server also makes one each night while it is running).
//
//   node scripts/backup.js
//
// Chats, memory, who is signed in and the GIF/video catalogues go in a dated folder in Rosia-Backups (in your user folder,
// or ROSA_BACKUP_DIR); pictures go in the shared Rosia-Backups/media. See server/backup.js for how to restore.
import { config } from '../server/config.js';
import { backupNow, listBackups } from '../server/backup.js';

if (!config.backup.dir) {
  console.error('No backup folder: set ROSA_BACKUP_DIR.');
  process.exit(1);
}
const r = await backupNow();
console.log(`Backed up ${r.files} files and ${r.pictures} new picture${r.pictures === 1 ? '' : 's'} to ${r.folder}`);
if (r.removed) console.log(`(removed ${r.removed} night${r.removed === 1 ? '' : 's'} older than the newest ${config.backup.keep})`);
console.log(`Nights kept: ${(await listBackups()).map((b) => b.name.replace('rosia-', '')).join(', ')}`);
