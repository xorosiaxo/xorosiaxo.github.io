// Draws the same picture (same prompt, same seed, same sampler) with different model files and reports how long each took
// and how much of the graphics card it used. ComfyUI is started the way Rosia starts it (a cold start for every picture,
// which is what happens when she lends the card to the image generator), so the chat model must NOT be running.
//
//   node scripts/compare-unet.js <out-folder> <unet.gguf> [<unet.gguf> ...] [--seed 123456] [--rounds 2]
//
// Needs rosia.local.json with comfyDir (and comfyModels). Each round runs every model once, in the order given, so a second
// round shows the models with their files already in the computer's memory cache.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const flag = (name, fallback) => {
  const i = args.indexOf(name);
  if (i === -1) return fallback;
  const [, v] = args.splice(i, 2);
  return v;
};
const seed = Number(flag('--seed', 123456));
const rounds = Number(flag('--rounds', 2));
const outDir = path.resolve(args[0] || 'unet-compare');
const unets = args.slice(1);
if (!unets.length) {
  console.error('usage: node scripts/compare-unet.js <out-folder> <unet.gguf> [<unet.gguf> ...] [--seed N] [--rounds N]');
  process.exit(2);
}

const local = JSON.parse(fs.readFileSync(path.join(root, 'rosia.local.json'), 'utf8'));
const comfyDir = local.comfyDir;
const python = path.join(comfyDir, '.venv', 'Scripts', 'python.exe');
const port = 8188;
const url = `http://127.0.0.1:${port}`;
const workflow = path.join(comfyDir, 'user', 'default', 'workflows', 'rosia.json');
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'rosia-compare-'));

// the app's own settings, pointed at this ComfyUI
process.env.ROSA_COMFY_URL = url;
process.env.ROSA_IMAGE_WORKFLOW = workflow;
process.env.ROSA_DATA_DIR = dataDir;
const { comfyPathsYaml } = await import('./supervisor.js');
const { generate } = await import('../server/comfy.js');
const { fillTemplate, loadBasePrompt } = await import('../server/baseprompt.js');

// the same prompt every time: the base template with its slots filled by hand
const prompt = fillTemplate(loadBasePrompt(), {
  OUTFIT: 'wearing a tight red satin slip dress, a thin gold necklace',
  POSE: 'holding a phone taking a mirror selfie',
  FRAMING: 'medium close-up focused on her face and chest at a natural eye-level angle',
  'CLOSE DETAILS': 'the red satin and soft skin',
  MIDGROUND: 'her hand and the phone',
  BACKGROUND: 'a bedroom with a wooden wardrobe and soft indoor depth',
  'LIGHTING DESCRIPTION': 'Soft warm lamp lighting',
  'COLOR TONE': 'warm red and golden color tones'
});

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const up = async () => {
  try {
    return (await fetch(`${url}/system_stats`, { signal: AbortSignal.timeout(2000) })).ok;
  } catch {
    return false;
  }
};
const vramMb = () => {
  const r = spawnSync('nvidia-smi', ['--query-gpu=memory.used', '--format=csv,noheader,nounits'], { encoding: 'utf8' });
  return Number(String(r.stdout).trim().split('\n')[0]) || 0;
};

fs.mkdirSync(outDir, { recursive: true });
const yaml = path.join(dataDir, 'extra_model_paths.yaml');
if (local.comfyModels) fs.writeFileSync(yaml, comfyPathsYaml(local.comfyModels));
const comfyArgs = [
  'main.py', '--listen', '127.0.0.1', '--port', String(port), '--disable-auto-launch',
  '--disable-all-custom-nodes', '--whitelist-custom-nodes', ...(local.comfyNodes || ['ComfyUI-GGUF', 'comfyui-kjnodes', 'RES4LYF']),
  ...(local.comfyModels ? ['--extra-model-paths-config', yaml] : []),
  ...(local.comfyArgs || [])
];

if (await up()) {
  console.error('ComfyUI is already running on port 8188. Stop it (and the chat model) first so the timings are fair.');
  process.exit(1);
}
const baseline = vramMb();
console.log(`prompt (${prompt.length} chars), seed ${seed}, card in use before: ${baseline} MiB\n`);

const results = [];
for (let round = 1; round <= rounds; round += 1) {
  for (const unet of unets) {
    fs.writeFileSync(path.join(dataDir, 'image-override.json'), JSON.stringify({ seed, unet }));
    const t0 = Date.now();
    const child = spawn(python, comfyArgs, { cwd: comfyDir, stdio: 'ignore', windowsHide: true });
    let peak = 0;
    const sampler = setInterval(() => { peak = Math.max(peak, vramMb()); }, 1500);
    try {
      while (!(await up())) {
        if (Date.now() - t0 > 240_000) throw new Error('ComfyUI did not start');
        await sleep(500);
      }
      const startedMs = Date.now() - t0;
      const t1 = Date.now();
      const out = await generate({ prompt, orientation: 'portrait' });
      const drawMs = Date.now() - t1;
      const file = path.join(outDir, `${unet.replace(/\.gguf$/i, '')}-round${round}.png`);
      fs.writeFileSync(file, out.buffer);
      const r = { unet, round, startMs: startedMs, drawMs, comfyMs: out.execMs, totalMs: Date.now() - t0, peakMiB: Math.max(peak, vramMb()) - baseline, size: `${out.width}x${out.height}`, file };
      results.push(r);
      console.log(`${unet} (round ${round}): ComfyUI up in ${(startedMs / 1000).toFixed(1)} s, picture in ${(drawMs / 1000).toFixed(1)} s (ComfyUI's own clock ${out.execMs ? (out.execMs / 1000).toFixed(1) : '?'} s), total ${(r.totalMs / 1000).toFixed(1)} s, card used ${r.peakMiB} MiB, ${r.size}`);
    } catch (err) {
      console.log(`${unet} (round ${round}): FAILED: ${String(err.message || err).slice(0, 200)}`);
      results.push({ unet, round, error: String(err.message || err) });
    } finally {
      clearInterval(sampler);
      spawnSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' });
      for (let i = 0; i < 40 && (await up()); i += 1) await sleep(500);
      await sleep(3000); // let the card empty
    }
  }
}
fs.writeFileSync(path.join(outDir, 'results.json'), JSON.stringify({ seed, prompt, results }, null, 1));
console.log(`\nwritten to ${outDir}`);
process.exit(0);
