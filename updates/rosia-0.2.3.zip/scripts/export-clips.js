// Builds the clip catalogue that ships with the app (server/clips/catalogue.json): every GIF and video she can send, as a
// link with what it shows, how it feels and when it fits, and its meaning as a compact vector. No files: each install
// sends the link, kept fresh by its own Rosia plugin in Discord (see server/clips/catalogue.js).
//
//   node scripts/export-clips.js            reads data/gifs/*.json and the Rosia-GIFs folder, writes the catalogue
//
// Left out: copies of another clip, anything not described, anything flagged or quarantined as possibly showing someone
// under 18, and anything from a site whose name suggests teen content.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const home = process.env.ROSIA_HOME ? path.resolve(process.env.ROSIA_HOME) : root;
const dataDir = process.env.ROSA_DATA_DIR || path.join(home, 'data');
const gifsDir = process.env.ROSA_GIFS_DIR || path.join(os.homedir(), 'Rosia-GIFs');
const out = path.join(root, 'server', 'clips', 'catalogue.json');

const read = (file, fallback) => {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
};

/** A host she may send links from: no site whose name suggests teen content, ever. */
export function hostAllowed(url) {
  let host = '';
  try { host = new URL(url).host.toLowerCase(); } catch { return false; }
  return Boolean(host) && !/teen|young|school|jail ?bait|loli|minor/.test(host);
}

/** A vector as signed bytes (scaled by its largest value), base64: a quarter of the size, and close enough to compare. */
export function packVector(vec) {
  const max = Math.max(...vec.map((x) => Math.abs(x))) || 1;
  const bytes = Int8Array.from(vec, (x) => Math.round((x / max) * 127));
  return { scale: max / 127, q: Buffer.from(bytes.buffer).toString('base64') };
}

const DISCORD = /(^|\.)(discordapp\.(com|net)|discord\.com)$/i;
// a page about a clip (tenor.com/view/..., imgur.com/abc) is not the clip itself, and would not play in the chat
const PAGE_ONLY = /^(www\.)?(tenor\.com|imgur\.com|giphy\.com)$/i;

/** The link as it should be kept: a Discord link without its old signature (the plugin gets a fresh one), others as they are. */
export function cleanLink(url) {
  let u;
  try { u = new URL(url); } catch { return ''; }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return '';
  if (PAGE_ONLY.test(u.host)) return '';
  if (DISCORD.test(u.host)) return `https://${u.host}${u.pathname}`;
  return u.href;
}

const usable = (e) => e.status === 'ok' && !e.quarantined && !e.dupOf && e.vec && e.vecKind && e.description && !/under 18/.test(e.why || '');

const keep = (e) => ({
  name: String(e.name || '').slice(0, 80),
  description: String(e.description || '').slice(0, 400),
  reaction: String(e.reaction || '').slice(0, 120),
  useWhen: String(e.useWhen || '').slice(0, 160),
  mood: e.mood || '',
  intensity: e.intensity || 0,
  tags: Array.isArray(e.tags) ? e.tags.slice(0, 8) : [],
  text: String(e.text || '').slice(0, 160),
  adult: Boolean(e.adult),
  vecKind: e.vecKind,
  vec: packVector(e.vec)
});

function main() {
  const gifs = read(path.join(dataDir, 'gifs', 'library.json'), []);
  const index = read(path.join(gifsDir, 'index.json'), []);
  const sourceOf = new Map(index.map((x) => [path.basename(String(x.file || '')), x.source]));
  const videos = read(path.join(dataDir, 'gifs', 'video-library.json'), []);

  const clips = [];
  let noLink = 0;
  let blocked = 0;
  const seen = new Set();
  for (const g of gifs.filter(usable)) {
    const url = cleanLink(sourceOf.get(path.basename(g.file)));
    if (!url) { noLink += 1; continue; }
    if (seen.has(g.id)) continue;
    seen.add(g.id);
    if (!hostAllowed(url)) { blocked += 1; continue; }
    clips.push({ id: g.id, kind: g.ext === '.mp4' || g.ext === '.webm' ? 'video' : 'image', url, ...keep(g) });
  }
  for (const v of videos.filter(usable)) {
    const url = cleanLink(v.url);
    if (!url) { noLink += 1; continue; }
    if (!hostAllowed(url)) { blocked += 1; continue; }
    const id = `v${crypto.createHash('md5').update(url).digest('hex').slice(0, 11)}`;
    if (seen.has(id)) continue;
    seen.add(id);
    clips.push({ id, kind: 'video', url, ...keep(v) });
  }

  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, JSON.stringify({ version: 1, builtAt: new Date().toISOString(), clips }));
  const mb = (fs.statSync(out).size / 1048576).toFixed(1);
  console.log(`  ${clips.length} clips (${clips.filter((c) => c.kind === 'video').length} played as video), ${mb} MB -> ${path.relative(root, out)}`);
  console.log(`  left out: ${noLink} with no usable link, ${blocked} from blocked sites`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) main();
