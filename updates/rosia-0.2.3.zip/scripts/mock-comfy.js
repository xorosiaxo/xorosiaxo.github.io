// A stand-in for ComfyUI's HTTP API, for tests: accepts a workflow, "draws" for a moment, returns a tiny PNG.
// Usage: node scripts/mock-comfy.js [port]      MOCK_COMFY_MS=1500 sets how long a picture takes.
import http from 'node:http';
import fs from 'node:fs';

const port = Number(process.argv[2] || 8188);
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const jobs = new Map();
let counter = 0;
let lastPrompt = null;
const OBJECT_INFO = JSON.parse(fs.readFileSync(new URL('../test-support/comfy-object-info.json', import.meta.url), 'utf8'));

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${port}`);
  const json = (status, body) => {
    res.writeHead(status, { 'content-type': 'application/json' });
    res.end(JSON.stringify(body));
  };

  if (url.pathname === '/system_stats') return json(200, { system: { os: 'mock' } });
  if (url.pathname === '/free') return json(200, {});
  if (url.pathname === '/last-prompt') return json(200, lastPrompt || {});

  const definition = /^\/object_info\/(.+)$/.exec(url.pathname);
  if (definition) {
    const type = decodeURIComponent(definition[1]);
    return OBJECT_INFO[type] ? json(200, { [type]: OBJECT_INFO[type] }) : json(200, {});
  }

  if (url.pathname === '/prompt' && req.method === 'POST') {
    let raw = '';
    for await (const chunk of req) raw += chunk;
    const { prompt } = JSON.parse(raw);
    // MOCK_COMFY_REJECT=1 answers the way ComfyUI does when a custom node (and its sampler) is not loaded
    if (process.env.MOCK_COMFY_REJECT) {
      return json(400, { error: { type: 'prompt_outputs_failed_validation', message: 'Prompt outputs failed validation' }, node_errors: { 8: { errors: [{ type: 'value_not_in_list', message: 'Value not in list', extra_info: { input_name: 'sampler_name', received_value: 'res_2s' } }, { type: 'value_not_in_list', message: 'Value not in list', extra_info: { input_name: 'scheduler', received_value: 'bong_tangent' } }] } } });
    }
    const nodes = Object.values(prompt || {});
    const bad = !nodes.some((n) => n.class_type === 'KSampler') || !nodes.some((n) => n.class_type === 'CLIPTextEncode');
    if (bad) return json(400, { error: { message: 'bad workflow' }, node_errors: {} });
    counter += 1;
    const id = `mock-${counter}`;
    lastPrompt = prompt;
    jobs.set(id, { doneAt: Date.now() + Number(process.env.MOCK_COMFY_MS || 300), prompt });
    return json(200, { prompt_id: id, number: counter, node_errors: {} });
  }

  const history = /^\/history\/(.+)$/.exec(url.pathname);
  if (history) {
    const job = jobs.get(history[1]);
    if (!job || Date.now() < job.doneAt) return json(200, {});
    return json(200, { [history[1]]: { status: { status_str: 'success', completed: true }, outputs: { 10: { images: [{ filename: 'mock.png', subfolder: '', type: 'temp' }] } } } });
  }

  if (url.pathname === '/view') {
    res.writeHead(200, { 'content-type': 'image/png' });
    return res.end(PNG);
  }

  json(404, { error: 'not found' });
});

server.listen(port, '127.0.0.1');
