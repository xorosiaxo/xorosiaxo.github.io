// A stand-in for scripts/tts-server.py, for tests: answers /voices and /speak with a short silent WAV.
// Usage: node scripts/mock-tts.js [port]
import http from 'node:http';

const port = Number(process.argv[2] || 8082);
const VOICES = ['af_heart', 'af_nicole', 'am_adam', 'bf_emma', 'bm_george', 'zf_xiaobei'];

function wav(ms = 300) {
  const rate = 24000;
  const samples = Math.round((rate * ms) / 1000);
  const buf = Buffer.alloc(44 + samples * 2);
  buf.write('RIFF', 0); buf.writeUInt32LE(36 + samples * 2, 4); buf.write('WAVEfmt ', 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22); buf.writeUInt32LE(rate, 24);
  buf.writeUInt32LE(rate * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write('data', 36); buf.writeUInt32LE(samples * 2, 40);
  return buf;
}

http.createServer(async (req, res) => {
  const json = (status, body) => { res.writeHead(status, { 'content-type': 'application/json' }); res.end(JSON.stringify(body)); };
  if (req.url === '/health') return json(200, { ok: true });
  if (req.url === '/voices') return json(200, { voices: VOICES });
  if (req.url === '/speak' && req.method === 'POST') {
    let raw = '';
    for await (const c of req) raw += c;
    const body = JSON.parse(raw || '{}');
    if (!body.text) return json(400, { error: 'no text' });
    res.writeHead(200, { 'content-type': 'audio/wav', 'x-said': encodeURIComponent(`${body.voice}|${body.speed}|${body.text}`) });
    return res.end(wav());
  }
  json(404, { error: 'not found' });
}).listen(port, '127.0.0.1');
