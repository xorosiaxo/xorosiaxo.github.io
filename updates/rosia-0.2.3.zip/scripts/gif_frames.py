"""Cuts a few frames out of a GIF, animated WebP, video or picture and lays them side by side in one JPEG,
so a vision model can be shown what a short clip is about with a single picture.

    python scripts/gif_frames.py <input> <output.jpg> [--frames 3] [--size 384]

Prints one line of JSON: {"ok": true, "frames": 3, "width": ..., "height": ..., "source_frames": ..., "seconds": ...}
Needs Pillow (for GIF / WebP / PNG / JPEG) and ffmpeg + ffprobe on the PATH (for MP4 / WebM).
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile
from urllib.parse import urlparse

from PIL import Image

VIDEO = {".mp4", ".webm", ".mov", ".m4v", ".mkv"}


def positions(count, wanted):
    """Frame numbers spread over the clip: the first, the middle, near the end."""
    if count <= 1:
        return [0]
    if wanted <= 1:
        return [0]
    picks = sorted({round(i * (count - 1) / (wanted - 1) * (0.9 if i == wanted - 1 else 1)) for i in range(wanted)})
    return picks


def flatten(im):
    """Transparent GIFs are shown on mid-grey so both light and dark subjects stay visible."""
    im = im.convert("RGBA")
    base = Image.new("RGBA", im.size, (128, 128, 128, 255))
    base.alpha_composite(im)
    return base.convert("RGB")


def from_picture(path, wanted):
    im = Image.open(path)
    total = getattr(im, "n_frames", 1)
    frames = []
    for n in positions(total, wanted):
        im.seek(n)
        frames.append(flatten(im.copy()))
    seconds = None
    if total > 1:
        try:
            im.seek(0)
            seconds = round(sum(_duration(im, n) for n in range(total)) / 1000, 2)
        except Exception:  # noqa: BLE001 - duration is a nicety
            seconds = None
    return frames, total, seconds


def _duration(im, n):
    im.seek(n)
    return im.info.get("duration", 0) or 0


# for a video that is a web link: only plain web protocols, a browser-like name, and a limit on how long a stalled read waits.
# These are options of the web protocols: given with a file on disk, current ffmpeg refuses them ("Option user_agent not found").
NET = ["-protocol_whitelist", "file,http,https,tcp,tls,crypto", "-user_agent", "Mozilla/5.0", "-rw_timeout", "20000000"]


def net_options(path):
    return NET if urlparse(path).scheme in ("http", "https") else []


def from_video(path, wanted):
    probe = subprocess.run(
        ["ffprobe", "-v", "error", *net_options(path), "-show_entries", "format=duration", "-of", "csv=p=0", path],
        capture_output=True, text=True, timeout=45,
    )
    try:
        seconds = float(probe.stdout.strip())
    except ValueError:
        seconds = 0.0
    frames = []
    with tempfile.TemporaryDirectory() as tmp:
        for i, at in enumerate([0.0] if wanted <= 1 or seconds <= 0.2 else [seconds * k for k in (0.05, 0.5, 0.9)][:wanted]):
            out = os.path.join(tmp, f"f{i}.png")
            subprocess.run(
                ["ffmpeg", "-v", "error", "-y", *net_options(path), "-ss", f"{at:.2f}", "-i", path, "-frames:v", "1", out],
                capture_output=True, timeout=60,
            )
            if os.path.exists(out):
                frames.append(Image.open(out).convert("RGB").copy())
    return frames, max(1, round(seconds * 24)), round(seconds, 2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--frames", type=int, default=3)
    ap.add_argument("--size", type=int, default=384)
    ap.add_argument("--video", action="store_true", help="treat the input as a video even if its name does not say so (a web link)")
    args = ap.parse_args()

    ext = os.path.splitext(urlparse(args.input).path)[1].lower()  # a link's ?signature is not part of its extension
    frames, source_frames, seconds = (from_video if args.video or ext in VIDEO else from_picture)(args.input, max(1, args.frames))
    if not frames:
        print(json.dumps({"ok": False, "error": "no frames"}))
        return 1

    tiles = []
    for f in frames:
        f.thumbnail((args.size, args.size))
        tiles.append(f)
    height = max(t.height for t in tiles)
    strip = Image.new("RGB", (sum(t.width for t in tiles) + 6 * (len(tiles) - 1), height), (0, 0, 0))
    x = 0
    for t in tiles:
        strip.paste(t, (x, (height - t.height) // 2))
        x += t.width + 6
    strip.save(args.output, "JPEG", quality=82)
    print(json.dumps({"ok": True, "frames": len(tiles), "width": frames[0].width, "height": frames[0].height,
                      "source_frames": source_frames, "seconds": seconds}))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as err:  # noqa: BLE001 - report to the caller, never crash noisily
        print(json.dumps({"ok": False, "error": str(err)[:200]}))
        sys.exit(1)
