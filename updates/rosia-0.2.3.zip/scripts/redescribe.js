// Describes the GIF and video catalogue again with the fuller prompt, as fast as the graphics card allows, and nothing else.
//
//   node scripts/redescribe.js              start what is needed, do all of it, stop
//   node scripts/redescribe.js --retry      also retry clips that failed before (clears their "failed" mark)
//   node scripts/redescribe.js --limit 20   only the next 20 (to try it out)
//
// It starts only the chat model (it has to see the frames) and the small memory model that makes the vectors. No app, no
// ComfyUI, no voice, no idle waiting. The next clip's frames are cut while the model reads this one. Progress is saved every
// 20 clips and when you press Ctrl+C, and it carries on where it left off the next time. Close the app first: both
// would write the same catalogue. Settings come from rosia.local.json, as for start.bat.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { supervise, waitForHealth } from './supervisor.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const retry = args.includes('--retry');
const limit = args.includes('--limit') ? Number(args[args.indexOf('--limit') + 1]) || 0 : 0;

let local = {};
try {
  local = JSON.parse(fs.readFileSync(path.join(root, 'rosia.local.json'), 'utf8'));
} catch {
  /* optional */
}
const pick = (env, key, fallback) => process.env[env] || local[key] || fallback;
const llamaDir = pick('LLAMA_DIR', 'llamaDir', 'C:\\AI\\llama-b11057-bin-win-cuda-13.4-x64');
const server = pick('LLAMA_SERVER', 'llamaServer', path.join(llamaDir, process.platform === 'win32' ? 'llama-server.exe' : 'llama-server'));
const model = pick('ROSA_MODEL_FILE', 'model', path.join(pick('ROSA_MODEL_DIR', 'modelDir', 'C:\\AI\\models\\gemma4-e4b-uncensored'), 'model.gguf'));
const mmproj = 'mmproj' in local ? local.mmproj : path.join(path.dirname(model), 'mmproj.gguf');
const modelPort = Number(pick('ROSA_MODEL_PORT', 'modelPort', 8080));
const embedPort = Number(pick('ROSA_EMBED_PORT', 'embedPort', 8081));
const appPort = Number(pick('PORT', 'port', 8787));
const embedFile = pick('ROSA_EMBED_FILE', 'embedModel', '');
const alias = pick('ROSA_MODEL', 'alias', 'rosia');

// the same settings the app would run with, set before the app's own modules are loaded
Object.assign(process.env, {
  OLLAMA_URL: `http://127.0.0.1:${modelPort}`,
  ROSA_MODEL: alias,
  ROSA_EMBED_STYLE: pick('ROSA_EMBED_STYLE', 'embedStyle', 'none'),
  ...(embedFile ? { ROSA_EMBED_URL: `http://127.0.0.1:${embedPort}`, ROSA_EMBED_MODEL: 'embed' } : {}),
  ...(pick('ROSA_GIF_PYTHON', 'gifPython', '') ? { ROSA_GIF_PYTHON: pick('ROSA_GIF_PYTHON', 'gifPython', '') } : {}),
  ...(pick('ROSA_GIFS_DIR', 'gifsDir', '') ? { ROSA_GIFS_DIR: pick('ROSA_GIFS_DIR', 'gifsDir', '') } : {}),
  ROSA_DEBUG_LOG: process.env.ROSA_DEBUG_LOG || '1'
});

const say = (line) => console.log(`  ${line}`);

if (await waitForHealth(`http://127.0.0.1:${appPort}/api/alive`, 1200, 300)) {
  console.log(`\n  The app is still running on :${appPort}. Close it first (Ctrl+C in its window): it would overwrite the catalogue this writes.\n`);
  process.exit(1);
}

const parts = [];
const logTo = (name) => () => {};
async function ensure(name, url, command, argv) {
  if (await waitForHealth(url, 1500, 300)) {
    say(`${name}: already running`);
    return;
  }
  if (!fs.existsSync(command)) throw new Error(`${name}: ${command} not found. Edit rosia.local.json.`);
  say(`${name}: starting ...`);
  parts.push(supervise({ name, command, args: argv, log: logTo(name), health: { url, intervalMs: 20_000, failures: 3, graceMs: 180_000 } }));
  if (!(await waitForHealth(url, 180_000, 1000))) throw new Error(`${name} did not start`);
  say(`${name}: ready`);
}

const stopAll = () => {
  for (const p of parts) p.stop();
};
let lib;
let videos;
let saveNow = async () => {};
let stopping = false;
process.on('SIGINT', async () => {
  if (stopping) process.exit(1);
  stopping = true;
  console.log('\n  stopping after this clip, saving ...');
});

try {
  console.log('\n  R E D E S C R I B E\n');
  if (!fs.existsSync(mmproj)) throw new Error(`the vision projector is missing (${mmproj}): the model could not see frames`);
  await ensure('chat model', `http://127.0.0.1:${modelPort}/health`, server, [
    '-m', model, '--mmproj', mmproj, '--host', '127.0.0.1', '--port', String(modelPort), '--alias', alias,
    // one clip at a time, no more context than a strip and an answer need
    ...(local.modelArgs || ['-c', '8192', '-np', '1', '--jinja'])
  ]);
  if (embedFile && fs.existsSync(embedFile)) {
    await ensure('memory model', `http://127.0.0.1:${embedPort}/health`, server, [
      '-m', embedFile, '--host', '127.0.0.1', '--port', String(embedPort), '--embeddings', '-ngl', '0', '-c', '2048', '-b', '2048', '-ub', '2048', '-t', '4', '--alias', 'embed'
    ]);
  } else {
    say('memory model: none set, the built-in word matcher makes the vectors (they will be redone when the real one is back)');
  }

  lib = await import('../server/gifs/library.js');
  const idx = await import('../server/gifs/indexer.js');
  videos = await import('../server/videos/catalog.js');
  const desc = await import('../server/gifs/describe.js');
  const { extractStrip } = desc;
  await lib.loadLibrary();
  await videos.loadVideoCatalog();
  await videos.syncVideoCatalog();

  if (retry) {
    let cleared = 0;
    for (const item of lib.allItems()) if (item.upgradeFailed) { delete item.upgradeFailed; cleared += 1; }
    say(`${cleared} clips that failed before will be tried again`);
  }

  saveNow = async () => {
    await lib.saveLibrary();
    await videos.saveVideoCatalog();
  };

  const clipsLeft = () => lib.allItems().filter((i) => i.status === 'ok' && !i.dupOf && (i.descVersion || 1) < desc.DESC_VERSION && !i.upgradeFailed).length;
  // the saved videos come after the clips; they are counted too, so the number never reads 0 while work is left
  const total = () => clipsLeft() + videos.videosToUpgrade();
  const left = total();
  say(`${left} clips${videos.nextVideoUpgrade() ? ' and the saved videos' : ''} to describe\n`);

  // the next clip's frames are cut while the model reads this one
  const prefetched = new Map();
  const peek = () => {
    const seen = [];
    for (const item of lib.allItems()) {
      if (item.status === 'ok' && !item.dupOf && (item.descVersion || 1) < desc.DESC_VERSION && !item.upgradeFailed) seen.push(item);
      if (seen.length >= 2) break;
    }
    return seen;
  };
  const strip = (file) => {
    const ready = prefetched.get(file);
    prefetched.delete(file);
    return ready || extractStrip(file);
  };

  const began = Date.now();
  let done = 0;
  let failed = 0;
  let sinceSave = 0;
  while (!stopping && (!limit || done + failed < limit)) {
    const [current, following] = peek();
    if (following && !prefetched.has(lib.fileFor(following)) && prefetched.size < 3) {
      const p = extractStrip(lib.fileFor(following));
      p.catch(() => {});
      prefetched.set(lib.fileFor(following), p);
    }
    const target = current || videos.nextVideoUpgrade();
    const moved = current ? await idx.upgradeNext({ strip }) : await videos.upgradeNextVideo();
    if (!moved) break;
    if (target?.upgradeFailed) failed += 1;
    else done += 1;
    sinceSave += 1;
    if (sinceSave >= 20) {
      sinceSave = 0;
      await saveNow();
      const rate = (done + failed) / ((Date.now() - began) / 1000);
      const remaining = total();
      say(`${done} described, ${failed} failed, ${remaining} to go (about ${Math.ceil(remaining / Math.max(rate, 0.01) / 60)} min)`);
    }
  }
  await saveNow();
  say(`\n  finished: ${done} described, ${failed} could not be read${stopping ? ' (stopped early; run it again to carry on)' : ''}.`);
  const stats = lib.libraryStats();
  const v = videos.videoCatalogStats();
  say(`GIFs with the fuller description: ${stats.fuller} / ${stats.ok}; videos: ${v.fuller} / ${v.ok}`);
  if (failed) say('The ones that failed keep their old description. Run with --retry to try them again.');
} catch (err) {
  console.error(`\n  ${err.message}`);
  process.exitCode = 1;
} finally {
  try {
    await saveNow();
  } catch {
    /* nothing more to do */
  }
  stopAll();
  setTimeout(() => process.exit(process.exitCode || 0), 800);
}
