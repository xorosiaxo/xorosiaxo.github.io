import fs from 'node:fs';
import path from 'node:path';

/*
 * What the app (update.js) and the launcher (scripts/supervisor.js, scripts/apply-update.js) agree on. The app finds, downloads
 * and checks an update and leaves it staged; the launcher, which is the only thing that can replace the files of a running app,
 * swaps it in after the app has exited with UPDATE_EXIT_CODE, and puts the old version back if the new one does not come up.
 */

/** The app exits with this code when it is leaving only so that a staged update can be put in place. */
export const UPDATE_EXIT_CODE = 75;

/** Never replaced, removed or read from an update: the person's own data and settings, and what the install needs. */
export const PROTECTED = ['data', 'node_modules', '.git', 'dist', 'rosia.local.json', 'image-prompts.txt', 'image-base-prompt.txt'];

export function isProtected(rel) {
  const first = String(rel).replace(/\\/g, '/').split('/')[0];
  return PROTECTED.includes(first);
}

export const updatesDir = (dataDir) => path.join(dataDir, 'updates');
export const updateFile = (dataDir, name) => path.join(updatesDir(dataDir), name);

// the files in data/updates/
export const FILES = {
  state: 'state.json', //     the app's own record: last check, latest version, what is staged
  pending: 'pending.json', // an update is staged and waiting for the launcher to swap it in
  trial: 'trial.json', //     a new version is on trial: if it does not come up, the old one is put back
  failed: 'failed.json', //   the last version that did not come up, and why (shown to the owner; see recordFailure)
  installed: 'installed.json' // the files the last update put in place, so the next one can remove what a release dropped
};

/** What is signed: the version, the zip's hash and size, and the oldest version allowed to carry on. The address is not part of it. */
export function signedText({ version, sha256, size, minVersion }) {
  return `rosia-update\n${version}\n${sha256}\n${size}\n${minVersion || ''}`;
}

/*
 * A version that crashes on this machine is taken out again, the owner is told why, and it is NOT given up on: it stays on offer.
 * Because a crash loop (download, install, crash, restore, repeat) would be worse than the problem, installing it by itself is
 * paused after a failure: tried again by itself at most MAX_AUTO_ATTEMPTS times in all, at least AUTO_RETRY_GAP_MS apart, and the
 * owner can press "install" at any time. A newer release is a fresh start.
 */
export const MAX_AUTO_ATTEMPTS = 3;
export const AUTO_RETRY_GAP_MS = 24 * 3600_000;

export function readFailure(dataDir) {
  try {
    const f = JSON.parse(fs.readFileSync(updateFile(dataDir, FILES.failed), 'utf8'));
    return f && typeof f.version === 'string' ? f : null;
  } catch {
    return null;
  }
}

/** Notes that `version` failed here (and why). The count goes up each time the same version fails again. */
export function recordFailure(dataDir, { version, from, reason, tail = [] }) {
  const before = readFailure(dataDir);
  const failure = {
    version: String(version),
    from: String(from || ''),
    reason: String(reason || 'it did not start').slice(0, 300),
    tail: tail.slice(-12).map((l) => String(l).slice(0, 300)),
    attempts: before?.version === String(version) ? before.attempts + 1 : 1,
    at: Date.now()
  };
  fs.mkdirSync(updatesDir(dataDir), { recursive: true });
  fs.writeFileSync(updateFile(dataDir, FILES.failed), JSON.stringify(failure, null, 2), 'utf8');
  return failure;
}

export function clearFailure(dataDir, version) {
  const f = readFailure(dataDir);
  if (f && (!version || f.version === String(version))) fs.rmSync(updateFile(dataDir, FILES.failed), { force: true });
}

/** May the app install this version by itself? (The owner pressing the button is always allowed.) */
export function autoInstallAllowed(failure, version, now = Date.now()) {
  if (!failure || failure.version !== String(version)) return true;
  return failure.attempts < MAX_AUTO_ATTEMPTS && now - failure.at >= AUTO_RETRY_GAP_MS;
}
