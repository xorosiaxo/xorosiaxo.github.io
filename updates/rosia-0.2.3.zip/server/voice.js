import crypto from 'node:crypto';
import { config } from './config.js';

/*
 * Her voice. The words are turned into speech by a local Kokoro server (scripts/tts-server.py) on this
 * machine's CPU. It is not a cloud service and applies no content filter: it reads exactly what it is given.
 */

export { describeVoices, speakable, chunks };
import { describeVoices, speakable, chunks } from '../public/speech-text.js';

export const voiceEnabled = () => Boolean(config.tts.url);

/* ---------- talking to the speech server ---------- */

let voiceList = null;

export async function voices() {
  if (voiceList) return voiceList;
  const res = await fetch(`${config.tts.url}/voices`, { signal: AbortSignal.timeout(5000) });
  if (!res.ok) throw new Error('The voice server did not answer.');
  voiceList = describeVoices((await res.json()).voices || []);
  return voiceList;
}

const cache = new Map(); // recent sentences, so replaying a reply is instant
const CACHE_MAX = 80;

export async function speak({ text, voice, speed }) {
  const clean = speakable(text).slice(0, 600);
  if (!clean) {
    const err = new Error('Nothing to say.');
    err.status = 400;
    throw err;
  }
  const known = await voices().catch(() => []);
  const chosen = known.some((v) => v.id === voice) ? voice : config.tts.voice;
  const rate = Math.min(1.4, Math.max(0.7, Number(speed) || 1));
  const key = crypto.createHash('sha1').update(`${chosen}|${rate}|${clean}`).digest('hex');
  const hit = cache.get(key);
  if (hit) return hit;

  const res = await fetch(`${config.tts.url}/speak`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ text: clean, voice: chosen, speed: rate }),
    signal: AbortSignal.timeout(60_000)
  });
  if (!res.ok) throw new Error('The voice server could not say that.');
  const wav = Buffer.from(await res.arrayBuffer());
  cache.set(key, wav);
  if (cache.size > CACHE_MAX) cache.delete(cache.keys().next().value);
  return wav;
}
