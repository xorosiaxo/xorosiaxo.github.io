import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';

/*
 * A testing aid for comparing picture models fairly. If data/image-override.json exists, the next pictures use what it says,
 * and it is read again for every picture (no restart):
 *
 *   { "seed": 12345, "unet": "z_image_turbo-Q8_0.gguf", "prompt": "the exact prompt to send" }
 *
 * Every field is optional. `seed` pins the random seed, `unet` swaps the model file in the saved workflow's GGUF loader, and
 * `prompt` is sent as it is (instead of the one she wrote, base prompt and all). Delete the file to go back to normal.
 */

const file = () => path.join(config.dataDir, 'image-override.json');

export function imageOverride() {
  try {
    const o = JSON.parse(fs.readFileSync(file(), 'utf8'));
    return {
      seed: Number.isInteger(o.seed) && o.seed >= 0 ? o.seed : undefined,
      unet: typeof o.unet === 'string' && /^[\w .()-]+\.gguf$/i.test(o.unet) ? o.unet : undefined,
      prompt: typeof o.prompt === 'string' && o.prompt.trim() ? o.prompt.trim() : undefined
    };
  } catch {
    return {};
  }
}

/** Points the GGUF model loader(s) of an API-format prompt at another file. Returns how many were changed. */
export function useUnet(apiPrompt, unet) {
  let changed = 0;
  for (const node of Object.values(apiPrompt || {})) {
    if (node && ['UnetLoaderGGUF', 'UnetLoaderGGUFAdvanced'].includes(node.class_type) && node.inputs) {
      node.inputs.unet_name = unet;
      changed += 1;
    }
  }
  return changed;
}
