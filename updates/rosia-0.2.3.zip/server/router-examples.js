/*
 * What each request sounds like, for the router's first step (router.js): a message is compared by meaning with these,
 * and the closest ones say what it is. "none" is ordinary talk, including talk ABOUT music, videos, games and screens,
 * which must not set anything off. Add a phrase here when a real request is missed; the test set
 * (test/router-cases.js) is kept separate, so the router is never measured on what it was given.
 */

export const EXAMPLES = {
  play_music: [
    'play some music', 'put some music on', 'play something', 'play me a song', 'can you play blood in your eyes',
    'play some taylor swift', 'put on some jazz', 'play something chill', 'play something upbeat', 'i want to hear some rock',
    'how about some reggae', 'wanna listen to some music', 'lets listen to some songs', 'put on my favourites',
    'play something you like', 'play the weeknd', 'queue up some lofi', 'music please', 'can we have some tunes',
    'play that song from the trailer', 'play a sad song', 'throw on some drake', 'i fancy some 80s music',
    'play something to dance to', 'play something i like', 'play kill bill by sza', 'get some music going',
    'play the new kendrick album', 'stick on some classical', 'play some songs for the gym'
  ],
  music_control: [
    'pause', 'pause the music', 'stop the music', 'skip this', 'next song', 'skip this song', 'go back a song',
    'play the last one again', 'restart this song', 'turn it up', 'louder', 'turn the music down', 'quieter please',
    'what song is this', "what's playing", 'who sings this', 'resume the music', 'unpause', 'keep playing',
    'mute it', 'volume to 50', 'carry on with the music', 'i hate this song skip', 'turn it off', 'next one',
    'play that again', 'go back', 'previous song', 'set the volume lower', 'kill the music'
  ],
  watch_video: [
    'watch the gta 6 trailer with me', 'lets watch something on youtube', 'lets watch the latest sidemen video',
    'can we watch a video together', 'watch cat videos with me', 'put on a youtube video', 'show me the new mrbeast video',
    'lets watch a funny video', 'watch this trailer with me', 'can we watch some highlights from the match',
    'pull up a video of baby otters', 'lets watch a cooking video', 'wanna watch something together', 'lets watch a movie trailer',
    'find a video about black holes and lets watch it', 'watch the new iphone keynote with me', 'youtube the dune 2 trailer',
    'put on some f1 highlights', 'lets watch a vlog', 'watch the latest pewdiepie video'
  ],
  video_control: [
    'pause the video', 'stop the video', 'close the video', 'resume the video', 'play the video again',
    'start the video from the beginning', 'turn off the video', 'close that', 'hold on pause it', 'unpause the video',
    'restart the vid', 'get rid of the video', 'carry on with the video', 'end the video'
  ],
  look_at_screen: [
    'look at this', 'can you see my screen', 'what do you think of this', 'look at my code', 'check out what im doing',
    'rate my setup', "what's on my screen", 'have a look at this game', 'look at these shoes im buying', 'can you see this',
    'what do you reckon about this website', 'look at my desktop', 'judge my code', 'take a look at this error',
    'look at what im playing', 'check my screen', 'what am i looking at', 'roast my tabs'
  ],
  game: [
    "let's play 20 questions", 'wanna play truth or dare', 'lets play would you rather', 'play rock paper scissors with me',
    'how well do you know me', 'quiz me about myself', 'lets play a game', 'can we play a game', 'truth or dare?',
    'would you rather?', 'lets do 20 questions', 'stop the game', 'i give up', 'whats the score', 'who is winning',
    'lets play again', 'another round', 'end the game'
  ],
  set_reminder: [
    'remind me at 5 to call mum', 'remind me in 10 minutes to take the pizza out', 'wake me up at 7', 'set a timer for 20 minutes',
    'set an alarm for 6am', "don't let me forget to text sam tonight", 'remind me tomorrow about the dentist',
    'can you remind me to drink water every hour', 'remind me to study at 8', 'make sure i remember to pay rent on friday',
    'set a reminder for my meeting at 3', 'remind me every day at 9 to take my tablets', 'timer 5 minutes'
  ],
  cancel_reminder: [
    'cancel the reminder about mum', 'delete my alarm', 'remove the dentist reminder', "i don't need that reminder anymore",
    'cancel all my reminders', 'turn off the timer', 'scrap the reminder', 'forget the reminder about rent'
  ],
  get_weather: [
    "what's the weather like", 'is it going to rain today', 'weather in london', 'how hot is it in dubai',
    'do i need an umbrella tomorrow', "what's the forecast for the weekend", 'is it cold outside', 'will it snow in leeds'
  ],
  web_search: [
    'search for the best pizza near me', 'look up who won the match last night', 'google the release date of gta 6',
    "what's the latest news", 'find out how tall the eiffel tower is', 'search online for cheap flights to rome',
    'look up the lyrics to this song', 'who won the champions league', 'what time does tesco close', 'check the news for me'
  ],
  none: [
    'hey', 'how are you', 'i missed you', 'lol', 'haha you are funny', 'good morning babe', 'i had a long day',
    'what music do you like', 'do you like taylor swift', 'i love this song', 'this song is so good', 'i was listening to music earlier',
    'i watch netflix a lot', 'have you seen the gta 6 trailer', 'i played games all day', 'my screen is broken',
    'i look at you and smile', 'you look cute', 'what do you think of me', 'tell me about yourself', 'i am so tired',
    'my mum called me today', 'i need to remember to be nicer', 'i forgot my keys today', 'what is your favourite film',
    'i passed my driving test', 'i hate mondays', 'come here', 'tell me a joke', 'i love you', 'good night', 'what are you up to',
    'that was fun', 'you are so cheeky', 'stop it lol', 'are you real', 'i went to the gym', 'the weather was nice today',
    'i searched everywhere for my phone', 'my friend showed me a video yesterday', 'i used to play guitar', 'music is my life',
    'whats up', 'yes', 'no', 'maybe', 'ok', 'sure', 'tell me more', 'that is so cool', 'i am bored', 'i cooked pasta',
    'did you sleep well', 'what did you dream about', 'i am watching tv', 'i can see why', 'games are boring', 'remind me why we started',
    'you remind me of someone', 'i just woke up', 'i have exams next week', 'kiss me', 'hold me', 'you are beautiful',
    // talk that sounds like a request but is about the past, a complaint or a feeling (the router's commonest false alarms)
    'i saw that trailer last night', 'we watched a film at my mates yesterday', 'that youtube video i saw earlier was hilarious',
    'it is freezing here today', 'the rain here is awful', 'its been so hot all week', 'my game keeps crashing',
    'i stopped watching that show', 'i listened to that album on the bus', 'i was searching for a new job today',
    'i paused the game to talk to you', 'that song was stuck in my head all day', 'i finally fixed the bug in my project',
    'my laptop screen is cracked', 'i played chess with my dad', 'do you ever watch anything', 'i set an alarm but slept through it',
    'stop playing games with me', 'quit teasing', 'you are winning me over'
  ]
};

export const ROUTED = Object.keys(EXAMPLES).filter((k) => k !== 'none');
