/*
 * Runs a web search across several providers without being at the mercy of any one of them.
 *
 *  - providers are tried in order; the first that returns results wins
 *  - a provider that fails (bot check, error, timeout) is put on a cool-down that doubles each time it
 *    fails again, so a blocked one is not hammered and the next one answers straight away
 *  - answers are cached for a few minutes, and identical searches in flight share one request
 *  - if what comes back is thin, a supplement (Wikipedia) tops it up
 */
export function createSearcher({
  providers,
  supplement = null,
  isReference = () => false, // questions a reference work answers well: its hits go first
  validate = (_query, results) => results, // drop results that have nothing to do with the question
  cacheMs = 5 * 60_000,
  timeoutMs = 8000,
  now = Date.now
} = {}) {
  const state = new Map(providers.concat(supplement ? [supplement] : []).map((p) => [
    p.name,
    { calls: 0, fails: 0, streak: 0, downUntil: 0, lastError: '', lastOkAt: 0 }
  ]));
  const cache = new Map();
  const inflight = new Map();

  const available = (p) => p.available() && now() >= state.get(p.name).downUntil;

  async function attempt(p, query, limit, { strict = true } = {}) {
    const s = state.get(p.name);
    s.calls += 1;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const raw = await p.run(query, limit, controller.signal);
      const results = validate(query, raw);
      // an engine that answers a different question (it happens, from some addresses) counts as failing
      if (strict && raw.length && !results.length) throw new Error('its results had nothing to do with the question');
      s.streak = 0;
      s.lastOkAt = now();
      return results;
    } catch (err) {
      s.fails += 1;
      s.streak += 1;
      s.lastError = controller.signal.aborted ? 'timed out' : err?.message || 'failed';
      // 1 min, 2, 4 ... up to 15
      s.downUntil = now() + Math.min(15 * 60_000, 60_000 * 2 ** (s.streak - 1));
      throw new Error(`${p.name}: ${s.lastError}`);
    } finally {
      clearTimeout(timer);
    }
  }

  async function run(query, limit) {
    const errors = [];
    let results = [];
    let provider = '';

    for (const p of providers) {
      if (!available(p)) continue;
      try {
        const found = await attempt(p, query, limit);
        if (found.length) {
          results = found;
          provider = p.name;
          break;
        }
        errors.push(`${p.name}: no results`);
      } catch (err) {
        errors.push(err.message);
      }
    }

    const reference = Boolean(supplement && isReference(query));
    if ((reference || results.length < 3) && supplement && available(supplement)) {
      try {
        const extra = await attempt(supplement, query, reference ? 2 : 3, { strict: false });
        const seen = new Set(results.map((r) => r.url));
        const fresh = extra.filter((r) => !seen.has(r.url));
        results = reference ? fresh.concat(results) : results.concat(fresh);
        if (!provider && results.length) provider = supplement.name;
      } catch (err) {
        errors.push(err.message);
      }
    }

    if (!results.length && errors.some((e) => !/no results/.test(e))) {
      throw new Error(`Web search is not working right now (${errors.join('; ')})`);
    }
    return { results, provider, cached: false };
  }

  async function search(query, limit = 5) {
    const key = `${limit}|${String(query).trim().toLowerCase()}`;
    const hit = cache.get(key);
    if (hit && now() - hit.at < cacheMs) return { ...hit.value, cached: true };
    if (inflight.has(key)) return inflight.get(key);

    const job = run(String(query).trim(), limit)
      .then((value) => {
        if (value.results.length) cache.set(key, { at: now(), value });
        if (cache.size > 100) cache.delete(cache.keys().next().value);
        return value;
      })
      .finally(() => inflight.delete(key));
    inflight.set(key, job);
    return job;
  }

  /** For the status page. */
  function health() {
    return [...state.entries()].map(([name, s]) => ({
      name,
      up: now() >= s.downUntil,
      calls: s.calls,
      failures: s.fails,
      lastError: s.lastError,
      lastOkAt: s.lastOkAt,
      retryAt: s.downUntil > now() ? s.downUntil : 0
    }));
  }

  return { search, health };
}
