import { config } from '../config.js';

/*
 * Where web results come from. Each provider is { name, available(), run(query, limit, signal) } and
 * resolves to [{ title, url, snippet }] or throws (a bot check, an HTTP error, a timeout).
 *
 * In order of preference:
 *   searxng      your own SearXNG instance (ROSA_SEARXNG_URL), if set
 *   brave        the Brave Search API (ROSA_BRAVE_KEY), if set
 *   duckduckgo   scraped HTML, no key; sometimes shows a bot check
 *   yahoo        scraped HTML, no key
 *   bing         scraped HTML, no key (last: from some addresses it answers with unrelated pages)
 *   wikipedia    the MediaWiki search API, no key; added when the others find little
 */

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };

export function stripTags(html) {
  return String(html || '')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&([a-z]+);/gi, (m, name) => ENTITIES[name.toLowerCase()] ?? m)
    .replace(/\s+/g, ' ')
    .trim();
}

/* ---------- parsers (kept separate so they can be tested on saved pages) ---------- */

function decodeDuckRedirect(href) {
  try {
    const url = new URL(href, 'https://html.duckduckgo.com/html/');
    const target = url.searchParams.get('uddg');
    return target ? decodeURIComponent(target) : url.toString();
  } catch {
    return href;
  }
}

export function parseDuckHtml(html, limit) {
  const blocks = html.split(/<div[^>]+class="[^"]*result\b[^"]*"[^>]*>/i).slice(1);
  const out = [];
  for (const block of blocks) {
    if (out.length >= limit) break;
    const link = block.match(/<a[^>]+class="[^"]*result__a[^"]*"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
    if (!link) continue;
    const url = decodeDuckRedirect(link[1]);
    const title = stripTags(link[2]);
    if (!title || !/^https?:/i.test(url)) continue;
    const snip =
      block.match(/<a[^>]+class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/a>/i) ||
      block.match(/<div[^>]+class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
    out.push({ title, url, snippet: snip ? stripTags(snip[1]) : '' });
  }
  return out;
}

/** Bing wraps every result in a tracking redirect whose real address is base64 in the "u" parameter. */
export function decodeBingUrl(href) {
  try {
    const url = new URL(href.replace(/&amp;/g, '&'));
    const u = url.searchParams.get('u');
    if (u && /^a1/.test(u)) {
      const real = Buffer.from(u.slice(2).replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
      if (/^https?:\/\//i.test(real)) return real;
    }
    return /bing\.com$/i.test(url.hostname) ? '' : url.toString();
  } catch {
    return '';
  }
}

export function parseBing(html, limit) {
  const blocks = html.split(/<li class="b_algo"/i).slice(1);
  const out = [];
  for (const block of blocks) {
    if (out.length >= limit) break;
    const h2 = block.match(/<h2[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
    if (!h2) continue;
    const url = decodeBingUrl(h2[1]);
    const title = stripTags(h2[2]);
    if (!url || !title) continue;
    const snip = block.match(/<p[^>]*class="[^"]*b_lineclamp[^"]*"[^>]*>([\s\S]*?)<\/p>/i) || block.match(/<p[^>]*>([\s\S]*?)<\/p>/i);
    out.push({ title, url, snippet: snip ? stripTags(snip[1]).replace(/^[A-Z][a-z]{2} \d{1,2}, \d{4}\s*[·-]?\s*/, '') : '' });
  }
  return out;
}

/** Yahoo hides the real address in the "RU" part of its redirect. */
export function parseYahoo(html, limit) {
  const blocks = html.split(/<div class="compTitle options-toggle"/i).slice(1);
  const out = [];
  for (const block of blocks) {
    if (out.length >= limit) break;
    const a = block.match(/<a[^>]+href="(https?:\/\/r\.search\.yahoo\.com\/[^"]+)"/i);
    const h3 = block.match(/<h3[^>]*>([\s\S]*?)<\/h3>/i);
    if (!a || !h3) continue;
    const ru = /\/RU=([^/]+)\/RK=/.exec(a[1]);
    let url = '';
    try {
      url = ru ? decodeURIComponent(ru[1]) : '';
    } catch {
      url = '';
    }
    const title = stripTags(h3[1]);
    if (!/^https?:\/\//i.test(url) || !title) continue;
    const snip = block.match(/<p[^>]*class="[^"]*(?:fc-dustygray|lh-)[^"]*"[^>]*>([\s\S]*?)<\/p>/i);
    out.push({ title, url, snippet: snip ? stripTags(snip[1]) : '' });
  }
  return out;
}

export function parseSearx(data, limit) {
  return (Array.isArray(data?.results) ? data.results : [])
    .filter((r) => /^https?:/i.test(r.url || '') && r.title)
    .slice(0, limit)
    .map((r) => ({ title: stripTags(r.title), url: r.url, snippet: stripTags(r.content || '') }));
}

export function parseBrave(data, limit) {
  return (Array.isArray(data?.web?.results) ? data.web.results : [])
    .filter((r) => /^https?:/i.test(r.url || '') && r.title)
    .slice(0, limit)
    .map((r) => ({ title: stripTags(r.title), url: r.url, snippet: stripTags(r.description || '') }));
}

export function parseWikipedia(data, limit) {
  return (Array.isArray(data?.query?.search) ? data.query.search : []).slice(0, limit).map((r) => ({
    title: `${r.title} - Wikipedia`,
    url: `https://en.wikipedia.org/wiki/${encodeURIComponent(String(r.title).replace(/ /g, '_'))}`,
    snippet: stripTags(r.snippet || '')
  }));
}

/* ---------- fetching ---------- */

async function get(url, { signal, headers, method = 'GET', body } = {}) {
  const res = await fetch(url, {
    method,
    headers: { 'user-agent': UA, 'accept-language': 'en-GB,en;q=0.9', ...headers },
    body,
    signal
  });
  if (!res.ok) throw new Error(`${new URL(url).hostname} answered ${res.status}`);
  return res;
}

const BOT_CHECK = /anomaly-modal|challenge-form|unusual traffic|captcha|are you a human/i;

export function buildProviders(cfg = config.search) {
  const providers = [];

  if (cfg.searxngUrl) {
    providers.push({
      name: 'searxng',
      available: () => true,
      async run(query, limit, signal) {
        const url = `${cfg.searxngUrl}/search?${new URLSearchParams({ q: query, format: 'json', language: 'en-GB', safesearch: '0' })}`;
        return parseSearx(await (await get(url, { signal, headers: { accept: 'application/json' } })).json(), limit);
      }
    });
  }

  if (cfg.braveKey) {
    providers.push({
      name: 'brave',
      available: () => true,
      async run(query, limit, signal) {
        const url = `https://api.search.brave.com/res/v1/web/search?${new URLSearchParams({ q: query, count: String(limit), country: 'GB' })}`;
        const res = await get(url, { signal, headers: { accept: 'application/json', 'x-subscription-token': cfg.braveKey } });
        return parseBrave(await res.json(), limit);
      }
    });
  }

  providers.push({
    name: 'duckduckgo',
    available: () => true,
    async run(query, limit, signal) {
      const res = await get(cfg.duckUrl, {
        signal,
        method: 'POST',
        headers: { 'content-type': 'application/x-www-form-urlencoded', accept: 'text/html,application/xhtml+xml' },
        body: new URLSearchParams({ q: query, kl: 'uk-en' })
      });
      const html = await res.text();
      if (BOT_CHECK.test(html)) throw new Error('DuckDuckGo asked for a bot check');
      return parseDuckHtml(html, limit);
    }
  });

  providers.push({
    name: 'yahoo',
    available: () => true,
    async run(query, limit, signal) {
      const url = `${cfg.yahooUrl}?${new URLSearchParams({ p: query, ei: 'UTF-8' })}`;
      const html = await (await get(url, { signal, headers: { accept: 'text/html' } })).text();
      return parseYahoo(html, limit);
    }
  });

  providers.push({
    name: 'bing',
    available: () => true,
    async run(query, limit, signal) {
      const url = `${cfg.bingUrl}?${new URLSearchParams({ q: query, setlang: 'en-GB', cc: 'GB' })}`;
      const html = await (await get(url, { signal, headers: { accept: 'text/html' } })).text();
      if (BOT_CHECK.test(html) && !/b_algo/.test(html)) throw new Error('Bing asked for a bot check');
      return parseBing(html, limit);
    }
  });

  return providers;
}

/** Only used to top up a thin result list. */
/** "what is the capital of australia" finds the article "Question"; "capital of australia" finds Canberra. */
export function encyclopediaQuery(query) {
  return String(query)
    .trim()
    .replace(/^(what|who|when|where|which|why)\s+(is|are|was|were|does|do|did)\s+/i, '')
    .replace(/^(the|a|an)\s+/i, '');
}

export function buildSupplement(cfg = config.search) {
  return {
    name: 'wikipedia',
    available: () => true,
    async run(query, limit, signal) {
      const url = `${cfg.wikipediaUrl}?${new URLSearchParams({
        action: 'query', list: 'search', srsearch: encyclopediaQuery(query), format: 'json', srlimit: String(limit), srprop: 'snippet'
      })}`;
      return parseWikipedia(await (await get(url, { signal, headers: { accept: 'application/json' } })).json(), limit);
    }
  };
}
