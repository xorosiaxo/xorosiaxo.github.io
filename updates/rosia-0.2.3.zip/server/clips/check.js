import { isPrivateAddress } from '../videos/links.js';
import dns from 'node:dns/promises';

/*
 * Before a clip goes out as a link, its first bytes are fetched: only a working link to a picture or a video counts.
 * Answers are remembered for a few minutes so a run of picks does not ask the same host again and again.
 */

const OK_FOR = 10 * 60_000;
const BAD_FOR = 30 * 60_000;
const cache = new Map(); // url -> { ok, at }

async function publicHost(url) {
  let host;
  try { host = new URL(url).hostname; } catch { return false; }
  try {
    const found = await dns.lookup(host, { all: true });
    return found.length > 0 && found.every((a) => !isPrivateAddress(a.address));
  } catch {
    return false;
  }
}

export async function checkClip(url, { fetchFn = fetch, resolve = publicHost, now = Date.now() } = {}) {
  if (!/^https?:\/\//i.test(String(url || ''))) return false;
  const hit = cache.get(url);
  if (hit && now - hit.at < (hit.ok ? OK_FOR : BAD_FOR)) return hit.ok;
  let ok = false;
  try {
    let current = url;
    for (let hop = 0; hop < 4; hop += 1) {
      if (!(await resolve(current))) break; // never this computer or a private network, also after a redirect
      const res = await fetchFn(current, { redirect: 'manual', headers: { Range: 'bytes=0-2047', 'User-Agent': 'Mozilla/5.0 (Rosia link check)' }, signal: AbortSignal.timeout(7000) });
      res.body?.cancel?.().catch(() => {});
      if ([301, 302, 303, 307, 308].includes(res.status) && res.headers.get('location')) {
        current = new URL(res.headers.get('location'), current).href;
        continue;
      }
      const type = String(res.headers.get('content-type') || '').toLowerCase();
      ok = (res.status === 200 || res.status === 206) && (type.startsWith('image/') || type.startsWith('video/'));
      break;
    }
  } catch {
    ok = false;
  }
  cache.set(url, { ok, at: now });
  if (cache.size > 1000) cache.delete(cache.keys().next().value);
  return ok;
}

export const resetClipChecks = () => cache.clear();
