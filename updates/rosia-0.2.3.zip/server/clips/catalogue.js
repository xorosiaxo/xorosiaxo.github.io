import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';
import { hashEmbed } from '../embed.js';
import { coalescedWriter } from '../atomic.js';

/*
 * The clips that ship with the app (catalogue.json, built by scripts/export-clips.js): links with what each shows and when
 * it fits, and no files. A clip on Discord is only reachable through a signed link that lasts about a day, so each install's
 * Rosia plugin, inside the person's own Discord, renews the links and hands the fresh ones back here (see the /api/clips
 * routes in index.js). A clip is only offered while it has a working link.
 */

const DISCORD = /(^|\.)(discordapp\.(com|net)|discord\.com)$/i;
const RENEW_BEFORE_MS = 8 * 3600_000; // links that end within this are asked for again
const BAD_FOR_MS = 6 * 3600_000; // a link that failed its check is not offered again for a while

let clips = null; // id -> clip
const fresh = new Map(); // Discord path -> { url, until }
const bad = new Map(); // id -> when its link last failed
const write = coalescedWriter('clip links');
const linksFile = () => path.join(config.dataDir, 'clips', 'links.json');

/** A packed vector back to numbers. */
export function unpackVector(packed) {
  if (!packed?.q) return null;
  const bytes = new Int8Array(Buffer.from(packed.q, 'base64'));
  return Array.from(bytes, (b) => b * packed.scale);
}

export const isDiscordLink = (url) => { try { return DISCORD.test(new URL(url).host); } catch { return false; } };
export const pathOf = (url) => { try { return new URL(url).pathname; } catch { return ''; } };

/** When a signed Discord link stops working (its ex= is hexadecimal seconds), or 0 when it has none. */
export function linkExpiry(url) {
  try {
    const ex = new URL(url).searchParams.get('ex');
    return ex && /^[0-9a-f]+$/i.test(ex) ? parseInt(ex, 16) * 1000 : 0;
  } catch {
    return 0;
  }
}

export function loadCatalogue(file = path.join(config.root, 'server', 'clips', 'catalogue.json')) {
  if (clips) return clips;
  clips = new Map();
  try {
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    for (const c of data.clips || []) {
      clips.set(c.id, { ...c, vec: unpackVector(c.vec), remote: true, status: 'ok' });
    }
  } catch { /* no catalogue: she has only what is on this computer */ }
  try {
    const saved = JSON.parse(fs.readFileSync(linksFile(), 'utf8'));
    for (const [p, v] of Object.entries(saved || {})) if (v?.url && v.until > Date.now()) fresh.set(p, v);
  } catch { /* none renewed yet */ }
  return clips;
}

export const catalogueClips = () => [...loadCatalogue().values()];
export const getClip = (id) => loadCatalogue().get(id);

/** The link to send for a clip right now, or '' when it has none that works. */
export function linkFor(clip, now = Date.now()) {
  if (!clip?.url) return '';
  if (!isDiscordLink(clip.url)) return clip.url;
  const f = fresh.get(pathOf(clip.url));
  return f && f.until > now + 60_000 ? f.url : '';
}

/** Can this clip be offered: it has a link that works, and its link has not just failed. */
export function sendable(clip, now = Date.now()) {
  if (!linkFor(clip, now)) return false;
  const failed = bad.get(clip.id);
  return !failed || now - failed > BAD_FOR_MS;
}

export const markBad = (id) => bad.set(id, Date.now());

/** Its meaning as a vector in the embedding `kind`: the catalogue's own when it matches, otherwise made from its words. */
const hashed = new Map();
export function clipVector(clip, kind) {
  if (clip.vecKind === kind) return clip.vec;
  if (kind !== 'hash') return null;
  if (!hashed.has(clip.id)) hashed.set(clip.id, hashEmbed([clip.description, clip.reaction, clip.useWhen, clip.text].filter(Boolean).join('. ')));
  return hashed.get(clip.id);
}

/** Discord links that need a fresh signature, the ones never renewed first. */
export function staleLinks(limit = 200, now = Date.now()) {
  const out = [];
  const later = [];
  for (const c of loadCatalogue().values()) {
    if (!isDiscordLink(c.url)) continue;
    const f = fresh.get(pathOf(c.url));
    if (!f) out.push(c.url);
    else if (f.until < now + RENEW_BEFORE_MS) later.push(c.url);
  }
  return [...out, ...later].slice(0, Math.max(1, Math.min(2000, limit)));
}

/**
 * Fresh links from the plugin. Only a Discord link for the same file as one in the catalogue, signed and not yet expired,
 * is kept. Returns how many were kept.
 */
export function acceptFresh(pairs, now = Date.now()) {
  const known = new Set([...loadCatalogue().values()].filter((c) => isDiscordLink(c.url)).map((c) => pathOf(c.url)));
  let kept = 0;
  for (const pair of Array.isArray(pairs) ? pairs.slice(0, 1000) : []) {
    const original = String(pair?.original || '');
    const refreshed = String(pair?.refreshed || '');
    let u;
    try { u = new URL(refreshed); } catch { continue; }
    if (u.protocol !== 'https:' || !DISCORD.test(u.host)) continue;
    const p = u.pathname;
    if (!known.has(p) || (original && pathOf(original) !== p)) continue;
    const until = linkExpiry(refreshed);
    if (!until || until < now + 60_000) continue;
    fresh.set(p, { url: refreshed, until });
    kept += 1;
  }
  if (kept) write(linksFile(), () => JSON.stringify(Object.fromEntries(fresh)));
  return kept;
}

export function catalogueStats(now = Date.now()) {
  const all = catalogueClips();
  const discord = all.filter((c) => isDiscordLink(c.url));
  const needRenewing = discord.filter((c) => { const f = fresh.get(pathOf(c.url)); return !f || f.until < now + RENEW_BEFORE_MS; }).length;
  return { clips: all.length, sendable: all.filter((c) => sendable(c, now)).length, needRenewing };
}

/** For tests. */
export function resetCatalogue() {
  clips = null;
  fresh.clear();
  bad.clear();
  hashed.clear();
}
