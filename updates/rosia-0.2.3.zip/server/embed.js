import { config } from './config.js';

/*
 * Turns text into a vector so notes can be found by similarity instead of exact words.
 *
 * Two backends:
 *  - a real embedding model, if ROSA_EMBED_URL points at an OpenAI-style /v1/embeddings server
 *    (e.g. `llama-server -m nomic-embed-text.gguf --embeddings --port 8081`). This matches on meaning.
 *  - otherwise a local "hashed n-gram" embedding: words (lightly stemmed), word pairs and character
 *    trigrams hashed into a fixed-size vector. No model needed and it copes with plurals, tenses and
 *    typos ("football" finds "plays football on Sundays"), but it does not know that "puppy" means
 *    "dog". That needs the real model.
 *
 * Every vector is stored with the kind of embedder that made it, so the two are never compared.
 */

const HASH_DIM = 384;

const STOP = new Set(
  ('a an the and or but if of to in on at for with from by as is are was were be been am do does did ' +
    'it its this that these those i me my you your he she they them his her their we our us not no so ' +
    'just really very about into over than then too also have has had will would can could should').split(' ')
);

function stem(word) {
  let w = word;
  if (w.length > 3 && w.endsWith('s') && !w.endsWith('ss')) w = w.slice(0, -1); // plurals and "plays"
  if (w.length > 5) w = w.replace(/(ing|ed|ly)$/, '');
  return w;
}

/* Everyday topics: words that usually mean "the same area" share a feature, so "movies" can find
   "loves horror films" even without a real embedding model. */
const GROUPS = [
  'film movie cinema horror thriller comedy netflix show series',
  'sport football soccer rugby tennis gym run swim cricket basketball match training workout',
  'pet cat dog puppy kitten hamster rabbit vet',
  'job work career nurse teacher engineer developer doctor intern office employ boss colleague shift',
  'study uni university degree course exam student college lecture module dissertation assignment',
  'music song band guitar piano gig concert playlist album sing',
  'food eat cook restaurant pizza vegan vegetarian allergic allergy peanut nut satay diet dinner lunch breakfast',
  'family mum mom dad brother sister parent sibling cousin gran',
  'partner girlfriend boyfriend wife husband date dating relationship ex crush',
  'home live flat city town move house rent roommate flatmate',
  'travel trip holiday flight abroad visit vacation',
  'health sick ill anxious anxiety stress tired sleep headache therapy',
  'drive driving car licence test bus train commute',
  'game gaming xbox playstation steam console',
  'birthday anniversary party wedding'
];

const GROUP_OF = new Map();
GROUPS.forEach((g, i) => g.split(' ').forEach((w) => GROUP_OF.set(stem(w), i)));

export function words(text) {
  return String(text || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 1 && !STOP.has(w))
    .map(stem);
}

function fnv(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i += 1) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function add(vec, feature, weight) {
  const h = fnv(feature);
  vec[h % HASH_DIM] += (h & 0x80000000 ? -1 : 1) * weight;
}

function normalise(vec) {
  let sum = 0;
  for (const v of vec) sum += v * v;
  const norm = Math.sqrt(sum) || 1;
  return vec.map((v) => Math.round((v / norm) * 1000) / 1000);
}

export function hashEmbed(text) {
  const vec = new Array(HASH_DIM).fill(0);
  const ws = words(text);
  ws.forEach((w, i) => {
    add(vec, `w:${w}`, 1);
    if (GROUP_OF.has(w)) add(vec, `g:${GROUP_OF.get(w)}`, 1.2);
    if (i > 0) add(vec, `b:${ws[i - 1]}_${w}`, 0.5);
    const padded = `#${w}#`;
    for (let j = 0; j + 3 <= padded.length; j += 1) add(vec, `t:${padded.slice(j, j + 3)}`, 0.3);
  });
  return normalise(vec);
}

let modelDownUntil = 0;

/* Embedding models are trained to expect a short prefix that says what the text is for. */
const PREFIX = {
  nomic: { query: 'search_query: ', document: 'search_document: ' },
  embeddinggemma: { query: 'task: search result | query: ', document: 'title: none | text: ' },
  bge: { query: 'Represent this sentence for searching relevant passages: ', document: '' },
  none: { query: '', document: '' }
};

async function modelEmbed(text, role) {
  const res = await fetch(`${config.embedUrl}/v1/embeddings`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ model: config.embedModel, input: (PREFIX[config.embedStyle] || PREFIX.none)[role] + text }),
    signal: AbortSignal.timeout(8000)
  });
  if (!res.ok) throw new Error(`embeddings ${res.status}`);
  const data = await res.json();
  const vec = data?.data?.[0]?.embedding;
  if (!Array.isArray(vec) || !vec.length) throw new Error('no embedding returned');
  return normalise(vec);
}

/**
 * Many texts at once, in batches (one request per 32): { vecs, kind }. With the embedding model down it gives local hash
 * vectors for all of them, so the kind is the same for every text.
 */
export async function embedMany(texts, role = 'document') {
  const list = texts.map((t) => String(t ?? ''));
  if (!list.length) return { vecs: [], kind: currentKind() };
  if (config.embedUrl && Date.now() > modelDownUntil) {
    try {
      const prefix = (PREFIX[config.embedStyle] || PREFIX.none)[role];
      const vecs = [];
      for (let i = 0; i < list.length; i += 32) {
        const batch = list.slice(i, i + 32);
        const res = await fetch(`${config.embedUrl}/v1/embeddings`, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ model: config.embedModel, input: batch.map((t) => prefix + t) }),
          signal: AbortSignal.timeout(30_000)
        });
        if (!res.ok) throw new Error(`embeddings ${res.status}`);
        const data = (await res.json())?.data || [];
        // answers carry their index; keep them in the order asked
        const sorted = [...data].sort((a, b) => (a.index ?? 0) - (b.index ?? 0));
        if (sorted.length !== batch.length) throw new Error('embeddings: wrong number back');
        for (const d of sorted) vecs.push(normalise(d.embedding));
      }
      return { vecs, kind: `model:${config.embedModel}` };
    } catch {
      modelDownUntil = Date.now() + 60_000;
    }
  }
  return { vecs: list.map((t) => hashEmbed(t)), kind: 'hash' };
}

/** Returns { vec, kind }. Falls back to the local embedding if the model server is unavailable. */
export async function embed(text, role = 'document') {
  if (config.embedUrl && Date.now() > modelDownUntil) {
    try {
      return { vec: await modelEmbed(text, role), kind: `model:${config.embedModel}` };
    } catch {
      modelDownUntil = Date.now() + 60_000; // don't hammer a server that is down
    }
  }
  return { vec: hashEmbed(text), kind: 'hash' };
}

export function currentKind() {
  return config.embedUrl && Date.now() > modelDownUntil ? `model:${config.embedModel}` : 'hash';
}

export function cosine(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  let dot = 0;
  for (let i = 0; i < a.length; i += 1) dot += a[i] * b[i];
  return dot;
}
