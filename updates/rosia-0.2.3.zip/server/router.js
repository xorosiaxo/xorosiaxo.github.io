import { config } from './config.js';
import { embed, embedMany, cosine } from './embed.js';
import { EXAMPLES, ROUTED } from './router-examples.js';
import { wantedWords, plain } from './music/library.js';
import { gameNamed } from './games.js';

/*
 * The router: what someone wants, when the plain word rules in preflight.js did not recognise it ("how about some gta 6
 * music", "lets wtach something on youtube", "can u see this"). A small model left to choose sometimes says "putting
 * it on now" and never does, or writes the call out as text; this decides for her, before she speaks.
 *
 *  1. Meaning: the message is compared with example phrases for each request (router-examples.js) using the memory
 *     model already running on the processor (about 20 ms). Ordinary talk ends here, as "none".
 *  2. When step 1 thinks it is a request, a small model of its own (Qwen3 0.6B on the processor, if installed) decides
 *     which one and fills in the details, its answer held to a fixed JSON shape so it cannot wander off. Without it,
 *     step 1 decides alone (only when it is sure) and the details come from simple rules.
 *
 * Only for the requests listed in router-examples.js; photos, GIFs and pictures have their own handling.
 */

let bank = null; // { kind, items: [{ label, vec }] }
let building = null;

/** The example phrases as vectors, made once (and again if the memory model comes or goes). */
async function examples() {
  if (bank) return bank;
  building ||= (async () => {
    const items = Object.entries(EXAMPLES).flatMap(([label, list]) => list.map((text) => ({ label, text })));
    const { vecs, kind } = await embedMany(items.map((i) => i.text), 'query');
    bank = { kind, items: items.map((i, n) => ({ label: i.label, vec: vecs[n] })) };
    return bank;
  })().finally(() => { building = null; });
  return building;
}

/** Starts making the example vectors now, so the first message does not wait for them. */
export function warmRouter() {
  examples().catch(() => {});
}

/** For tests: forget the vectors. */
export function resetRouter() {
  bank = null;
}

/**
 * How close a message is to each kind of request: the average of its three closest examples of that kind, best first.
 * Pure, for tests: `vec` is the message's vector, `items` the examples'.
 */
export function scoreLabels(vec, items) {
  const by = new Map();
  for (const it of items) {
    const s = cosine(vec, it.vec);
    const list = by.get(it.label) || [];
    list.push(s);
    by.set(it.label, list);
  }
  return [...by.entries()]
    .map(([label, list]) => {
      const top = list.sort((a, b) => b - a).slice(0, 3);
      return { label, score: top.reduce((a, b) => a + b, 0) / top.length };
    })
    .sort((a, b) => b.score - a.score);
}

// How sure step 1 must be, for the memory model and for the built-in word matcher (measured on test/router-cases.js)
const LINES = {
  model: { maybe: 0.5, sure: 0.62, over: 0.06 },
  hash: { maybe: 0.32, sure: 0.5, over: 0.12 }
};
export const linesFor = (kind) => (String(kind).startsWith('model') ? LINES.model : LINES.hash);

/**
 * Step 1's verdict from the scores: { label, sure } where label is a request or 'none'. Pure, for tests.
 * `sure` means step 1 can act alone; otherwise step 2 (when installed) is asked.
 */
export function verdict(scores, kind) {
  const L = linesFor(kind);
  const top = scores[0];
  const none = scores.find((s) => s.label === 'none')?.score ?? 0;
  if (!top || top.label === 'none' || top.score < L.maybe) return { label: 'none', sure: true, score: top?.score ?? 0 };
  const lead = top.score - Math.max(none, scores.find((s) => s !== top)?.score ?? 0);
  return { label: top.label, sure: top.score >= L.sure && top.score - none >= L.over && lead >= 0.02, score: top.score, none };
}

/* ---------- step 2: a small model that decides, held to a fixed shape ---------- */

const DESCRIBE = {
  play_music: 'put a song, artist, genre or mood on (query: what to play, empty for anything)',
  music_control: 'work the music already playing (action: pause, resume, skip, previous, restart, stop, louder, quieter, now_playing)',
  watch_video: 'watch a YouTube video together (query: what to search for; empty if they did not say what)',
  video_control: 'work the video already on (action: pause, resume, restart, stop)',
  look_at_screen: 'look at their screen or a window on it (query: which window, in their words, or empty)',
  game: 'a game (action: start, stop or scores; game: twenty, rather, truth, rps or knows)',
  set_reminder: 'set a reminder, alarm or timer (query: what it is for)',
  cancel_reminder: 'cancel a reminder (query: which one, or "all")',
  get_weather: 'the weather somewhere (query: the place, empty for theirs)',
  web_search: 'look something up online (query: what to search for)',
  none: 'ordinary talk, a question about her, or talk ABOUT music, videos, games or screens: nothing to do'
};

// Only the tool's name: a few characters, so it answers in well under a second on the processor (asked to fill in the
// details too, a 0.6B model rambles until it runs out of room). The details come from their own words (callFor).
const SHAPE = {
  type: 'object',
  properties: { tool: { type: 'string', enum: [...ROUTED, 'none'] } },
  required: ['tool']
};

// worked examples: the hard part is ordinary talk that sounds like a request
// (kept apart from test/router-cases.js, which checks they never match, so the model is not measured on its examples)
export const SHOTS = [
  ['should i skip work and stay in bed', 'none'], ['my friend sent me a funny clip last week', 'none'], ['it has been raining all day here ugh', 'none'],
  ['who is your favourite singer', 'none'], ['you look amazing tonight', 'none'], ['remind me why i like you', 'none'],
  ['best of three, rock paper scissors', 'game'], ['quiz me, see how well you know me', 'game'], ['pull up the new mrbeast video for us', 'watch_video'],
  ['what do you think of my room setup', 'look_at_screen'], ['who won the match last night', 'web_search'], ['how about some drake', 'play_music'],
  ['way too loud', 'music_control'], ['shut the video', 'video_control'], ['wake me at 7', 'set_reminder'], ['is it raining in leeds', 'get_weather']
];

// the same every time, so the model server keeps its work on it from one request to the next. `shots: false` leaves out
// the worked examples: the model on its own, with only what each tool is for (scripts/router-eval.js --zero-shot).
const systemFor = (shots) =>
  'You decide what a person wants from their companion app, from their newest message. Tools:\n' +
  Object.entries(DESCRIBE).map(([k, v]) => `- ${k}: ${v.replace(/\s*\(.*\)$/, '')}`).join('\n') +
  '\nChoose a tool only when they are asking for it now; talk about something is "none".' +
  (shots ? `\nExamples:\n${SHOTS.map(([t, tool]) => `"${t}" -> ${tool}`).join('\n')}` : '') +
  '\nReply with JSON only: {"tool": "..."}';
const SYSTEM = systemFor(true);
const SYSTEM_ALONE = systemFor(false);

/** Asks the router model which tool. Returns { tool } or null when it is not running or does not answer in time. */
export async function askModel(text, context = {}, { fetchFn = fetch, shots = true } = {}) {
  if (!config.router.url) return null;
  const state = [
    context.music ? `Music is ${context.music}.` : '',
    context.watching ? 'A video is on.' : '',
    context.gameOn ? 'A game is going on.' : ''
  ].filter(Boolean).join(' ');
  try {
    const res = await fetchFn(`${config.router.url}/v1/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'router',
        temperature: 0,
        max_tokens: 16,
        messages: [
          { role: 'system', content: shots ? SYSTEM : SYSTEM_ALONE },
          { role: 'user', content: `${state ? `${state}\n` : ''}"${String(text).slice(0, 300)}"` }
        ],
        response_format: { type: 'json_schema', json_schema: { name: 'route', schema: SHAPE } },
        chat_template_kwargs: { enable_thinking: false },
        cache_prompt: true
      }),
      signal: AbortSignal.timeout(config.router.timeoutMs)
    });
    if (!res.ok) return null;
    const body = await res.json();
    const out = JSON.parse(body?.choices?.[0]?.message?.content || '{}');
    return [...ROUTED, 'none'].includes(out.tool) ? { tool: out.tool, query: '', action: '', game: '' } : null;
  } catch {
    return null;
  }
}

/** Warms the router model up, so the instructions are read once now and not on someone's first message. */
export function warmModel() {
  if (config.router.url) askModel('hello').catch(() => {});
}

/* ---------- the details for each request ---------- */

const LEAD = /^(?:(?:lol|lmao|haha+|hmm+|ok(?:ay)?|yeah|yea|yep|so|well|anyway[s]?|oh|ooh|hey|babe|rosia|please|pls|plz|can (?:you|u)|could (?:you|u)|would (?:you|u)|will (?:you|u)|lets|let'?s|wanna|want to|i want to|i wanna|shall we|should we|can we|could we)[\s,.!?]+)+/i;
const FILLER = new Set(['play', 'put', 'on', 'some', 'something', 'smth', 'somethin', 'music', 'song', 'songs', 'tunes', 'a', 'an', 'the', 'me', 'us', 'for', 'please', 'pls', 'plz', 'rn', 'now', 'with', 'together', 'watch', 'wtach', 'video', 'vid', 'vids', 'videos', 'youtube', 'yt', 'any', 'chance', 'of', 'hear', 'listen', 'to', 'lets', 'let', 'wanna', 'can', 'u', 'you', 'i', 'want', 'how', 'about', 'w', 'show', 'pull', 'up', 'find', 'stick', 'throw', 'queue', 'give', 'gimme', 'time', 'ok', 'okay', 'lol', 'hmm', 'could', 'would', 'just', 'go', 'get', 'going']);

/** The words that say what, from the message itself: "how about some gta 6 music" gives "gta 6". */
export function whatFrom(text) {
  return wantedWords(String(text || '').replace(LEAD, '')).filter((w) => !FILLER.has(w)).join(' ').trim();
}

function musicAction(text) {
  const t = plain(text);
  if (/\b(?:what|whats|who|called|name)\b/.test(t)) return 'now_playing';
  if (/\b(?:skip|next|hate)\b/.test(t)) return 'skip';
  if (/\b(?:previous|back|last one|again)\b/.test(t)) return /\bagain\b/.test(t) && !/\bprevious|back\b/.test(t) ? 'restart' : 'previous';
  if (/\b(?:restart|from the start|beginning)\b/.test(t)) return 'restart';
  if (/\b(?:mute)\b/.test(t)) return 'mute';
  if (/\b(?:louder|up|loud(?:er)? please)\b/.test(t) && !/\btoo loud\b/.test(t)) return 'louder';
  if (/\b(?:quieter|down|too loud|lower|softer)\b/.test(t)) return 'quieter';
  if (/\b(?:stop|kill|off)\b/.test(t)) return 'stop';
  if (/\b(?:pause|hold on|wait)\b/.test(t)) return 'pause';
  if (/\b(?:resume|unpause|carry on|keep (?:playing|going)|play)\b/.test(t)) return 'resume';
  return '';
}

function videoAction(text) {
  const t = plain(text);
  if (/\b(?:stop|close|end|off|get rid)\b/.test(t)) return 'stop';
  if (/\b(?:restart|again|beginning|start)\b/.test(t)) return 'restart';
  if (/\b(?:pause|hold|wait)\b/.test(t)) return 'pause';
  if (/\b(?:resume|unpause|carry on|keep|play|continue)\b/.test(t)) return 'resume';
  return '';
}

const MUSIC_ACTIONS = new Set(['pause', 'resume', 'skip', 'previous', 'restart', 'stop', 'louder', 'quieter', 'now_playing', 'mute']);
const VIDEO_ACTIONS = new Set(['pause', 'resume', 'restart', 'stop']);

/**
 * The tool call for a decision, as { name, args }, or null when there is not enough to act on (she asks instead):
 * "lets watch something on youtube" names no video, "lets play a game" no game.
 */
export function callFor(label, text, model = null, context = {}) {
  const q = (model?.query || '').trim();
  switch (label) {
    case 'play_music':
      return { name: 'play_music', args: { query: q || whatFrom(text) } };
    case 'music_control': {
      if (!context.music) return null; // nothing playing: nothing to work
      const action = MUSIC_ACTIONS.has(model?.action) ? model.action : musicAction(text);
      if (!action) return null;
      return action === 'mute' ? { name: 'music_control', args: { action: 'volume', volume: 0 } } : { name: 'music_control', args: { action } };
    }
    case 'watch_video': {
      const what = q || whatFrom(text).replace(/\b(?:something|anything|on)\b/g, '').trim();
      return what.length >= 2 ? { name: 'watch_video', args: { query: what } } : null;
    }
    case 'video_control': {
      if (!context.watching) return null;
      const action = VIDEO_ACTIONS.has(model?.action) ? model.action : videoAction(text);
      return action ? { name: 'video_control', args: { action } } : null;
    }
    case 'look_at_screen':
      return { name: 'look_at_screen', args: { which: '' } };
    case 'game': {
      const t = plain(text);
      if (/\b(?:quit|give up|stop|end)\b/.test(t)) return context.gameOn ? { name: 'game', args: { action: 'stop' } } : null;
      if (/\b(?:score|winning|won)\b/.test(t)) return { name: 'game', args: { action: 'scores' } };
      const game = gameNamed(text) || (['twenty', 'rather', 'truth', 'rps', 'knows'].includes(model?.game) ? model.game : '') || (/\bknow me\b|\btest me\b/.test(t) ? 'knows' : '');
      return game ? { name: 'game', args: { action: 'start', game } } : null; // "lets play a game": she offers some
    }
    case 'set_reminder':
      return { name: 'set_reminder', args: { about: q, when: '' } }; // (the time is read from their own words by the tool)
    case 'cancel_reminder':
      return { name: 'cancel_reminder', args: { which: q || (/\ball\b/i.test(text) ? 'all' : whatFrom(text).replace(/\b(?:cancel|delete|remove|reminders?|alarms?|timers?|my|that|get|rid)\b/g, '').trim() || 'all') } };
    case 'get_weather': {
      // with no place named and none known, nothing is run: the weather tool cannot guess, and she asks where
      const place = q || context.place || '';
      return place ? { name: 'get_weather', args: { place } } : null;
    }
    case 'web_search':
      return { name: 'web_search', args: { query: q || String(text).replace(LEAD, '').replace(/^(?:search(?: online)?(?: for)?|look up|google|find out)\s+/i, '').trim() } };
    default:
      return null;
  }
}

/**
 * What a message wants, as { name, args, why } or null. `available` is the tools offered for this reply; `context`
 * says what is on (music, a video, a game) and her last message.
 */
export async function route(text, available = [], context = {}) {
  const d = await decide(text, context);
  if (!d || d.label === 'none' || !available.includes(d.label)) return null;
  const t = String(text).trim();
  let call = callFor(d.label, t, d.model, context);
  let asked = null;
  // it is the music, the video or the game, but their words do not say which button ("enough of this video", "ok i
  // surrender"): the router model picks one from that tool's own list, rather than a list of words kept here
  const choices = ACTIONS_FOR[d.label]?.(context);
  if (!call && choices && config.router.url) {
    asked = await askChoice(t, choices, PURPOSE[d.label], context);
    if (asked) call = callFor(d.label, t, { ...(d.model || {}), action: asked }, context) || gameCall(asked, context);
  }
  return call ? { ...call, why: { step1: d.step1, model: d.model?.tool || null, action: asked, ms: d.ms } } : null;
}

// the buttons each tool has, when there is something to press (nothing playing: no music buttons)
const ACTIONS_FOR = {
  music_control: (c) => (c.music ? ['pause', 'resume', 'skip', 'previous', 'restart', 'stop', 'louder', 'quieter', 'now_playing'] : null),
  video_control: (c) => (c.watching ? ['pause', 'resume', 'restart', 'stop'] : null),
  game: (c) => (c.gameOn ? ['stop', 'scores', 'keep_playing'] : null)
};
const PURPOSE = {
  music_control: 'what to do with the music that is playing',
  video_control: 'what to do with the video that is on',
  game: 'what to do with the game being played (stop: they give up, quit or concede)'
};
const gameCall = (action, c) => (action === 'stop' && c.gameOn ? { name: 'game', args: { action: 'stop' } } : action === 'scores' ? { name: 'game', args: { action: 'scores' } } : null);

/** Asks the router model to pick one of `options` for a message. Returns the option, or null. */
export async function askChoice(text, options, purpose, context = {}, { fetchFn = fetch } = {}) {
  if (!config.router.url || !options?.length) return null;
  try {
    const res = await fetchFn(`${config.router.url}/v1/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'router',
        temperature: 0,
        max_tokens: 16,
        messages: [
          { role: 'system', content: `From the person's message, choose ${purpose}. Options: ${options.join(', ')}. Reply with JSON only: {"choice": "..."}` },
          { role: 'user', content: `"${String(text).slice(0, 300)}"` }
        ],
        response_format: { type: 'json_schema', json_schema: { name: 'pick', schema: { type: 'object', properties: { choice: { type: 'string', enum: options } }, required: ['choice'] } } },
        chat_template_kwargs: { enable_thinking: false },
        cache_prompt: true
      }),
      signal: AbortSignal.timeout(config.router.timeoutMs)
    });
    if (!res.ok) return null;
    const choice = JSON.parse((await res.json())?.choices?.[0]?.message?.content || '{}').choice;
    return options.includes(choice) && choice !== 'keep_playing' ? choice : null;
  } catch {
    return null;
  }
}

/**
 * What a message is, before its details: { label, step1, model, ms }, or null when the router is off. label is 'none'
 * for ordinary talk. (route() turns it into a call; a request that names nothing to act on gets none, and she asks.)
 */
export async function decide(text, context = {}) {
  const t = String(text || '').trim();
  if (!config.router.on || !t || t.length > 240) return null;
  const started = Date.now();
  const { kind, items } = await examples();
  const { vec, kind: mine } = await embed(t, 'query');
  if (mine !== kind) {
    // the memory model came or went since the examples were made: made again, in the background
    resetRouter();
    warmRouter();
    return null;
  }
  const step1 = verdict(scoreLabels(vec, items), kind);
  const out = (label, model = null) => ({ label, step1, model, ms: Date.now() - started });
  if (step1.label === 'none') return out('none');
  if (config.router.url && !step1.sure) {
    // step 2 settles what step 1 is unsure of. (When step 1 is sure, it stands: measured on the test set, the small
    // model is the more cautious of the two and talked it out of requests it had right, "plz play smth chill".)
    const model = await askModel(t, context);
    if (model) return out(model.tool, model);
  }
  return out(step1.sure ? step1.label : 'none');
}
