import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { config } from './config.js';
import { uiToApi, fill, targetSize } from './workflow.js';
import { imageOverride, useUnet } from './imageoverride.js';

/*
 * A small ComfyUI client for text-to-image with Z-Image Turbo.
 *
 * It sends a fixed workflow (GGUF image model, GGUF text encoder, VAE, 8 steps) to a ComfyUI server and
 * reports progress. Progress comes over ComfyUI's websocket when Node has one (22.4+); otherwise, or if
 * the socket fails, it polls the history, so a result is always found.
 */

/** Width and height (multiples of 16) for a requested shape, with the long side set by config. */
export function sizeFor(orientation, longSide = config.images.longSide) {
  return targetSize(orientation, longSide);
}

export function buildWorkflow({ prompt, width, height, seed, steps = config.images.steps }) {
  const m = config.images;
  return {
    1: { class_type: 'UnetLoaderGGUF', inputs: { unet_name: m.unet } },
    2: { class_type: 'ModelSamplingAuraFlow', inputs: { model: ['1', 0], shift: 3 } },
    3: { class_type: 'CLIPLoaderGGUF', inputs: { clip_name: m.clip, type: m.clipType } },
    4: { class_type: 'CLIPTextEncode', inputs: { text: prompt, clip: ['3', 0] } },
    5: { class_type: 'ConditioningZeroOut', inputs: { conditioning: ['4', 0] } },
    6: { class_type: 'EmptySD3LatentImage', inputs: { width, height, batch_size: 1 } },
    7: {
      class_type: 'KSampler',
      inputs: { model: ['2', 0], seed, steps, cfg: 1, sampler_name: 'euler', scheduler: 'simple', positive: ['4', 0], negative: ['5', 0], latent_image: ['6', 0], denoise: 1 }
    },
    8: { class_type: 'VAELoader', inputs: { vae_name: m.vae } },
    9: { class_type: 'VAEDecode', inputs: { samples: ['7', 0], vae: ['8', 0] } },
    10: { class_type: 'PreviewImage', inputs: { images: ['9', 0] } }
  };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function api(path, init = {}) {
  const res = await fetch(`${config.images.url}${path}`, { ...init, signal: init.signal || AbortSignal.timeout(30_000) });
  if (!res.ok) {
    let detail = '';
    try {
      const body = await res.json();
      detail = body?.error?.message || body?.error || '';
      // say which input and which value were refused ("sampler_name: res_2s"), not just "Value not in list"
      const nodeErrors = body?.node_errors && Object.values(body.node_errors).flatMap((n) => (n.errors || []).map((e) => {
        const input = e.extra_info?.input_name;
        const got = e.extra_info?.received_value;
        return `${e.message}${input ? ` (${input}: ${JSON.stringify(got)})` : ''}`;
      }));
      if (nodeErrors?.length) detail = [...new Set(nodeErrors)].join('; ');
    } catch {
      /* not JSON */
    }
    throw new Error(`The image generator said no (${res.status})${detail ? `: ${String(detail).slice(0, 200)}` : ''}`);
  }
  return res;
}

/* ---------- the workflow made in ComfyUI ---------- */

const definitions = new Map(); // node type -> its definition (stable for as long as the install is)

async function definitionOf(type) {
  if (definitions.has(type)) return definitions.get(type);
  const res = await api(`/object_info/${encodeURIComponent(type)}`);
  const def = (await res.json())[type];
  if (def) definitions.set(type, def);
  return def;
}

/**
 * The saved workflow (config.images.workflow) ready to run for this request, or null when none is set.
 * Throws if one is set but cannot be used, so a typo is reported rather than quietly replaced by something else.
 */
export async function workflowFor({ prompt, orientation, seed, unet }) {
  const file = config.images.workflow;
  if (!file) return null;
  let ui;
  try {
    ui = JSON.parse(await fs.readFile(file, 'utf8'));
  } catch (err) {
    throw new Error(`The saved workflow could not be read (${err.code || err.message}). Save it in ComfyUI as "${path.basename(file)}".`);
  }
  if (!Array.isArray(ui.nodes)) throw new Error('That workflow file is in the API format. Save it from the ComfyUI menu with "Save", not "Export (API)".');
  const info = {};
  for (const type of new Set(ui.nodes.map((n) => n.type))) {
    if (['Note', 'MarkdownNote', 'Reroute', 'PrimitiveNode'].includes(type)) continue;
    info[type] = await definitionOf(type);
  }
  const api = uiToApi(ui, info);
  // Fast mode (the default) uses euler / simple for a few steps, as Z-Image Turbo was designed for, in place of the saved
  // workflow's slower sampler; ROSA_IMAGE_FAST=0 keeps the workflow's own sampler, scheduler and steps.
  const sampling = config.images.fast ? { sampler_name: 'euler', scheduler: 'simple', steps: config.images.steps } : null;
  const used = fill(api, { text: prompt, orientation, seed, longSide: config.images.longSide, sampling });
  if (unet) useUnet(api.prompt, unet);
  return { prompt: api.prompt, steps: used.steps, size: used.size };
}

/** True when the image generator answers. */
export async function comfyUp() {
  try {
    await api('/system_stats', { signal: AbortSignal.timeout(2500) });
    return true;
  } catch {
    return false;
  }
}

/** Frees the card without stopping the server. */
export async function freeMemory() {
  try {
    await api('/free', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ unload_models: true, free_memory: true }) });
  } catch {
    /* best effort */
  }
}

/**
 * Makes one picture. onProgress({ step, steps }) is called as it goes.
 * Resolves to { buffer, seed } (PNG bytes).
 */
export async function generate({ prompt, orientation, onProgress = () => {}, signal, timeoutMs = config.images.timeoutMs }) {
  const override = imageOverride();
  const seed = override.seed ?? crypto.randomInt(0, 2 ** 31);
  const clientId = crypto.randomUUID();
  const deadline = Date.now() + timeoutMs;

  let socket = null;
  let finishedByEvent = false;
  let promptId = null;
  try {
    if (typeof WebSocket === 'function') {
      try {
        socket = new WebSocket(`${config.images.url.replace(/^http/, 'ws')}/ws?clientId=${clientId}`);
        socket.addEventListener('message', (event) => {
          if (typeof event.data !== 'string') return;
          let msg;
          try {
            msg = JSON.parse(event.data);
          } catch {
            return;
          }
          if (promptId && msg.data?.prompt_id && msg.data.prompt_id !== promptId) return;
          if (msg.type === 'progress') onProgress({ step: msg.data.value, steps: msg.data.max || steps });
          if (msg.type === 'executing' && msg.data?.node === null) finishedByEvent = true;
          if (msg.type === 'execution_success') finishedByEvent = true;
        });
        socket.addEventListener('error', () => {});
        await Promise.race([new Promise((r) => socket.addEventListener('open', r, { once: true })), sleep(800)]);
      } catch {
        socket = null; // polling will do
      }
    }

    const saved = await workflowFor({ prompt, orientation, seed, unet: override.unet });
    const { width, height } = saved?.size || sizeFor(orientation);
    const steps = saved?.steps || config.images.steps;
    const queued = await (await api('/prompt', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ prompt: saved?.prompt || buildWorkflow({ prompt, width, height, seed, steps }), client_id: clientId }),
      signal
    })).json();
    promptId = queued.prompt_id;
    if (!promptId) throw new Error('The image generator did not accept the job.');

    // wait for it to appear in the history (it only does once it has finished or failed)
    let entry = null;
    while (Date.now() < deadline) {
      if (signal?.aborted) throw Object.assign(new Error('Cancelled'), { name: 'AbortError' });
      const history = await (await api(`/history/${promptId}`, { signal })).json();
      entry = history[promptId];
      if (entry?.status?.completed || entry?.status?.status_str === 'error' || entry?.outputs && Object.keys(entry.outputs).length) break;
      entry = null;
      await sleep(finishedByEvent ? 150 : 700);
    }
    if (!entry) throw new Error('The picture took too long, so it was given up on.');
    if (entry.status?.status_str === 'error') {
      const failure = (entry.status.messages || []).find((m) => m[0] === 'execution_error')?.[1];
      throw new Error(`The image generator failed${failure?.exception_message ? `: ${String(failure.exception_message).slice(0, 160)}` : '.'}`);
    }

    const images = Object.values(entry.outputs || {}).flatMap((o) => o.images || []);
    if (!images.length) throw new Error('The image generator finished without a picture.');
    const first = images[0];
    const query = new URLSearchParams({ filename: first.filename, subfolder: first.subfolder || '', type: first.type || 'temp' });
    const buffer = Buffer.from(await (await api(`/view?${query}`, { signal })).arrayBuffer());
    onProgress({ step: steps, steps });
    // ComfyUI's own clock for the run (model loading and drawing, not the waiting around it)
    const stamps = Object.fromEntries((entry.status?.messages || []).map((m) => [m[0], m[1]?.timestamp]));
    const execMs = stamps.execution_start && stamps.execution_success ? stamps.execution_success - stamps.execution_start : undefined;
    return { buffer, seed, width, height, execMs, unet: override.unet };
  } finally {
    try {
      socket?.close();
    } catch {
      /* already closed */
    }
  }
}
