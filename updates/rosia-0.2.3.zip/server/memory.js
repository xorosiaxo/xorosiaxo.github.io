import { complete as defaultComplete } from './llm.js';
import { config } from './config.js';
import { background, msSinceActivity } from './activity.js';
import {
  addNote, updateNote, mergeDuplicates, activeNotes, getUser, saveUser, searchNotes, recentNotes, similarPairs, isExpired
} from './users.js';
import { saveSession, windowStart } from './sessions.js';
import { resolveUntil } from './dates.js';
import { findJoke, noteUse, takeOffer, LAUGHED } from './jokes.js';
import { settleOffer } from './diary.js';
import { takeOccasion, markOccasion } from './occasions.js';

/*
 * The model-driven side of long-term memory. Everything here runs in the background, one job at a
 * time and only while no reply is being generated (see activity.js).
 *
 * Keeping memory clean is part of the job, not an afterthought:
 *   - when something new contradicts a note ("moved to Bristol" vs "lives in Leeds"), the note is
 *     corrected in place and what it said before is kept in its history
 *   - facts that stop mattering ("driving test on Friday") get an end date and drop out of use
 *   - near-identical notes are merged
 *   - notes the person wrote or edited themselves are never changed behind their back
 */

/*
 * Only what the person said. Notes about them are taken from their own words: a small model's replies are full of
 * things it made up ("Priya is practising for her driving test"), and those must never become facts about them.
 */
function transcriptThem(messages) {
  return messages
    .filter((m) => m.role === 'user' && (m.content || m.images?.length))
    .map((m) => `Them: ${String(m.content || '').replace(/\s+/g, ' ').slice(0, 500)}${m.images?.length ? ' [sent a picture]' : ''}`)
    .join('\n');
}

function transcript(messages) {
  return messages
    .filter((m) => (m.role === 'user' || m.role === 'assistant') && (m.content || m.images?.length))
    .map((m) => {
      const who = m.role === 'user' ? 'Them' : 'Rosia';
      const pic = m.images?.length ? ' [sent a picture]' : '';
      return `${who}: ${String(m.content || '').replace(/\s+/g, ' ').slice(0, 500)}${pic}`;
    })
    .join('\n');
}

/* ---------- 1. keep the notes right as the conversation goes ---------- */

const VERB_FORM = { has: 'have', is: 'are', was: 'were', does: 'do', "doesn't": "don't", "isn't": "aren't", "hasn't": "haven't" };

/*
 * Facts about the chat are not facts about the person. "They are asking Rosia to show a bikini picture"
 * was saved as a note and then put back in front of her every turn, which is how a one-off request
 * turned into a running theme she would not drop. Anything that is about her, or about what was asked
 * for in the moment, is refused before it reaches the notes.
 */
const CHAT_ONLY =
  /\b(?:rosia|her|she)\b[^.]{0,80}\b(?:ask|asks|asked|asking|want|wants|wanted|request|requests|requested|show|shows|showing|send|sends|sending|picture|photo|bikini|pose)\b/i;
const CHAT_ONLY_2 =
  /\b(?:asking|asked|asks|wants|requested)\b[^.]{0,50}\b(?:picture|photo|bikini|selfie|pose)\b|\b(?:in (?:a |her )?bikini|nudes?|sexting|sexual|horny|aroused|turned on)\b/i;

/** True for a "fact" that is really about what was said in the chat rather than about the person's life. */
export function isChatOnly(text) {
  const t = String(text || '');
  return CHAT_ONLY.test(t) || CHAT_ONLY_2.test(t);
}

/** Gender is never assumed from a name, whatever the model wrote: he/she/his/her become they/their. */
export function neutralise(text) {
  const same = (from, to) => (from[0] === from[0].toUpperCase() ? to[0].toUpperCase() + to.slice(1) : to);
  // the verb after he/she is made plural too: "he lives" -> "they live", "she has" -> "they have"
  const plural = (verb) => {
    const known = VERB_FORM[verb.toLowerCase()];
    if (known) return known;
    if (!/s$/i.test(verb) || /(ss|us|is)$/i.test(verb) || verb.length < 3) return verb; // not a third-person verb
    if (/[^aeiou]ies$/i.test(verb)) return verb.replace(/ies$/i, 'y'); // studies -> study
    if (/(ches|shes|xes|zes|sses|oes)$/i.test(verb)) return verb.slice(0, -2); // watches -> watch, goes -> go
    return verb.slice(0, -1); // lives -> live
  };
  // a word or two may come between the pronoun and its verb ("she always lives", "he still goes")
  const ADVERB = '(?:always|usually|often|never|really|also|still|just|sometimes|now|already|even|only|actually|mostly|rarely|probably|currently|recently|no longer)';
  return String(text)
    // contractions first, or "she's" turns into "they's"
    .replace(/\b(he|she)'s\s+(got|been|gone|had|done)\b/gi, (m, p, w) => `${same(p, 'they')}'ve ${w}`)
    .replace(/\b(he|she)'(s|d|ll)\b/gi, (m, p, c) => `${same(p, 'they')}'${c.toLowerCase() === 's' ? 're' : c}`)
    .replace(/\b(he|she)\s+(doesn't|does not|isn't|is not|wasn't|was not|hasn't|has not)\b/gi, (m, p, neg) => `${same(p, 'they')} ${{ "doesn't": "don't", 'does not': 'do not', "isn't": "aren't", 'is not': 'are not', "wasn't": "weren't", 'was not': 'were not', "hasn't": "haven't", 'has not': 'have not' }[neg.toLowerCase()]}`)
    .replace(new RegExp(`\\b(he|she)\\s+((?:${ADVERB}\\s+){0,2})([a-z']+)`, 'gi'), (m, pronoun, between, verb) => `${same(pronoun, 'they')} ${between}${plural(verb)}`)
    .replace(/\b(?:he|she)\b/gi, (m) => same(m, 'they'))
    // "her" as an object ("told her", "with her.") is "them"; before a noun ("her sister") it is "their"
    .replace(/\bher\b(?=\s*(?:[.,!?;:)]|$|\s+(?:a|an|the|to|and|or|that|about|for|on|in|at|with|so|too|again|back|up|out|off|over|when|if|because|every|after|before|from|by|lots|loads|very|much)\b))/gi, (m) => same(m, 'them'))
    .replace(/\b(?:his|her)\b/gi, (m) => same(m, 'their'))
    .replace(/\bhim\b/gi, (m) => same(m, 'them'))
    .replace(/\bhers\b/gi, (m) => same(m, 'theirs'))
    .replace(/\b(?:himself|herself)\b/gi, (m) => same(m, 'themselves'));
}

/** What the model replied: a list of { text, until } (or plain strings). Tolerates stray text. */
export function parseFacts(text) {
  const raw = String(text || '');
  const list = /\[[\s\S]*\]/.exec(raw);
  if (!list) return [];
  try {
    const items = JSON.parse(list[0]);
    if (!Array.isArray(items)) return [];
    return items
      .map((i) => (typeof i === 'string' ? { text: i, until: null } : { text: i?.text, until: i?.until }))
      .filter((i) => typeof i.text === 'string' && i.text.trim().length >= 3)
      // neutralise first: "She works as a nurse" is a fact about them, "She asked Rosia..." is not
      .map((i) => ({ ...i, text: neutralise(i.text) }))
      .filter((i) => !isChatOnly(i.text));
  } catch {
    return [];
  }
}

/** One small yes/no-style question per pair: far more reliable from a small model than "edit my notes". */
async function relation(oldText, newText, complete) {
  const reply = await complete({
    maxTokens: 6,
    temperature: 0,
    messages: [
      {
        role: 'system',
        content:
          'You compare two statements about the same person. Reply with exactly one word.\n' +
          'SAME: they state the same fact.\n' +
          'REPLACES: the NEW statement means the OLD one is no longer true or is out of date (they moved, changed job, broke up, changed their mind).\n' +
          'UNRELATED: both can be true at the same time.'
      },
      { role: 'user', content: `OLD: ${oldText}\nNEW: ${newText}` }
    ]
  });
  const m = /\b(SAME|REPLACES|UNRELATED)\b/i.exec(reply || '');
  return m ? m[1].toUpperCase() : 'UNRELATED';
}

/**
 * Files one new fact: if it repeats a note it is merged, if it makes one out of date that note is
 * corrected in place (its old wording kept in its history), otherwise it is added. A note the person
 * wrote themselves is never changed: a new fact that contradicts one is dropped instead.
 */
/** Only things about an event or a plan can expire: "Sister's name is Priya" never does, whatever the model says. */
export function looksTimeBound(text) {
  return /\b(today|tonight|tomorrow|weekend|this (week|month|morning|afternoon|evening|monday|tuesday|wednesday|thursday|friday|saturday|sunday)|next (week|month)|on (monday|tuesday|wednesday|thursday|friday|saturday|sunday)|test|exam|interview|appointment|deadline|trip|flight|holiday|visit\w*|party|wedding|concert|match|lessons?|starts?|starting|due|until|by (monday|tuesday|wednesday|thursday|friday|saturday|sunday))\b/i.test(String(text));
}

export async function settleFact(user, fact, { complete = defaultComplete, now = Date.now(), timeZone } = {}) {
  if (isChatOnly(fact.text)) return 'kept'; // a fact about the chat, not about them
  const until = looksTimeBound(fact.text) ? resolveUntil(fact.until, now, timeZone || config.timezone) : undefined;
  const close = (await searchNotes(user, fact.text, 3)).slice(0, 2);

  for (const neighbour of close) {
    const kind = await relation(neighbour.text, fact.text, complete);
    const note = user.notes.find((n) => n.id === neighbour.id);
    if (!note) continue;
    if (kind === 'SAME') {
      note.at = now;
      await saveUser(user);
      return 'same';
    }
    if (kind === 'REPLACES') {
      if (note.source === 'user') return 'kept';
      await updateNote(user, note.id, fact.text, { system: true });
      if (until) note.expires = until;
      else delete note.expires;
      await saveUser(user);
      return 'updated';
    }
  }
  const { created } = await addNote(user, fact.text, 'auto', { until });
  return created ? 'added' : 'same';
}

export async function extractNotes(session, user, { complete = defaultComplete, now = Date.now(), timeZone } = {}) {
  const done = { added: 0, updated: 0, removed: 0 };
  // how far this run reads, fixed now: messages that arrive while the model is answering are left for the next run
  const upTo = session.messages.length;
  const from = Math.min(session.extractedUpTo, upTo);
  const fresh = session.messages.slice(Math.max(from, upTo - 12), upTo);
  if (!fresh.some((m) => m.role === 'user')) return done;

  const known = recentNotes(user, 10).map((n) => `- ${n.text}`).join('\n');
  const stamp = new Date(now).toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: timeZone || config.timezone });
  const reply = await complete({
    maxTokens: 260,
    temperature: 0.1,
    messages: [
      {
        role: 'system',
        content:
          'You keep notes about a person from their chat with a friend called Rosia. Today is ' + stamp + '. ' +
          'List the facts about THEM worth remembering weeks from now: name, age, where they live, work or study, family, ' +
          'friends, partner, pets, hobbies, tastes, plans, ongoing situations, how they feel about important things. ' +
          'Include anything new OR changed (if they say they moved or changed job, state the new fact), even if it seems to ' +
          'contradict the known notes. Skip small talk, jokes, anything about Rosia, and exact repeats of known notes. ' +
          'Never note what they asked her to do or see in the chat ("asked Rosia for a photo", "wants to see her in a bikini"): ' +
          'a request in this conversation is not a fact about their life, and anything sexual or about her body is never a note. ' +
          'Each fact is one short sentence that never uses he, she, his or her: start with the name or a verb, or use "they" and "their", ' +
          'e.g. "Lives in Leeds." or "Has a dog called Biscuit." Never guess gender from a name. Never add a year, date or detail that was not said.\n' +
          'Reply with ONLY a JSON array, at most 4 items: [{"text": "...", "until": "..."}]. For something that stops mattering ' +
          'after a day (an exam, a trip, a deadline) put the last day it matters in "until": a date like 2026-11-13, a weekday ' +
          'like "friday", "today", "tomorrow" or "this weekend"; otherwise null. Reply [] if there is nothing.'
      },
      { role: 'user', content: `Known notes:\n${known || '(none)'}\n\nWhat they said in the conversation:\n${transcriptThem(fresh)}` }
    ]
  });

  session.extractedUpTo = Math.max(session.extractedUpTo, upTo);
  for (const fact of parseFacts(reply).slice(0, 4)) {
    const result = await settleFact(user, fact, { complete, now, timeZone });
    if (result === 'added') done.added += 1;
    if (result === 'updated') done.updated += 1;
  }
  await saveSession(session);
  return done;
}

/* ---------- 2. keep a short running profile of the person ---------- */

export async function updateProfile(user, { complete = defaultComplete } = {}) {
  const current = activeNotes(user);
  if (current.length < 3) return false;
  const notes = [...current].sort((a, b) => a.at - b.at).slice(-60).map((n) => `- ${n.text}`).join('\n');
  const text = await complete({
    maxTokens: 220,
    temperature: 0.2,
    messages: [
      {
        role: 'system',
        content:
          'Write a compact profile of a person for a friend who is about to chat with them: who they are, ' +
          'what is going on in their life, what they like, anything to be careful about. Plain sentences, ' +
          'at most 90 words, no bullet points. Refer to them by name or as "they"/"their" and never use he, she, him or her: ' +
          'gender is never guessed from a name (for example: "Sam lives in Bristol. They work as a tester and have a sister called Priya."). ' +
          'Use only the notes given; do not invent anything. This is about their life, never about what they asked ' +
          'Rosia for in a chat.'
      },
      { role: 'user', content: notes }
    ]
  });
  if (!text) return false;
  user.profile = text.replace(/\s+/g, ' ').slice(0, 900);
  user.profileCount = user.notes.length;
  user.profileAt = Date.now();
  await saveUser(user);
  return true;
}

/* ---------- 3. fold old turns into a summary so they aren't forgotten ---------- */

export async function summariseOldTurns(session, { complete = defaultComplete } = {}) {
  const upTo = windowStart(session);
  if (upTo <= session.summary.upTo) return false;
  const chunk = session.messages.slice(session.summary.upTo, upTo);
  if (!chunk.length) return false;

  const text = await complete({
    maxTokens: 260,
    temperature: 0.2,
    messages: [
      {
        role: 'system',
        content:
          'You maintain a running summary of a chat between a person and their friend Rosia. ' +
          'Merge the new messages into the existing summary. Keep what matters later: topics, decisions, ' +
          'plans, anything personal they shared, running jokes, how the mood has been. Plain prose, past tense, ' +
          'at most 110 words, no preamble.'
      },
      {
        role: 'user',
        content: `Existing summary:\n${session.summary.text || '(none yet)'}\n\nNew messages:\n${transcript(chunk)}`
      }
    ]
  });
  if (!text) return false;
  session.summary = { text: text.replace(/\s+/g, ' ').slice(0, 900), upTo };
  await saveSession(session);
  return true;
}

/* ---------- 4. a short title for the conversation ---------- */

export function provisionalTitle(session) {
  const first = session.messages.find((m) => m.role === 'user' && m.content)?.content || '';
  const clean = first.replace(/\s+/g, ' ').trim();
  if (!clean) return 'New chat';
  return clean.length > 38 ? `${clean.slice(0, 36).trim()}…` : clean;
}

export async function generateTitle(session, { complete = defaultComplete } = {}) {
  const text = await complete({
    maxTokens: 24,
    temperature: 0.3,
    messages: [
      {
        role: 'system',
        content:
          'Give this chat a title of 2 to 4 words that says what it is about. Reply with the title only: ' +
          'no quotes, no full stop, no emoji.'
      },
      { role: 'user', content: transcript(session.messages.slice(0, 6)) }
    ]
  });
  const title = text.replace(/["'.\n]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 50);
  if (title.length >= 3 && !session.titleByUser) {
    session.title = title;
    await saveSession(session);
  }
}

/* ---------- scheduling: called after every finished reply ---------- */

export function afterReply(session, userId, { timeZone } = {}) {
  const lastReply = [...session.messages].reverse().find((m) => m.role === 'assistant')?.content || '';
  const lastSaid = [...session.messages].reverse().find((m) => m.role === 'user')?.content || '';
  const offeredJoke = takeOffer(userId);
  const occasion = takeOccasion(userId);
  (async () => {
    const user = await getUser(userId);
    // their time zone, for the diary's "end of the day" when they are not here to say it
    if (timeZone && user.tz !== timeZone) {
      user.tz = timeZone;
      await saveUser(user);
    }
    // the running joke she was offered: if she used it, it rests for a while
    if (offeredJoke && (await noteUse(user, offeredJoke, lastReply))) console.log('[jokes] brought one back');
    // the diary key she was told: theirs only once her reply really says it
    if (await settleOffer(userId, lastReply)) console.log('[diary] she gave them the key');
    // a birthday or anniversary she was told about: said once, then not again that day
    await markOccasion(user, occasion, lastReply);
  })().catch((err) => console.warn('[memory] after reply:', err.message));

  // they laughed: something here may be worth keeping as a running joke
  if (LAUGHED.test(lastSaid)) {
    background('jokes', async () => {
      const user = await getUser(userId);
      if ((await findJoke(session, user)) === 'added') console.log('[jokes] a new running joke');
    });
  }

  if (!session.title) {
    session.title = provisionalTitle(session);
    background('title', () => generateTitle(session));
  }

  const userTurnsSince = session.messages.slice(session.extractedUpTo).filter((m) => m.role === 'user').length;
  if (userTurnsSince >= config.extractEveryTurns) {
    background('memory', async () => {
      const user = await getUser(userId);
      const done = await extractNotes(session, user, { timeZone });
      const merged = await mergeDuplicates(user);
      const changes = [done.added && `+${done.added}`, done.updated && `${done.updated} corrected`, done.removed && `-${done.removed}`, merged && `${merged} merged`].filter(Boolean);
      if (changes.length) console.log(`[memory] ${changes.join(', ')} (${activeNotes(user).length} in use)`);
      const changed = done.added + done.updated + done.removed + merged;
      if (changed || (!user.profile && activeNotes(user).length >= 3)) {
        if (activeNotes(user).length - user.profileCount >= 3 || changed || !user.profile) {
          if (await updateProfile(user)) console.log('[memory] profile refreshed');
        }
      }
    });
  }

  if (windowStart(session) > session.summary.upTo) {
    background('summary', () => summariseOldTurns(session));
  }
}

/* ---------- 5. tidying: copies merged, and an older note a newer one replaces put away ---------- */

const pairKey = (a, b) => [a.id, b.id].sort().join(':');

/**
 * One tidy of a person's notes, for a quiet moment: near-copies are merged, then the most alike pairs not looked at
 * before are each asked about once ("lives in Leeds" then "moved to London": the newer replaces the older). The note
 * that is out of date is not deleted: it is put under Past with what replaced it, so the change is never silent. A note
 * the person wrote themselves always wins, and two of theirs are never touched. Returns what it did.
 */
export async function tidyMemory(user, { complete = defaultComplete, now = Date.now(), maxQuestions = 6 } = {}) {
  const done = { merged: await mergeDuplicates(user), retired: 0, asked: 0 };
  const checked = new Set(Array.isArray(user.tidied) ? user.tidied : []);
  const pairs = (await similarPairs(user, { limit: 40 })).filter(({ older, newer }) => !checked.has(pairKey(older, newer)));
  for (const { older, newer } of pairs) {
    if (done.asked >= maxQuestions) break;
    if (older.source === 'user' && newer.source === 'user') {
      checked.add(pairKey(older, newer));
      continue;
    }
    if (isExpired(older, now) || isExpired(newer, now)) continue; // put away earlier in this same pass
    done.asked += 1;
    checked.add(pairKey(older, newer));
    const kind = await relation(older.text, newer.text, complete);
    if (kind !== 'REPLACES' && kind !== 'SAME') continue;
    // the newer fact wins, unless the older one is theirs and the newer one is hers
    const [keep, retire] = older.source === 'user' && newer.source !== 'user' ? [older, newer] : [newer, older];
    retire.expires = now;
    retire.replacedBy = keep.text;
    done.retired += 1;
  }
  user.tidied = [...checked].slice(-2000);
  user.tidiedAt = now;
  await saveUser(user);
  return done;
}

let tidyTimer = null;
/** Every half hour, once nobody has written for ten minutes, each person's notes are tidied (at most once a day each). */
export function startTidying({ listUsers }) {
  if (tidyTimer) return;
  tidyTimer = setInterval(async () => {
    if (msSinceActivity() < 10 * 60_000) return;
    for (const id of await listUsers().catch(() => [])) {
      const user = await getUser(id);
      if (activeNotes(user).length < 2 || Date.now() - (user.tidiedAt || 0) < 86_400_000) continue;
      background('tidy', async () => {
        const done = await tidyMemory(user);
        if (done.merged || done.retired) {
          console.log(`[memory] tidied: ${done.merged} merged, ${done.retired} out of date`);
          await updateProfile(user).catch(() => false);
        }
      });
    }
  }, 30 * 60_000);
  tidyTimer.unref();
}

/** Rebuilds the profile soon after the person edits or removes notes. */
export function profileStale(userId) {
  background('profile', async () => {
    const user = await getUser(userId);
    if (activeNotes(user).length >= 3) await updateProfile(user);
    else {
      user.profile = '';
      user.profileCount = user.notes.length;
      await saveUser(user);
    }
  });
}

/** Notes worth putting in front of the model for this message. */
export async function relevantNotes(user, text) {
  const hits = await searchNotes(user, text, config.recallTopK);
  return hits.map((h) => h.text);
}
