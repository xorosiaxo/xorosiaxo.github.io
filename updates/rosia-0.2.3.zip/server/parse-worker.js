import { parentPort } from 'node:worker_threads';
import { parseHtml } from './htmlparse.js';

parentPort.on('message', ({ id, html, base }) => {
  try {
    parentPort.postMessage({ id, result: parseHtml(html, base) });
  } catch (err) {
    parentPort.postMessage({ id, error: err?.message || 'parse failed' });
  }
});
