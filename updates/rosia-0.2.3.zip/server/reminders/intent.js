import { parseWhen } from './when.js';

/*
 * "remind me at 5 to call mum", "set a timer for 10 minutes", "cancel the reminder about mum": requests that leave no
 * doubt. A small model left to choose will sometimes just say "sure, i'll remind you" and save nothing, so for these the
 * tool is run for her first (see preflight.js) and she only has to say it in her own voice. The time is worked out here
 * from the person's own words, never by the model.
 *
 * Deliberately narrow: a time has to be there ("remind me to call mum" with no time is left to her, to ask when), and
 * talk about reminding ("why didn't you remind me", "remind me what your name is") is not a request.
 */

const ASK = /\b(?:remind me|(?:set|make|add|create)\s+(?:me\s+)?(?:up\s+)?(?:a|an|another)?\s*(?:reminder|alarm|timer)(?:\s+for me)?|(?:give|send) me a reminder|don'?t let me forget|make sure i (?:don'?t forget|remember)|wake me(?: up)?)\b/i;
const TIMER = /\b(?:reminder|alarm|timer)\b/i;
// "don't remind me", "did you remind me?", "why didn't you remind me", "stop reminding me", "you reminded me"
const NOT_ASKING = /\b(?:don'?t|do not|didn'?t|did not|never|stop|quit|no need to|needn'?t|did you|why|forgot to|supposed to)\b[^.?!]{0,25}\bremind|\breminded\b|\breminding\b/i;
// "remind me what we said", "remind me who that is": they want telling now, not later
const TELL_ME = /^(?:again\s+)?(?:what|who|whom|why|how|where|which|whether|if|of)\b/i;
const CANCEL = /\b(?:cancel|delete|remove|clear|scrap|drop|forget|get rid of|turn off|stop)\b[^.?!]{0,30}\b(?:reminders?|alarms?|timers?)\b/i;

/** What a reminder is for, from the words left once the time is taken out: "to call mum please" gives "call mum". */
export function aboutText(rest) {
  let t = String(rest || '').replace(/\s+/g, ' ').trim();
  t = t.replace(/^[\s,:;.\-–—]+/, '');
  t = t.replace(/^(?:please\s+|pls\s+)?(?:(?:to|about|that|for|of)\s+)?/i, '');
  t = t.replace(/^(?:i|we)(?:\s+(?:really|still|also))?\s+(?:need|have|should|must|want|ought|got|gotta|'?ve got)\s+(?:to\s+)?/i, '');
  t = t.replace(/^(?:to|about)\s+/i, '');
  // what is left hanging once the time has gone: "call mum at", "the dentist on"
  for (let i = 0; i < 3; i += 1) {
    t = t.replace(/[\s,.!?;:]+$/, '').replace(/\s+(?:please|pls|thanks|thank you|ok|okay|babe|baby|rosia)$/i, '').replace(/\s+(?:at|on|by|for|in|around|about|to|and|then)$/i, '');
  }
  return t.slice(0, 160);
}

/**
 * A request for a reminder in someone's own words, as { about, at, repeat }, or null. `about` is '' when they named a
 * time and nothing to be reminded of ("remind me in 10 minutes").
 */
export function reminderRequest(text, now = Date.now(), timeZone = 'UTC') {
  const t = String(text || '').trim();
  if (!t || t.split(/\s+/).length > 45) return null;
  const m = ASK.exec(t);
  if (!m || (/\bremind\b/i.test(m[0]) && NOT_ASKING.test(t))) return null;
  const before = t.slice(0, m.index);
  const after = t.slice(m.index + m[0].length);
  const loose = TIMER.test(m[0]);
  // the time usually follows ("remind me at 5 to..."); sometimes it comes first ("at 5 remind me to...")
  // ("wake me at 7" is seven in the morning, whatever the time is now)
  const waking = /\bwake me\b/i.test(m[0]);
  const tail = parseWhen(waking ? `${after} in the morning` : after, now, timeZone, { loose });
  const when = tail || parseWhen(before, now, timeZone);
  if (!when) return null;
  let about = aboutText(tail ? tail.rest : after);
  if (TELL_ME.test(about)) return null;
  if (!about && /\bwake me\b/i.test(m[0])) about = 'wake up';
  if (!about && /\btimer\b/i.test(m[0])) about = 'your timer is up';
  return { about, at: when.at, repeat: when.repeat };
}

/** Which reminder tool a message plainly calls for, as { name, args }, or null. Pure: easy to test. */
export function reminderIntent(text, { now = Date.now(), timeZone = 'UTC' } = {}) {
  const t = String(text || '').trim();
  if (!t) return null;
  if (CANCEL.test(t) && t.split(/\s+/).length <= 16 && !/\b(?:don'?t|do not|never)\b/i.test(t)) {
    const which = t
      .replace(/\b(?:can you|could you|please|pls|cancel|delete|remove|clear|scrap|drop|forget|get rid of|turn off|stop|reminders?|alarms?|timers?|the one|about|for|to)\b/gi, ' ')
      .replace(/[^\w' ]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    return { name: 'cancel_reminder', args: { which: /\b(?:reminders|alarms|timers)\b/i.test(t) && !which ? 'all' : which } };
  }
  const asked = reminderRequest(t, now, timeZone);
  if (!asked || !asked.about) return null; // no time, or nothing to be reminded of: she asks
  // (the tool reads the time from their message again, so only what it is about is passed on)
  return { name: 'set_reminder', args: { about: asked.about, when: '' } };
}
