import crypto from 'node:crypto';
import { saveUser } from '../users.js';
import { nextTime, sayWhen } from './when.js';

/*
 * The reminders a person has asked for: "remind me at 5 to call mum". They are kept with everything else she knows about
 * that person (user.reminders, in their own file), so each person has their own and a restart loses nothing.
 *
 * A reminder: { id, text, at, repeat ('' | 'daily' | 'weekly'), tz, by ('chat' | 'hand'), createdAt } plus, as it goes:
 *   snoozedTo  "in 10 minutes": the moment it is due instead of `at` (a repeating one keeps its own time for next time)
 *   toldAt     when she said it in the chat, so she says it once
 *   doneAt     when they marked it done; kept for a while under "Earlier"
 *
 * When one is due the page shows it and asks her to say it (see index.js, kind 'remind'). Nothing here needs the chat
 * model: a reminder is shown on time whether or not she can talk.
 */

const MAX_WAITING = 60;
const MAX_DONE = 20;
const REPEATS = new Set(['', 'daily', 'weekly']);
const telling = new Set(); // "user:id" while she is in the middle of saying one, so two windows do not both ask her

const clean = (raw) => String(raw ?? '').replace(/\s+/g, ' ').trim().slice(0, 160);
const list = (user) => (Array.isArray(user.reminders) ? user.reminders : (user.reminders = []));

/** The moment a reminder is due. */
export const dueAt = (r) => r.snoozedTo || r.at;
export const isDue = (r, now = Date.now()) => !r.doneAt && dueAt(r) <= now;

/** Adds one. Throws, in words that can be shown, when it cannot be kept. Asking twice for the same thing gives the one already there. */
export async function addReminder(user, { text, at, repeat = '', tz = 'UTC', by = 'chat' }, now = Date.now()) {
  const what = clean(text);
  const when = Math.round(Number(at));
  if (what.length < 2) throw new Error('Say what the reminder is for.');
  if (!Number.isFinite(when) || when <= now) throw new Error('That time has already gone.');
  if (when - now > 2 * 366 * 86_400_000) throw new Error('That is too far away.');
  const all = list(user);
  const same = all.find((r) => !r.doneAt && r.text.toLowerCase() === what.toLowerCase() && Math.abs(dueAt(r) - when) < 60_000);
  if (same) return same;
  if (all.filter((r) => !r.doneAt).length >= MAX_WAITING) throw new Error('There are too many reminders waiting. Remove some first.');
  const reminder = { id: crypto.randomBytes(6).toString('hex'), text: what, at: when, repeat: REPEATS.has(repeat) ? repeat : '', tz, by: by === 'hand' ? 'hand' : 'chat', createdAt: now };
  all.push(reminder);
  await saveUser(user);
  return reminder;
}

const find = (user, id) => list(user).find((r) => r.id === String(id || '')) || null;

/** Changes what one says, when it is due, or how often. Returns it, or null when there is no such reminder. */
export async function editReminder(user, id, { text, at, repeat } = {}, now = Date.now()) {
  const r = find(user, id);
  if (!r) return null;
  if (text !== undefined) {
    const what = clean(text);
    if (what.length < 2) throw new Error('Say what the reminder is for.');
    r.text = what;
  }
  if (at !== undefined) {
    const when = Math.round(Number(at));
    if (!Number.isFinite(when) || when <= now) throw new Error('That time has already gone.');
    Object.assign(r, { at: when, snoozedTo: 0, toldAt: 0, doneAt: 0 }); // a new time: it is waiting again
  }
  if (repeat !== undefined && REPEATS.has(repeat)) r.repeat = repeat;
  await saveUser(user);
  return r;
}

export async function removeReminder(user, id) {
  const before = list(user).length;
  user.reminders = list(user).filter((r) => r.id !== String(id || ''));
  if (user.reminders.length === before) return false;
  await saveUser(user);
  return true;
}

/** "Done": a one-off is finished; one that repeats waits for its next time. */
export async function finishReminder(user, id, now = Date.now()) {
  const r = find(user, id);
  if (!r) return null;
  if (r.repeat) Object.assign(r, { at: nextTime(r.at, r.repeat, now, r.tz), snoozedTo: 0, toldAt: 0 });
  else r.doneAt = now;
  // the finished ones are kept for a while, newest first, so "Earlier" never grows without end
  const done = list(user).filter((x) => x.doneAt).sort((a, b) => b.doneAt - a.doneAt);
  const drop = new Set(done.slice(MAX_DONE).map((x) => x.id));
  if (drop.size) user.reminders = list(user).filter((x) => !drop.has(x.id));
  await saveUser(user);
  return r;
}

/** "In 10 minutes": it comes up again then, and she says it again. */
export async function snoozeReminder(user, id, minutes = 10, now = Date.now()) {
  const r = find(user, id);
  if (!r || r.doneAt) return null;
  const mins = Math.min(24 * 60, Math.max(1, Math.round(Number(minutes) || 10)));
  Object.assign(r, { snoozedTo: now + mins * 60_000, toldAt: 0 });
  await saveUser(user);
  return r;
}

/** What the page is given: soonest first, the finished ones after them (newest first). */
export function publicReminders(user, now = Date.now()) {
  const shape = (r) => ({ id: r.id, text: r.text, at: dueAt(r), repeat: r.repeat || '', by: r.by, due: isDue(r, now), told: Boolean(r.toldAt), done: Boolean(r.doneAt) });
  const all = list(user);
  return [
    ...all.filter((r) => !r.doneAt).sort((a, b) => dueAt(a) - dueAt(b)).map(shape),
    ...all.filter((r) => r.doneAt).sort((a, b) => b.doneAt - a.doneAt).map(shape)
  ];
}

/**
 * She is about to say a reminder: the reminder, or null when it is not due, was already said, or is being said for
 * another of this person's windows right now. Whoever gets it must call `told` when finished.
 */
export function startTelling(user, id, now = Date.now()) {
  const r = find(user, id);
  const key = `${user.id}:${id}`;
  if (!r || !isDue(r, now) || r.toldAt || telling.has(key)) return null;
  telling.add(key);
  return r;
}

/** She has finished (said = true) or it did not work out: either way the reminder is free again. */
export function told(user, id, said, now = Date.now()) {
  telling.delete(`${user.id}:${id}`);
  const r = find(user, id);
  if (r && said) r.toldAt = now; // (the caller saves the person straight afterwards)
}

const STOP = new Set(['the', 'a', 'an', 'my', 'me', 'that', 'this', 'one', 'about', 'for', 'to', 'reminder', 'reminders', 'alarm', 'alarms', 'timer', 'timers', 'please', 'it', 'of', 'at', 'on', 'i', 'set', 'you']);
const words = (s) => (String(s || '').toLowerCase().match(/[a-z0-9']+/g) || []).filter((w) => !STOP.has(w));

/**
 * Which waiting reminders some words point at: "the one about mum", "all of them", "" (the only one, when there is one).
 * Returns { hits, all } where `all` says the whole lot was asked for.
 */
export function matchReminders(user, which) {
  const waiting = list(user).filter((r) => !r.doneAt).sort((a, b) => dueAt(a) - dueAt(b));
  const said = String(which || '').toLowerCase();
  if (/\b(?:all|every|everything|each)\b/.test(said)) return { hits: waiting, all: true };
  const wanted = words(said);
  if (!wanted.length) return { hits: waiting.length === 1 ? waiting : [], all: false };
  const scored = waiting
    .map((r) => ({ r, score: wanted.filter((w) => words(r.text).some((x) => x === w || (w.length > 3 && (x.startsWith(w) || w.startsWith(x))))).length }))
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score);
  // the best match only, unless several fit equally well
  return { hits: scored.filter((s) => s.score === scored[0].score).map((s) => s.r), all: false };
}

/**
 * What she is told about a person's reminders with every message, so "what have i got coming up?" is answered from what
 * is really there. '' when they have none (unless they are asking about reminders: then she is told there are none).
 */
export function reminderLine(user, timeZone = 'UTC', theirText = '', now = Date.now()) {
  const waiting = list(user).filter((r) => !r.doneAt).sort((a, b) => dueAt(a) - dueAt(b));
  if (!waiting.length) {
    return /\b(?:reminders?|alarms?|remind)\b/i.test(String(theirText || '')) ? 'They have no reminders set with you right now.' : '';
  }
  const shown = waiting.slice(0, 4).map((r) => `"${r.text}" ${sayWhen(dueAt(r), now, timeZone)}${r.repeat ? ` (every ${r.repeat === 'daily' ? 'day' : 'week'})` : ''}`);
  const more = waiting.length > shown.length ? ` and ${waiting.length - shown.length} more` : '';
  return `Reminders you are keeping for them: ${shown.join('; ')}${more}. You tell them when each is due; do not bring them up before then unless they ask.`;
}
