/*
 * Turns the way a person says when ("in 10 minutes", "at 5pm", "tomorrow morning", "on friday at 3", "every day at 8")
 * into a moment. Done here, in code, because a small language model gets dates and times wrong: she passes on the words,
 * and this works out the clock time in the person's own time zone.
 *
 * parseWhen gives { at, repeat, rest }: the moment, 'daily' | 'weekly' | '' for one that comes round again, and what is
 * left of the text once the words about time are taken out (which is what the reminder is about). null when the text
 * names no time, or one that has already gone.
 */

const MIN = 60_000;
const HOUR = 60 * MIN;
const DAY = 24 * HOUR;

const DAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
const MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
const MONTH_RE = MONTHS.map((m) => `${m}|${m.slice(0, 3)}`).join('|');
const WORDS = {
  a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12,
  fifteen: 15, twenty: 20, thirty: 30, forty: 40, 'forty five': 45, 'forty-five': 45, fifty: 50, sixty: 60, ninety: 90,
  'half a': 0.5, 'half an': 0.5, 'a couple of': 2, 'a couple': 2, 'a few': 3
};
// longest first, so "a couple of" is not read as "a"
const NUM = `\\d+(?:\\.\\d+)?|${Object.keys(WORDS).sort((x, y) => y.length - x.length).join('|')}`;
const UNIT = 'seconds?|secs?|minutes?|mins?|hours?|hrs?|days?|weeks?|[smhd](?![a-z])';
const UNIT_MS = { s: 1000, m: MIN, h: HOUR, d: DAY, w: 7 * DAY };
// the hour each part of the day stands for when no clock time is said
const PART_HOUR = { morning: 9, lunch: 13, lunchtime: 13, afternoon: 15, evening: 19, night: 21, tonight: 21 };

const number = (s) => (/^\d/.test(s) ? Number(s) : WORDS[String(s).toLowerCase().replace(/\s+/g, ' ')] ?? NaN);
const unitMs = (u) => UNIT_MS[String(u).toLowerCase()[0]];

const formats = new Map();
function format(timeZone) {
  if (!formats.has(timeZone)) {
    formats.set(timeZone, new Intl.DateTimeFormat('en-GB', { timeZone, year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', weekday: 'long', hourCycle: 'h23' }));
  }
  return formats.get(timeZone);
}

/** What the clock and calendar say at `ms` in a time zone: { y, m (0-11), d, h, min, weekday (0 = Sunday) }. */
export function wall(ms, timeZone = 'UTC') {
  const parts = format(timeZone).formatToParts(new Date(ms));
  const get = (type) => parts.find((p) => p.type === type)?.value;
  return {
    y: Number(get('year')),
    m: Number(get('month')) - 1,
    d: Number(get('day')),
    h: Number(get('hour')) % 24,
    min: Number(get('minute')),
    weekday: DAYS.indexOf(String(get('weekday')).toLowerCase())
  };
}

/** The moment the clock in a time zone shows this date and time (days and months may overflow: the 32nd is the 1st of the next). */
export function moment(y, m, d, h, min, timeZone = 'UTC') {
  const want = Date.UTC(y, m, d, h, min);
  let t = want;
  // the zone's distance from UTC depends on the moment itself (summer time), so it is homed in on
  for (let i = 0; i < 3; i += 1) {
    const w = wall(t, timeZone);
    t = want - (Date.UTC(w.y, w.m, w.d, w.h, w.min) - t);
  }
  return t;
}

/**
 * @param input     the words: "at 5pm", "remind me tomorrow morning to call mum", "2026-11-20 14:00"
 * @param loose     also take "for 10 minutes" as "in 10 minutes" (a timer: "set a timer for 10 minutes")
 */
export function parseWhen(input, now = Date.now(), timeZone = 'UTC', { loose = false } = {}) {
  // (a "T" between an ISO date and its time is a space here)
  let text = ` ${String(input ?? '').replace(/(\d{4}-\d{2}-\d{2})T(\d{1,2}:\d{2})/i, '$1 $2').slice(0, 400)} `;
  /** Finds the first match and takes it out of the text, so the same words are never read twice. */
  const take = (re) => {
    const m = re.exec(text);
    if (m) text = `${text.slice(0, m.index)} ${text.slice(m.index + m[0].length)}`;
    return m;
  };
  const today = wall(now, timeZone);

  let repeat = '';
  let part = ''; // morning, evening...
  let dayOff = null; // days from today
  let date = null; // { y, m, d, yearSaid }
  let weekdaySaid = false;
  let todaySaid = false;

  // ---- coming round again: "every day", "daily", "every monday", "every morning"
  const every = take(new RegExp(`\\b(?:every|each)\\s+(day|morning|afternoon|evening|night|week|${DAYS.join('|')})\\b|\\b(daily|weekly)\\b`, 'i'));
  if (every) {
    const word = (every[1] || every[2]).toLowerCase();
    if (DAYS.includes(word)) {
      repeat = 'weekly';
      dayOff = (DAYS.indexOf(word) - today.weekday + 7) % 7;
      weekdaySaid = true;
    } else if (word === 'week' || word === 'weekly') repeat = 'weekly';
    else {
      repeat = 'daily';
      if (PART_HOUR[word]) part = word;
    }
  }

  // ---- "in 10 minutes", "in an hour and a half", "in 2 hours and 15 minutes", "20 minutes from now"
  const lead = loose ? '(?:in|after|for)' : '(?:in|after)';
  const rel =
    take(new RegExp(`\\b${lead}\\s+(?:about\\s+|around\\s+|like\\s+)?(${NUM})\\s*(${UNIT})(?:\\s+and\\s+(?:(a half)|(${NUM})\\s*(${UNIT})))?(?:\\s+(?:from now|time))?(?![a-z])`, 'i')) ||
    take(new RegExp(`(?<![a-z])(${NUM})\\s*(${UNIT})\\s+from now\\b`, 'i'));
  if (rel) {
    let ms = number(rel[1]) * unitMs(rel[2]);
    if (rel[3]) ms += 0.5 * unitMs(rel[2]);
    if (rel[4] && rel[5]) ms += number(rel[4]) * unitMs(rel[5]);
    if (!Number.isFinite(ms) || ms < 1000 || ms > 2 * 366 * DAY) return null;
    return { at: now + Math.round(ms), repeat, rest: tidy(text) };
  }

  // ---- the day
  const iso = take(/\b(?:on\s+)?(\d{4})-(\d{1,2})-(\d{1,2})\b/);
  if (iso) date = { y: Number(iso[1]), m: Number(iso[2]) - 1, d: Number(iso[3]), yearSaid: true };
  if (!date) {
    const dm = take(new RegExp(`\\b(?:on\\s+)?(?:the\\s+)?(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?(${MONTH_RE})\\b(?:\\s+(\\d{4}))?`, 'i')) ;
    const md = dm ? null : take(new RegExp(`\\b(?:on\\s+)?(${MONTH_RE})\\s+(?:the\\s+)?(\\d{1,2})(?:st|nd|rd|th)?\\b(?:,?\\s+(\\d{4}))?`, 'i'));
    const found = dm ? { d: dm[1], month: dm[2], y: dm[3] } : md ? { d: md[2], month: md[1], y: md[3] } : null;
    if (found) {
      const m = MONTHS.findIndex((name) => name.startsWith(found.month.toLowerCase().slice(0, 3)));
      date = { y: found.y ? Number(found.y) : today.y, m, d: Number(found.d), yearSaid: Boolean(found.y) };
    }
  }
  if (!date && dayOff === null) {
    if (take(/\b(?:the\s+)?day after (?:tomorrow|tmrw|tmr)\b/i)) dayOff = 2;
    else if (take(/\b(?:tomorrow|tmrw|tmr|2moro|tomoz)\b/i)) dayOff = 1;
    else if (take(/\b(?:later\s+)?today\b/i)) {
      dayOff = 0;
      todaySaid = true;
    } else {
      const wd = take(new RegExp(`\\b(?:on\\s+)?(?:(next|this|coming)\\s+)?(${DAYS.join('|')})\\b`, 'i'));
      if (wd) {
        dayOff = (DAYS.indexOf(wd[2].toLowerCase()) - today.weekday + 7) % 7; // today counts when it is that day
        if (String(wd[1]).toLowerCase() === 'next') dayOff += 7;
        weekdaySaid = true;
      } else if (take(/\bnext week\b/i)) dayOff = 7;
    }
  }

  // ---- the part of the day: "tonight", "this evening", "in the morning", "tomorrow night"
  // (a bare "morning" only counts next to a day, "tomorrow morning": "my morning pills" is not a time)
  const partWord =
    take(/\b(?:(?:in|during)\s+the\s+|this\s+|at\s+)(morning|afternoon|evening|night|lunch ?time|lunch)\b|\b(tonight)\b/i) ||
    (dayOff !== null || date ? take(/\b(morning|afternoon|evening|night|lunch ?time)\b/i) : null);
  if (partWord && !partWord[1]) partWord[1] = partWord[2];
  if (partWord) part = partWord[1].toLowerCase().replace(/\s+/g, '');

  // ---- the clock time
  let hours = null; // the hour, or the two it could be ("at 5" is 5 in the morning or 5 in the evening)
  let minute = 0;
  const pre = '(?:at|by|around|about|for|@)?\\s*';
  const half = (ap) => (/^p/i.test(ap || '') ? 'pm' : /^a/i.test(ap || '') ? 'am' : '');
  /** One hour as said, to what it means on a 24-hour clock: the one reading, or both when nothing says which. */
  const reading = (h, ap) => {
    if (!Number.isInteger(h) || h < 0 || h > 23) return null;
    if (ap === 'pm') return h > 12 ? null : [h % 12 + 12];
    if (ap === 'am') return h > 12 ? null : [h % 12];
    if (h > 12 || h === 0) return [h];
    if (part === 'morning') return [h % 12];
    if (part && part !== 'lunch' && part !== 'lunchtime') return [h % 12 + 12];
    return h === 12 ? [12, 0] : [h, h + 12];
  };

  if (take(/\b(?:at\s+)?(?:noon|midday)\b/i)) hours = [12];
  else if (take(/\b(?:at\s+)?midnight\b/i)) {
    hours = [0];
    if (dayOff === 0 || (dayOff === null && !date)) dayOff = 1; // tonight's midnight is the start of tomorrow
  } else {
    const past = take(new RegExp(`\\b${pre}(half|quarter)\\s+(past|to)\\s+(\\d{1,2}|${Object.keys(WORDS).filter((w) => WORDS[w] >= 1 && WORDS[w] <= 12 && /^[a-z]+$/.test(w) && w.length > 2).join('|')})(?:\\s*([ap])\\.?m\\.?)?(?![a-z0-9])`, 'i'));
    const colon = past ? null : take(new RegExp(`(?<![\\d:.])${pre}(\\d{1,2}):(\\d{2})\\s*(?:([ap])\\.?m\\.?)?(?![\\d:a-z])`, 'i'));
    const ampm = past || colon ? null : take(new RegExp(`(?<![\\d:.])${pre}(\\d{1,2})(?:\\.(\\d{2}))?\\s*([ap])\\.?m\\.?(?![a-z0-9])`, 'i'));
    const oclock = past || colon || ampm ? null : take(/\b(?:at\s+|by\s+|around\s+)?(\d{1,2})\s*o'? ?clock\b/i);
    const bare = past || colon || ampm || oclock ? null : take(/\b(?:at|@)\s*(\d{1,2})(?:\.(\d{2}))?(?![\d:%a-z]|\s*(?:percent|minutes?|mins?|hours?|days?|weeks?|times|people|pm|am)\b)/i);
    if (past) {
      let h = number(past[3]);
      const amount = past[1].toLowerCase() === 'half' ? 30 : 15;
      if (past[2].toLowerCase() === 'to') {
        h = h - 1 < 1 ? 12 : h - 1; // "quarter to 1" is 12:45
        minute = 60 - amount;
      } else minute = amount;
      hours = reading(h, half(past[4]));
    } else if (colon) {
      minute = Number(colon[2]);
      hours = reading(Number(colon[1]), half(colon[3]));
    } else if (ampm) {
      minute = Number(ampm[2] || 0);
      hours = reading(Number(ampm[1]), half(ampm[3]));
    } else if (oclock) hours = reading(Number(oclock[1]), '');
    else if (bare) {
      minute = Number(bare[2] || 0);
      hours = reading(Number(bare[1]), '');
    }
    if ((past || colon || ampm || oclock || bare) && (!hours || minute > 59)) return null; // "at 25", "9:75"
  }

  if (!hours && part) hours = [PART_HOUR[part]];
  const rest = tidy(text);
  const on = (off, h) => moment(today.y, today.m, today.d + off, h, minute, timeZone);
  const good = (at) => (at > now + 5000 && at - now < 2 * 366 * DAY ? { at, repeat, rest } : null);

  // ---- a calendar date
  if (date) {
    if (date.m < 0 || date.d < 1 || date.d > 31) return null;
    const h = hours ? sensible(hours) : 9;
    let at = moment(date.y, date.m, date.d, h, minute, timeZone);
    if (wall(at, timeZone).d !== date.d) return null; // the 31st of a month that has 30
    if (at <= now && !date.yearSaid) at = moment(date.y + 1, date.m, date.d, h, minute, timeZone); // "20 march", said in april
    return good(at);
  }

  // ---- a day ("tomorrow", "friday", "today")
  if (dayOff !== null) {
    if (!hours) {
      if (dayOff === 0 && todaySaid) return null; // "today" alone says no time
      hours = [9];
    }
    if (dayOff === 0 && weekdaySaid) {
      // "monday at 9", said on a Monday: this morning if that is still to come, otherwise next Monday's
      const at = on(0, sensible(hours));
      return good(at > now + 5000 ? at : on(7, sensible(hours)));
    }
    if (dayOff === 0) {
      // today: whichever reading is still to come
      return good(hours.map((h) => on(0, h)).sort((a, b) => a - b).find((at) => at > now + 5000));
    }
    return good(on(dayOff, sensible(hours)));
  }

  // ---- only a time: the next time the clock shows it
  if (hours) {
    if (hours.length === 1) {
      const at = on(0, hours[0]);
      if (at > now + 5000) return good(at);
      // "tonight" or "this evening" said when that hour has already gone: in an hour, not tomorrow night
      if (partWord && !every && /night|evening|afternoon/.test(part) && today.h >= PART_HOUR[part]) return good(now + HOUR);
      return good(on(1, hours[0]));
    }
    // "at 5": the next 5 o'clock that falls in waking hours (never 5 in the morning when it is the evening that is meant)
    const options = [0, 1].flatMap((off) => hours.map((h) => ({ at: on(off, h), h }))).sort((a, b) => a.at - b.at).filter((o) => o.at > now + 5000);
    return good((options.find((o) => o.h >= 6) || options[0])?.at);
  }

  // ---- "every day" with no time said: in the morning
  if (repeat) {
    const at = on(0, 9);
    return good(at > now + 5000 ? at : on(repeat === 'weekly' ? 7 : 1, 9));
  }
  return null;
}

/** On a day that is not today, "at 3" is the afternoon and "at 8" the morning: the reading inside ordinary waking hours. */
function sensible(hours) {
  if (hours.length === 1) return hours[0];
  const h = Math.min(...hours) % 12;
  return h < 7 ? h + 12 : h;
}

function tidy(text) {
  return String(text).replace(/\s+/g, ' ').trim();
}

/** The same moment a day or a week on, by the clock in their time zone (so it stays at 8 o'clock when the clocks change). */
export function nextTime(at, repeat, now = Date.now(), timeZone = 'UTC') {
  const step = repeat === 'weekly' ? 7 : repeat === 'daily' ? 1 : 0;
  if (!step) return at;
  const w = wall(at, timeZone);
  let next = at;
  for (let n = 1; next <= now && n < 4000; n += 1) next = moment(w.y, w.m, w.d + n * step, w.h, w.min, timeZone);
  return next;
}

/** "in 10 minutes", "in about 3 hours", "in 2 days": how far off a moment is, for her to say. */
export function howLong(ms) {
  const min = Math.round(ms / MIN);
  if (min < 1) return 'less than a minute';
  if (min < 60) return min === 1 ? '1 minute' : `${min} minutes`;
  const hours = Math.round(min / 60);
  if (min < 90) return 'about an hour';
  if (hours < 24) return `about ${hours} hours`;
  const days = Math.round(hours / 24);
  return days === 1 ? 'about a day' : `${days} days`;
}

/** A moment in plain words, in their time zone: "today at 5:00 pm", "tomorrow at 9:00 am", "on Friday 20 November at 3:00 pm". */
export function sayWhen(at, now = Date.now(), timeZone = 'UTC') {
  const time = new Intl.DateTimeFormat('en-GB', { timeZone, hour: 'numeric', minute: '2-digit', hour12: true }).format(new Date(at)).replace(/\s+/g, ' ');
  const a = wall(at, timeZone);
  const n = wall(now, timeZone);
  const days = Math.round((Date.UTC(a.y, a.m, a.d) - Date.UTC(n.y, n.m, n.d)) / DAY);
  if (days === 0) return `today at ${time}`;
  if (days === 1) return `tomorrow at ${time}`;
  if (days === -1) return `yesterday at ${time}`;
  const day = new Intl.DateTimeFormat('en-GB', { timeZone, weekday: 'long', day: 'numeric', month: 'long', ...(a.y !== n.y ? { year: 'numeric' } : {}) }).format(new Date(at)).replace(/,/g, '');
  return `on ${day} at ${time}`;
}
