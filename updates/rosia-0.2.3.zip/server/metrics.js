import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';

/*
 * What the server has been doing, so "it feels slow" or "search is broken" can be answered with numbers.
 *
 * Only operational facts are recorded (timings, token counts, which tool or job ran, whether it
 * failed and why in a few words). Never message text, names, addresses or anything about a person.
 * Events live in memory (the last few thousand) and in data/logs/metrics.jsonl, which is trimmed by size.
 */

const MAX_IN_MEMORY = 6000;
const MAX_FILE_BYTES = 4 * 1024 * 1024;
const KEEP_MS = 7 * 24 * 3600 * 1000;

const events = [];
const startedAt = Date.now();
let pending = [];
let flushTimer = 0;

const file = () => path.join(config.dataDir, 'logs', 'metrics.jsonl');

function flush() {
  flushTimer = 0;
  if (!pending.length) return;
  const chunk = pending.map((e) => JSON.stringify(e)).join('\n') + '\n';
  pending = [];
  try {
    fs.mkdirSync(path.dirname(file()), { recursive: true });
    if (fs.existsSync(file()) && fs.statSync(file()).size > MAX_FILE_BYTES) fs.renameSync(file(), `${file()}.old`);
    fs.appendFileSync(file(), chunk);
  } catch {
    /* metrics must never take the app down */
  }
}

export function record(type, fields = {}) {
  const e = { t: Date.now(), type, ...fields };
  for (const [k, v] of Object.entries(e)) if (typeof v === 'string' && v.length > 200) e[k] = `${v.slice(0, 200)}…`;
  events.push(e);
  if (events.length > MAX_IN_MEMORY) events.splice(0, events.length - MAX_IN_MEMORY);
  pending.push(e);
  if (!flushTimer) {
    flushTimer = setTimeout(flush, 2000);
    flushTimer.unref?.();
  }
  return e;
}

/** Reads back the last week from disk after a restart. */
export function loadHistory() {
  const cutoff = Date.now() - KEEP_MS;
  const loaded = [];
  for (const f of [`${file()}.old`, file()]) {
    try {
      for (const line of fs.readFileSync(f, 'utf8').split('\n')) {
        if (!line) continue;
        try {
          const e = JSON.parse(line);
          if (e.t >= cutoff) loaded.push(e);
        } catch {
          /* a half-written last line */
        }
      }
    } catch {
      /* no file yet */
    }
  }
  loaded.sort((a, b) => a.t - b.t);
  events.splice(0, events.length, ...loaded.slice(-MAX_IN_MEMORY));
  return events.length;
}

export function flushNow() {
  clearTimeout(flushTimer);
  flush();
}

/** For tests. */
export function reset() {
  events.length = 0;
  pending = [];
}

/* ---------- reading ---------- */

export function percentile(values, p) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const i = Math.min(sorted.length - 1, Math.max(0, Math.ceil((p / 100) * sorted.length) - 1));
  return sorted[i];
}

const mean = (values) => (values.length ? values.reduce((a, b) => a + b, 0) / values.length : null);
const round = (n, d = 0) => (n === null || n === undefined ? null : Math.round(n * 10 ** d) / 10 ** d);

function groupBy(list, key) {
  const out = new Map();
  for (const item of list) {
    const k = item[key];
    if (!out.has(k)) out.set(k, []);
    out.get(k).push(item);
  }
  return out;
}

export function summarise({ hours = 24, now = Date.now() } = {}) {
  const since = now - hours * 3600 * 1000;
  const inWindow = events.filter((e) => e.t >= since);
  const replies = inWindow.filter((e) => e.type === 'reply');
  const errors = inWindow.filter((e) => e.type === 'error');

  const ttft = replies.map((r) => r.ttftMs).filter(Number.isFinite);
  const total = replies.map((r) => r.totalMs).filter(Number.isFinite);
  const tps = replies.map((r) => r.tps).filter((n) => n > 0);
  const prompt = replies.reduce((a, r) => a + (r.promptTokens || 0), 0);
  const cached = replies.reduce((a, r) => a + (r.cachedTokens || 0), 0);

  const stat = (list) => ({
    calls: list.length,
    failures: list.filter((e) => !e.ok).length,
    meanMs: round(mean(list.map((e) => e.ms).filter(Number.isFinite)))
  });

  // hourly buckets, oldest first, so the page can draw a timeline
  const bucketMs = hours <= 48 ? 3600 * 1000 : 6 * 3600 * 1000;
  const first = Math.floor(since / bucketMs) * bucketMs;
  const timeline = [];
  for (let t = first; t <= now; t += bucketMs) {
    const here = (list) => list.filter((e) => e.t >= t && e.t < t + bucketMs);
    const r = here(replies);
    timeline.push({
      t,
      replies: r.length,
      errors: here(errors).length,
      p50TotalMs: percentile(r.map((x) => x.totalMs).filter(Number.isFinite), 50)
    });
  }

  return {
    generatedAt: now,
    uptimeS: Math.round((now - startedAt) / 1000),
    windowHours: hours,
    replies: {
      count: replies.length,
      byKind: Object.fromEntries([...groupBy(replies, 'kind')].map(([k, v]) => [k || 'chat', v.length])),
      ttftMs: { p50: percentile(ttft, 50), p95: percentile(ttft, 95) },
      totalMs: { p50: percentile(total, 50), p95: percentile(total, 95) },
      tokensPerSecond: round(mean(tps), 1),
      cacheHitRate: prompt + cached ? round(cached / (prompt + cached), 3) : null,
      aborted: inWindow.filter((e) => e.type === 'abort').length,
      errors: errors.filter((e) => e.where === 'chat').length
    },
    tools: [...groupBy(inWindow.filter((e) => e.type === 'tool'), 'name')].map(([name, list]) => ({ name, ...stat(list) })).sort((a, b) => b.calls - a.calls),
    jobs: [...groupBy(inWindow.filter((e) => e.type === 'job'), 'name')].map(([name, list]) => ({ name, ...stat(list) })).sort((a, b) => b.calls - a.calls),
    errors: {
      count: errors.length,
      byWhere: Object.fromEntries([...groupBy(errors, 'where')].map(([k, v]) => [k, v.length])),
      recent: errors.slice(-15).reverse().map((e) => ({ t: e.t, where: e.where, message: e.message }))
    },
    timeline
  };
}
