import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { config } from './config.js';

/*
 * Connecting Discord (optional, offered once during setup and kept in Settings). Rosia's GIFs and clips can come from the
 * person's own Discord favourites; the Rosia plugin for BetterDiscord saves them and keeps their links alive. This file:
 *
 *  - says what is there: Discord, BetterDiscord, the Rosia plugin (and whether it is switched on and up to date);
 *  - puts the plugin in place and switches it on;
 *  - fetches the official BetterDiscord installer from BetterDiscord's own GitHub release, checks it against the checksum
 *    published with it, and opens it for the person to click through. Nothing is installed without them.
 *
 * Only the owner, at this computer, may use any of it (see index.js). Windows only, like the desktop app.
 */

export const PLUGIN_FILE = 'RosiaGifExport.plugin.js';
export const PLUGIN_NAME = 'RosiaGifExport';
const BD_RELEASE = 'https://api.github.com/repos/BetterDiscord/Installer/releases/latest';
const BD_ASSET = 'BetterDiscord-Installer-Windows.exe';
const BD_SUMS = 'checksums_windows.txt';

/** The folders that matter, from the environment (passed in so tests can use their own). */
export function places(env = process.env) {
  const appData = env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  const localAppData = env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
  const bd = path.join(appData, 'BetterDiscord');
  return {
    discord: ['Discord', 'DiscordPTB', 'DiscordCanary'].map((d) => path.join(localAppData, d)),
    betterDiscord: bd,
    plugins: path.join(bd, 'plugins'),
    enabledFile: path.join(bd, 'data', 'stable', 'plugins.json')
  };
}

/** The @version in a plugin's header, or ''. */
export function pluginVersion(text) {
  return /@version\s+([0-9][0-9.]*)/.exec(String(text || ''))?.[1] || '';
}

/** a.b.c compared numerically: -1, 0 or 1. */
export function compareVersions(a, b) {
  const pa = String(a || '0').split('.').map(Number);
  const pb = String(b || '0').split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i += 1) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

/** BetterDiscord's list of switched-on plugins, with ours switched on; everything else is left as it was. */
export function withPluginEnabled(text) {
  let list = {};
  try {
    const parsed = JSON.parse(String(text || '{}'));
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) list = parsed;
  } catch { /* unreadable: start a fresh list rather than lose the switch */ }
  return JSON.stringify({ ...list, [PLUGIN_NAME]: true }, null, 4);
}

/** The SHA-256 a checksum file gives for `name`, lowercase, or ''. */
export function checksumFor(text, name) {
  for (const line of String(text || '').split(/\r?\n/)) {
    const m = /^([a-f0-9]{64})\s+\*?(.+)$/i.exec(line.trim());
    if (m && m[2].trim() === name) return m[1].toLowerCase();
  }
  return '';
}

const bundledPlugin = () => path.join(config.root, 'tools', 'betterdiscord', PLUGIN_FILE);

/** What is on this computer. */
export function discordState({ env = process.env, plugin = bundledPlugin() } = {}) {
  const p = places(env);
  const latest = (() => { try { return pluginVersion(fs.readFileSync(plugin, 'utf8')); } catch { return ''; } })();
  const installedFile = path.join(p.plugins, PLUGIN_FILE);
  const installed = (() => { try { return pluginVersion(fs.readFileSync(installedFile, 'utf8')); } catch { return ''; } })();
  const enabled = (() => { try { return JSON.parse(fs.readFileSync(p.enabledFile, 'utf8'))[PLUGIN_NAME] === true; } catch { return false; } })();
  return {
    supported: process.platform === 'win32' || env.ROSIA_DISCORD_ANY_OS === '1',
    discord: p.discord.some((d) => fs.existsSync(d)),
    betterDiscord: fs.existsSync(p.plugins),
    plugin: { installed, latest, enabled, current: Boolean(installed) && compareVersions(installed, latest) >= 0 }
  };
}

/** Puts the plugin in BetterDiscord's plugins folder (replacing an older copy) and switches it on. */
export function installPlugin({ env = process.env, plugin = bundledPlugin() } = {}) {
  const p = places(env);
  if (!fs.existsSync(p.plugins)) throw Object.assign(new Error('BetterDiscord is not installed yet.'), { status: 409 });
  const target = path.join(p.plugins, PLUGIN_FILE);
  const tmp = `${target}.${process.pid}.tmp`;
  fs.copyFileSync(plugin, tmp);
  fs.renameSync(tmp, target);
  let current = '';
  try { current = fs.readFileSync(p.enabledFile, 'utf8'); } catch { /* none yet */ }
  fs.mkdirSync(path.dirname(p.enabledFile), { recursive: true });
  fs.writeFileSync(p.enabledFile, withPluginEnabled(current), 'utf8');
  return discordState({ env, plugin });
}

/**
 * Fetches the official BetterDiscord installer, checks it against the checksum BetterDiscord publishes with it, and opens
 * it. Resolves with { opened, version }.
 */
export async function openBetterDiscordInstaller({ fetchFn = fetch, launch = defaultLaunch, dir = path.join(os.tmpdir(), 'rosia-betterdiscord') } = {}) {
  const ask = async (url, as) => {
    const res = await fetchFn(url, { headers: { 'user-agent': 'rosia-app', accept: as === 'json' ? 'application/vnd.github+json' : '*/*' }, redirect: 'follow', signal: AbortSignal.timeout(60_000) });
    if (!res.ok) throw new Error(`BetterDiscord's download page answered ${res.status}.`);
    return as === 'json' ? res.json() : as === 'text' ? res.text() : Buffer.from(await res.arrayBuffer());
  };
  const release = await ask(BD_RELEASE, 'json');
  const asset = (release.assets || []).find((a) => a.name === BD_ASSET);
  const sums = (release.assets || []).find((a) => a.name === BD_SUMS);
  if (!asset || !sums) throw new Error('The BetterDiscord installer for Windows was not found in its latest release.');
  const host = (u) => { try { return new URL(u).host; } catch { return ''; } };
  if (host(asset.browser_download_url) !== 'github.com' || host(sums.browser_download_url) !== 'github.com') {
    throw new Error('The BetterDiscord installer is not on GitHub, so it was not downloaded.');
  }
  const expected = checksumFor(await ask(sums.browser_download_url, 'text'), BD_ASSET);
  if (!expected) throw new Error('BetterDiscord did not publish a checksum for its installer, so it was not opened.');
  const data = await ask(asset.browser_download_url, 'bytes');
  const actual = crypto.createHash('sha256').update(data).digest('hex');
  if (actual !== expected) throw new Error('The downloaded installer did not match its checksum, so it was not opened.');
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, BD_ASSET);
  fs.writeFileSync(file, data);
  launch(file);
  return { opened: true, version: String(release.tag_name || '') };
}

function defaultLaunch(file) {
  if (process.platform === 'win32') {
    // started by Windows (WMI), not by her: the desktop app ends everything she started when it closes, and the installer
    // (and the Discord it restarts) must not go with it
    const cmd = `$r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = '"${file.replace(/'/g, "''")}"' }; exit $r.ReturnValue`;
    const ps = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', cmd], { stdio: 'ignore', windowsHide: true });
    ps.on('exit', (code) => { if (code !== 0) spawn(file, [], { detached: true, stdio: 'ignore', windowsHide: false }).unref(); });
    return;
  }
  spawn(file, [], { detached: true, stdio: 'ignore', windowsHide: false }).unref();
}
