import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from './config.js';
import { renameRetrying } from './atomic.js';

/*
 * Who is asking. Every machine (really: every browser profile) gets a long random token the first
 * time it is let in. Memory, conversations and pictures are stored under the person that token
 * belongs to, so two machines never see each other's data.
 *
 *  - Only a SHA-256 hash of each token is stored (data/auth.json); the token itself lives in the
 *    browser as an HttpOnly cookie, or can be sent as "Authorization: Bearer <token>" by scripts.
 *  - Several machines can belong to one person: an already signed-in machine makes a short-lived
 *    pairing code, the other machine redeems it and gets its own token for the same person.
 *  - Machines can be listed and revoked.
 *
 * Who gets a token without a code (ROSA_ACCESS):
 *   invite (default)  only someone using the computer the server runs on (a direct connection that did
 *                     not come through a tunnel or proxy). Everyone else needs a pairing code.
 *   open              anyone who can reach the address gets their own private space. Convenient for
 *                     sharing a tunnel link; it also means anyone with the link can use the model.
 */

const COOKIE = 'rosia_token';
const MAX_AGE = 365 * 24 * 3600;
const PAIR_TTL_MS = 10 * 60_000;
const PAIR_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

// (a live binding: the owner can change it from Settings while the app runs, see share.js)
export let accessMode = /^open$/i.test(process.env.ROSA_ACCESS || '') ? 'open' : 'invite';

export function setAccessMode(mode) {
  accessMode = mode === 'open' ? 'open' : 'invite';
  return accessMode;
}

/** How many people other than the owner have a key, and how many of them were here in the last day. */
export function friendsSummary(now = Date.now()) {
  const seen = new Map(); // person -> when they were last here
  for (const d of state.devices) {
    if (d.userId === 'local') continue;
    seen.set(d.userId, Math.max(seen.get(d.userId) || 0, d.lastSeenAt || 0));
  }
  return { count: seen.size, today: [...seen.values()].filter((at) => now - at < 86_400_000).length };
}

const file = path.join(config.dataDir, 'auth.json');
let state = { devices: [] };
let ready = false;
const pairing = new Map(); // code -> { userId, expires }

export async function initAuth() {
  try {
    const data = JSON.parse(await fs.readFile(file, 'utf8'));
    if (Array.isArray(data.devices)) state = { devices: data.devices };
  } catch {
    /* first run */
  }
  ready = true;
}

let writeChain = Promise.resolve();

function save() {
  const snapshot = JSON.stringify(state, null, 2);
  writeChain = writeChain
    .then(async () => {
      await fs.mkdir(path.dirname(file), { recursive: true });
      const tmp = `${file}.${process.pid}.tmp`;
      await fs.writeFile(tmp, snapshot, 'utf8');
      await renameRetrying(tmp, file);
    })
    .catch((err) => console.error('[auth] save failed:', err.message));
  return writeChain;
}

const hash = (token) => crypto.createHash('sha256').update(token).digest('hex');
const randomToken = () => crypto.randomBytes(32).toString('base64url');
const randomId = (bytes = 12) => crypto.randomBytes(bytes).toString('hex');

/* ---------- reading the request ---------- */

function cookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  }
  return out;
}

function tokenFrom(req) {
  const auth = String(req.headers.authorization || '');
  if (/^Bearer\s+/i.test(auth)) return auth.replace(/^Bearer\s+/i, '').trim();
  return cookies(req)[COOKIE] || '';
}

/** The name in the Host header, without the port ("localhost", "127.0.0.1", "::1", "rosia.example"). */
export function hostName(req) {
  const host = String(req.headers.host || '').trim().toLowerCase();
  const v6 = /^\[([^\]]+)\](?::\d+)?$/.exec(host);
  if (v6) return v6[1];
  return host.replace(/:\d+$/, '');
}

/** A Host name that can only mean this computer. (A page whose own domain is pointed at 127.0.0.1 still sends its domain.) */
export function isLoopbackHost(name) {
  return name === 'localhost' || name.endsWith('.localhost') || name === '127.0.0.1' || name === '::1';
}

/**
 * True only for someone using the computer the server runs on: a loopback connection that did not come via a proxy, and
 * that was addressed to this computer by name. The last check stops DNS rebinding: a web page whose domain re-resolves to
 * 127.0.0.1 connects over loopback too, but its requests still carry its own domain in Host.
 */
export function isDirectLocal(req) {
  const addr = req.socket?.remoteAddress || '';
  const loopback = addr === '127.0.0.1' || addr === '::1' || addr === '::ffff:127.0.0.1';
  const proxied = ['x-forwarded-for', 'forwarded', 'cf-connecting-ip', 'x-real-ip', 'cf-ray'].some((h) => req.headers[h]);
  return loopback && !proxied && isLoopbackHost(hostName(req));
}

/** A short, human label from the User-Agent, e.g. "Chrome on Windows". */
export function describeAgent(ua = '') {
  const browser = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /Firefox\//.test(ua) ? 'Firefox'
    : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
  const os = /Windows/.test(ua) ? 'Windows' : /Android/.test(ua) ? 'Android' : /iPhone|iPad|iOS/.test(ua) ? 'iOS'
    : /Mac OS X/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : '';
  return os ? `${browser} on ${os}` : browser;
}

/* ---------- who is this? ---------- */

/** Returns { userId, device } for a valid token, otherwise null. */
export function authenticate(req) {
  const token = tokenFrom(req);
  if (!token || token.length < 20) return null;
  const h = hash(token);
  const device = state.devices.find((d) => d.hash === h);
  if (!device) return null;
  if (Date.now() - device.lastSeenAt > 10 * 60_000) {
    device.lastSeenAt = Date.now();
    save();
  }
  return { userId: device.userId, device };
}

/** Hands out a token for `userId`. Returns { token, device }. */
function issue(req, userId, label) {
  const token = randomToken();
  const now = Date.now();
  const device = {
    id: randomId(6),
    hash: hash(token),
    userId,
    label: String(label || describeAgent(req.headers['user-agent'])).slice(0, 40),
    createdAt: now,
    lastSeenAt: now
  };
  state.devices.push(device);
  save();
  return { token, device };
}

/**
 * A request with no valid token: decide whether it may have one.
 * Returns { token, device } or null (needs a pairing code).
 */
export function admit(req) {
  if (!ready) return null;
  if (isDirectLocal(req)) {
    // whoever sits at this computer is the owner, "local": that is also where conversations from before
    // machines had tokens already live, and it keeps them reachable if the owner clears their cookies
    return issue(req, 'local');
  }
  if (accessMode === 'open') return issue(req, randomId(12));
  return null;
}

export function sessionCookie(token, req) {
  const secure = req.headers['x-forwarded-proto'] === 'https' || req.socket?.encrypted ? '; Secure' : '';
  return `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${MAX_AGE}${secure}`;
}

/* ---------- devices ---------- */

export function devicesOf(userId, currentId) {
  return state.devices
    .filter((d) => d.userId === userId)
    .map((d) => ({ id: d.id, label: d.label, createdAt: d.createdAt, lastSeenAt: d.lastSeenAt, current: d.id === currentId }))
    .sort((a, b) => a.createdAt - b.createdAt);
}

export function renameDevice(userId, id, label) {
  const device = state.devices.find((d) => d.id === id && d.userId === userId);
  const clean = String(label || '').replace(/\s+/g, ' ').trim().slice(0, 40);
  if (!device || !clean) return false;
  device.label = clean;
  save();
  return true;
}

/** Revokes a machine's token. A person's last machine can't be removed (it would orphan their data). */
export function revokeDevice(userId, id) {
  const mine = state.devices.filter((d) => d.userId === userId);
  const device = mine.find((d) => d.id === id);
  if (!device) return 'missing';
  if (mine.length === 1) return 'last';
  state.devices = state.devices.filter((d) => d !== device);
  save();
  return 'ok';
}

/* ---------- pairing ---------- */

export function createPairingCode(userId) {
  for (const [code, p] of pairing) if (p.expires < Date.now() || p.userId === userId) pairing.delete(code);
  let code = '';
  for (let i = 0; i < 8; i += 1) code += PAIR_ALPHABET[crypto.randomInt(PAIR_ALPHABET.length)];
  const expires = Date.now() + PAIR_TTL_MS;
  pairing.set(code, { userId, expires });
  return { code, expires };
}

/** Uses a pairing code (once). Returns { token, device } for a new machine of the same person, or null. */
export function redeemPairingCode(req, rawCode, label) {
  const code = String(rawCode || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const entry = pairing.get(code);
  if (!entry || entry.expires < Date.now()) return null;
  pairing.delete(code);
  return issue(req, entry.userId, label);
}
