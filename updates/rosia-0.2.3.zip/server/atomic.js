import fs from 'node:fs/promises';
import path from 'node:path';

/*
 * Safe, cheap saving of JSON files.
 *  - write-then-rename, so a crash mid-write can't leave a half-written file
 *  - writes are queued one at a time, and several saves of the same file that arrive together are
 *    merged into one write of the newest content (the content is built when the write happens)
 */
/*
 * On Windows a file that another program has open (the nightly backup copying it, an antivirus or search indexer reading
 * it) cannot be replaced for a moment: rename fails with EPERM, EACCES or EBUSY. That is retried for up to about three
 * seconds instead of losing the save; if it still fails, the half-way file is removed and the error reported.
 */
export async function renameRetrying(from, to, { tries = 8, rename = fs.rename } = {}) {
  for (let attempt = 1; ; attempt += 1) {
    try {
      return await rename(from, to);
    } catch (err) {
      if (attempt >= tries || !['EPERM', 'EACCES', 'EBUSY'].includes(err.code)) {
        await fs.rm(from, { force: true }).catch(() => {});
        throw err;
      }
      await new Promise((r) => setTimeout(r, Math.min(800, 25 * 2 ** attempt)));
    }
  }
}

export function coalescedWriter(label = 'file') {
  const pending = new Map(); // file -> { make, waiters }
  let chain = Promise.resolve();
  let scheduled = false;

  function flush() {
    scheduled = false;
    const batch = [...pending.entries()];
    pending.clear();
    chain = chain.then(async () => {
      for (const [file, entry] of batch) {
        try {
          const content = entry.make();
          if (content == null) {
            for (const done of entry.waiters) done();
            continue; // the owner decided there is nothing to write (e.g. it was deleted meanwhile)
          }
          await fs.mkdir(path.dirname(file), { recursive: true });
          const tmp = `${file}.${process.pid}.tmp`;
          await fs.writeFile(tmp, content, 'utf8');
          await renameRetrying(tmp, file);
        } catch (err) {
          console.error(`[${label}] save failed:`, err.message);
        }
        for (const done of entry.waiters) done();
      }
    });
  }

  /** Saves `make()` to `file`. Resolves once it is on disk. */
  return function write(file, make) {
    return new Promise((resolve) => {
      const entry = pending.get(file);
      if (entry) {
        entry.make = make;
        entry.waiters.push(resolve);
      } else {
        pending.set(file, { make, waiters: [resolve] });
      }
      if (!scheduled) {
        scheduled = true;
        setTimeout(flush, 0);
      }
    });
  };
}
