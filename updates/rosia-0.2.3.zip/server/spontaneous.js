import { config } from './config.js';
import { maybeReact, adultOk } from './gifs/pick.js';
import { eligibleVideos } from './videos/catalog.js';
import { pickVideo } from './videos/links.js';
import { takeFromPool, poolSize } from './pool.js';
import { instantImage, mayDraw } from './images.js';

/*
 * What she sends on her own, without being asked: a GIF, a video, or a picture of herself. After a reply, now and then,
 * when her mood is strong enough and it has been a while since the last one of that kind. Never more than one thing per
 * reply, and never in a reply that already has a photo, picture, GIF or video.
 *
 *   GIFs      a reaction that fits what she just said        (gifs/pick.js maybeReact: ROSA_GIF_CHANCE / ROSA_GIF_GAP)
 *   videos    one of her saved favourites                    (ROSA_VIDEO_CHANCE / ROSA_VIDEO_GAP)
 *   pictures  one drawn ahead of time, handed over at once   (ROSA_PIC_CHANCE / ROSA_PIC_GAP)
 *
 * Videos and pictures follow the same rule as adult GIFs: only once the conversation is already heading that way (the
 * person's own words, or her recent mood). A picture is never drawn for this: only one already in the stock is sent, so
 * nobody waits for the graphics card because she felt like it.
 */

const WARM = new Set(['flirty', 'smitten', 'aroused', 'ecstatic', 'teasing']);

/** How many of her replies have gone by since one carried `field` (Infinity if none did). */
export function repliesSince(session, field) {
  let count = 0;
  for (let i = session.messages.length - 1; i >= 0; i -= 1) {
    const m = session.messages[i];
    if (m.role !== 'assistant') continue;
    if (m[field]) return count;
    count += 1;
  }
  return Infinity;
}

/**
 * Maybe something to go with her reply. Returns { gif: { item, score } } | { video: { url, name } } | { picture: job } | null.
 * rng and deps are for tests: deps = { videos: () => [...], check(url), pickVideo, takeFromPool, instantImage, react }.
 */
export async function maybeSpontaneous({ session, userId, text, mood, photo, image, gif, video, rng = Math.random, deps = {} }) {
  if (photo || image || gif || video) return null;
  if (!String(text || '').trim()) return null;
  const adult = adultOk(session);

  // the kinds are tried in a random order, so none is always the one that wins
  const order = ['picture', 'video', 'gif'].sort(() => rng() - 0.5);
  for (const kind of order) {
    if (kind === 'picture') {
      const s = config.spontaneous;
      if (!config.images.pool || !mayDraw(userId) || !adult || !WARM.has(mood)) continue;
      if (repliesSince(session, 'image') < s.pictureGap || rng() >= s.pictureChance) continue;
      if ((deps.poolSize || poolSize)() < 1) continue;
      const stock = await (deps.takeFromPool || takeFromPool)({ request: '', orientation: 'portrait' });
      if (!stock) continue;
      const job = await (deps.instantImage || instantImage)({ userId, sessionId: session.id, buffer: stock.buffer, orientation: 'portrait', prompt: stock.entry.prompt, request: stock.entry.request });
      return { picture: job };
    }
    if (kind === 'video') {
      const s = config.spontaneous;
      const list = (deps.videos || eligibleVideos)();
      if (!list.length || !adult || !WARM.has(mood)) continue;
      if (repliesSince(session, 'video') < s.videoGap || rng() >= s.videoChance) continue;
      // picked by what is actually being said (her reply and their last message), never at random: nothing that fits, nothing sent
      const theirs = [...session.messages].reverse().find((m) => m.role === 'user')?.content || '';
      const vibe = `${mood}. ${String(text).slice(0, 240)}. They said: ${String(theirs).slice(0, 160)}`;
      const choice = await (deps.pickVideo || pickVideo)({ vibe, session, userId, allowAdult: adult, maxTries: 2, purpose: 'react', strict: true, deps: { list, ...(deps.check ? { check: deps.check } : {}) } });
      if (choice) return { video: choice };
      continue;
    }
    const react = await (deps.react || maybeReact)({ session, userId, text, mood, photo, image, gif, rng }).catch(() => null);
    if (react) return { gif: react };
  }
  return null;
}
