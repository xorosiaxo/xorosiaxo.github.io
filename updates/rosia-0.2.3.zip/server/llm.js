import { config } from './config.js';

export class ModelError extends Error {
  constructor(message, status = 500) {
    super(message);
    this.status = status;
  }
}

let modelCache = { at: 0, names: [] };

/** Cached for a few seconds: the health check polls and shouldn't hit a busy model server each time. */
export async function listModels() {
  if (Date.now() - modelCache.at < 8000 && modelCache.names.length) return modelCache.names;
  const names = await fetchModels();
  modelCache = { at: Date.now(), names };
  return names;
}

async function fetchModels() {
  try {
    const res = await fetch(`${config.ollamaUrl}/api/tags`, { signal: AbortSignal.timeout(4000) });
    if (res.ok) {
      const data = await res.json();
      const names = (data.models || []).map((m) => m.name).filter(Boolean);
      if (names.length) return names;
    }
  } catch {
    /* not Ollama — fall through to the OpenAI-style endpoint */
  }

  const res = await fetch(`${config.ollamaUrl}/v1/models`, { signal: AbortSignal.timeout(4000) });
  if (!res.ok) throw new ModelError(`Model server responded ${res.status}`, 502);
  const data = await res.json();
  return (data.data || []).map((m) => m.id).filter(Boolean);
}

export async function pickModel() {
  if (config.model) return config.model;
  try {
    const names = await listModels();
    const prefer = names.find((n) => /llama3|qwen|mistral|gemma|deepseek|phi/i.test(n));
    return prefer || names[0] || '';
  } catch {
    return '';
  }
}

function endpoint() {
  return `${config.ollamaUrl}/v1/chat/completions`;
}

export async function streamCompletion({ model, messages, tools, signal, temperature, toolChoice = 'auto', maxTokens }) {
  const slots = await slotCount();
  const body = {
    model,
    messages,
    stream: true,
    cache_prompt: true, // llama.cpp: reuse the already-processed prefix of the previous prompt
    ...(slots > 1 ? { id_slot: 0 } : {}),
    temperature: temperature ?? config.temperature,
    ...config.sampling,
    max_tokens: maxTokens || config.maxTokens
  };
  if (config.reasoningEffort) body.reasoning_effort = config.reasoningEffort;
  if (!config.thinking) body.chat_template_kwargs = { enable_thinking: false };
  if (tools?.length) {
    body.tools = tools;
    body.tool_choice = toolChoice;
  }

  let res;
  try {
    res = await fetch(endpoint(), {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
      signal
    });
  } catch (err) {
    if (err?.name === 'AbortError') throw err;
    throw new ModelError(
      "She can't answer right now: her model isn't responding. Restart Rosia, or open Settings, then Models.",
      503
    );
  }

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new ModelError(`Model request failed (${res.status}). ${text.slice(0, 400)}`.trim(), 502);
  }

  return res.body;
}

export async function* parseStream(webStream) {
  const decoder = new TextDecoder();
  let buffer = '';
  const reader = webStream.getReader();

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      let idx;
      while ((idx = buffer.indexOf('\n')) !== -1) {
        const line = buffer.slice(0, idx).trim();
        buffer = buffer.slice(idx + 1);
        if (!line.startsWith('data:')) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === '[DONE]') continue;
        let json;
        try {
          json = JSON.parse(payload);
        } catch {
          continue;
        }
        const choice = json.choices?.[0];
        // llama.cpp reports timings on the closing chunk, which can have an empty choices list
        if (!choice) {
          if (json.timings) yield { content: '', toolCalls: null, finish: null, timings: json.timings };
          continue;
        }
        const delta = choice.delta || {};
        yield {
          content: delta.content || '',
          toolCalls: delta.tool_calls || null,
          finish: choice.finish_reason || null,
          timings: json.timings || null
        };
      }
    }
  } finally {
    reader.releaseLock?.();
  }
}

export function mergeToolCalls(acc, incoming) {
  for (const tc of incoming) {
    const index = tc.index ?? acc.length;
    if (!acc[index]) {
      acc[index] = {
        id: tc.id || `call_${index}`,
        type: 'function',
        function: { name: '', arguments: '' }
      };
    }
    const slot = acc[index];
    if (tc.id) slot.id = tc.id;
    if (tc.function?.name) slot.function.name += tc.function.name;
    if (tc.function?.arguments) slot.function.arguments += tc.function.arguments;
  }
  return acc;
}

/**
 * Pre-processes the constant part of the prompt (persona + tool definitions) so the first real
 * message doesn't pay for it. Fire-and-forget; failure just means a cold first reply.
 */
export async function primePrompt({ messages, tools }) {
  const model = await pickModel();
  if (!model) return false;
  try {
    const res = await fetch(endpoint(), {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        model,
        stream: false,
        cache_prompt: true,
        ...((await slotCount()) > 1 ? { id_slot: 0 } : {}),
        ...(config.thinking ? {} : { chat_template_kwargs: { enable_thinking: false } }),
        max_tokens: 1,
        temperature: 0,
        messages,
        ...(tools?.length ? { tools, tool_choice: 'none' } : {})
      }),
      signal: AbortSignal.timeout(120_000)
    });
    await res.text();
    return res.ok;
  } catch {
    return false;
  }
}

export function warmup({ system, tools }) {
  return primePrompt({ messages: [{ role: 'system', content: system }, { role: 'user', content: 'hi' }], tools });
}

/**
 * One-shot (non-streaming) completion for background jobs: pulling out memories, summaries, titles.
 * Never uses tools and keeps hidden thinking off so it stays cheap.
 */
export async function complete({ messages, maxTokens = 300, temperature = 0.2, signal } = {}) {
  const slots = await slotCount();
  const model = await pickModel();
  if (!model) throw new ModelError('No model available', 503);
  const body = {
    model,
    messages,
    stream: false,
    cache_prompt: true,
    // with more than one slot, background jobs get their own so they never evict the chat's cached prompt
    ...(slots > 1 ? { id_slot: slots - 1 } : {}),
    temperature,
    max_tokens: maxTokens
  };
  if (!config.thinking) body.chat_template_kwargs = { enable_thinking: false };
  const res = await fetch(endpoint(), {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    // the caller's signal (someone has started chatting: give the model back) and the time limit both end it
    signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(120_000)]) : AbortSignal.timeout(120_000)
  });
  if (!res.ok) throw new ModelError(`Model request failed (${res.status})`, 502);
  const data = await res.json();
  return String(data.choices?.[0]?.message?.content || '').trim();
}

let propsCache = { at: 0, value: null };

/** llama.cpp's /props, cached for a minute. null for servers that don't have it. */
async function serverProps() {
  if (Date.now() - propsCache.at < 60_000) return propsCache.value;
  let value = null;
  try {
    const res = await fetch(`${config.ollamaUrl}/props`, { signal: AbortSignal.timeout(3000) });
    if (res.ok) value = await res.json();
  } catch {
    /* unknown server */
  }
  propsCache = { at: Date.now(), value };
  return value;
}

/** Does the model server accept pictures? Assumes yes if it can't tell (non-llama.cpp servers). */
export async function visionSupported() {
  const props = await serverProps();
  return typeof props?.modalities?.vision === 'boolean' ? props.modalities.vision : true;
}

/** How many requests the model server can work on at once (llama-server -np). */
export async function slotCount() {
  if (config.slots > 0) return config.slots;
  const props = await serverProps();
  return Math.max(1, Number(props?.total_slots) || 1);
}
