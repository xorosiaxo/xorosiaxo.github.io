import { config } from './config.js';
import { holdModel } from './activity.js';

/*
 * The graphics card can hold the chat model or the image generator, not both. While a picture is being
 * made the chat model is off the card, so anything that needs it (a new message, a background job) waits
 * here and carries on the moment the card is handed back.
 *
 *   chat      normal: the model is on the card
 *   reserved  a picture is about to be made; replies in progress finish, new ones wait
 *   image     the image generator has the card
 */

let phase = 'chat';
let waiters = [];

export const swapAvailable = () => Boolean(config.images.controlUrl);
export const chatReady = () => phase === 'chat';
export const currentPhase = () => phase;

export function setPhase(next) {
  phase = next;
  holdModel(next === 'image');
  if (next === 'chat') {
    const go = waiters;
    waiters = [];
    for (const w of go) w.resolve();
  }
}

/** Resolves when the chat model is available; rejects (AbortError) if the caller gives up first. */
export function whenChatReady(signal) {
  if (phase === 'chat') return Promise.resolve();
  const cancelled = () => Object.assign(new Error('Cancelled'), { name: 'AbortError' });
  if (signal?.aborted) return Promise.reject(cancelled());
  return new Promise((resolve, reject) => {
    const onAbort = () => {
      waiters = waiters.filter((w) => w !== waiter);
      reject(cancelled());
    };
    const waiter = {
      resolve: () => {
        signal?.removeEventListener('abort', onAbort);
        resolve();
      }
    };
    waiters.push(waiter);
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

/** How many messages are waiting for the chat model to come back (people who turned up while a picture was drawn). */
export const chatWaiters = () => waiters.length;

/** Asks the launcher to move the card: '/gpu/image' or '/gpu/chat'. */
export async function control(path, timeoutMs = 6 * 60_000) {
  const res = await fetch(`${config.images.controlUrl}${path}`, {
    method: 'POST',
    headers: { 'x-rosia-control': config.images.controlToken },
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!res.ok) {
    let detail = '';
    try {
      detail = (await res.json()).error || '';
    } catch {
      /* no body */
    }
    throw new Error(detail || `The launcher said ${res.status}.`);
  }
}
