import crypto from 'node:crypto';
import { complete as defaultComplete } from './llm.js';
import { saveUser } from './users.js';
import { hashEmbed, cosine } from './embed.js';
import { neutralise } from './memory.js';

/*
 * Inside jokes: the funny things the two of them share, which she brings back weeks later ("the pigeon incident").
 *
 * Found in the background, and only when they laughed (lol, haha, 😂, "i'm dead"): a small model asked "was anything
 * funny here?" after every message makes jokes out of nothing. Each one is a short name and one sentence of what
 * happened, from the conversation itself.
 *
 * Brought back sparingly: never in the conversation it was born in, never two days running, usually when something
 * now said is close to it, and now and then just because. When she offers one and her reply uses it, that is noted,
 * so the same joke does not come round again too soon.
 *
 * Kept on the person (user.jokes) and shown in "What she remembers", where they can remove one.
 */

const MAX = 30;
const RESTING = 2 * 86_400_000; // after she uses one, it rests this long
export const LAUGHED = /\b(?:lo+l|lmf?a+o+|ha(?:ha)+h?|he(?:he)+|rofl|i'?m (?:dead|crying|weak)|dead+|dying|crying|screaming|stop+ it)\b|😂|🤣|💀|😭/i;

const STOP = new Set('the a an and or but of to in on at for with from by as is are was were be been it this that these those you your they them their she her he his we our us i me my not no so just really very about into over than then too also have has had will would can could should what when one'.split(' '));

/** The words that make a joke recognisable ("pigeon", "incident"): for noticing that her reply used it. */
export function keyWords(joke) {
  return [...new Set(String(joke?.name || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((w) => w.length >= 4 && !STOP.has(w)))];
}

const SEXUAL = /\b(?:sex|sexy|nude|nudes|naked|horny|boob|boobs|tits|ass|dick|cock|pussy|cum|porn|bikini|lingerie|bed)\b/i;

/** The model's answer, as { name, about } or null. Tolerates stray text; refuses anything vague or sexual. */
export function parseJoke(text) {
  const m = /\{[\s\S]*\}/.exec(String(text || ''));
  if (!m) return null;
  try {
    const j = JSON.parse(m[0]);
    const name = String(j?.name || '').replace(/\s+/g, ' ').trim().replace(/^["']|["'.]$/g, '');
    const about = neutralise(String(j?.about || '').replace(/\s+/g, ' ').trim());
    if (name.length < 4 || name.length > 60 || about.length < 12) return null;
    if (SEXUAL.test(`${name} ${about}`)) return null; // flirting is not a running joke, and is never kept as one
    if (/\b(?:flirt|flirting|compliment|banter|teasing each other|joking around)\b/i.test(name)) return null; // too vague to call back
    return { name: name.slice(0, 60), about: about.slice(0, 200) };
  } catch {
    return null;
  }
}

function transcript(messages) {
  return messages
    .filter((m) => (m.role === 'user' || m.role === 'assistant') && m.content)
    .map((m) => `${m.role === 'user' ? 'Them' : 'Rosia'}: ${String(m.content).replace(/\s+/g, ' ').slice(0, 300)}`)
    .join('\n');
}

/** Looks at the last few messages, if they laughed, for something worth keeping as a running joke. Returns what it did. */
export async function findJoke(session, user, { complete = defaultComplete, now = Date.now() } = {}) {
  const recent = session.messages.filter((m) => m.role === 'user' || m.role === 'assistant').slice(-8);
  const theirs = recent.filter((m) => m.role === 'user').slice(-3);
  if (!theirs.some((m) => LAUGHED.test(String(m.content || '')))) return 'no laugh';
  const upTo = session.messages.length;
  if ((session.jokesCheckedUpTo || 0) >= upTo) return 'seen';
  session.jokesCheckedUpTo = upTo;

  const known = (user.jokes || []).map((j) => `- ${j.name}`).join('\n');
  const reply = await complete({
    maxTokens: 90,
    temperature: 0.2,
    messages: [
      {
        role: 'system',
        content:
          'You read the end of a chat between a person and their friend Rosia, where the person just laughed. Decide if ' +
          'something in it could become a running joke between them: a specific funny moment, story, mix-up or phrase ' +
          'they could bring back weeks later as a callback ("the pigeon incident", "the time the toaster won"). General ' +
          'flirting, teasing or banter is NOT a running joke. Never anything sexual. Use only what is in the chat; invent nothing.\n' +
          'If there is one, reply with ONLY JSON: {"name": "a short name for it, 2 to 6 words", "about": "one sentence on ' +
          'what happened, without he or she"}. If there is none, or it is one of the known jokes, reply {}.'
      },
      { role: 'user', content: `Known jokes:\n${known || '(none)'}\n\nThe chat:\n${transcript(recent)}` }
    ]
  });
  const joke = parseJoke(reply);
  if (!joke) return 'none';
  return addJoke(user, { ...joke, session: session.id }, now);
}

/** Keeps a joke. One very like a known joke only refreshes that one. Returns 'added' or 'same'. */
export async function addJoke(user, { name, about, session = '' }, now = Date.now()) {
  user.jokes ||= [];
  const vec = hashEmbed(`${name}. ${about}`);
  const twin = user.jokes.find((j) => cosine(vec, hashEmbed(`${j.name}. ${j.about}`)) >= 0.6 || j.name.toLowerCase() === name.toLowerCase());
  if (twin) {
    twin.at = now;
    await saveUser(user);
    return 'same';
  }
  user.jokes.push({ id: crypto.randomBytes(6).toString('hex'), name, about, at: now, born: now, session, used: 0, lastUsed: 0 });
  // the store stays small: the joke used least and longest ago goes first
  while (user.jokes.length > MAX) {
    const worst = user.jokes.reduce((a, b) => ((b.used - a.used || (b.lastUsed || b.born) - (a.lastUsed || a.born)) < 0 ? b : a));
    user.jokes.splice(user.jokes.indexOf(worst), 1);
  }
  await saveUser(user);
  return 'added';
}

/**
 * The joke worth offering her for this message, or null. Never one from this very conversation (it is not a callback
 * yet), never one used in the last two days. One that fits what was just said is offered; otherwise, now and then
 * (`chance`), one at random.
 */
export function pickJoke(user, session, message, { now = Date.now(), rng = Math.random, chance = 0.12 } = {}) {
  const ready = (user?.jokes || []).filter((j) => j.session !== session?.id && now - (j.lastUsed || 0) >= RESTING && now - j.born >= 6 * 3600_000);
  if (!ready.length) return null;
  const said = hashEmbed(String(message || ''));
  const scored = ready.map((j) => ({ j, score: cosine(said, hashEmbed(`${j.name}. ${j.about}`)) })).sort((a, b) => b.score - a.score);
  if (scored[0].score >= 0.22) return { joke: scored[0].j, fits: true };
  if (rng() < chance) return { joke: ready[Math.floor(rng() * ready.length)], fits: false };
  return null;
}

// the joke offered for each person's reply being written, so the reply can be checked for it afterwards
const offers = new Map();
export const rememberOffer = (userId, offer) => (offer ? offers.set(String(userId), offer.joke.id) : offers.delete(String(userId)));
export function takeOffer(userId) {
  const id = offers.get(String(userId)) || '';
  offers.delete(String(userId));
  return id;
}

/** What she is told when one is offered. Plain words; the joke's own name is how she should refer to it. */
export function jokeLine(offer) {
  if (!offer) return '';
  const { joke, fits } = offer;
  return fits
    ? `A running joke between you two fits here: "${joke.name}" (${joke.about}). Bring it back in a few words if it feels natural, as a callback, without explaining it.`
    : `A running joke between you two, if a callback would land right now: "${joke.name}" (${joke.about}). Only if it fits; never force it or explain it.`;
}

/** After her reply: if it used the joke she was offered, that joke rests for a while. Returns true when it was used. */
export async function noteUse(user, offeredId, replyText, now = Date.now()) {
  const joke = (user?.jokes || []).find((j) => j.id === offeredId);
  if (!joke) return false;
  const said = String(replyText || '').toLowerCase();
  const words = keyWords(joke);
  if (!words.length || !words.some((w) => said.includes(w))) return false;
  joke.used += 1;
  joke.lastUsed = now;
  await saveUser(user);
  return true;
}

/** What "What she remembers" shows. */
export function publicJokes(user) {
  return [...(user?.jokes || [])].sort((a, b) => b.born - a.born).map((j) => ({ id: j.id, name: j.name, about: j.about, at: j.born, used: j.used }));
}

export async function removeJoke(user, id) {
  const before = (user.jokes || []).length;
  user.jokes = (user.jokes || []).filter((j) => j.id !== id);
  if (user.jokes.length === before) return false;
  await saveUser(user);
  return true;
}
