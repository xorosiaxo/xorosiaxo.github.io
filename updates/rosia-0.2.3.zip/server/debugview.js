import fs from 'node:fs/promises';
import path from 'node:path';
import { config } from './config.js';

/*
 * Reads the debugging log (debuglog.js) back for the owner's page: a list of conversations, and everything that happened
 * in one of them. Read-only. Nothing here changes or removes anything.
 */

const files = () => [path.join(config.dataDir, 'logs', 'debug.1.jsonl'), path.join(config.dataDir, 'logs', 'debug.jsonl')];
const TAIL = 30 * 1024 * 1024;

async function lines() {
  const out = [];
  for (const file of files()) {
    let text = '';
    try {
      const handle = await fs.open(file, 'r');
      try {
        const { size } = await handle.stat();
        const length = Math.min(size, TAIL);
        const buf = Buffer.alloc(length);
        await handle.read(buf, 0, length, size - length);
        text = buf.toString('utf8');
        if (size > length) text = text.slice(text.indexOf('\n') + 1); // the first line of a tail may be cut
      } finally {
        await handle.close();
      }
    } catch {
      continue;
    }
    for (const line of text.split('\n')) {
      if (!line) continue;
      try {
        out.push(JSON.parse(line));
      } catch {
        /* a half-written line */
      }
    }
  }
  return out;
}

const clip = (s, n = 140) => String(s ?? '').replace(/\s+/g, ' ').slice(0, n);

/** One row per conversation seen in the log, newest first. */
export async function listChats({ hours = 72, now = Date.now() } = {}) {
  const since = now - hours * 3600_000;
  const by = new Map();
  for (const e of await lines()) {
    if (!e.session || Date.parse(e.t) < since) continue;
    let c = by.get(e.session);
    if (!c) {
      c = { session: e.session, user: e.user, first: e.t, last: e.t, messages: 0, replies: 0, tools: 0, problems: 0, opening: '', latest: '' };
      by.set(e.session, c);
    }
    c.last = e.t;
    if (e.event === 'chat.request' && e.text !== undefined) {
      c.messages += 1;
      if (!c.opening) c.opening = clip(e.text);
    }
    if (e.event === 'chat.reply') {
      c.replies += 1;
      c.latest = clip(e.text);
    }
    if (e.event === 'tool') {
      c.tools += 1;
      if (e.ok === false) c.problems += 1;
    }
    if (e.event === 'chat.error' || e.event === 'image.failed') c.problems += 1;
  }
  return [...by.values()].sort((a, b) => (a.last < b.last ? 1 : -1));
}

/** Everything logged for one conversation, in order. */
export async function chatEvents(session, { limit = 3000 } = {}) {
  const id = String(session || '');
  if (!/^[A-Za-z0-9_-]{4,64}$/.test(id)) return [];
  return (await lines()).filter((e) => e.session === id).slice(-limit);
}
