/*
 * Tidying and duplicate-spotting for what the model wrote.
 *
 * Small local models latch on to their own last message: the same sentence, question or whole
 * paragraph comes back two or three turns running (and sometimes twice inside one reply). Prompt
 * wording helps; these checks are the part that does not depend on the model listening.
 *
 * Everything here is pure, so it is tested directly (test/replytext.test.js).
 */

export const REPEAT_NOTE =
  'Your previous draft repeated something you already said earlier in this chat. Write a different ' +
  'reply to their latest message. Never reuse a sentence, question or phrase you have used before, ' +
  'and do not ask a question you have already asked.';

const STOP = new Set((
  'a an and are as at be been but by can could did do does for from had has have he her here him his ' +
  'how i if in into is it its just like me my no not of on or our out she so some than that the their ' +
  'them then there these they this to too up us was we were what when where which who why will with ' +
  'would you your youre dont thats im ive ill'
).split(' '));

/** Lowercase, no tags/punctuation/emoji/apostrophes: the form compared for repeats. */
export function normalize(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/\[[^\]]*\]/g, ' ')
    .replace(/[*_`~#>]/g, ' ')
    .replace(/[^a-z0-9' ]+/g, ' ')
    .replace(/'/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Words that carry meaning, for a rough similarity score. */
export function wordsOf(text) {
  return normalize(text).split(' ').filter((w) => w.length >= 3 && !STOP.has(w));
}

export function sentencesOf(text) {
  return String(text || '')
    .split(/(?<=[.!?\u2026])\s+|\n+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

function jaccard(a, b) {
  const sa = new Set(a);
  const sb = new Set(b);
  if (!sa.size || !sb.size) return 0;
  let shared = 0;
  for (const w of sa) if (sb.has(w)) shared += 1;
  return shared / (sa.size + sb.size - shared);
}

// Words too common to prove that two replies are about the same thing.
const GENERIC = new Set((
  'want wants wanted know knows think thought feel feels feeling going gonna today tonight right ' +
  'really actually thing things something question tell told mean means sure good better best like ' +
  'little lot much many more most just very even still again back away'
).split(' '));

const QUESTION = /\?/;

/** Drops paragraphs that say exactly the same thing twice (her reply repeated verbatim inside itself). */
export function dedupeParagraphs(text) {
  const seen = new Set();
  const out = [];
  for (const para of String(text || '').split(/\n{2,}/)) {
    const key = normalize(para);
    if (!key) continue;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(para.trim());
  }
  return out.join('\n\n');
}

/**
 * True when this reply reuses a whole sentence from one of the last few replies, or is broadly the
 * same text (a small model answering the same question again).
 */
export function isRepetitive(text, previous = []) {
  const mine = wordsOf(text);
  if (mine.length < 5) return false;

  const mySentences = new Set(
    sentencesOf(text)
      .map((s) => normalize(s))
      .filter((s) => s.length >= 14 && s.split(' ').filter((w) => !STOP.has(w)).length >= 3)
  );
  const mineSet = new Set(mine);
  const asksSomething = QUESTION.test(text);

  for (const prev of previous) {
    if (!prev) continue;
    const theirs = wordsOf(prev);
    if (mine.length >= 8 && theirs.length >= 8 && jaccard(mine, theirs) >= 0.5) return true;

    for (const s of sentencesOf(prev)) {
      if (mySentences.has(normalize(s))) return true;
    }

    // a short reply that asks a question about the same thing as her last one is the loop people notice most
    if (asksSomething && QUESTION.test(prev) && mine.length <= 45) {
      const shared = [...mineSet].filter((w) => theirs.includes(w) && !GENERIC.has(w));
      if (shared.length >= 2) return true;
    }
  }
  return false;
}

const LEADING_FILLER =
  /^\s*((gimme|give me) a (sec|second|moment|minute)|(hold|hang) on|one (sec|second|moment)|let me (check|look|search|see|find))\b[^\n.!?]*[.!?\u2026]?\s*/i;

/** A "gimme a sec" at the very start of a reply that made no tool call: it would be a lie, so it goes. */
export function dropLeadingFiller(text) {
  return String(text || '').replace(LEADING_FILLER, '').trimStart();
}

/* ---------- spotting a repeat while the reply is still being written ---------- */

// a sentence long enough, and with enough real words, to count as "the same sentence again"
const countable = (s) => s.length >= 14 && s.split(' ').filter((w) => !STOP.has(w)).length >= 3;

/** Every sentence she has said recently, in the form compared for repeats. */
export function sentenceKeys(texts) {
  const keys = new Set();
  for (const text of texts) {
    for (const s of sentencesOf(text)) {
      const key = normalize(s);
      if (countable(key)) keys.add(key);
    }
  }
  return keys;
}

/** True when this sentence is one she has already said. */
export function isKnownSentence(sentence, keys) {
  const key = normalize(sentence);
  return countable(key) && keys.has(key);
}

/**
 * The end of the first complete sentence in text that is still arriving, as an index just past it, or -1.
 * A sentence ends at . ! ? or … followed by a space or newline, so "3.5" and "e.g." do not end one early.
 */
export function firstSentenceEnd(text) {
  const t = String(text || '');
  const m = /[.!?…]+["')\]]*[ \t]*(?:\n|\s(?=\S))/.exec(t);
  const stop = m ? m.index + m[0].length : -1;
  // a line break ends one too, as it does when the old replies are split into sentences
  const nl = t.indexOf('\n');
  const lineEnd = nl === -1 || nl === t.length - 1 && t.trim().length === 0 ? -1 : nl + 1;
  if (stop === -1) return lineEnd;
  return lineEnd === -1 ? stop : Math.min(stop, lineEnd);
}

/** At most `count` sentences. A photo sent with a reply only needs a line; anything longer starts describing the picture. */
export function limitSentences(text, count = 2) {
  const parts = sentencesOf(text);
  if (parts.length <= count) return String(text || '').trim();
  return parts.slice(0, count).join(' ').trim();
}

/** A line of text with Markdown's marks taken out, cut to a title's length. */
export function plainTitle(text) {
  const clean = String(text || '')
    .replace(/\[([^\]]+)\]\((?:[^)\s]+)\)/g, '$1') // [words](link) -> words
    .replace(/(\*\*|__)(?=\S)(.+?)(?<=\S)\1/g, '$2') // **bold**
    .replace(/(?<![\w*])\*(?=\S)([^*\n]+?)(?<=\S)\*(?![\w*])/g, '$1') // *italic*, but not 2 * 3 * 4
    .replace(/`+([^`]+)`+/g, '$1') // `code`
    .replace(/^\s{0,3}(?:#{1,6}|>)\s+/gm, '') // headings and quotes
    .replace(/\s+/g, ' ')
    .trim();
  return clean.length > 38 ? `${clean.slice(0, 36).trim()}…` : clean;
}
