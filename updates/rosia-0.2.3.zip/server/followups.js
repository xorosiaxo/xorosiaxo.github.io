/*
 * Following up: the day after something they told her about ("driving test on Friday"), she asks how it went.
 *
 * A dated note carries `expires`: the end of the day it is about, plus a day of grace (dates.js). So the day itself is over
 * at `expires - DAY`, and from then until a few days later it is worth asking about, once. Pure, so it is tested directly.
 */

const DAY = 86_400_000;
export const FOLLOW_WINDOW_DAYS = 4;

/** The dated note that has just passed and has not been asked about, most recent first; or null. */
export function dueFollowUp(notes, now = Date.now()) {
  const due = (Array.isArray(notes) ? notes : []).filter((n) => {
    if (!n || !n.expires || n.followedUp || !n.text) return false;
    const over = n.expires - DAY;
    return now >= over && now <= over + FOLLOW_WINDOW_DAYS * DAY;
  });
  due.sort((a, b) => b.expires - a.expires);
  return due[0] || null;
}

/** What the model is told. It says what to do; how she says it is hers. */
export function followUpLine(note) {
  if (!note?.text) return '';
  const what = String(note.text).replace(/\s+/g, ' ').trim().slice(0, 160);
  return `Something they told you about has happened since you last talked: "${what}". Ask them how it went, in your own words, as the main thing you say.`;
}
