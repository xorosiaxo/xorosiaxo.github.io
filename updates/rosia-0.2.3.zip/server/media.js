import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from './config.js';

/* Pictures: ones people send, and ones that come from links they share. Each person has their own
   folder, data/media/<userId>/<id>.<ext>, and is only ever served their own files. */

const TYPES = {
  'image/jpeg': { ext: 'jpg', magic: [0xff, 0xd8, 0xff] },
  'image/png': { ext: 'png', magic: [0x89, 0x50, 0x4e, 0x47] },
  'image/gif': { ext: 'gif', magic: [0x47, 0x49, 0x46, 0x38] },
  'image/webp': { ext: 'webp', magic: null } // checked separately (RIFF....WEBP)
};

const MIME_BY_EXT = { jpg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp' };

export const MEDIA_ID = /^[a-f0-9]{24}\.(jpg|png|gif|webp)$/;

function dirFor(userId) {
  const safe = /^[A-Za-z0-9_-]{1,64}$/.test(String(userId)) ? String(userId) : 'local';
  return path.join(config.mediaDir, safe);
}

function looksLike(buf, type) {
  if (type === 'image/webp') return buf.length > 12 && buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP';
  return TYPES[type].magic.every((b, i) => buf[i] === b);
}

/** Works out what kind of picture some bytes are, or null. */
export function sniffImage(buf) {
  for (const type of Object.keys(TYPES)) if (buf.length > 12 && looksLike(buf, type)) return type;
  return null;
}

/* How much room each person's pictures take, worked out once from the folder and then kept up as pictures arrive. */
const usage = new Map(); // userId -> { bytes, at }
const USAGE_TTL_MS = 10 * 60_000;

export async function mediaUsage(userId) {
  const hit = usage.get(userId);
  if (hit && Date.now() - hit.at < USAGE_TTL_MS) return hit.bytes;
  let bytes = 0;
  try {
    const dir = dirFor(userId);
    for (const name of await fs.readdir(dir)) {
      try {
        bytes += (await fs.stat(path.join(dir, name))).size;
      } catch {
        /* removed while counting */
      }
    }
  } catch {
    /* no folder yet */
  }
  usage.set(userId, { bytes, at: Date.now() });
  return bytes;
}

async function store(userId, buf, type) {
  const used = await mediaUsage(userId);
  if (used + buf.length > config.quota.mediaBytes) {
    const err = new Error("You've used up the space for pictures. Nothing is removed to make room, so ask whoever runs this to raise the limit.");
    err.code = 'quota';
    throw err;
  }
  const id = `${crypto.randomBytes(12).toString('hex')}.${TYPES[type].ext}`;
  await fs.mkdir(dirFor(userId), { recursive: true });
  await fs.writeFile(path.join(dirFor(userId), id), buf);
  const entry = usage.get(userId);
  if (entry) entry.bytes += buf.length;
  return id;
}

/** Validates a data URL from the browser and stores it. Returns { id } or throws. */
export async function saveImage(userId, dataUrl) {
  const match = /^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
  if (!match) throw new Error('That does not look like a supported picture (JPEG, PNG, GIF or WebP).');
  const [, type, b64] = match;
  const buf = Buffer.from(b64, 'base64');
  if (buf.length > config.maxImageBytes) throw new Error('That picture is too big.');
  if (!looksLike(buf, type)) throw new Error('That file is not a real picture.');
  return { id: await store(userId, buf, type) };
}

/** Stores picture bytes fetched from a link. Returns the id, or null if they are not a picture we can use. */
export async function saveImageBuffer(userId, buf) {
  const type = sniffImage(buf);
  if (!type || buf.length > config.maxImageBytes) return null;
  try {
    return await store(userId, buf, type);
  } catch (err) {
    if (err.code === 'quota') return null; // the link is still read; its picture just is not kept
    throw err;
  }
}

function safeName(id) {
  return MEDIA_ID.test(String(id || '')) ? String(id) : null;
}

/** Reads one of this person's pictures back as a data URL (what the model is sent). */
export async function readImageDataUrl(userId, id) {
  const file = safeName(id);
  if (!file) return null;
  try {
    const buf = await fs.readFile(path.join(dirFor(userId), file));
    return `data:${MIME_BY_EXT[file.split('.').pop()]};base64,${buf.toString('base64')}`;
  } catch {
    return null;
  }
}

export function mediaMime(id) {
  const file = safeName(id);
  return file ? MIME_BY_EXT[file.split('.').pop()] : null;
}

export async function readMedia(userId, id) {
  const file = safeName(id);
  if (!file) return null;
  try {
    return await fs.readFile(path.join(dirFor(userId), file));
  } catch {
    return null;
  }
}

export async function deleteMedia(userId, ids) {
  for (const id of ids || []) {
    const file = safeName(id);
    if (file) await fs.rm(path.join(dirFor(userId), file), { force: true });
  }
  usage.delete(userId);
}

/** Pictures saved before people had their own folders belong to the owner ("local"). */
export async function migrateFlatMedia() {
  let entries = [];
  try {
    entries = await fs.readdir(config.mediaDir, { withFileTypes: true });
  } catch {
    return 0;
  }
  let moved = 0;
  for (const e of entries) {
    if (e.isFile() && MEDIA_ID.test(e.name)) {
      await fs.mkdir(dirFor('local'), { recursive: true });
      await fs.rename(path.join(config.mediaDir, e.name), path.join(dirFor('local'), e.name));
      moved += 1;
    }
  }
  return moved;
}
