import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import { config } from './config.js';
import { coalescedWriter } from './atomic.js';
import { embed, embedMany, hashEmbed } from './embed.js';
import { matchFloor, pickByMeaning } from './media-match.js';
import { debug } from './debuglog.js';

/*
 * A stock of pictures drawn ahead of time, so that a request for a picture of her is answered at once instead of after
 * a minute or two. While nobody has been chatting for a while, the server draws a few (see poolLoop in images.js) and
 * keeps them here, in data/pool: the pictures themselves, named so a glance at the folder says what they are
 * (pool-20261111-1317-lace-bra-and-shorts-balcony-9a280b.png: when, what for, a short id), and pool.json, which lists them
 * (what each was drawn for, the full prompt, a vector for finding it by meaning). When someone asks for a picture, the
 * closest one in the stock is handed over (copied into their own pictures) and a new one is drawn later to replace it. A
 * request nothing in the stock fits is drawn as usual.
 *
 * A restart changes nothing here: the list is read back, an older picture named only by its id is renamed once to the
 * readable form, and an entry whose picture has gone is removed from the list (and said so in the debugging log) instead of
 * lingering in it. The time of the last top-up is kept in state.json, so a restart does not start another straight away.
 *
 * An entry: { id, file, request, prompt, orientation, createdAt, vec, vecKind }
 */

const write = coalescedWriter('pool');
const dir = () => path.join(config.dataDir, 'pool');
const indexFile = () => path.join(dir(), 'pool.json');
const stateFile = () => path.join(dir(), 'state.json');
let entries = [];
let loaded = false;
let lastBatch = 0; // when the stock was last topped up

const slug = (text) => String(text || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40).replace(/-+$/, '') || 'picture';
const stamp = (ms) => {
  const d = new Date(ms);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
};
/** The readable name of a stocked picture: when it was drawn, what for, and the start of its id. */
export const poolFileName = ({ id, request, createdAt }) => `pool-${stamp(createdAt || Date.now())}-${slug(request)}-${String(id).slice(0, 6)}.png`;
const fileOf = (e) => e.file || `${e.id}.png`;
const exists = (p) => fs.access(p).then(() => true, () => false);

export const poolLastBatch = () => lastBatch;
export async function markPoolBatch(at = Date.now()) {
  lastBatch = at;
  await fs.mkdir(dir(), { recursive: true });
  await fs.writeFile(stateFile(), JSON.stringify({ lastBatchAt: at }));
}

/** How many pictures to queue now: only once the stock is down to the low-water mark, and never more than a batch. */
export function poolNeed({ size, inFlight = 0, target, batch }) {
  if (!target) return 0;
  const low = Math.max(0, target - batch); // a picture or two used is not worth lending out the graphics card for
  if (size + inFlight > low) return 0;
  return Math.max(0, Math.min(batch, target - size - inFlight));
}

export const poolTarget = () => config.images.pool;

export async function loadPool() {
  if (loaded) return;
  loaded = true;
  try {
    lastBatch = Number(JSON.parse(await fs.readFile(stateFile(), 'utf8')).lastBatchAt) || 0;
  } catch {
    /* never topped up */
  }
  let list = [];
  try {
    list = JSON.parse(await fs.readFile(indexFile(), 'utf8'));
  } catch {
    return; // no stock yet
  }
  let dropped = 0;
  let renamed = 0;
  for (const e of list) {
    const current = path.join(dir(), fileOf(e));
    if (!(await exists(current))) {
      dropped += 1;
      debug('pool.missing', { file: fileOf(e), request: e.request });
      continue; // its picture has gone: it comes off the list too
    }
    if (!e.file) {
      // an older picture, named only by its id: it gets the readable name
      const file = poolFileName(e);
      try {
        await fs.rename(current, path.join(dir(), file));
        e.file = file;
        renamed += 1;
      } catch {
        e.file = fileOf(e);
      }
    }
    entries.push(e);
  }
  if (dropped || renamed) await save(); // the list is rewritten so it never names a picture that is not there
  debug('pool.load', { kept: entries.length, dropped, renamed });
}

const save = () => write(indexFile(), () => JSON.stringify(entries));

export const poolSize = () => entries.length;
/** What the pictures in stock were drawn for, so the next ones are different. */
export const poolRequests = () => entries.map((e) => e.request);
export const poolStats = () => ({ size: entries.length, target: poolTarget(), orientations: entries.reduce((a, e) => ({ ...a, [e.orientation]: (a[e.orientation] || 0) + 1 }), {}) });

/** Puts a finished picture in the stock. */
export async function addToPool({ request, prompt, orientation }, buffer) {
  await loadPool();
  const id = crypto.randomBytes(8).toString('hex');
  let vec = null;
  let vecKind = '';
  try {
    ({ vec, kind: vecKind } = await embed(String(request).slice(0, 400), 'document'));
  } catch {
    /* matched by words instead */
  }
  await fs.mkdir(dir(), { recursive: true });
  const createdAt = Date.now();
  const file = poolFileName({ id, request, createdAt });
  await fs.writeFile(path.join(dir(), file), buffer);
  entries.push({ id, file, request: String(request).slice(0, 300), prompt: String(prompt).slice(0, 1800), orientation, createdAt, vec, vecKind });
  await save();
  return file;
}

const WORD = /[a-z]{3,}/g;
const STOP = new Set(['the', 'and', 'with', 'you', 'your', 'pic', 'pics', 'picture', 'photo', 'image', 'send', 'show', 'make', 'generate', 'draw', 'create', 'of', 'me', 'for', 'her', 'she', 'can', 'please', 'one', 'some', 'something', 'new', 'yourself', 'selfie']);
const words = (s) => new Set((String(s || '').toLowerCase().match(WORD) || []).filter((w) => !STOP.has(w)));

/**
 * Makes sure every stocked picture has a vector of the kind the embedding model gives now (one drawn while it was down
 * has none, or a hash one), in one batch. Hash vectors are made on the spot and not stored.
 */
async function vectorsFor(list, kind) { // (model kinds only)
  if (kind === 'hash') return list.map((e) => (e.vecKind === 'hash' && e.vec ? e.vec : hashEmbed(String(e.request).slice(0, 400))));
  const missing = list.filter((e) => !(e.vec && e.vecKind === kind));
  if (missing.length) {
    const { vecs, kind: madeBy } = await embedMany(missing.map((e) => String(e.request).slice(0, 400)), 'document');
    if (madeBy !== kind) return null;
    missing.forEach((e, i) => Object.assign(e, { vec: vecs[i], vecKind: kind }));
    await save();
  }
  return list.map((e) => e.vec);
}

/**
 * The picture in the stock that best fits `request`, taken out of it (it is single use), as { entry, buffer }, or null.
 * It is matched by meaning: the scene it was drawn for against what was asked (media-match.js), and only one that really
 * fits is handed over; otherwise it is drawn as usual. A request that names nothing in particular ("a pic of you") gets
 * any picture of the right shape. deps.embedQuery and deps.rng are for tests.
 */
export async function takeFromPool({ request, orientation = 'portrait', deps = {} } = {}) {
  await loadPool();
  if (!entries.some((e) => e.orientation === orientation)) return null;
  const want = words(request);
  let query = null;
  if (want.size) {
    try {
      query = await (deps.embedQuery || ((t) => embed(t, 'query')))(String(request).slice(0, 300));
    } catch {
      query = null;
    }
    if (!query) return null; // something specific, and nothing to judge it with: drawn properly instead
  }
  // looked at again after every wait, so two requests at once can never be handed the same picture
  if (query && query.kind !== 'hash' && !deps.embedQuery) await vectorsFor(entries.filter((e) => e.orientation === orientation), query.kind);
  // (read after that wait: the stock may have changed meanwhile)
  const fits = entries.filter((e) => e.orientation === orientation);
  if (!fits.length) return null;
  const vecOf = (e) => {
    if (e.vec && e.vecKind === query?.kind) return e.vec;
    return query?.kind === 'hash' ? hashEmbed(String(e.request).slice(0, 400)) : null;
  };
  const choice = pickByMeaning({
    items: fits,
    query,
    keyOf: (e) => e.id,
    vecOf,
    floor: query ? matchFloor(query.kind, 'pool') : 0,
    band: 0.04,
    rng: deps.rng || Math.random
  });
  if (!choice) return null;
  const pick = choice.item;
  entries = entries.filter((e) => e !== pick); // taken at once, before anything else can wait
  let buffer;
  try {
    buffer = await fs.readFile(path.join(dir(), fileOf(pick)));
  } catch {
    await save();
    return null;
  }
  await save();
  fs.rm(path.join(dir(), fileOf(pick)), { force: true }).catch(() => {});
  return { entry: pick, buffer, score: choice.score };
}

/** For tests. */
export function resetPool() {
  entries = [];
  loaded = false;
  lastBatch = 0;
}
