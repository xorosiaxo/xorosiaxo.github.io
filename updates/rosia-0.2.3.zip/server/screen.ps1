# Lists the windows on screen, top first, or saves a picture of one. Used by server/screen.js (Windows only).
#   screen.ps1 list
#   screen.ps1 shot <handle> <file.png>
param([string]$What = 'list', [string]$Handle = '', [string]$Out = '')
$ErrorActionPreference = 'Stop'

Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;

public static class RosiaScreen {
  delegate bool EnumProc(IntPtr h, IntPtr p);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc f, IntPtr p);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] static extern int GetWindowTextLength(IntPtr h);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
  [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int i);
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr h, IntPtr dc, uint flags);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int a, out int v, int size);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }

  public static string List() {
    SetProcessDPIAware();
    var rows = new List<string>();
    EnumWindows((h, p) => {
      if (!IsWindowVisible(h) || IsIconic(h) || GetWindowTextLength(h) == 0) return true;
      if (GetWindow(h, 4) != IntPtr.Zero) return true;            // owned pop-ups and tool windows
      if ((GetWindowLong(h, -20) & 0x80) != 0) return true;        // WS_EX_TOOLWINDOW
      int cloaked; DwmGetWindowAttribute(h, 14, out cloaked, 4);   // on another desktop, or a hidden app frame
      if (cloaked != 0) return true;
      RECT r; GetWindowRect(h, out r);
      if (r.R - r.L < 120 || r.B - r.T < 80) return true;
      var t = new StringBuilder(512); GetWindowText(h, t, 512);
      uint pid; GetWindowThreadProcessId(h, out pid);
      string name = "";
      try { name = Process.GetProcessById((int)pid).ProcessName; } catch { }
      rows.Add(h.ToInt64() + "\t" + name + "\t" + t.ToString().Replace("\t", " "));
      return true;
    }, IntPtr.Zero);
    return string.Join("\n", rows);
  }

  public static void Shot(long handle, string file) {
    SetProcessDPIAware();
    var h = new IntPtr(handle);
    RECT r; GetWindowRect(h, out r);
    int w = Math.Max(1, r.R - r.L), ht = Math.Max(1, r.B - r.T);
    using (var bmp = new Bitmap(w, ht, PixelFormat.Format32bppArgb)) {
      using (var g = Graphics.FromImage(bmp)) {
        var dc = g.GetHdc();
        bool ok = PrintWindow(h, dc, 2); // 2: the whole window, as it is drawn now (browsers and games included)
        g.ReleaseHdc(dc);
        if (!ok) g.CopyFromScreen(r.L, r.T, 0, 0, new Size(w, ht)); // some windows will not draw themselves: what is on screen there
      }
      // big enough to read, small enough for her model
      double scale = Math.Min(1.0, 1280.0 / Math.Max(w, ht));
      int sw = Math.Max(1, (int)(w * scale)), sh = Math.Max(1, (int)(ht * scale));
      using (var small = new Bitmap(sw, sh))
      using (var g2 = Graphics.FromImage(small)) {
        g2.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
        g2.DrawImage(bmp, 0, 0, sw, sh);
        small.Save(file, ImageFormat.Png);
      }
    }
  }
}
'@

if ($What -eq 'list') { [Console]::OutputEncoding = [Text.Encoding]::UTF8; [RosiaScreen]::List() }
elseif ($What -eq 'shot') { [RosiaScreen]::Shot([long]$Handle, $Out); 'ok' }
