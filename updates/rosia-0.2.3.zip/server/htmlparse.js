/* Pure functions that pull a title, description, picture and readable text out of a web page.
   They run inside a worker thread (see parse-worker.js): the page is untrusted and up to 1.5 MB, so a
   pathological one must not be able to stall the server. */

const NOTE_TEXT_CHARS = 2500;

const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', ndash: '-', mdash: '-', hellip: '...', rsquo: "'", lsquo: "'", ldquo: '"', rdquo: '"' };

function decodeEntities(s) {
  return s
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Math.min(Number(n), 0x10ffff)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(Math.min(parseInt(n, 16), 0x10ffff)))
    .replace(/&([a-z]+);/gi, (m, name) => ENTITIES[name.toLowerCase()] ?? m);
}

function meta(html, keys) {
  for (const key of keys) {
    const a = new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html);
    if (a) return decodeEntities(a[1]).trim();
    const b = new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html);
    if (b) return decodeEntities(b[1]).trim();
  }
  return '';
}

function readableText(html) {
  let h = html
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<(script|style|noscript|svg|nav|header|footer|form|iframe|aside|template)\b[\s\S]*?<\/\1>/gi, ' ');
  const main = /<(article|main)\b[\s\S]*?<\/\1>/i.exec(h);
  if (main) h = main[0];
  h = h
    .replace(/<\/(p|div|li|h[1-6]|tr|section|blockquote|br)\s*>|<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ');
  const lines = decodeEntities(h)
    .split('\n')
    .map((l) => l.replace(/\s+/g, ' ').trim())
    .filter((l) => l.length >= 30);
  return lines.join('\n').slice(0, NOTE_TEXT_CHARS * 2);
}

export function parseHtml(html, base) {
  const title =
    meta(html, ['og:title', 'twitter:title']) ||
    decodeEntities((/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] || '').replace(/\s+/g, ' ')).trim();
  const description = meta(html, ['og:description', 'twitter:description', 'description']);
  const site = meta(html, ['og:site_name']) || new URL(base).hostname.replace(/^www\./, '');
  let image = meta(html, ['og:image', 'og:image:url', 'twitter:image', 'twitter:image:src']);
  if (!image) image = /<link[^>]+rel=["']image_src["'][^>]*href=["']([^"']+)["']/i.exec(html)?.[1] || '';
  if (!image) {
    // GIF sites whose pages carry no usable meta tags still embed the media from their own CDN
    const cdn = /https?:\/\/(?:media\d*|c)\.(?:giphy|tenor)\.com\/[^"'\s\\<>]+?\.(?:gif|webp)/i.exec(html);
    image = cdn ? cdn[0] : '';
  }
  if (image) {
    try {
      image = new URL(image, base).href;
    } catch {
      image = '';
    }
  }
  return { title, description, site, image, text: readableText(html) };
}
