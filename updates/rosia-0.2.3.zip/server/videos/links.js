import fs from 'node:fs';
import path from 'node:path';
import dns from 'node:dns/promises';
import net from 'node:net';
import { config } from '../config.js';
import { embed } from '../embed.js';
import { matchFloor, pickByMeaning, noteSent, sentLately, resetSent, SENT_STRICT } from '../media-match.js';

/*
 * Her favourite videos. Unlike the GIFs these are never downloaded: the BetterDiscord plugin keeps just the links in
 * videos.json (in the same folder as the GIFs), and a video is sent to the person as a link that their own browser plays.
 * Before one is sent the link is checked, because links to files on Discord's servers expire.
 *
 * An entry: { url, name, label?, addedAt }
 */

const VIDEO_EXT = /\.(mp4|webm|mov|m4v|ogv)$/i;
const MAX_REDIRECTS = 3;
const CHECK_MS = 6000;

const cache = new Map(); // url -> { ok, at, reason }
const OK_FOR = 10 * 60_000;
const BAD_FOR = 5 * 60_000;
const recent_ = new Map(); // userId -> the last videos sent, newest last (also kept on disk, see media-match.js)

const linksFile = () => (config.gifs.dir ? path.join(config.gifs.dir, 'videos.json') : '');

/** Reads the list of saved links (never throws). Bad entries are dropped. */
export function loadVideos() {
  const file = linksFile();
  if (!file) return [];
  let list;
  try {
    list = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return [];
  }
  if (!Array.isArray(list)) return [];
  const seen = new Set();
  const out = [];
  for (const e of list) {
    const url = typeof e === 'string' ? e : String(e?.url || '');
    if (!/^https?:\/\//i.test(url) || seen.has(url)) continue;
    seen.add(url);
    out.push({ url, name: String(e?.name || '').slice(0, 120), label: String(e?.label || '').slice(0, 120), addedAt: Number(e?.addedAt) || 0 });
  }
  return out;
}

export const videosAvailable = () => loadVideos().length > 0;

/** Two links to the same file have the same key (Discord's differ only in their signature). Matches the plugin's. */
export function videoKey(url) {
  try {
    const u = new URL(url);
    return u.hostname === 'cdn.discordapp.com' || u.hostname === 'media.discordapp.net' ? u.pathname : u.href;
  } catch {
    return String(url);
  }
}

/** The `ex=` expiry Discord puts in its signed links (seconds since 1970, in hex), or 0. */
export function expiryOf(url) {
  try {
    const ex = new URL(url).searchParams.get('ex');
    return ex && /^[0-9a-f]{6,10}$/i.test(ex) ? parseInt(ex, 16) * 1000 : 0;
  } catch {
    return 0;
  }
}

/** True for addresses that are this machine or the local network: a saved link must never make the server look there. */
export function isPrivateAddress(ip) {
  if (net.isIPv6(ip)) {
    const v = ip.toLowerCase();
    if (v === '::1' || v === '::' || v.startsWith('fe8') || v.startsWith('fe9') || v.startsWith('fea') || v.startsWith('feb') || v.startsWith('fc') || v.startsWith('fd')) return true;
    const mapped = /^::ffff:(\d+\.\d+\.\d+\.\d+)$/.exec(v);
    return mapped ? isPrivateAddress(mapped[1]) : false;
  }
  const p = ip.split('.').map(Number);
  if (p.length !== 4 || p.some((n) => !Number.isInteger(n))) return true;
  const [a, b] = p;
  return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
}

async function safeHost(url) {
  if (process.env.ROSA_VIDEO_ALLOW_LOCAL === '1') return /^https?:/.test(new URL(url).protocol); // for tests that serve a video from this machine
  const u = new URL(url);
  if (!/^https?:$/.test(u.protocol)) return false;
  const host = u.hostname.replace(/^\[|\]$/g, '');
  if (net.isIP(host)) return !isPrivateAddress(host);
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || host.endsWith('.internal')) return false;
  const found = await dns.lookup(host, { all: true });
  return found.length > 0 && found.every((f) => !isPrivateAddress(f.address));
}

/**
 * Is this link working right now? Asks for the first few bytes only. Returns { ok, reason }.
 * deps.fetch is for tests.
 */
export async function checkLink(url, deps = {}) {
  const hit = cache.get(url);
  if (hit && Date.now() - hit.at < (hit.ok ? OK_FOR : BAD_FOR)) return hit;
  const result = await probe(url, deps).catch((err) => ({ ok: false, reason: String(err?.message || err).slice(0, 80) }));
  const stored = { ...result, at: Date.now() };
  cache.set(url, stored);
  if (cache.size > 500) cache.delete(cache.keys().next().value);
  return stored;
}

async function probe(url, deps) {
  const expires = expiryOf(url);
  if (expires && expires < Date.now() + 30_000) return { ok: false, reason: 'the link has expired' };
  const ask = deps.fetch || fetch;
  let current = url;
  for (let hop = 0; hop <= MAX_REDIRECTS; hop += 1) {
    if (!deps.fetch && !(await safeHost(current))) return { ok: false, reason: 'not a public web address' };
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), CHECK_MS);
    try {
      const res = await ask(current, { method: 'GET', redirect: 'manual', signal: ctl.signal, headers: { Range: 'bytes=0-2047', 'User-Agent': 'Mozilla/5.0 (RosiaLinkCheck)' } });
      if ([301, 302, 303, 307, 308].includes(res.status)) {
        const next = res.headers.get('location');
        res.body?.cancel?.().catch(() => {});
        if (!next) return { ok: false, reason: 'redirect with nowhere to go' };
        current = new URL(next, current).href;
        continue;
      }
      res.body?.cancel?.().catch(() => {});
      if (res.status !== 200 && res.status !== 206) return { ok: false, reason: `HTTP ${res.status}` };
      const type = String(res.headers.get('content-type') || '').toLowerCase();
      const looksVideo = type.startsWith('video/') || ((type.startsWith('application/octet-stream') || !type) && VIDEO_EXT.test(new URL(current).pathname));
      if (!looksVideo) return { ok: false, reason: `not a video file (${type.split(';')[0] || 'unknown type'})` };
      return { ok: true };
    } finally {
      clearTimeout(timer);
    }
  }
  return { ok: false, reason: 'too many redirects' };
}

const WORD = /[a-z0-9]{3,}/g;
const STOP = new Set(['video', 'videos', 'clip', 'clips', 'the', 'and', 'for', 'with', 'send', 'show', 'some', 'something', 'one', 'mp4', 'webm', 'you', 'your', 'got', 'any', 'can', 'please']);
const words = (s) => new Set((String(s || '').toLowerCase().match(WORD) || []).filter((w) => !STOP.has(w)));

/**
 * Picks a saved video whose link works. Something specific asked for is matched by meaning against what each video was
 * found to show (media-match.js); a video nobody has looked at yet can still be found by the words in its name. "Any
 * video" gets a random one. Never one sent to this person lately (any chat, across restarts). Tries a few, because some
 * links will have expired. Returns { url, name } or null.
 * deps are for tests: { list, check(url) -> {ok}, rng, embedQuery }.
 */
export async function pickVideo({ vibe = '', session, userId, allowAdult = true, maxTries = 6, purpose = 'ask', strict = false, deps = {} } = {}) {
  let candidates = (deps.list || loadVideos()).filter((v) => allowAdult || !v.adult);
  if (!candidates.length) return null;
  const check = deps.check || checkLink;
  const rng = deps.rng || Math.random;
  const inChat = (session?.messages || []).filter((m) => m.video).map((m) => videoKey(m.video.url));
  const recent = [...new Set([...inChat, ...(recent_.get(userId) || []), ...(await sentLately(userId, 'video'))])];

  // what was asked for, against what each video was found to show
  const want = words(vibe);
  let query = null;
  if (want.size && candidates.some((v) => v.vec)) {
    try {
      query = await (deps.embedQuery || ((t) => embed(t, 'query')))(String(vibe).slice(0, 300));
    } catch {
      query = null; // no embedding model right now: names alone
    }
  }
  const shared = (v) => {
    const have = words(`${v.label} ${v.name} ${v.description || ''}`);
    let n = 0;
    for (const w of want) if (have.has(w)) n += 1;
    return n;
  };

  for (let tries = 0; tries < maxTries && candidates.length; tries += 1) {
    let choice;
    if (query) {
      // by meaning; a word from the request in its name or description nudges it up a little
      choice = pickByMeaning({
        items: candidates,
        query,
        keyOf: (v) => videoKey(v.url),
        vecOf: (v) => (v.vec && v.vecKind === query.kind ? v.vec : null),
        recent,
        floor: matchFloor(query.kind, purpose),
        strict: SENT_STRICT.video,
        bonus: (v) => Math.min(2, shared(v)) * 0.04,
        rng
      });
    } else if (strict) {
      return null; // has to fit, and nothing has been looked at closely enough to tell: nothing is sent
    } else if (want.size) {
      // nothing has been looked at yet: the names decide, and with no name that fits, any one will do
      const named = candidates.filter((v) => shared(v) > 0);
      choice = pickByMeaning({ items: named.length ? named : candidates, query: null, keyOf: (v) => videoKey(v.url), recent, rng });
      if (!choice && named.length) choice = pickByMeaning({ items: candidates, query: null, keyOf: (v) => videoKey(v.url), recent, rng });
    } else {
      choice = pickByMeaning({ items: candidates, query: null, keyOf: (v) => videoKey(v.url), recent, strict: SENT_STRICT.video, rng });
    }
    if (!choice) return null;
    const v = choice.item;
    const state = await check(v.url);
    if (state.ok) {
      const key = videoKey(v.url);
      const list2 = recent_.get(userId) || [];
      list2.push(key);
      recent_.set(userId, list2.slice(-40));
      noteSent(userId, 'video', key);
      return { url: v.url, name: v.label || v.name };
    }
    candidates = candidates.filter((c) => c !== v); // a dead link: the next best
  }
  return null;
}

/** The link as the page may show it: only http(s). */
export const publicVideo = (v) => (v && /^https?:\/\//i.test(v.url) ? { url: v.url, name: v.name || '' } : undefined);

/** For tests. */
export function resetVideoState() {
  cache.clear();
  recent_.clear();
  resetSent();
}
