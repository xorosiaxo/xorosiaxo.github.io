import { getUser, saveUser } from '../users.js';
import { onMusic, playerOf } from './state.js';
import { wantedWords, plain } from './library.js';

/*
 * Music taste: theirs, learnt from what they do with the player, and hers, which is fixed and hers to defend.
 *
 * Theirs is counted, never guessed: a song they asked for by name, one they let play to the end, one they went back
 * to, and one they skipped early each count for its artist. From that she knows "you always skip the slow ones" in
 * her own words ("you skip lana every single time"), can put on "something i like" without asking what that is, and
 * notices when a favourite comes on.
 *
 * Kept on the person (user.taste), bounded, and shown to them in "What she remembers", where they can clear it.
 */

// Her own taste. Change it here and she changes with it.
export const HER_TASTE = {
  loves: ['SZA', 'Frank Ocean', 'The Weeknd', 'Lana Del Rey', 'Tove Lo', 'Doja Cat', 'Arctic Monkeys'],
  soft: 'a guilty soft spot for 2000s pop (Nelly Furtado, Rihanna)',
  not: 'not into heavy metal or country, and will say so'
};

const MAX_ARTISTS = 150;
const MAX_SONGS = 300;
const SKIP_SECONDS = 45; // a song left before this point, or before half of it, was skipped

const fresh = () => ({ artists: {}, songs: {} });

/** "Tove Lo & Grand Theft Auto VI", "Justice, Tame Impala & SZA", "Lil Wayne feat. Drake": each artist named. */
export function artistsOf(artist) {
  return String(artist || '')
    .split(/\s*(?:,|&|\bx\b|\band\b|\bfeat\.?|\bft\.?|\bfeaturing\b|\bwith\b)\s*/i)
    .map((a) => a.trim())
    .filter((a) => a.length >= 2 && !/^(grand theft auto|various artists|unknown)/i.test(a))
    .slice(0, 4);
}

const songKey = (t) => plain(`${t.title} ${t.artist}`).slice(0, 120);

function bump(taste, track, field, now) {
  if (!track?.title) return;
  const key = songKey(track);
  const s = (taste.songs[key] ||= { title: String(track.title).slice(0, 120), artist: String(track.artist || '').slice(0, 120), asked: 0, full: 0, replays: 0, skips: 0 });
  s[field] += 1;
  s.last = now;
  for (const name of artistsOf(track.artist)) {
    const k = plain(name);
    const a = (taste.artists[k] ||= { name, asked: 0, full: 0, replays: 0, skips: 0 });
    a[field] += 1;
    a.last = now;
  }
}

function trim(map, max) {
  const keys = Object.keys(map);
  if (keys.length <= max) return;
  keys.sort((a, b) => (map[a].last || 0) - (map[b].last || 0));
  for (const k of keys.slice(0, keys.length - max)) delete map[k];
}

/** How far into the song they were when a change came: the last position the browser told, plus the time since. */
function positionAt(player, now) {
  const told = Number(player?.position) || 0;
  return player?.paused ? told : told + Math.max(0, (now - (player?.at || now)) / 1000);
}

/**
 * What one change to the player says about their taste, as [track, field] pairs. Pure, for tests.
 * field is 'asked' | 'full' | 'replays' | 'skips'.
 */
export function signals(before, result, action, now = Date.now()) {
  const out = [];
  const type = String(action?.type || '');
  const was = before?.tracks?.[before.index];
  if (type === 'play' && wantedWords(action.asked || '').length && result.player?.tracks?.[0]) {
    // asked for by name: the first song is what they wanted
    out.push([result.player.tracks[0], 'asked']);
  } else if (type === 'next' && was) {
    if (action.auto) out.push([was, 'full']);
    else {
      const at = positionAt(before, now);
      const length = Number(was.duration) || 0;
      if (at < SKIP_SECONDS || (length && at < length / 2)) out.push([was, 'skips']);
    }
  } else if (type === 'restart' && was) {
    out.push([was, 'replays']);
  } else if (type === 'previous' && result.player) {
    out.push([result.player.tracks[result.player.index], 'replays']);
  }
  return out;
}

/** Counts what a change says. Returns true when anything was learnt. */
export async function learn(userId, before, result, action, now = Date.now()) {
  const found = signals(before, result, action, now);
  if (!found.length) return false;
  const user = await getUser(userId);
  user.taste ||= fresh();
  for (const [track, field] of found) bump(user.taste, track, field, now);
  trim(user.taste.artists, MAX_ARTISTS);
  trim(user.taste.songs, MAX_SONGS);
  await saveUser(user);
  return true;
}

let watching = false;
/** Starts learning from every player. */
export function watchTaste() {
  if (watching) return;
  watching = true;
  onMusic((userId, before, result, action) => {
    learn(userId, before, result, action).catch((err) => console.warn('[music] taste:', err.message));
  });
}

/* ---------- what it adds up to ---------- */

const score = (a) => a.asked * 3 + a.replays * 2 + a.full - a.skips * 1.5;

/** Their favourite artists (best first), the ones they keep skipping, and their most replayed songs. */
export function summary(taste) {
  const artists = Object.values(taste?.artists || {});
  const loves = artists.filter((a) => score(a) >= 3).sort((a, b) => score(b) - score(a) || (b.last || 0) - (a.last || 0));
  const skips = artists.filter((a) => a.skips >= 2 && a.skips > a.full + a.asked + a.replays).sort((a, b) => b.skips - a.skips);
  const replayed = Object.values(taste?.songs || {}).filter((s) => s.replays + s.asked >= 2).sort((a, b) => b.replays + b.asked - (a.replays + a.asked));
  return {
    loves: loves.slice(0, 6).map((a) => a.name),
    skips: skips.slice(0, 4).map((a) => a.name),
    replayed: replayed.slice(0, 3).map((s) => (s.artist ? `"${s.title}" by ${s.artist}` : `"${s.title}"`))
  };
}

const MINE = /\b(?:something|stuff|songs?|music|tunes?|anything)\s+(?:(?:that\s+)?i\s+(?:like|love|enjoy|listen to)|i'?d like|i'?m into)\b|\bmy\s+(?:favou?rites?|faves?|usual|songs|music|stuff|kind of music|type of music)\b|\bwhat i (?:like|love|usually listen to)\b/i;
const YOURS = /\b(?:something|stuff|songs?|music|tunes?|anything)\s+(?:that\s+)?you\s+(?:like|love|enjoy|listen to|are into)\b|\byour\s+(?:favou?rites?|faves?|music|songs|kind of music|type of music|playlist)\b|\bwhat you (?:like|love|listen to)\b/i;

/**
 * "play something i like" becomes one of their favourite artists; "play something you like" one of hers.
 * Anything else is returned as it was. `pick` chooses from a short list (random by default).
 */
export function tasteQuery(asked, taste, { pick = (list) => list[Math.floor(Math.random() * list.length)] } = {}) {
  const text = String(asked || '');
  if (YOURS.test(text)) return { query: pick(HER_TASTE.loves), whose: 'hers' };
  if (MINE.test(text)) {
    const loves = summary(taste).loves.slice(0, 3);
    if (loves.length) return { query: pick(loves), whose: 'theirs' };
    return { query: text, whose: 'unknown' }; // nothing learnt yet: she can say she is still working out what they like
  }
  return { query: text, whose: '' };
}

const TALKS_MUSIC = /\b(?:music|songs?|tunes?|playlist|album|artist|band|singer|rapper|listen|listening|spotify|concert|gig|play|playing|track)\b/i;

/**
 * What she is told about music taste, only when music is on or being talked about (so an ordinary message costs nothing):
 * what they like and skip, whether the song on now is one of theirs, and her own taste.
 */
export function tasteLine(user, userId, message = '') {
  const player = playerOf(userId);
  if (!player && !TALKS_MUSIC.test(String(message))) return '';
  const { loves, skips, replayed } = summary(user?.taste);
  const parts = [];
  if (loves.length) parts.push(`they love ${loves.join(', ')}`);
  if (skips.length) parts.push(`they keep skipping ${skips.join(', ')}`);
  if (replayed.length) parts.push(`they go back to ${replayed.join(', ')} again and again`);
  const theirs = parts.length ? `Their music taste, from what they actually play (tease them about it now and then, never list it): ${parts.join('; ')}.` : '';
  const on = player?.tracks?.[player.index];
  let now = '';
  if (on && !player.paused) {
    const names = artistsOf(on.artist).map(plain);
    const fav = loves.some((l) => names.includes(plain(l)));
    const disliked = skips.some((s) => names.includes(plain(s)));
    const hers = HER_TASTE.loves.some((l) => names.includes(plain(l)));
    if (fav) now = 'What is playing is one of their favourites.';
    else if (disliked) now = 'What is playing is by someone they usually skip.';
    if (hers) now += ' It is also one of yours.';
  }
  const own = `Your own taste: you love ${HER_TASTE.loves.join(', ')}; ${HER_TASTE.soft}; ${HER_TASTE.not}. You have real opinions about what is on, and can say so in a few words.`;
  return [theirs, now.trim(), own].filter(Boolean).join(' ');
}

/** What "What she remembers" shows. */
export function publicTaste(user) {
  const s = summary(user?.taste);
  return { loves: s.loves, skips: s.skips, replayed: s.replayed, hers: HER_TASTE.loves };
}

export async function clearTaste(user) {
  user.taste = fresh();
  await saveUser(user);
}
