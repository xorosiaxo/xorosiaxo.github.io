import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { coalescedWriter } from '../atomic.js';
import { describe, readId3, id3Size } from './tags.js';

/*
 * The owner's own songs. The files stay where they are (config.music.dir, and any folders inside it); this keeps a small
 * catalogue of them in data/music/library.json: what each one is called, who it is by, and where it is. Looking through
 * the folder only reads file names and the first part of each MP3 (its tags): no model, no graphics card.
 *
 * A song: { id, rel, title, artist, album, genre, folder, ext, size, mtime }
 */

export const AUDIO = {
  '.mp3': 'audio/mpeg',
  '.m4a': 'audio/mp4',
  '.aac': 'audio/aac',
  '.flac': 'audio/flac',
  '.ogg': 'audio/ogg',
  '.opus': 'audio/ogg',
  '.wav': 'audio/wav'
};
export const SONG_ID = /^[a-f0-9]{12}$/;

const MAX_SONGS = 20_000;
const MAX_DEPTH = 6;
const TAG_BYTES = 256 * 1024; // the text of a tag sits near its start; a cover picture after it is not read
const RESCAN_MS = 60_000;

const write = coalescedWriter('music');
const songs = new Map();
let loaded = false;
let scannedAt = 0;
let scanning = null;

const libraryFile = () => path.join(config.dataDir, 'music', 'library.json');
const idOf = (rel) => crypto.createHash('md5').update(String(rel).replace(/\\/g, '/').toLowerCase()).digest('hex').slice(0, 12);

/** True when there is a music folder on this computer. */
export function folderReady() {
  const dir = config.music.dir;
  try {
    return Boolean(dir) && fs.statSync(dir).isDirectory();
  } catch {
    return false;
  }
}

async function loadLibrary() {
  if (loaded) return;
  loaded = true;
  try {
    const list = JSON.parse(await fs.promises.readFile(libraryFile(), 'utf8'));
    for (const song of list) songs.set(song.id, song);
  } catch {
    /* no catalogue yet */
  }
}

/** Every audio file under the folder, as paths inside it. Hidden folders are left alone. */
async function walk(dir) {
  const found = [];
  const todo = [{ at: '', depth: 0 }];
  while (todo.length && found.length < MAX_SONGS) {
    const { at, depth } = todo.pop();
    let entries = [];
    try {
      entries = await fs.promises.readdir(path.join(dir, at), { withFileTypes: true });
    } catch {
      continue; // a folder that cannot be opened is skipped
    }
    for (const entry of entries) {
      if (entry.name.startsWith('.')) continue;
      const rel = at ? `${at}/${entry.name}` : entry.name;
      if (entry.isDirectory()) {
        if (depth < MAX_DEPTH) todo.push({ at: rel, depth: depth + 1 });
      } else if (entry.isFile() && AUDIO[path.extname(entry.name).toLowerCase()]) {
        found.push(rel);
        if (found.length >= MAX_SONGS) break;
      }
    }
  }
  return found;
}

/** The tags at the start of an MP3, or {} for anything else or a file that cannot be read. */
async function tagsOf(file, ext) {
  if (ext !== '.mp3') return {};
  let handle;
  try {
    handle = await fs.promises.open(file, 'r');
    const head = Buffer.alloc(10);
    await handle.read(head, 0, 10, 0);
    const size = Math.min(id3Size(head), TAG_BYTES);
    if (!size) return {};
    const buf = Buffer.alloc(size);
    await handle.read(buf, 0, size, 0);
    return readId3(buf);
  } catch {
    return {};
  } finally {
    await handle?.close().catch(() => {});
  }
}

/**
 * Brings the catalogue in line with the folder: new files are added, changed ones read again, files that have gone are
 * dropped. Safe to call often: it looks at most once a minute unless `force` is set, and two calls at once share one look.
 */
export function syncLibrary({ force = false } = {}) {
  if (scanning) return scanning;
  if (!force && scannedAt && Date.now() - scannedAt < RESCAN_MS) return Promise.resolve(songs.size);
  scanning = (async () => {
    await loadLibrary();
    if (!folderReady()) {
      if (songs.size) {
        songs.clear();
        await saveLibrary();
      }
      return 0;
    }
    const dir = config.music.dir;
    const seen = new Set();
    let changed = false;
    for (const rel of await walk(dir)) {
      const id = idOf(rel);
      seen.add(id);
      const file = path.join(dir, rel);
      let stat;
      try {
        stat = await fs.promises.stat(file);
      } catch {
        continue;
      }
      const known = songs.get(id);
      if (known && known.size === stat.size && known.mtime === Math.floor(stat.mtimeMs)) continue;
      const ext = path.extname(rel).toLowerCase();
      songs.set(id, { id, rel, ext, size: stat.size, mtime: Math.floor(stat.mtimeMs), ...describe(rel, await tagsOf(file, ext)) });
      changed = true;
    }
    for (const id of [...songs.keys()]) {
      if (!seen.has(id)) {
        songs.delete(id);
        changed = true;
      }
    }
    if (changed) await saveLibrary();
    return songs.size;
  })().finally(() => {
    scannedAt = Date.now();
    scanning = null;
  });
  return scanning;
}

function saveLibrary() {
  return write(libraryFile(), () => JSON.stringify([...songs.values()]));
}

export const allSongs = () => [...songs.values()];
export const getSong = (id) => songs.get(id);
export const songCount = () => songs.size;

/** Where a song's file is. Never anything outside the music folder. */
export function fileFor(song) {
  const dir = config.music.dir;
  if (!dir || !song) return null;
  const file = path.resolve(dir, song.rel);
  return file.startsWith(path.resolve(dir) + path.sep) ? file : null;
}

/** For tests. */
export function resetLibrary() {
  songs.clear();
  loaded = false;
  scannedAt = 0;
}

/* ---------- finding a song by what was asked for ---------- */

// words that say "play me something" and nothing about which song
const FILLER = new Set(['play', 'put', 'on', 'some', 'a', 'an', 'the', 'me', 'us', 'please', 'song', 'songs', 'music', 'track', 'tracks', 'tune', 'tunes',
  'something', 'anything', 'by', 'from', 'of', 'to', 'for', 'and', 'my', 'your', 'you', 'can', 'could', 'like', 'want', 'hear', 'listen', 'i', 'it', 'that', 'this', 'one', 'good', 'nice', 'bit', 'little', 'else', 'other', 'different', 'more', 'new', 'random', 'whatever', 'any', 'again']);

/** Lower case, accents and punctuation removed: "Beyoncé's" and "beyonces" are the same word. */
export const plain = (text) => String(text || '').normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/['’`]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();

/** The words of a request that say which song: "play some taylor swift please" gives ["taylor", "swift"]. */
export function wantedWords(query) {
  return plain(query).split(' ').filter((w) => w && !FILLER.has(w));
}

/**
 * How well a song fits the words asked for. Every word has to be somewhere in it (title, artist, album, genre or the
 * folders it is in), otherwise 0; words in the title or the artist count for more.
 */
export function scoreSong(song, words) {
  if (!words.length) return 0;
  const title = ` ${plain(song.title)} `;
  const artist = ` ${plain(song.artist)} `;
  const rest = ` ${plain(`${song.album} ${song.genre} ${song.folder}`)} `;
  let score = 0;
  for (const w of words) {
    const word = ` ${w} `;
    if (title.includes(word)) score += 3;
    else if (artist.includes(word)) score += 3;
    else if (rest.includes(word)) score += 2;
    else if (title.includes(w) || artist.includes(w) || rest.includes(w)) score += 1; // part of a longer word
    else return 0;
  }
  return score;
}

function shuffled(list, rng) {
  const out = [...list];
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

/**
 * The owner's songs that fit a request, best first (equally good ones in a random order, so an artist's songs do not
 * always come in the same order). With nothing particular asked for, a random handful.
 */
export function searchSongs(query, { limit = config.music.queue, rng = Math.random, list = allSongs() } = {}) {
  const words = wantedWords(query);
  if (!words.length) return shuffled(list, rng).slice(0, limit);
  return shuffled(list, rng)
    .map((song) => ({ song, score: scoreSong(song, words) }))
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((x) => x.song);
}

/** What the player is given for one of the owner's songs: no file names, no folders. */
export function publicSong(song) {
  return { id: song.id, source: 'folder', title: song.title, artist: song.artist || '', url: `/music/${song.id}` };
}
