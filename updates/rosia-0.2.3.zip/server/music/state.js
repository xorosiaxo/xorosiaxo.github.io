/*
 * Each person's music player: what is lined up, which song it is on, whether it is paused, and how loud.
 *
 * The sound itself plays in that person's own browser (public/music.js). This is the copy the server keeps, so that she
 * knows what is on ("skip this", "play that again", "what's this?") and so that a click on the player is known to her
 * on the next message. Every change goes through `reduce`, whether it came from her (a tool) or from a click, and the
 * browser is then shown the result.
 *
 * It lives in memory only: after a restart the players are simply closed, the way they are when the window is.
 *
 * A player: { tracks: [{ id, source, title, artist, url, duration?, art? }], index, paused, volume (0-100),
 *             position (seconds, as last heard from the browser), seq, asked, at }
 * `seq` goes up whenever the browser has to start a song from a given place (a new song, a skip, a restart). Pausing,
 * carrying on and the volume leave it alone, so the browser can tell "start this" from "nothing new to load".
 */

const players = new Map(); // userId -> player
const VOLUME_STEP = 20;
const DEFAULT_VOLUME = 70;

const clampVolume = (n) => Math.min(100, Math.max(0, Math.round(Number(n))));
const seconds = (n) => (Number.isFinite(Number(n)) && Number(n) >= 0 ? Math.round(Number(n) * 10) / 10 : null);

/**
 * One change to a player. Returns { player, did } where player is the new state (null when there is no player any more)
 * and did says in a word what happened. Throws, in words she can pass on, when the change makes no sense.
 * Pure: the same player and action always give the same result, and the player passed in is not changed.
 */
export function reduce(player, action = {}, now = Date.now()) {
  const type = String(action.type || '');

  if (type === 'play') {
    const tracks = Array.isArray(action.tracks) ? action.tracks.filter((t) => t && t.id && t.url && t.title) : [];
    if (!tracks.length) throw new Error('There was nothing to play.');
    return {
      did: 'play',
      player: { tracks, index: 0, paused: false, volume: player?.volume ?? DEFAULT_VOLUME, position: 0, seq: (player?.seq || 0) + 1, asked: String(action.asked || '').slice(0, 120), at: now }
    };
  }

  if (!player) throw new Error('Nothing is playing.');
  const next = { ...player, at: now };
  const startSong = (index) => Object.assign(next, { index, position: 0, paused: false, seq: player.seq + 1 });

  switch (type) {
    case 'pause': {
      const at = seconds(action.position);
      if (at !== null) next.position = at;
      next.paused = true;
      return { did: player.paused ? 'already paused' : 'paused', player: next };
    }
    case 'resume':
      next.paused = false;
      return { did: player.paused ? 'resumed' : 'already playing', player: next };
    case 'next':
      if (player.index >= player.tracks.length - 1) {
        // a song that ran to its end with nothing after it: the player stays, ready to be played again
        if (action.auto) return { did: 'finished', player: Object.assign(next, { paused: true, position: 0, seq: player.seq + 1 }) };
        throw new Error('That was the last song lined up. Ask for something else to carry on.');
      }
      startSong(player.index + 1);
      return { did: 'skipped', player: next };
    case 'previous':
      // on the first song there is nothing to go back to: it starts again, which is what the button does on any player
      startSong(Math.max(0, player.index - 1));
      return { did: player.index > 0 ? 'went back' : 'restarted', player: next };
    case 'restart':
      startSong(player.index);
      return { did: 'restarted', player: next };
    case 'stop':
      return { did: 'stopped', player: null };
    case 'volume': {
      const v = action.value;
      const to = v === 'up' ? player.volume + VOLUME_STEP : v === 'down' ? player.volume - VOLUME_STEP : Number(v);
      if (!Number.isFinite(to)) throw new Error('That is not a volume.');
      next.volume = clampVolume(to);
      return { did: next.volume > player.volume ? 'louder' : next.volume < player.volume ? 'quieter' : 'same volume', player: next };
    }
    case 'report': {
      // the browser saying where it has got to (and whether it is really playing: a browser can refuse to start sound)
      const at = seconds(action.position);
      if (at !== null) next.position = at;
      if (typeof action.paused === 'boolean') next.paused = action.paused;
      return { did: 'noted', player: next };
    }
    default:
      throw new Error('The player does not know how to do that.');
  }
}

export const playerOf = (userId) => players.get(String(userId || 'local')) || null;

const watchers = new Set();

/** Calls fn(userId, before, result, action) after every change to anyone's player (taste.js learns from these). */
export function onMusic(fn) {
  watchers.add(fn);
  return () => watchers.delete(fn);
}

/** Applies one change to a person's player and keeps the result. Returns what `reduce` returns. */
export function act(userId, action) {
  const id = String(userId || 'local');
  const before = players.get(id) || null;
  const result = reduce(before, action);
  if (result.player) players.set(id, result.player);
  else players.delete(id);
  for (const fn of watchers) {
    try {
      fn(id, before, result, action);
    } catch (err) {
      console.warn('[music] watcher:', err.message);
    }
  }
  return result;
}

/** What the page is given: the whole player, or null when this person has none. */
export function publicPlayer(userId) {
  const p = playerOf(userId);
  return p ? { tracks: p.tracks, index: p.index, paused: p.paused, volume: p.volume, position: p.position, seq: p.seq } : null;
}

const named = (t) => (t.artist ? `"${t.title}" by ${t.artist}` : `"${t.title}"`);

/** The song a player is on, in words: `"Hello" by Adele`. */
export function nowPlaying(player) {
  const t = player?.tracks?.[player.index];
  return t ? named(t) : '';
}

/**
 * What she is told about a person's player with every message, so she always knows what is on, including anything they
 * did with the buttons themselves. '' when they have no player, so it costs nothing in an ordinary chat.
 */
export function musicLine(userId) {
  const p = playerOf(userId);
  if (!p) return '';
  const after = p.tracks[p.index + 1];
  const where = p.tracks.length > 1 ? ` (song ${p.index + 1} of ${p.tracks.length}${after ? `, next is ${named(after)}` : ', the last one'})` : '';
  return `Music: ${nowPlaying(p)} is ${p.paused ? 'paused' : 'playing'} in their player${where}, volume ${p.volume}%. They hear it; you control it with music_control.`;
}

/** For tests. */
export function resetPlayers() {
  players.clear();
}
