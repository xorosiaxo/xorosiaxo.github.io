import { Readable } from 'node:stream';
import { audioFor, forget, warm, VIDEO_ID } from './ytdlp.js';
import { playerOf } from './state.js';

/*
 * /music/yt/<id>: a YouTube song's sound, passed on to the listener's browser. The browser cannot fetch it itself (the
 * link yt-dlp finds only works for the computer that asked for it), so the app asks for each piece the browser wants,
 * with the same byte range, and sends it straight on. Nothing is written to disk.
 */

const PASS = ['content-type', 'content-length', 'content-range', 'accept-ranges', 'last-modified'];

async function upstream(found, range, signal) {
  const headers = { ...found.headers };
  delete headers['Sec-Fetch-Mode']; // that is for pages, not for sound
  if (range) headers.range = range;
  return fetch(found.url, { headers, signal, redirect: 'follow' });
}

/** Sends the song, or answers 404/502 when it cannot. `userId` is whose player it is, so the song after it can be got ready. */
export async function streamYoutube(req, res, videoId, userId, { kind = 'audio' } = {}) {
  if (!VIDEO_ID.test(videoId)) return false;
  const stop = new AbortController();
  res.on('close', () => stop.abort());
  const range = /^bytes=\d*-\d*$/.test(String(req.headers.range || '')) ? req.headers.range : '';

  let found;
  let got;
  try {
    found = await audioFor(videoId, { kind });
    got = await upstream(found, range, stop.signal);
    // a link that stopped working (it had expired, or YouTube changed its mind): found again, once
    if (got.status === 403 || got.status === 410) {
      got.body?.cancel().catch(() => {});
      forget(videoId, kind);
      found = await audioFor(videoId, { fresh: true, kind });
      got = await upstream(found, range, stop.signal);
    }
  } catch (err) {
    if (stop.signal.aborted) return true;
    console.warn(`[music] ${videoId}: ${err.message}`);
    res.statusCode = 502;
    res.setHeader('content-type', 'application/json');
    res.end(JSON.stringify({ error: 'That song could not be played right now.' }));
    return true;
  }

  if (got.status === 416) {
    res.statusCode = 416;
    res.end();
    return true;
  }
  if (!got.ok) {
    got.body?.cancel().catch(() => {});
    res.statusCode = 502;
    res.end();
    return true;
  }

  // the song after this one is looked up while this one plays, so a skip starts at once
  if (kind === 'audio') {
    const player = playerOf(userId);
    const next = player?.tracks?.[player.index + 1];
    if (next?.source === 'youtube') warm([next.id.slice(2)]);
  }

  res.statusCode = got.status;
  for (const h of PASS) {
    const v = got.headers.get(h);
    if (v) res.setHeader(h, v);
  }
  if (!/^(?:audio|video)\//.test(String(res.getHeader('content-type') || ''))) res.setHeader('content-type', found.type);
  res.setHeader('accept-ranges', 'bytes');
  res.setHeader('cache-control', 'private, no-store');
  res.setHeader('x-content-type-options', 'nosniff');
  if (req.method === 'HEAD' || !got.body) {
    got.body?.cancel().catch(() => {});
    res.end();
    return true;
  }
  Readable.fromWeb(got.body).on('error', () => res.destroy()).pipe(res);
  return true;
}
