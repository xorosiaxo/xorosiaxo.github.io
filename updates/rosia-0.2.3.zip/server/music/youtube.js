import { config } from '../config.js';
import { onlineQuery } from './online.js';
import { ytdlpInstalled, VIDEO_ID } from './ytdlp.js';

/*
 * Songs from YouTube Music: the whole catalogue, famous songs included, with no adverts. It is searched the way the
 * YouTube Music website searches (its "Songs" list, so the official track comes before covers and lyric videos), and
 * each song is then played through the app: yt-dlp finds where its sound is (ytdlp.js) and /music/yt/<id> passes it
 * on to the listener's browser a piece at a time, so the bar can still jump anywhere.
 *
 * On by default. "youtubeMusic": false in rosia.local.json (or ROSA_YOUTUBE=0) turns it off, and then the free Audius
 * catalogue is used as before. Nothing is downloaded or kept: the sound only passes through.
 */

export const youtubeReady = () => Boolean(config.music.youtube && config.music.ytmUrl && ytdlpInstalled());

// what the website sends to say "only songs, please"
const SONGS_ONLY = 'EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D';
const CLIENT = { clientName: 'WEB_REMIX', clientVersion: '1.20251110.01.00', hl: 'en', gl: 'US' };

const FILLER = /\b(karaoke|playlist|instrumentals?|hits? (mix|music)|best songs of)\b/i;

const text = (col) => (col?.musicResponsiveListItemFlexColumnRenderer?.text?.runs || []).map((r) => r.text).join('');
const clock = (s) => String(s || '').split(':').reduce((sum, n) => sum * 60 + Number(n), 0) || 0;

/** One row of the "Songs" list as the player wants it, or null for anything that is not a playable song. */
export function rowToTrack(row) {
  const r = row?.musicResponsiveListItemRenderer;
  const id = r?.playlistItemData?.videoId
    || r?.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint?.videoId;
  if (!r || !VIDEO_ID.test(String(id || ''))) return null;
  const title = text(r.flexColumns?.[0]);
  // "Tove Lo & Grand Theft Auto VI • Blood In Your Eyes (from GTAVI: The Album) • 2:42": artist, album, length
  const about = text(r.flexColumns?.[1]).split(' • ');
  const length = about.find((p) => /^\d+(?::\d{2}){1,2}$/.test(p.trim()));
  const thumbs = r.thumbnail?.musicThumbnailRenderer?.thumbnail?.thumbnails || [];
  if (!title) return null;
  return {
    id: `y-${id}`,
    source: 'youtube',
    title: title.slice(0, 160),
    artist: String(about[0] || '').slice(0, 120),
    duration: clock(length),
    art: thumbs.at(-1)?.url || '',
    url: `/music/yt/${id}`
  };
}

/** Every song row in a search answer. */
export function songsIn(body) {
  const tabs = body?.contents?.tabbedSearchResultsRenderer?.tabs || [];
  const sections = tabs[0]?.tabRenderer?.content?.sectionListRenderer?.contents || [];
  return sections.flatMap((s) => s.musicShelfRenderer?.contents || []).map(rowToTrack).filter(Boolean);
}

/** What to type into the search box for a request: the song as asked for, or a mood and genre made into words. */
export function searchWords(query) {
  const want = onlineQuery(query);
  if (want.text) return { words: want.text, named: true };
  const parts = [want.mood, want.genre].filter(Boolean).map((p) => p.replace('/', ' ').toLowerCase());
  // ("popular songs" gives real songs people like where the computer is; "top hits" gives filler made to match the words)
  return { words: parts.length ? `${parts.join(' ')} songs` : 'popular songs', named: false };
}

function shuffled(list, rng) {
  const out = [...list];
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

/**
 * Songs from YouTube Music for a request. A named song comes back best match first, the rest of the list after it
 * (often more by the same artist); a mood, a genre or "anything" comes back mixed up.
 */
export async function searchYoutube(query, { limit = config.music.queue, signal, rng = Math.random } = {}) {
  if (!youtubeReady()) return [];
  const { words, named } = searchWords(query);
  const gaveUp = AbortSignal.timeout(config.music.timeoutMs);
  const res = await fetch(`${config.music.ytmUrl}/youtubei/v1/search?prettyPrint=false`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      origin: 'https://music.youtube.com',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36'
    },
    body: JSON.stringify({ context: { client: CLIENT }, query: words, params: SONGS_ONLY }),
    signal: signal ? AbortSignal.any([signal, gaveUp]) : gaveUp
  });
  if (!res.ok) throw new Error(`YouTube Music answered ${res.status}.`);
  const found = songsIn(await res.json())
    .filter((t) => !t.duration || (t.duration >= 40 && t.duration <= 900))
    // a mood or genre is a search for words, which brings up karaoke copies and "playlist" filler; a named song keeps them
    .filter((t) => named || !FILLER.test(`${t.title} ${t.artist}`));
  return (named ? found : shuffled(found, rng)).slice(0, limit);
}
