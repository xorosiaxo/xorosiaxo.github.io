import path from 'node:path';

/*
 * What a song is called and who it is by. Two sources, best first:
 *   - the tags inside an MP3 (ID3v2: title, artist, album, genre), read here without any library;
 *   - the file's name and the folders it sits in ("Artist - Title.mp3", or Artist/Album/01 Title.flac).
 * Only the text is read. Pictures and everything else in the tag are skipped.
 */

const FRAMES = { TIT2: 'title', TPE1: 'artist', TALB: 'album', TCON: 'genre' };

// the four bytes of a "syncsafe" number hold seven bits each
const syncsafe = (buf, at) => ((buf[at] & 0x7f) << 21) | ((buf[at + 1] & 0x7f) << 14) | ((buf[at + 2] & 0x7f) << 7) | (buf[at + 3] & 0x7f);

function utf16be(buf) {
  const swapped = Buffer.from(buf.subarray(0, buf.length - (buf.length % 2)));
  swapped.swap16();
  return swapped.toString('utf16le');
}

/** The text of one tag frame: the first byte says how the rest is written. */
function frameText(body) {
  if (!body.length) return '';
  const kind = body[0];
  const data = body.subarray(1);
  let text;
  if (kind === 1) {
    // UTF-16 with a mark at the start saying which way round the bytes are
    if (data[0] === 0xfe && data[1] === 0xff) text = utf16be(data.subarray(2));
    else text = data.subarray(data[0] === 0xff && data[1] === 0xfe ? 2 : 0).toString('utf16le');
  } else if (kind === 2) text = utf16be(data);
  else if (kind === 3) text = data.toString('utf8');
  else text = data.toString('latin1');
  // a frame can hold several values separated by a zero; the first is the one that matters
  return text.split('\u0000')[0].trim();
}

/** How many bytes the tag at the start of an MP3 takes (header included), or 0 when there is none. */
export function id3Size(head) {
  if (!head || head.length < 10 || head.toString('latin1', 0, 3) !== 'ID3') return 0;
  return 10 + syncsafe(head, 6);
}

/** { title, artist, album, genre } from the start of an MP3; whatever is missing is left out. */
export function readId3(buf) {
  const out = {};
  const size = id3Size(buf);
  const version = buf?.[3];
  if (!size || (version !== 3 && version !== 4)) return out; // older tags are rare; the file name is used instead
  const end = Math.min(size, buf.length);
  let at = 10;
  if (buf[5] & 0x40) at += version === 4 ? syncsafe(buf, 10) : buf.readUInt32BE(10) + 4; // an extended header: stepped over
  while (at + 10 <= end) {
    const id = buf.toString('latin1', at, at + 4);
    if (!/^[A-Z0-9]{4}$/.test(id)) break; // padding: the frames are over
    const length = version === 4 ? syncsafe(buf, at + 4) : buf.readUInt32BE(at + 4);
    const from = at + 10;
    if (length <= 0 || from + length > end) break;
    const field = FRAMES[id];
    if (field && !out[field]) {
      const text = frameText(buf.subarray(from, from + length)).slice(0, 160);
      // a genre can be written as a number in brackets ("(17)"): that says nothing to a search, so it is dropped
      if (text && !(field === 'genre' && /^\(?\d+\)?$/.test(text))) out[field] = text;
    }
    at = from + length;
  }
  return out;
}

const tidy = (s) => String(s || '').replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim();

/**
 * What a file's place in the folder says about it. `rel` is its path inside the music folder.
 *   "The Weeknd - Blinding Lights.mp3"        artist and title from the name
 *   "Adele/25/03 Hello.flac"                  artist from the first folder, album from the one it sits in
 *   "chill/rainy evening.mp3"                 one folder deep: the folder is a label ("chill"), not an artist
 */
export function fromPath(rel) {
  const parts = String(rel).split(/[\\/]+/).filter(Boolean);
  const name = tidy(path.basename(parts.at(-1) || '', path.extname(parts.at(-1) || '')));
  const folders = parts.slice(0, -1).map(tidy);
  // a track number in front ("01 ", "01. ", "1-03 - ") is not part of the name
  const bare = name.replace(/^\d{1,3}(?:-\d{1,3})?\s*[.)-]?\s+(?=\S)/, '');
  const out = { title: bare || name, artist: '', album: '', folder: folders.join(' ') };
  const split = /^(.{1,80}?)\s+[-–—]\s+(.{1,160})$/.exec(bare);
  if (split) {
    out.artist = split[1].trim();
    out.title = split[2].trim();
  }
  if (folders.length >= 2) {
    if (!out.artist) out.artist = folders.at(-2);
    out.album = folders.at(-1);
  }
  return out;
}

/** The two put together: what the tags say wins, the path fills the gaps. */
export function describe(rel, tags = {}) {
  const guess = fromPath(rel);
  return {
    title: tags.title || guess.title,
    artist: tags.artist || guess.artist,
    album: tags.album || guess.album,
    genre: tags.genre || '',
    folder: guess.folder
  };
}
