import { config } from '../config.js';
import { plain, wantedWords } from './library.js';

/*
 * Songs from Audius: an open music catalogue whose public interface is there for other apps to search and play from,
 * free and with no adverts. It is searched here; the song itself is played by the listener's own browser, straight from
 * Audius, so nothing is downloaded or kept on this computer.
 *
 * It is mostly independent artists. A famous chart song is usually only there as somebody's cover or remix, which is why
 * the owner's own folder is always looked in first (see find.js).
 */

export const onlineReady = () => Boolean(config.music.onlineUrl);

// What a word in a request means to the catalogue: one of its genres, one of its moods, or both.
const GENRES = {
  lofi: 'Lo-Fi', chill: 'Lo-Fi', chilled: 'Lo-Fi', chillout: 'Lo-Fi', study: 'Lo-Fi', studying: 'Lo-Fi', mellow: 'Lo-Fi',
  jazz: 'Jazz', jazzy: 'Jazz', rock: 'Rock', metal: 'Metal', pop: 'Pop', classical: 'Classical', piano: 'Classical', ambient: 'Ambient',
  acoustic: 'Acoustic', folk: 'Folk', country: 'Country', blues: 'Blues', reggae: 'Reggae', funk: 'Funk', funky: 'Funk', punk: 'Punk',
  latin: 'Latin', rap: 'Hip-Hop/Rap', hiphop: 'Hip-Hop/Rap', soul: 'R&B/Soul', rnb: 'R&B/Soul', electronic: 'Electronic', edm: 'Electronic',
  dance: 'Electronic', house: 'House', techno: 'Techno', trance: 'Trance', dubstep: 'Dubstep', disco: 'Disco', trap: 'Trap', indie: 'Alternative',
  alternative: 'Alternative', soundtrack: 'Soundtrack'
};
const MOODS = {
  calm: 'Peaceful', calming: 'Peaceful', peaceful: 'Peaceful', relaxing: 'Peaceful', relax: 'Peaceful', relaxed: 'Peaceful', sleepy: 'Peaceful',
  sleep: 'Peaceful', soothing: 'Peaceful', quiet: 'Peaceful', soft: 'Tender', gentle: 'Tender', sad: 'Melancholy', melancholy: 'Melancholy',
  heartbreak: 'Melancholy', moody: 'Brooding', dark: 'Brooding', happy: 'Upbeat', upbeat: 'Upbeat', cheerful: 'Upbeat', fun: 'Upbeat',
  romantic: 'Romantic', love: 'Romantic', sexy: 'Sensual', sensual: 'Sensual', sultry: 'Sensual', party: 'Energizing', hype: 'Energizing',
  energetic: 'Energizing', workout: 'Energizing', gym: 'Energizing', angry: 'Aggressive', aggressive: 'Aggressive', easygoing: 'Easygoing',
  cool: 'Cool', dreamy: 'Yearning', nostalgic: 'Sentimental', sentimental: 'Sentimental'
};

/**
 * What to ask the catalogue for. "something chill" is a genre, "sad songs" a mood, "sad jazz" both; anything else in
 * the request ("midnight city") is searched for by name.
 */
export function onlineQuery(query) {
  const words = wantedWords(plain(query).replace(/\bhip hop\b/g, 'hiphop').replace(/\br (?:and|n) b\b/g, 'rnb').replace(/\blo fi\b/g, 'lofi'));
  let genre = '';
  let mood = '';
  const named = [];
  for (const w of words) {
    if (!genre && GENRES[w]) genre = GENRES[w];
    else if (!mood && MOODS[w]) mood = MOODS[w];
    else named.push(w);
  }
  // a name was given: the request is searched as written (less the "play me some"), so "love story" is not turned into
  // a mood and "someone like you" keeps all three of its words
  if (named.length) {
    const asWritten = plain(query).replace(/^(?:(?:please|can|could|would|you|play|put|on|me|us|some|a|an|the|hear|listen|to|want|i)\s+)+/, '').replace(/\s+please$/, '');
    return { text: asWritten || words.join(' '), genre: '', mood: '' };
  }
  return { text: '', genre, mood };
}

/** A song the catalogue will actually play for anyone, and that is a song rather than an hour-long mix. */
function playable(t) {
  return Boolean(t && t.id && t.title && t.is_streamable !== false && !t.is_stream_gated && !t.is_delete && !t.is_unlisted && t.duration >= 40 && t.duration <= 900);
}

export function publicTrack(t, base = config.music.onlineUrl) {
  return {
    id: `a-${t.id}`,
    source: 'online',
    title: String(t.title).slice(0, 160),
    artist: String(t.user?.name || '').slice(0, 120),
    duration: Math.round(t.duration) || 0,
    art: t.artwork?.['150x150'] || '',
    url: `${base}/v1/tracks/${encodeURIComponent(t.id)}/stream?app_name=${encodeURIComponent(config.music.appName)}`
  };
}

async function askOnce(pathAndQuery, signal) {
  const gaveUp = AbortSignal.timeout(config.music.timeoutMs);
  const res = await fetch(`${config.music.onlineUrl}${pathAndQuery}`, {
    headers: { accept: 'application/json' },
    signal: signal ? AbortSignal.any([signal, gaveUp]) : gaveUp
  });
  if (!res.ok) throw new Error(`The music catalogue answered ${res.status}.`);
  const body = await res.json();
  return Array.isArray(body?.data) ? body.data : [];
}

/** One question to the catalogue. A slow or dropped answer is asked for once more: its first answer after a quiet spell is often the slow one. */
async function ask(pathAndQuery, signal) {
  try {
    return await askOnce(pathAndQuery, signal);
  } catch (err) {
    if (signal?.aborted) throw err; // the person hit stop
    return askOnce(pathAndQuery, signal);
  }
}

function shuffled(list, rng) {
  const out = [...list];
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

/**
 * Songs from the catalogue for a request, as the player wants them. A named song or artist comes back in the catalogue's
 * own order (closest first); a genre, a mood or "anything" comes back mixed up, so it is not the same handful every time.
 */
export async function searchOnline(query, { limit = config.music.queue, signal, rng = Math.random } = {}) {
  if (!onlineReady()) return [];
  const want = onlineQuery(query);
  const app = `app_name=${encodeURIComponent(config.music.appName)}`;
  let found;
  let mix = true;
  if (want.text) {
    found = await ask(`/v1/tracks/search?query=${encodeURIComponent(want.text)}&limit=20&${app}`, signal);
    mix = false;
  } else if (want.genre || want.mood) {
    const filters = [want.genre && `genre=${encodeURIComponent(want.genre)}`, want.mood && `mood=${encodeURIComponent(want.mood)}`].filter(Boolean).join('&');
    found = await ask(`/v1/tracks/search?query=&${filters}&limit=25&${app}`, signal);
  } else {
    found = await ask(`/v1/tracks/trending?time=week&limit=25&${app}`, signal);
  }
  const usable = found.filter(playable);
  return (mix ? shuffled(usable, rng) : usable).slice(0, limit).map((t) => publicTrack(t));
}
