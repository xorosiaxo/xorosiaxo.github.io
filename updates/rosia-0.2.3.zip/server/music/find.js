import { config } from '../config.js';
import { syncLibrary, searchSongs, publicSong, wantedWords, songCount, folderReady } from './library.js';
import { searchOnline, onlineReady } from './online.js';
import { searchYoutube, youtubeReady } from './youtube.js';
import { warm } from './ytdlp.js';

/*
 * Turns "play something chill" or "play hello by adele" into songs to line up.
 *
 * The owner's own folder is looked in first: it is where the songs they actually asked to have are, and it works with
 * no internet. Whatever the folder cannot answer goes to YouTube Music, which has nearly every song there is, and if
 * that is off or not answering, to the Audius catalogue. With nothing particular asked for ("play something"), the
 * folder is used when it has songs, otherwise the online places.
 */

/** True when there is anywhere at all to get music from (YouTube counts once it is on, while yt-dlp is still arriving). */
export const musicReady = () => folderReady() || onlineReady() || Boolean(config.music.youtube);

/** Returns { tracks, from: 'folder' | 'youtube' | 'online' | '' }: the songs for the player, first one first. */
export async function findTracks(query, { signal, rng = Math.random } = {}) {
  const limit = config.music.queue;
  await syncLibrary().catch(() => 0); // new files in the folder are picked up without a restart
  const particular = wantedWords(query).length > 0;
  const online = youtubeReady() || onlineReady();

  if (songCount() && (particular || !online || songCount() >= 3)) {
    const mine = searchSongs(query, { limit, rng });
    if (mine.length) return { tracks: mine.map(publicSong), from: 'folder' };
  }
  if (youtubeReady()) {
    try {
      const found = await searchYoutube(query, { limit, signal, rng });
      if (found.length) {
        // the first two start being looked up now, so the first one starts sooner and the skip to the second is quick
        warm(found.slice(0, 2).map((t) => t.id.slice(2)));
        return { tracks: found, from: 'youtube' };
      }
    } catch (err) {
      if (signal?.aborted) throw err;
      console.warn(`[music] YouTube Music: ${err.message}`);
    }
  }
  if (onlineReady()) {
    const found = await searchOnline(query, { limit, signal, rng });
    if (found.length) return { tracks: found, from: 'online' };
  }
  return { tracks: [], from: '' };
}
