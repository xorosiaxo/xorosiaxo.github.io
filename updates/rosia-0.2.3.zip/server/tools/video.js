import { defineTool } from './registry.js';
import { pickVideo } from '../videos/links.js';
import { eligibleVideos, videoCatalogStats } from '../videos/catalog.js';
import { adultOk } from '../gifs/pick.js';
import { repliesSince } from '../spontaneous.js';
import { config } from '../config.js';

/*
 * Sends one of her favourite videos. They are links saved by the BetterDiscord plugin (videos.json), looked at in the
 * background so she knows roughly what each shows, and the person's own browser plays them. The link is checked first, so
 * a video that has expired is never sent. When the person asks for a video it is sent at once; on her own she is held to a
 * gap of several replies (and server/spontaneous.js now and then sends one without her asking).
 * Adult ones follow the same rule as adult GIFs: only once the conversation is already heading there.
 */
defineTool({
  name: 'send_video',
  description:
    'Send a video from your favourites. Use it when they ask for a video or clip, or now and then on your own when the mood is ' +
    'right and things are already heated (rarely: not every few messages). Say in a few words what kind (or leave it blank ' +
    'for any). The video appears under your message by itself: do not describe it.',
  parameters: {
    type: 'object',
    properties: { about: { type: 'string', description: 'What kind of video, in a few words. Blank for any.' } }
  },
  available: () => videoCatalogStats().ok > 0,
  async run({ about, asked }, ctx) {
    const session = ctx.session;
    if (!asked && repliesSince(session, 'video') < config.spontaneous.videoGap / 2) throw new Error('You sent a video a while back. Just talk this time.');
    const choice = await pickVideo({ vibe: about || '', session, userId: session?.userId, allowAdult: adultOk(session), deps: { list: eligibleVideos() } });
    if (!choice) throw new Error('No saved video fits that right now (or its link has stopped working). Say so in a line, and offer to chat or send a GIF instead.');
    return { video: true, url: choice.url, name: choice.name };
  }
});
