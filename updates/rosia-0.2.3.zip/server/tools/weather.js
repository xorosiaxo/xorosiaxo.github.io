import { defineTool } from './registry.js';
import { config } from '../config.js';

/* Weather from Open-Meteo: no key, no scraping, and it does not go down when a search engine does. */

const WMO = {
  0: 'clear sky', 1: 'mostly clear', 2: 'partly cloudy', 3: 'overcast', 45: 'fog', 48: 'freezing fog',
  51: 'light drizzle', 53: 'drizzle', 55: 'heavy drizzle', 56: 'freezing drizzle', 57: 'heavy freezing drizzle',
  61: 'light rain', 63: 'rain', 65: 'heavy rain', 66: 'freezing rain', 67: 'heavy freezing rain',
  71: 'light snow', 73: 'snow', 75: 'heavy snow', 77: 'snow grains', 80: 'light showers', 81: 'showers',
  82: 'heavy showers', 85: 'snow showers', 86: 'heavy snow showers', 95: 'thunderstorm', 96: 'thunderstorm with hail',
  99: 'thunderstorm with heavy hail'
};

const cache = new Map();

async function getJson(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(8000), headers: { accept: 'application/json' } });
  if (!res.ok) throw new Error(`weather service answered ${res.status}`);
  return res.json();
}

export function describeWeather(code) {
  return WMO[code] || 'unclear';
}

export async function weatherFor(place, base = config.search) {
  const key = String(place).trim().toLowerCase();
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < 10 * 60_000) return hit.value;

  const geo = await getJson(`${base.geocodeUrl}?${new URLSearchParams({ name: place, count: '1', language: 'en', format: 'json' })}`);
  const spot = geo?.results?.[0];
  if (!spot) throw new Error(`I couldn't find a place called "${place}"`);

  const data = await getJson(`${base.forecastUrl}?${new URLSearchParams({
    latitude: String(spot.latitude),
    longitude: String(spot.longitude),
    current: 'temperature_2m,apparent_temperature,weather_code,wind_speed_10m,precipitation,relative_humidity_2m',
    daily: 'temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code',
    timezone: 'auto',
    forecast_days: '3'
  })}`);

  const cur = data.current || {};
  const daily = data.daily || {};
  const days = (daily.time || []).map((date, i) => ({
    date,
    summary: describeWeather(daily.weather_code?.[i]),
    high: daily.temperature_2m_max?.[i],
    low: daily.temperature_2m_min?.[i],
    rainChance: daily.precipitation_probability_max?.[i]
  }));

  const value = {
    weather: true,
    place: [spot.name, spot.admin1, spot.country].filter(Boolean).join(', '),
    observedAt: cur.time,
    now: {
      summary: describeWeather(cur.weather_code),
      temperatureC: cur.temperature_2m,
      feelsLikeC: cur.apparent_temperature,
      windKmh: cur.wind_speed_10m,
      humidityPct: cur.relative_humidity_2m,
      rainMm: cur.precipitation
    },
    days
  };
  cache.set(key, { at: Date.now(), value });
  if (cache.size > 50) cache.delete(cache.keys().next().value);
  return value;
}

defineTool({
  name: 'get_weather',
  description:
    'Get the current weather and the next three days for a place. Use this, not web_search, for any question about the weather, temperature, rain or forecast.',
  parameters: {
    type: 'object',
    properties: { place: { type: 'string', description: 'A city or town, e.g. "Leeds" or "Paris, France".' } },
    required: ['place']
  },
  async run({ place }) {
    const name = String(place || '').trim();
    if (!name) throw new Error('Which place?');
    return weatherFor(name);
  }
});
