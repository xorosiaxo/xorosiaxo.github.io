import { defineTool } from './registry.js';
import { outfitOf } from '../outfits.js';

// The pictures themselves live in public/assets/avatar/web/photo-<pose>.webp (see scripts/build-avatar.py).
// Descriptions are kept short and factual on purpose: the model must only pick the key, never narrate the pose
// back (a long description here reads like a script it starts reciting).
export const PHOTO_POSES = {
  bikini: 'standing, black bikini',
  front: 'front, tube top and skirt',
  back: 'from behind',
  feet: 'soles toward camera',
  kneeling: 'kneeling',
  gymwear: 'black gym crop top and shorts',
  swimsuit: 'navy one-piece swimsuit, arms up',
  'swimsuit-back': 'navy one-piece swimsuit, from behind'
};

// Used when the request points at a photo but not at which one.
export const DEFAULT_POSE = 'front';

defineTool({
  name: 'send_photo',
  description:
    'Send the person a photo of yourself in the chat. Call it whenever they ask to see you, ask for a pic, ' +
    'ask what you are wearing or how you look, ask you to turn around or show your back/feet/bikini/swimsuit/gym outfit, or when ' +
    'the flirting has clearly invited it. Never send one unprompted and never send more than one per message. ' +
    'Poses: ' + Object.entries(PHOTO_POSES).map(([k, v]) => `${k} (${v})`).join('; ') + '. ' +
    'Pick the pose that matches what they asked for; if they did not say, use ' + DEFAULT_POSE + '. ' +
    'The photo appears in the chat by itself: do NOT describe it, do NOT name the pose, and do NOT put the pose ' +
    'in square brackets. Just say one short line with it.',
  parameters: {
    type: 'object',
    properties: {
      pose: { type: 'string', enum: Object.keys(PHOTO_POSES), description: 'Which photo to send.' }
    },
    required: []
  },
  async run({ pose } = {}) {
    const key = String(pose || '').trim().toLowerCase() || DEFAULT_POSE;
    if (!PHOTO_POSES[key]) throw new Error(`Unknown pose. Choose one of: ${Object.keys(PHOTO_POSES).join(', ')}`);
    // what she has on in it, so she says the same thing the picture shows
    return { sent: true, pose: key, wearing: outfitOf(key) };
  }
});
