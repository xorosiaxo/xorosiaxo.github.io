import { defineTool } from './registry.js';
import { findTracks, musicReady } from '../music/find.js';
import { act, playerOf, nowPlaying } from '../music/state.js';
import { wantedWords } from '../music/library.js';
import { tasteQuery } from '../music/taste.js';
import { getUser } from '../users.js';

/*
 * Music she controls from the chat. The song plays in the person's own browser, in the small player at the top left of
 * her window; these tools only change that person's player (see music/state.js) and return at once, so she carries on
 * talking in the same reply.
 *
 * Two tools rather than one for every button: the model that runs her is small and reads every tool's description with
 * every message, so "play something" is one tool and everything done to what is already playing is the other.
 */

export const MUSIC_ACTIONS = ['pause', 'resume', 'skip', 'previous', 'restart', 'stop', 'louder', 'quieter', 'volume', 'now_playing'];

/** What comes back from a music tool: a word for what happened and the song the player is on now. (The page is sent the player itself by chat.js.) */
function outcome(userId, did, extra = {}) {
  const player = playerOf(userId);
  const track = player?.tracks[player.index];
  return {
    music: did,
    title: track?.title || '',
    artist: track?.artist || '',
    paused: Boolean(player?.paused),
    volume: player?.volume,
    song: player ? player.index + 1 : 0,
    songs: player ? player.tracks.length : 0,
    ...extra
  };
}

if (musicReady()) {
  defineTool({
    name: 'play_music',
    description:
      'Put music on for them: a song, an artist, a genre or a mood ("something chill"). Use it when they ask you to play ' +
      'something. It starts in their player by itself and keeps playing while you talk. Never start music unasked when ' +
      'they are being serious or upset.',
    parameters: {
      type: 'object',
      properties: { query: { type: 'string', description: 'What to play: a song and artist, an artist, a genre or a mood. Empty for anything.' } },
      required: []
    },
    available: () => musicReady(),
    async run({ query }, ctx) {
      const userId = ctx.session?.userId ?? 'local';
      const asked = String(query || '').trim().slice(0, 200);
      // "play something i like" is one of their favourite artists, "something you like" one of hers (their own words count too)
      const theirWords = [...(ctx.session?.messages || [])].reverse().find((m) => m.role === 'user')?.content || '';
      const user = await getUser(userId);
      let pick = tasteQuery(asked, user.taste);
      if (!pick.whose) pick = tasteQuery(theirWords, user.taste);
      const search = pick.whose === 'theirs' || pick.whose === 'hers' ? pick.query : asked;
      const { tracks, from } = await findTracks(search, { signal: ctx.signal });
      if (!tracks.length) throw new Error(search ? `Nothing was found for "${search}"` : 'No music could be found right now');
      // (what was asked is kept as they said it: her own pick is not counted as something they asked for)
      act(userId, { type: 'play', tracks, asked: pick.whose ? '' : asked });
      // "anything" names no song, so there is nothing for her to compare what was found against
      return outcome(userId, 'play', {
        asked: pick.whose ? '' : wantedWords(asked).length ? asked : '',
        from,
        // whose taste picked it, so she can say so ("one of yours", "one of my favourites", or that she is still learning theirs)
        ...(pick.whose ? { picked: pick.whose === 'unknown' ? 'their taste is not known yet' : `${pick.whose === 'hers' ? 'your own' : 'their'} favourite: ${pick.query}` } : {})
      });
    }
  });

  defineTool({
    name: 'music_control',
    description:
      'Control the music that is already playing in their player: pause, resume, skip to the next song, go back to the ' +
      'previous one, restart the song, stop, make it louder or quieter, set the volume, or check what is playing. Use it ' +
      'when they tell you to.',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: MUSIC_ACTIONS },
        volume: { type: 'number', description: 'Only with action "volume": 0 to 100.' }
      },
      required: ['action']
    },
    available: () => musicReady(),
    async run({ action, volume }, ctx) {
      const userId = ctx.session?.userId ?? 'local';
      // the other words she uses for the same buttons ("play" when it is paused is "resume")
      const ALIAS = { play: 'resume', unpause: 'resume', continue: 'resume', next: 'skip', skip_song: 'skip', back: 'previous', prev: 'previous', replay: 'restart', mute: 'volume', whats_playing: 'now_playing', what_is_playing: 'now_playing' };
      const said = String(action || '').toLowerCase().replace(/[\s-]+/g, '_');
      const what = ALIAS[said] || said;
      if (said === 'mute') volume = 0;
      if (what === 'now_playing') {
        if (!playerOf(userId)) throw new Error('Nothing is playing');
        return outcome(userId, 'now_playing');
      }
      const change = {
        pause: { type: 'pause' },
        resume: { type: 'resume' },
        play: { type: 'resume' },
        skip: { type: 'next' },
        next: { type: 'next' },
        previous: { type: 'previous' },
        back: { type: 'previous' },
        restart: { type: 'restart' },
        stop: { type: 'stop' },
        louder: { type: 'volume', value: 'up' },
        quieter: { type: 'volume', value: 'down' },
        volume: { type: 'volume', value: volume }
      }[what];
      if (!change) throw new Error(`The player cannot do "${action}"`);
      const before = nowPlaying(playerOf(userId));
      const { did } = act(userId, change);
      return outcome(userId, did, did === 'stopped' ? { was: before } : {});
    }
  });
}
