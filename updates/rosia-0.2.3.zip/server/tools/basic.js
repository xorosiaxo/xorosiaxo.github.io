import { defineTool } from './registry.js';
import { config } from '../config.js';
import { addNote, searchNotes, recentNotes } from '../users.js';
import { neutralise, isChatOnly } from '../memory.js';

defineTool({
  name: 'get_time',
  description: 'Get the current local date and time for the machine and its time zone.',
  parameters: { type: 'object', properties: {}, required: [] },
  async run(_args, ctx = {}) {
    const timeZone = ctx.timezone || config.timezone;
    const now = new Date();
    return {
      iso: now.toISOString(),
      local: now.toLocaleString('en-GB', { timeZone, dateStyle: 'full', timeStyle: 'short' }),
      timezone: timeZone
    };
  }
});

defineTool({
  name: 'remember',
  description:
    'Save a short fact about the person so you can recall it in later conversations (their name, where they live, what they do, preferences, running jokes). Use it when they tell you something worth keeping.',
  parameters: {
    type: 'object',
    properties: {
      fact: { type: 'string', description: 'One short sentence, third person, max ~140 characters.' }
    },
    required: ['fact']
  },
  async run({ fact }, { user } = {}) {
    // the same rules as the notes taken in the background: gender is never guessed, and what was asked for in the chat
    // (a photo, a bikini pic) is not a fact about their life
    const text = neutralise(String(fact || '').trim().slice(0, 200));
    if (!text) throw new Error('Nothing to remember');
    if (!user) return { saved: false, reason: 'no active person' };
    if (isChatOnly(text)) return { saved: false, reason: 'that is about this chat, not about their life: not saved' };
    const { note, created } = await addNote(user, text, 'tool');
    return { saved: Boolean(note), new: created, total: user.notes.length, text: note?.text };
  }
});

defineTool({
  name: 'recall',
  description:
    'Look through what you have noted about the person, across all your conversations. Use it when you need to check something they told you earlier. Matches on meaning, not just exact words.',
  parameters: {
    type: 'object',
    properties: { query: { type: 'string', description: 'What you want to remember, in a few words.' } },
    required: ['query']
  },
  async run({ query }, { user } = {}) {
    if (!user) return { notes: [] };
    const q = String(query || '').trim();
    const hits = q ? await searchNotes(user, q, 8) : [];
    const notes = (hits.length ? hits : recentNotes(user, 5)).map((n) => n.text);
    return { notes };
  }
});
