import { config } from '../config.js';
import { record } from '../metrics.js';
import { debug, who } from '../debuglog.js';

const tools = [];
const byName = new Map();

export function defineTool(def) {
  tools.push(def);
  byName.set(def.name, def);
}

/** The tools offered to the model. With a context, tools that are not available to this person are left out. */
export function toolSchemas(ctx) {
  return tools.filter((t) => !ctx || !t.available || t.available(ctx)).map((t) => ({
    type: 'function',
    function: {
      name: t.name,
      description: t.description,
      parameters: t.parameters
    }
  }));
}

export function getTool(name) {
  return byName.get(name);
}

export function toolNames() {
  return tools.map((t) => t.name);
}

export async function runTool(name, rawArgs, ctx = {}) {
  const tool = byName.get(name);
  if (!tool || (tool.available && !tool.available(ctx))) {
    debug('tool', { user: who(ctx.session?.userId), session: ctx.session?.id, name, ok: false, error: 'unknown or not available' });
    return { ok: false, error: `Unknown tool: ${name}` };
  }

  let args = {};
  if (typeof rawArgs === 'string' && rawArgs.trim()) {
    try {
      args = JSON.parse(rawArgs);
    } catch {
      return { ok: false, error: 'Tool arguments were not valid JSON.' };
    }
  } else if (rawArgs && typeof rawArgs === 'object') {
    args = rawArgs;
  }

  const started = Date.now();
  try {
    const result = await tool.run(args, ctx);
    const text = typeof result === 'string' ? result : JSON.stringify(result);
    const clipped = text.length > config.maxToolChars ? `${text.slice(0, config.maxToolChars)}\n…[truncated]` : text;
    record('tool', { name, ok: true, ms: Date.now() - started });
    debug('tool', { user: who(ctx.session?.userId), session: ctx.session?.id, name, args, ok: true, ms: Date.now() - started, result: clipped });
    return { ok: true, result: clipped };
  } catch (err) {
    const message = err?.message || String(err);
    debug('tool', { user: who(ctx.session?.userId), session: ctx.session?.id, name, args, ok: false, ms: Date.now() - started, error: message });
    record('tool', { name, ok: false, ms: Date.now() - started, error: message.replace(/https?:\/\/\S+/g, '<link>').slice(0, 80) });
    return { ok: false, error: message };
  }
}
