import { defineTool } from './registry.js';
import { config } from '../config.js';
import { mayDraw, instantImage } from '../images.js';
import { takeFromPool, poolSize } from '../pool.js';
import { adultOk } from '../gifs/pick.js';
import { repliesSince } from '../spontaneous.js';

/*
 * A picture of herself, whenever she wants one to go with what she is saying. It is only ever one already drawn ahead of
 * time (pool.js), so it appears at once and nobody waits for the graphics card because she felt like it; when there is
 * none in stock the tool says so and she just talks. Like her other media it is only offered once the conversation is
 * already heading that way. (Asking for a picture of something specific is generate_image, which draws it.)
 */
defineTool({
  name: 'send_picture',
  description:
    'Send a picture of yourself right now, when it feels right: flirty or heated moments, a "look at me", showing off. Not ' +
    'every message, and never when they are being serious. Do not describe it: it appears under your message by itself. ' +
    'If they ask for a specific scene, use generate_image instead.',
  parameters: { type: 'object', properties: {} },
  available: (ctx) => Boolean(config.images.pool) && mayDraw(ctx.session?.userId ?? 'local') && poolSize() > 0,
  async run(_args, ctx) {
    const session = ctx.session;
    if (!adultOk(session)) throw new Error('This is not the moment for that. Just talk.');
    if (repliesSince(session, 'image') < 4) throw new Error('You sent a picture a moment ago. Just talk this time.');
    const stock = await takeFromPool({ request: '', orientation: 'portrait' });
    if (!stock) throw new Error('You have no picture ready right now. Just talk.');
    const job = await instantImage({ userId: session.userId, sessionId: session.id, buffer: stock.buffer, orientation: 'portrait', prompt: stock.entry.prompt, request: stock.entry.request });
    // the same shape as a picture that was asked for and was ready at once (see chat.js)
    return { queued: true, ready: true, job: job.id, orientation: job.orientation, prompt: job.prompt, media: job.media };
  }
});
