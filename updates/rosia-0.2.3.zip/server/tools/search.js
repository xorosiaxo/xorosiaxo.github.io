import { defineTool } from './registry.js';
import { buildProviders, buildSupplement } from '../search/providers.js';
import { createSearcher } from '../search/searcher.js';
import { readLink } from '../links.js';
import { words } from '../embed.js';

/* Questions a reference work answers well get Wikipedia's top hits first. */
export const isReferenceQuery = (q) =>
  /^(what|who|when|where|which|why|how (many|much|old|tall|long|far|big))\b/i.test(q.trim()) &&
  !/\b(latest|news|today|tonight|now|current|price|score|won|winner|weather)\b/i.test(q);


/* Snippets are thin: for the top results the page itself is opened (through the same safe fetcher links use)
   and a short excerpt of its text is added, so she can answer from what the page says. */
const UNREADABLE = /(^|\.)(youtube\.com|youtu\.be|twitter\.com|x\.com|facebook\.com|instagram\.com|tiktok\.com|reddit\.com|linkedin\.com)$/i;

export async function addExcerpts(results, { count = 2, timeoutMs = 4500, read = readLink } = {}) {
  const targets = results
    .slice(0, count + 2)
    .filter((r) => {
      try {
        const u = new URL(r.url);
        return /^https?:$/.test(u.protocol) && !UNREADABLE.test(u.hostname) && !/\.pdf($|\?)/i.test(u.pathname);
      } catch {
        return false;
      }
    })
    .slice(0, count);

  const limit = new Promise((resolve) => setTimeout(resolve, timeoutMs));
  await Promise.race([
    Promise.all(
      targets.map(async (r) => {
        const page = await read(r.url, 'local', { textOnly: true });
        const text = (page.text || '').replace(/\s+/g, ' ').trim();
        if (page.ok && page.kind === 'page' && text.length >= 120) r.excerpt = text.slice(0, 700);
      })
    ),
    limit
  ]);
  return results;
}

/** The model tends to write a question; engines do better without the trailing punctuation. */
export function normaliseQuery(q) {
  return String(q).trim().replace(/[?!.]+$/, '').replace(/\s+/g, ' ');
}

/* Search engines sometimes answer a different question altogether. Keep only results that share at
   least one word with it. (If nothing does, the engine is treated as having failed.) */
const QUESTION_WORDS = new Set(['what', 'who', 'whom', 'when', 'where', 'which', 'why', 'how', 'tell', 'me', 'please', 'look', 'search', 'find', 'about', 'any', 'there']);

export function onTopic(results, query) {
  const terms = new Set(words(query).filter((w) => !QUESTION_WORDS.has(w)));
  if (!terms.size) return results;
  return results.filter((r) => words(`${r.title} ${r.snippet} ${r.url}`).some((w) => terms.has(w)));
}

export const searcher = createSearcher({
  providers: buildProviders(),
  supplement: buildSupplement(),
  isReference: isReferenceQuery,
  validate: (query, results) => onTopic(results, query)
});

defineTool({
  name: 'web_search',
  description:
    'Search the live web. Use for current events, news, prices, releases, sport, anything that changes, or anything you are not sure about. Returns titles, URLs, snippets and, for the top results, an excerpt of the page.',
  parameters: {
    type: 'object',
    properties: {
      query: { type: 'string', description: 'The search query, phrased like a person would type it.' },
      limit: { type: 'integer', description: 'How many results, 1-8. Default 5.' }
    },
    required: ['query']
  },
  async run({ query, limit }) {
    const clean = String(query || '').trim();
    if (!clean) throw new Error('Empty search query');
    const n = Math.min(Math.max(Number(limit) || 5, 1), 8);
    const found = await searcher.search(normaliseQuery(clean), n);
    if (!found.results.length) {
      return { query: clean, results: [], note: 'No results were returned for that query.' };
    }
    const results = onTopic(found.results.map((r) => ({ ...r })), clean);
    await addExcerpts(results);
    return { query: clean, provider: found.provider, results };
  }
});
