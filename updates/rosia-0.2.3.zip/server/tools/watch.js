import { defineTool } from './registry.js';
import { watchReady, searchVideos, startWatching, changeWatching, watchingOf, positionNow } from '../watch.js';
import { playerOf, act } from '../music/state.js';

/*
 * Watching a video together (watch.js). watch_video finds one on YouTube and puts it in their video window (any music
 * playing is paused, so the two do not play over each other); video_control pauses, resumes, restarts or closes it.
 */

const named = (w) => `"${w.title}"${w.channel ? ` by ${w.channel}` : ''}`;

defineTool({
  name: 'watch_video',
  description:
    'Watch a YouTube video together with them: it plays in a small window on their screen and you can see what is on. Use ' +
    'it when they ask to watch something ("watch the gta 6 trailer with me", "let\'s watch cat videos"). `query` is what to search for.',
  parameters: {
    type: 'object',
    properties: { query: { type: 'string', description: 'What to watch, in a few words.' } },
    required: ['query']
  },
  available: () => watchReady(),
  async run({ query }, ctx = {}) {
    const userId = ctx.session?.userId ?? 'local';
    const asked = String(query || '').trim();
    if (!asked) throw new Error('They did not say what to watch');
    const found = await searchVideos(asked, { signal: ctx.signal });
    if (!found.length) throw new Error(`Nothing was found for "${asked}"`);
    // the first one that will really play (a video can be blocked or private)
    let w = null;
    let lastError = null;
    for (const v of found.slice(0, 3)) {
      try {
        w = await startWatching(userId, v, { signal: ctx.signal });
        break;
      } catch (err) {
        lastError = err;
      }
    }
    if (!w) throw lastError || new Error('That video would not play');
    const player = playerOf(userId);
    if (player && !player.paused) act(userId, { type: 'pause' });
    return { watch: 'started', title: w.title, channel: w.channel, length: w.duration, musicPaused: Boolean(player && !player.paused) };
  }
});

defineTool({
  name: 'video_control',
  description: 'Control the video you are watching together: pause, resume, restart it from the start, or stop (close it).',
  parameters: {
    type: 'object',
    properties: { action: { type: 'string', enum: ['pause', 'resume', 'restart', 'stop'] } },
    required: ['action']
  },
  available: () => watchReady(),
  async run({ action }, ctx = {}) {
    const userId = ctx.session?.userId ?? 'local';
    const w = watchingOf(userId);
    if (!w) throw new Error('No video is on');
    const what = String(action || '').toLowerCase();
    if (what === 'restart') {
      changeWatching(userId, { type: 'seek', position: 0 });
      changeWatching(userId, { type: 'resume', position: 0 });
    } else if (['pause', 'resume', 'stop'].includes(what)) {
      changeWatching(userId, { type: what });
    } else {
      throw new Error('The video window cannot do that');
    }
    return { watch: what, title: w.title, at: Math.round(positionNow(w)), video: named(w) };
  }
});
