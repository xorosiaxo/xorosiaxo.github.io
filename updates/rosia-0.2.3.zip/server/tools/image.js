import { defineTool } from './registry.js';
import { imagesEnabled, mayDraw, enqueue, whyNot, normaliseOrientation, instantImage } from '../images.js';
import { styledPrompt } from '../preflight.js';
import { takeFromPool } from '../pool.js';
import { config } from '../config.js';

/*
 * Draws a brand-new picture on request (text to image). It only queues the job and returns at once, so
 * she can say a line about it; the picture arrives in the chat by itself when it is done, which takes a
 * minute or two on this machine. Her own pre-made photos (send_photo) are separate.
 *
 * However the request arrives, the prompt that reaches the image model is written in the style of the
 * examples in image-prompts.txt. When the request was spotted before the model spoke (preflight.js) it is
 * already styled and arrives marked `styled`; otherwise her own wording is rewritten here.
 */
if (imagesEnabled()) {
  defineTool({
    name: 'generate_image',
    description:
      'Draw a brand-new picture from a description. Use it when the person asks you to draw, generate, make or ' +
      'imagine a picture, image, scene or wallpaper of something. Do NOT use it when they just ask to see you ' +
      '(use send_photo for that) and never draw unprompted. Say what the picture should show in English: the ' +
      'subject, setting, lighting and mood. The picture takes a minute or two and shows up in the chat on its own.',
    parameters: {
      type: 'object',
      properties: {
        prompt: { type: 'string', description: 'What the picture should show, in English: subject, setting, lighting, mood.' },
        orientation: { type: 'string', enum: ['portrait', 'landscape', 'square'], description: 'Shape of the picture. Default portrait.' }
      },
      required: ['prompt']
    },
    available: (ctx) => mayDraw(ctx.session?.userId ?? 'local'),
    async run({ prompt, orientation, styled, request }, ctx) {
      const text = String(prompt || '').trim();
      if (text.length < 8) throw new Error('The picture needs a proper description.');
      const userId = ctx.session.userId;
      const refusal = whyNot(userId);
      if (refusal) throw new Error(refusal);
      const shape = normaliseOrientation(orientation);
      // what was asked for, without her description ("" is a plain "a picture of you"); the model's own call has just `prompt`
      const asked = request === undefined ? text : String(request).trim();

      // one drawn earlier while nobody was around fits what was asked: it is handed over at once
      if (config.images.pool) {
        const stock = await takeFromPool({ request: asked, orientation: shape });
        if (stock) {
          const done = await instantImage({ userId, sessionId: ctx.session.id, buffer: stock.buffer, orientation: shape, prompt: stock.entry.prompt, request: asked });
          return { queued: true, ready: true, job: done.id, orientation: done.orientation, prompt: done.prompt, media: done.media };
        }
      }

      const written = styled ? text : await styledPrompt(text, ctx.signal);
      const job = enqueue({ userId, sessionId: ctx.session.id, prompt: written, orientation: shape, request: asked });
      return { queued: true, job: job.id, orientation: job.orientation, prompt: job.prompt };
    }
  });
}
