import { defineTool } from './registry.js';
import { startGame, stopGame, openingLine, publicGames, GAMES } from '../games.js';

/*
 * One tool for games: start one, stop it, or say the scores. Everything in between (each question, guess, throw and
 * answer) is moved on by the app with every message (games.js, gameTurn in context.js), so she never has to call a
 * tool mid-game and cannot lose count.
 */

defineTool({
  name: 'game',
  description:
    'Play a game with them: start one when they ask to play ("twenty" = 20 questions, "rather" = would you rather, ' +
    '"truth" = truth or dare, "rps" = rock paper scissors, "knows" = how well you know them), stop the one going on, or ' +
    'check the scores you have kept across days. You can also suggest a game yourself when things are quiet and light.',
  parameters: {
    type: 'object',
    properties: {
      action: { type: 'string', enum: ['start', 'stop', 'scores'] },
      game: { type: 'string', enum: Object.keys(GAMES), description: 'Which game, for "start".' }
    },
    required: ['action']
  },
  available: (ctx) => Boolean(ctx?.user),
  async run({ action, game }, ctx = {}) {
    const { user } = ctx;
    if (!user) throw new Error('There is nobody to play with.');
    if (action === 'stop') {
      const stopped = await stopGame(user);
      return stopped ? { games: 'stopped', game: stopped.game, reveal: stopped.reveal } : { games: 'none' };
    }
    if (action === 'scores') return { games: 'scores', ...publicGames(user) };
    const started = await startGame(user, String(game || ''));
    return { games: 'started', game: started.game, record: started.record, opening: openingLine(user) };
  }
});
