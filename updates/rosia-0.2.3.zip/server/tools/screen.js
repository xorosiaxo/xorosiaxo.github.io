import { defineTool } from './registry.js';
import { visionSupported } from '../llm.js';
import { screenSupported, listWindows, chooseWindow, windowName, shotOf, rememberAsk, pendingAsk, clearAsk } from '../screen.js';

/*
 * look_at_screen: she looks at a window on the owner's computer (see screen.js). The picture itself is not put in the
 * tool's answer (it would be read as text): it is kept here for the reply being written, and chat.js shows it to her
 * vision model right after, as something she is looking at.
 */

const OWNER = 'local';
const looks = new Map(); // session id -> { name, url } waiting to be shown to her

/** The picture she just took for this conversation, once. */
export function takeLook(sessionId) {
  const look = looks.get(sessionId);
  looks.delete(sessionId);
  return look || null;
}

/** Their answer to "which one?": "the chrome one", "2", "the second", or a window's name. */
function answerPicks(windows, names, said) {
  const t = String(said || '').toLowerCase();
  const ORD = { first: 1, '1': 1, one: 1, second: 2, '2': 2, two: 2, third: 3, '3': 3, three: 3, fourth: 4, '4': 4, four: 4, fifth: 5, '5': 5, five: 5, last: names.length };
  const n = Object.entries(ORD).find(([w]) => new RegExp(`\\b${w}\\b`).test(t))?.[1];
  if (n && names[n - 1]) return windows.find((w) => windowName(w) === names[n - 1]) || null;
  return null;
}

defineTool({
  name: 'look_at_screen',
  description:
    'Look at a window on their screen, when they ask you to look at something, check what they are doing, or say "can ' +
    'you see this". `which` is the window they mean in their own words ("my code", "the chrome one"), or empty for the ' +
    'one they were just using. If it is not clear which, you get a list to ask them about.',
  parameters: {
    type: 'object',
    properties: { which: { type: 'string', description: 'Which window, in their words; empty for the one they were just using.' } },
    required: []
  },
  available: (ctx) => (ctx?.session?.userId ?? OWNER) === OWNER && screenSupported(),
  async run({ which } = {}, ctx = {}) {
    const session = ctx.session;
    if (!(await visionSupported())) return { screen: 'blind' };
    const windows = await listWindows();
    const said = String(which || '').trim() || [...(session?.messages || [])].reverse().find((m) => m.role === 'user')?.content || '';
    const pending = pendingAsk(session?.userId ?? OWNER);
    let picked = pending ? answerPicks(windows, pending.names, said) : null;
    let choice = picked ? { window: picked } : chooseWindow(windows, said);
    // an answer to her question that names nothing she listed: the first of what she listed, rather than asking forever
    if (pending && choice.ask) {
      const first = windows.find((w) => windowName(w) === pending.names[0]);
      if (first) choice = { window: first };
    }
    if (choice.none) return { screen: 'none' };
    if (choice.ask) {
      rememberAsk(session?.userId ?? OWNER, choice.ask);
      return { screen: 'ask', windows: choice.ask };
    }
    clearAsk(session?.userId ?? OWNER);
    const url = await shotOf(choice.window);
    const name = windowName(choice.window);
    if (session?.id) looks.set(session.id, { name, url });
    return { screen: 'looked', window: name };
  }
});

export { pendingAsk };
