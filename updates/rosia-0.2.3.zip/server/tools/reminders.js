import { defineTool } from './registry.js';
import { config } from '../config.js';
import { parseWhen, sayWhen, howLong } from '../reminders/when.js';
import { reminderRequest, aboutText } from '../reminders/intent.js';
import { addReminder, removeReminder, matchReminders, dueAt } from '../reminders/store.js';

/*
 * Reminders she keeps for a person. She only passes on the words ("call mum", "at 5pm"): the clock time is worked out
 * in code (reminders/when.js), in the person's own time zone, because a small model gets dates wrong. Where their own
 * message says when, that is what counts, whatever she wrote in `when`.
 *
 * When one is due the page shows it and she says it in the chat (index.js, kind 'remind'). The person can also add,
 * change and remove them by hand under Reminders.
 */

const lastSaid = (session) => [...(session?.messages || [])].reverse().find((m) => m.role === 'user')?.content || '';

defineTool({
  name: 'set_reminder',
  description:
    'Set a reminder for them: you will tell them at that time. Use it when they ask you to remind them of something, wake ' +
    'them, or set an alarm or a timer. Pass the time in their own words ("in 10 minutes", "at 5pm", "tomorrow morning", ' +
    '"every day at 8am"); never work out a date yourself. If they have not said when, ask them first.',
  parameters: {
    type: 'object',
    properties: {
      about: { type: 'string', description: 'What to remind them of, in a few words: "call mum", "take the pizza out".' },
      when: { type: 'string', description: 'When, exactly as they said it: "in 10 minutes", "at 5pm", "friday at 3".' }
    },
    required: ['about', 'when']
  },
  available: (ctx) => Boolean(ctx?.user),
  async run({ about, when }, ctx = {}) {
    const { user } = ctx;
    if (!user) throw new Error('There is nobody to remind.');
    const timeZone = ctx.timezone || config.timezone;
    const now = Date.now();
    const theirs = lastSaid(ctx.session);
    // their own words first: "remind me at 5 to call mum", or just "at 5" in answer to her asking when
    const asked = reminderRequest(theirs, now, timeZone);
    const time = asked || parseWhen(theirs, now, timeZone) || parseWhen(when, now, timeZone, { loose: true });
    const text = aboutText(about) || asked?.about || '';
    if (!time) return { reminder: 'need', missing: 'when', about: text };
    if (!text) return { reminder: 'need', missing: 'what' };
    const r = await addReminder(user, { text, at: time.at, repeat: time.repeat, tz: timeZone, by: 'chat' }, now);
    return { reminder: 'set', about: r.text, when: sayWhen(dueAt(r), now, timeZone), in: howLong(dueAt(r) - now), repeat: r.repeat || undefined };
  }
});

defineTool({
  name: 'cancel_reminder',
  description: 'Cancel a reminder you are keeping for them. Use it when they say they no longer need one. `which` is a few words from the reminder, or "all".',
  parameters: {
    type: 'object',
    properties: { which: { type: 'string', description: 'A few words from the reminder to cancel ("mum", "dentist"), or "all".' } },
    required: ['which']
  },
  // (always offered, even with nothing to cancel: a list of tools that changes from one message to the next makes the
  // model server read her whole prompt again)
  available: (ctx) => Boolean(ctx?.user),
  async run({ which }, ctx = {}) {
    const { user } = ctx;
    if (!user) throw new Error('There is nobody to remind.');
    const { hits, all } = matchReminders(user, which);
    const waiting = matchReminders(user, 'all').hits;
    if (!waiting.length) return { reminder: 'none' };
    if (!hits.length || (hits.length > 1 && !all)) {
      // none fits, or several do: she asks which, from the real list
      return { reminder: 'which', have: (hits.length ? hits : waiting).slice(0, 6).map((r) => r.text) };
    }
    for (const r of hits) await removeReminder(user, r.id);
    return { reminder: 'cancelled', about: hits.map((r) => r.text).slice(0, 6), count: hits.length };
  }
});
