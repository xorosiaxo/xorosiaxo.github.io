// The model opens each reply with a bracketed mood tag, e.g. "[teasing] oh, so now you want my opinion?".
// The interface reads the tag to pick her expression; the person never sees it.
//
// Small models do not always stick to the list: they write [playful], [excited], or a pose name like
// [feet] in the middle of a reply. A tag the page does not know used to be passed straight through to
// the person, which looked like a leak. Now:
//   - any single-word bracket tag at the very start is stripped, known or not
//   - an invented mood is mapped to the nearest real face (see MOOD_ALIASES)
//   - matching bracket tokens anywhere in the text are removed too (poses, invented moods)
//   - "[link](url)" and "[1]" are left alone: they are Markdown, not tags
//
// MoodFilter sits on the token stream: it holds back just enough of the first characters to tell
// whether the reply starts with a tag, strips it, and passes everything else straight through.
// With { stripLead: true } (used for the answer that follows a tool call) it also drops a leading
// "gimme a sec..." the model sometimes repeats after the results are already in.

export const MOODS = [
  'neutral', 'flirty', 'teasing', 'amused', 'curious', 'warm', 'surprised', 'worried',
  'smitten', 'aroused', 'ecstatic'
];

// Words the model invents as tags, mapped to the closest face that actually exists.
export const MOOD_ALIASES = {
  playful: 'teasing',
  cheeky: 'teasing',
  mischievous: 'teasing',
  excited: 'ecstatic',
  thrilled: 'ecstatic',
  happy: 'amused',
  cheerful: 'amused',
  laughing: 'amused',
  funny: 'amused',
  sad: 'neutral',
  bored: 'neutral',
  tired: 'neutral',
  sleepy: 'neutral',
  angry: 'neutral',
  annoyed: 'neutral',
  serious: 'neutral',
  calm: 'neutral',
  horny: 'aroused',
  'turned on': 'aroused',
  lustful: 'aroused',
  sexy: 'smitten',
  seductive: 'smitten',
  loving: 'warm',
  affectionate: 'warm',
  tender: 'warm',
  sweet: 'warm',
  shocked: 'surprised',
  nervous: 'worried',
  anxious: 'worried',
  concerned: 'worried',
  confused: 'curious',
  thoughtful: 'curious',
  interested: 'curious'
};

/** Every word that is a valid tag, real or aliased. */
export const MOOD_TAGS = new Set([...MOODS, ...Object.keys(MOOD_ALIASES)]);

/** The real mood for a tag the model wrote, or null when it is not a mood at all. */
export function moodFor(word) {
  const w = String(word || '').trim().toLowerCase();
  if (MOODS.includes(w)) return w;
  return MOOD_ALIASES[w] || null;
}

const MAX_TAG_CHARS = 20;
const LEAD_HOLD_CHARS = 40;
const LEAD_FILLER = /^\s*((gimme|give me) a (sec|second|moment|minute)|hold on|hang on|one (sec|second|moment))\b[\s.,…!-]*/i;
// a single-word bracket token, not the "[text](url)" form of a link; an optional " - " after it is eaten with it
const INLINE_TAG = /(^|[\s([{])?\[([A-Za-z][A-Za-z' -]{0,20})\](?!\()([ \t]*[—–:][ \t]*)?/g;

/** Removes bracket tokens that name a mood or a photo pose, leaving Markdown and [1] alone. */
export function removeTagTokens(text, words) {
  if (!words || !words.size) return String(text);
  return String(text).replace(INLINE_TAG, (match, lead = '', word) =>
    words.has(word.toLowerCase()) ? lead : match
  );
}

/** The last tidy-up before a reply is saved or shown: no tag tokens, no doubled spaces, no orphan dashes. */
export function stripBracketTags(text, words) {
  return removeTagTokens(text, words)
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/[ \t]+([.,!?…:;])/g, '$1')
    .replace(/^[ \t]*[—–:][ \t]*/gm, '')
    .replace(/[ \t]+$/gm, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

export class MoodFilter {
  constructor({ stripLead = false, inlineWords = null } = {}) {
    this.stripLead = stripLead;
    this.inline = inlineWords ? new Set([...inlineWords].map((w) => String(w).toLowerCase())) : null;
    this.state = 'probe'; // probe (looking for a tag) -> lead (optional) -> pass
    this.buf = '';
    this.tail = ''; // a possibly-unfinished "[word" held back while passing
    this.mood = null;
  }

  /** Feed raw model text; returns the text that is safe to show (possibly empty while holding). */
  push(text) {
    if (this.state === 'probe') return this.probe(text);
    if (this.state === 'lead') return this.pushLead(text);
    return this.inlineOut(text);
  }

  probe(text) {
    this.buf += text;
    let head = this.buf.replace(/^\s+/, '');
    let tags = 0;

    while (head[0] === '[' && tags < 2) {
      const close = head.indexOf(']');
      if (close === -1) {
        // still no closing bracket: if it's getting long it isn't a tag
        if (head.length > MAX_TAG_CHARS) return this.afterTag(this.buf);
        this.buf = head;
        return '';
      }
      const word = head.slice(1, close).trim();
      // "[link](url)" is Markdown; "[1]" is not a tag; only a single word can be a tag
      if (head[close + 1] === '(' || !/^[A-Za-z][A-Za-z' -]{0,20}$/.test(word)) {
        return this.afterTag(this.buf);
      }
      const mapped = moodFor(word);
      if (mapped) this.mood = mapped;
      head = head.slice(close + 1).replace(/^\s+/, '').replace(/^[—–:][ \t]*/, '');
      tags += 1;
    }

    if (!tags) return this.afterTag(this.buf);
    this.buf = '';
    return this.afterTag(head);
  }

  /** End of stream: hand back anything still held. */
  flush() {
    if (this.state === 'pass') {
      const held = this.tail;
      this.tail = '';
      return held;
    }
    const held = this.buf;
    this.buf = '';
    this.tail = '';
    const wasLead = this.state === 'lead';
    this.state = 'pass';
    return this.inlineOut(wasLead ? held.replace(LEAD_FILLER, '') : held);
  }

  afterTag(text) {
    if (!this.stripLead) return this.release(text);
    this.state = 'lead';
    this.buf = '';
    return this.pushLead(text);
  }

  pushLead(text) {
    this.buf += text;
    // wait for enough text to recognise a filler phrase, or for the line to end
    if (this.buf.length < LEAD_HOLD_CHARS && !this.buf.includes('\n')) return '';
    const out = this.buf.replace(LEAD_FILLER, '');
    this.buf = '';
    return this.release(out);
  }

  release(text) {
    this.state = 'pass';
    this.buf = '';
    return this.inlineOut(text);
  }

  /** While passing, drop tag tokens without touching spacing that is still streaming in. */
  inlineOut(text) {
    if (!this.inline) return text;
    const held = this.tail;
    let buf = held + text;
    this.tail = '';
    if (!buf) return '';
    const open = buf.lastIndexOf('[');
    if (open !== -1 && buf.indexOf(']', open) === -1 && buf.length - open <= MAX_TAG_CHARS + 2) {
      this.tail = buf.slice(open); // hold a fragment that may become a tag
      buf = buf.slice(0, open);
    }
    let out = removeTagTokens(buf, this.inline).replace(/[ \t]{2,}/g, ' ');
    // the held fragment came right after whatever was emitted last, so a space it now starts with
    // would double the one already shown ("ok " + " nice")
    if (held && out.startsWith(' ')) out = out.slice(1);
    return out;
  }
}
