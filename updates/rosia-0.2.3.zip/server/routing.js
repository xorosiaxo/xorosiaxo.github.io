/*
 * A small model often reaches for web_search when a dedicated tool exists. Where the right tool is
 * obvious from the words, the call is quietly redirected instead of hoping the model chooses well.
 */

const WEATHER = /\b(weather|forecast|temperature|how (hot|cold|warm|chilly)|(is|will|going to) (it )?(rain|snow|be (hot|cold|sunny|windy))|raining|snowing|umbrella)\b/i;

const TIME_WORDS = '(?:right now|at the moment|currently|today|tonight|tomorrow|this (?:morning|afternoon|evening|week|weekend)|now)';
const PLACE = /\b(?:in|for|at|near|around)\s+([A-Za-z][A-Za-z .,'-]{1,40}?)(?=\s+(?:right now|at the moment|currently|today|tonight|tomorrow|this|now)\b|\s*[?.!]*$)/i;

export function isWeatherQuestion(text) {
  return WEATHER.test(String(text || ''));
}

/** "what's the weather like in Leeds right now?" -> "Leeds". Empty when no place is named. */
export function weatherPlaceFrom(text) {
  const m = PLACE.exec(String(text || '').replace(new RegExp(`\\s+${TIME_WORDS}\\s*[?.!]*$`, 'i'), ''));
  return m ? m[1].replace(/[.,\s]+$/, '').trim() : '';
}

/** Returns the call to actually run (the same object when nothing needs changing). */
export function routeToolCall(call, lastUserText = '') {
  if (call.function.name !== 'web_search') return call;
  let query = '';
  try {
    query = String(JSON.parse(call.function.arguments || '{}').query || '');
  } catch {
    return call;
  }
  if (!isWeatherQuestion(query) && !isWeatherQuestion(lastUserText)) return call;
  const place = weatherPlaceFrom(query) || weatherPlaceFrom(lastUserText);
  if (!place) return call;
  return { ...call, function: { name: 'get_weather', arguments: JSON.stringify({ place }) } };
}
