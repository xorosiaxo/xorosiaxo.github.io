import { isWeatherQuestion, weatherPlaceFrom } from './routing.js';
import fs from 'node:fs';
import path from 'node:path';
import { complete } from './llm.js';
import { config } from './config.js';
import { loadBasePrompt, templateSlots, fillPromptTemplate } from './baseprompt.js';
import { musicIntent } from './music/intent.js';
import { playerOf } from './music/state.js';
import { reminderIntent } from './reminders/intent.js';
import { asksToLook, pendingAsk } from './screen.js';
import { gameNamed } from './games.js';
import { route } from './router.js';
import { debug, who } from './debuglog.js';
import { watchingOf } from './watch.js';

// "watch X with me", "let's watch X", "can we watch X": X is what to look for
const WATCH = /^(?:(?:ok(?:ay)?|hey|yo|so|babe|rosia|lol|lmao|haha+|hmm+|yeah|yea|yep|alright|aight|right|well|anyway|anyways|oh|ooh|cool|now|and|then|sure)[\s,.!]+)*(?:(?:let'?s|lets|can we|could we|wanna|want to|shall we|should we|i want to|we should|i wanna)\s+)?(?:go\s+)?watch\s+(.+?)[\s.!?]*$/i;

/*
 * Some requests leave no doubt about which tool is needed. A small model left to choose will sometimes skip
 * the tool and invent the answer (a made-up temperature, a made-up news item), so for these the tool is run
 * first and the model is only asked to say the result in her own voice.
 */

const SEARCH = /^\s*(?:please\s+)?(?:can you\s+|could you\s+)?(?:search(?: the web| online| the internet)?(?: for)?|look ?up|google|find out(?: about)?)\s*[:,]?\s+(.{3,200})$/i;
const NEWS = /\b(?:latest|current|breaking|today'?s|recent)\s+news\b/i;
const DRAW_VERB = /\b(?:draw|paint|sketch|illustrate|generate|create|make|render|imagine|design)\b/i;
const DRAW_NOUN = /\b(?:picture|image|pic|photo|painting|drawing|illustration|wallpaper|artwork|portrait|scene|poster|sketch)\b/i;
const OF_HER = /\b(?:of|from)\s+(?:you|yourself|u)\b|\b(?:you|yourself)\s+(?:in|wearing|on)\b/i; // that is her own photo (send_photo), not a drawing

/*
 * Asking to see her is a photo, not a drawing and not a web search. Small models answer it by
 * describing the picture in words ("[feet] — sitting on the floor, soles towards the camera...")
 * instead of calling send_photo, so where the words leave no doubt the tool is run first.
 */
const SEE_VERB = '(?:send|show|gimme|give|let me see|i want to see|can i see|lemme see)';
// "send you", "show u", "give ya": the person is the one doing the sending ("let me show you my new car")
const TO_HER = '(?!\\s+(?:you|u|ya|yu)\\b)';
const SEE_YOU = new RegExp(
  `\\b${SEE_VERB}\\b${TO_HER}[^.?!]{0,40}?\\b(?:pic|pics|picture|photo|selfie|snap|you|yourself|u)\\b|` +
  `\\b${SEE_VERB}\\b${TO_HER}[^.?!]{0,30}?\\b(?:swim ?suit|swimwear|one.?piece|bikini|gym (?:outfit|clothes|gear|wear))\\b|` +
  '\\b(?:what are you wearing|what have you got on|how do you look|turn around|your back|your feet|' +
  'your bikini|in a bikini|your swimsuit|in a swimsuit|your swimwear|your gym (?:outfit|clothes|gear|wear)|gymwear|gym wear|your sports bra|nude|naked|strip for me)\\b',
  'i'
);
const OF_YOU = /\b(?:of|from)\s+(?:you|yourself|u)\b/i;

// A short message that only names the next photo, said right after one ("hehe nice, from behind", "another one").
const PHOTO_FOLLOW_UP = /^\s*(?:(?:hehe+|haha+|nice|mmm+|ooh+|wow|yes|yeah|ok(?:ay)?|and|now|then|more|please|pls|hmm+)[\s,.!…-]*)*(?:from\s+(?:the\s+)?(?:back|behind)|(?:the\s+|your\s+)?(?:back|feet|bikini|front)|turn(?:ing)?\s+around|another(?:\s+one)?|one\s+more|more(?:\s+please)?|again|next)\b[\s\S]{0,25}$/i;
// a short message that only asks for more of what was just sent ("more", "keep sending", "mroe", "some other ones")
const MORE_MEDIA = /\b(?:more|moar|mroe|mor|another|again|next|keep\s+(?:them\s+)?(?:sending|coming|going|it\s+coming)|other\s+(?:ones?|gifs?|vid(?:eo)?s?)|different\s+(?:ones?|gifs?|vid(?:eo)?s?)|one\s+more)\b/i;
const POSE_ORDER = ['bikini', 'front', 'back', 'feet', 'kneeling', 'swimsuit', 'gymwear', 'swimsuit-back'];
const nextPose = (sent = []) => POSE_ORDER.find((p) => !sent.includes(p)) || POSE_ORDER[sent.length % POSE_ORDER.length];

// What the picture generator is told she looks like when the request is "a picture of you".
const HER_LOOK = 'a slim, tanned young woman in her early twenties with blonde hair with brown lowlights, blue eyes and a small silver nose stud';
const OF_YOURS = /\b(?:of|from)\s+yours\b/i;
// (an adjective or two may come between: "your big ass", "ur pretty little feet")
const PARTS = 'face|body|feet|foot|legs?|back|bum|butt|ass|arse|tits|boobs|breasts?|cleavage|thighs?|bikini|smile|hair|eyes|mouth|lips|pussy';
const BODY = new RegExp(`\\b(?:your|ur)\\s+(?:[a-z]+\\s+){0,2}?(?:${PARTS})\\b`, 'i');
const SEE_PART = new RegExp(`\\b${SEE_VERB}\\b${TO_HER}[^.?!]{0,30}?\\b(?:that|those|these)\\s+(?:[a-z]+\\s+){0,2}?(?:${PARTS})\\b`, 'i');
// "i didnt get the ass pic", "never got it", "it didn't send": they say what she sent never arrived
const DIDNT_GET = /\b(?:didn'?t|did not|never|haven'?t|have not|can'?t|cannot|couldn'?t|could not|don'?t|do not)\s+(?:even\s+)?(?:get|got|see|seen|receive|received|find|show|load|come|arrive)\b|\bnothing (?:came|arrived|showed|loaded)\b|\bdidn'?t (?:send|work)\b/i;
const NOT_HER =/\b(?:of|with|showing)\s+(?!you\b|yourself\b|u\b)\w/i; // "a picture of a lighthouse"

/**
 * "stop sending gifs", "don't send me any more videos", "i don't want pics", "i hate gifs": a refusal, never a request.
 * ("i never got the pic" is not one: that asks for it again.)
 */
export const REFUSAL = /\b(?:stop|quit|enough|no more)\b[^.?!]{0,30}\b(?:send|sending|gifs?|vid(?:eo)?s?|clips?|pics?|photos?|pictures?|selfies?)\b|\b(?:don'?t|dont|do not|never)\s+(?:ever\s+)?(?:send|show|want|need)\b[^.?!]{0,30}\b(?:gifs?|vid(?:eo)?s?|clips?|pics?|photos?|pictures?|selfies?|anything|more)\b|\bhate\b[^.?!]{0,15}\b(?:gifs?|vid(?:eo)?s?|clips?)\b/i;

// "draw me a bath", "draw the curtains", "draw a line under it": not pictures
const DRAW_IDIOM = /\bdraw(?:ing)?\s+(?:me\s+|us\s+)?(?:a\s+|the\s+|your\s+)?(?:bath|curtains?|blinds?|line|conclusions?|breath|attention|blood|straws?|crowd|card)\b/i;

// Which photo a request points at. Order matters: the most specific word wins.
const POSES = [
  [/(?:swim ?suit|swimwear|one.?piece).{0,30}(?:\bback\b|behind|from behind)|(?:\bback\b|behind).{0,30}(?:swim ?suit|swimwear|one.?piece)/, 'swimsuit-back'],
  [/bikini/, 'bikini'],
  [/swim ?suit|swimwear|one.?piece/, 'swimsuit'],
  [/\bgym\b|gymwear|workout|sports bra|activewear/, 'gymwear'],
  [/\bback\b|behind|from behind|turn around|ass\b|bum\b|butt\b/, 'back'],
  [/\bfeet\b|\bfoot\b|soles|toes/, 'feet'],
  [/kneel|on your knees/, 'kneeling'],
  [/front|facing|face on|looking at me/, 'front']
];

/** The pose a request asks for, or null. */
export function poseFor(text) {
  const t = String(text || '').toLowerCase();
  for (const [re, pose] of POSES) if (re.test(t)) return pose;
  return '';
}

/** True when the message is a request to see her (rather than to draw something or look something up). */
export function asksToSeeHer(text) {
  const t = String(text || '').trim();
  if (!t) return false;
  if (/\b(?:draw|paint|sketch|illustrate|render|generate|create|imagine|design)\b/i.test(t)) return false; // those want a new picture made
  if (BODY.test(t)) return true; // "show me your feet", "of your back"
  if (SEE_PART.test(t)) return true; // "show me that ass", "let me see those tits"
  if (OF_YOU.test(t) || OF_YOURS.test(t)) return true; // "a pic of you", "a photo of yours"
  if (NOT_HER.test(t)) return false; // "a picture of a lighthouse", "of your dog"
  return SEE_YOU.test(t);
}

/** Which tool a message clearly calls for, as { name, args }, or null. Pure: easy to test. */
export function detectIntent(text, available = [], context = {}) {
  const t = String(text || '').trim();
  if (!t) return null;
  // nothing is sent to someone saying not to send it (a lookup or the weather still can be); "draw me a bath" is not a picture
  const refused = REFUSAL.test(t);
  const blocked = new Set([...(refused ? ['send_photo', 'send_gif', 'send_video', 'send_picture'] : []), ...(refused || DRAW_IDIOM.test(t) ? ['generate_image'] : [])]);
  const has = (name) => available.includes(name) && !blocked.has(name);

  // "let's play 20 questions", "wanna play truth or dare?": a game, before the music (so it is not looked for as a song)
  if (has('game')) {
    const game = gameNamed(t);
    if (game && /\b(?:play|start|do|game|again|another|how well|quiz|test)\b/i.test(t) && !/\b(?:don'?t|do not|not now|later|stop)\b/i.test(t)) {
      return { name: 'game', args: { action: 'start', game } };
    }
    if (context.gameOn && /\b(?:stop|end|quit)\b[^.?!]{0,15}\bgame\b|\bwhat'?s the score\b/i.test(t)) {
      return { name: 'game', args: { action: /score/i.test(t) ? 'scores' : 'stop' } };
    }
    if (/\b(?:our|my|the|game) scores?\b|\bwho'?s winning\b|\bhow many (?:games|times) have i (?:won|lost)\b/i.test(t) && /\b(?:game|games|score|scores|won|winning)\b/i.test(t)) {
      return { name: 'game', args: { action: 'scores' } };
    }
  }

  // "watch the gta 6 trailer with me", "pause the video": watching together (watch.js)
  if (has('watch_video')) {
    const want = WATCH.exec(t);
    if (want && t.split(/\s+/).length <= 16) {
      const query = want[1].replace(/\s+(?:with me|together|with you|rn|right now|now|please|pls|babe)\b/gi, '').replace(/^(?:a|the|some)\s+(?=video|vid|clip)/i, '').replace(/^(?:videos?|vids?|clips?)\s+(?:of|about|on)\s+/i, '').trim();
      if (query.length >= 2 && !/^(?:out|me|you|it|this|that|something|tv|a movie|a film|over|your back|my back)$/i.test(query)) return { name: 'watch_video', args: { query } };
    }
    if (context.watching && /\b(?:video|vid|clip)\b/i.test(t) && t.split(/\s+/).length <= 10) {
      const action = /\b(?:stop|close|end|turn off|get rid of)\b/i.test(t) ? 'stop' : /\b(?:restart|start (?:it )?(?:again|over)|from the (?:start|beginning))\b/i.test(t) ? 'restart' : /\b(?:pause|hold on|wait)\b/i.test(t) ? 'pause' : /\b(?:resume|unpause|carry on|keep going|play)\b/i.test(t) ? 'resume' : '';
      if (action) return { name: 'video_control', args: { action } };
    }
  }

  // "pause", "skip this", "play something chill": the player is worked for her (music/intent.js says which wording counts)
  const music = musicIntent(t, { state: context.music || '' });
  if (music && has(music.name)) return music;

  // "remind me at 5 to call mum", "cancel the reminder about mum": saved (or removed) for her, with the time worked out in code
  const reminder = reminderIntent(t, { timeZone: context.timeZone });
  if (reminder && has(reminder.name)) return reminder;

  // "look at this", "can you see my screen": she looks (and their answer to her "which one?" picks the window)
  if (has('look_at_screen')) {
    if (asksToLook(t, { pictures: context.pictures || 0 })) return { name: 'look_at_screen', args: { which: '' } };
    if (context.screenAsk && t.split(/\s+/).length <= 10) return { name: 'look_at_screen', args: { which: t } };
  }

  // "i didnt get the ass pic": it did not arrive, so it is sent again (the kind they name, or the kind she sent last)
  if (t.split(/\s+/).length <= 14 && DIDNT_GET.test(t) && !/\b(?:draw|generate|create|make)\b/i.test(t)) {
    const names = { photo: /\b(?:pics?|photos?|pictures?|selfies?|image)\b/i.test(t), gif: /\bgifs?\b/i.test(t), video: /\b(?:vid(?:eo)?s?|clips?)\b/i.test(t) };
    const kind = names.gif ? 'gif' : names.video ? 'video' : names.photo || poseFor(t) ? 'photo' : context.lastMedia || '';
    if (kind === 'photo' && has('send_photo')) return { name: 'send_photo', args: { pose: poseFor(t) || nextPose(context.sentPoses) } };
    if (kind === 'video' && has('send_video')) return { name: 'send_video', args: { about: '', asked: true } };
    if (kind === 'gif' && has('send_gif')) return { name: 'send_gif', args: { vibe: String(context.lastReply || '').replace(/^\s*\[[a-z]+\]\s*/i, '').slice(0, 200) || 'playful tease', asked: true } };
  }

  // "hehe nice, from behind" / "now your feet" / "another one" right after a photo: the next photo
  const lastMedia = context.lastMedia || (context.recentPhoto ? 'photo' : '');
  if (has('send_photo') && lastMedia === 'photo' && PHOTO_FOLLOW_UP.test(t) && t.split(/\s+/).length <= 9) {
    return { name: 'send_photo', args: { pose: poseFor(t) || nextPose(context.sentPoses) } };
  }

  // "more", "keep sending", "mmm mroe", "some other ones" right after a GIF or a video: another of the same kind
  if ((lastMedia === 'gif' || lastMedia === 'video') && t.split(/\s+/).length <= 10 && MORE_MEDIA.test(t) && !asksToSeeHer(t) && !/\b(?:photos?|pics?|pictures?|selfies?)\b/i.test(t)) {
    if (lastMedia === 'video' && has('send_video')) return { name: 'send_video', args: { about: '', asked: true } };
    if (has('send_gif')) return { name: 'send_gif', args: { vibe: String(context.lastReply || '').replace(/^\s*\[[a-z]+\]\s*/i, '').slice(0, 200) || 'playful tease', asked: true } };
  }

  // "send me a gif", "got a gif of someone facepalming?": one from her collection (she cannot make new ones)
  if (has('send_gif') && /\bgifs?\b/i.test(t) && /\b(?:send|show|got|have|give|post|drop|find|another|more|moar|react|reply|respond|use|want|see|share|any|other|different|next|new|keep|sending)\b/i.test(t) && !/\b(?:make|create|generate|draw)\b/i.test(t)) {
    const of = /\bgifs?\s+(?:of|for|about|where|that|showing|with|when)\s+(.+)$/i.exec(t) || /\b(?:reacting to|reaction to)\s+(.+)$/i.exec(t);
    let vibe = of
      ? of[1]
      : t.replace(/\b(?:please|can you|could you|send|show|me|a|an|the|gifs?|another|more|one|give|got|any|your|react|with|reply|to|that|have|post|drop|find|use|want|see|share)\b/gi, ' ').replace(/\s+/g, ' ').trim();
    vibe = vibe.replace(/[?.!\s]+$/, '');
    if (vibe.length < 3) vibe = String(context.lastReply || '').slice(0, 200) || 'playful tease';
    return { name: 'send_gif', args: { vibe, asked: true } };
  }

  // "send me a video", "got any funny videos?": one of her saved favourites (a link their browser plays)
  if (has('send_video') && /\b(?:videos?|vids?)\b/i.test(t) && !/https?:\/\//i.test(t) && !/\b(?:video|vid)\s+(?:call|chat|game|games|editing|editor|calls)\b/i.test(t) &&
      /\b(?:send|show|got|have|give|post|drop|find|another|more|want|see|share|any|watch)\b/i.test(t) && !/\b(?:make|create|generate|draw|record|film|edit)\b/i.test(t)) {
    const of = /\b(?:videos?|vids?)\s+(?:of|for|about|where|that|showing|with|when)\s+(.+)$/i.exec(t);
    let about = of
      ? of[1]
      : t.replace(/\b(?:please|can you|could you|send|show|me|a|an|the|videos?|vids?|another|more|one|give|got|any|your|have|post|drop|find|want|see|share|watch|to|some|something|favou?rites?|saved)\b/gi, ' ').replace(/\s+/g, ' ').trim();
    about = about.replace(/[?.!\s]+$/, '');
    return { name: 'send_video', args: { about, asked: true } };
  }

  // "generate an image of you in a crop top": she has no ready photo of that, so it is drawn, with her look
  const wantsNew = /\b(?:generate|create|draw|paint|sketch|illustrate|render|imagine|design|make)\b/i.test(t) && DRAW_NOUN.test(t);
  if (has('generate_image') && wantsNew && (OF_HER.test(t) || /\byourself\b/i.test(t))) {
    const rest = t
      .replace(/^\s*(?:(?:hm+|ok(?:ay)?|please)[.,]?\s*)*(?:can you\s+|could you\s+|will you\s+)?(?:generate|create|draw|paint|sketch|illustrate|render|imagine|design|make)\s+(?:me\s+)?(?:a\s+|an\s+)?(?:[\w-]+\s+){0,2}?(?:picture|image|pic|photo|painting|drawing|illustration|artwork|portrait)\s+(?:of\s+)?/i, '')
      .replace(/^(?:you|yourself)\b\s*/i, '')
      .trim();
    // `scene` is what was asked for without her description, which is what a picture drawn earlier is matched against
    return { name: 'generate_image', args: { request: `${HER_LOOK}${rest ? `, ${rest}` : ''}`.slice(0, 600), scene: rest } };
  }

  // drawing is not set up here: the closest thing she can do is send one of her own photos
  if (has('send_photo') && !has('generate_image') && wantsNew && (OF_HER.test(t) || /\byourself\b/i.test(t))) {
    return { name: 'send_photo', args: poseFor(t) ? { pose: poseFor(t) } : {} };
  }

  if (has('send_photo') && asksToSeeHer(t)) {
    const pose = poseFor(t);
    return { name: 'send_photo', args: pose ? { pose } : {} };
  }

  if (has('get_weather') && isWeatherQuestion(t)) {
    const place = weatherPlaceFrom(t);
    if (place) return { name: 'get_weather', args: { place } };
  }

  if (has('generate_image') && !OF_HER.test(t)) {
    const starts = /^\s*(?:please\s+)?(?:can you\s+|could you\s+|will you\s+)?(?:draw|paint|sketch)\b/i.exec(t);
    if (starts || (DRAW_VERB.test(t) && DRAW_NOUN.test(t) && /\b(?:of|with|showing|about)\b/i.test(t))) {
      // the writer is shown as "Request: ...", so give it the thing itself rather than the instruction
      const request = t
        .replace(/^\s*(?:please\s+)?(?:can you\s+|could you\s+|will you\s+)?(?:draw|paint|sketch|illustrate|generate|render|create|make)\s+(?:me\s+|us\s+)?(?:a\s+|an\s+|some\s+)?/i, '')
        .replace(/^\s*(?:a\s+|an\s+)?(?:[\w-]+\s+){0,2}(?:picture|image|pic|photo|painting|drawing|illustration|wallpaper|artwork|portrait|scene|poster|sketch)\s+(?:of|showing|with)\s+/i, '')
        .trim();
      return { name: 'generate_image', args: { request: (request || t).slice(0, 600) } };
    }
  }

  if (has('web_search')) {
    const m = SEARCH.exec(t);
    if (m) return { name: 'web_search', args: { query: m[1].replace(/[?.!\s]+$/, '') } };
    if (NEWS.test(t)) return { name: 'web_search', args: { query: t.replace(/[?.!\s]+$/, '').slice(0, 200) } };
  }
  return null;
}

export function orientationFor(text) {
  const t = String(text).toLowerCase();
  if (/\b(landscape|wide|wallpaper|scenery|panorama|desktop|skyline|beach|mountains?|cityscape)\b/.test(t)) return 'landscape';
  if (/\b(square|icon|avatar|logo)\b/.test(t)) return 'square';
  return 'portrait';
}

/* ---------- the prompts she learns from ---------- */

/*
 * image-prompts.txt (next to package.json; kept out of git) holds examples of the prompts that work well with the
 * workflow. Examples are separated by a line with three dashes. An example can be just the prompt, or a pair:
 *
 *   Request: a girl reading in a cafe
 *   Prompt: framegrid, (candid phone photo :1.3) of ...
 *
 * With pairs she also learns how a short request is turned into a full prompt. If the file is missing,
 * image-prompts.example.txt is used.
 */

const root = path.resolve(import.meta.dirname, '..');
let cached = { file: '', mtime: 0, items: [] };

export function parseExamples(text) {
  return String(text || '')
    .split(/^\s*-{3,}\s*$/m)
    .map((block) => block.trim())
    .filter(Boolean)
    .filter((block) => !/^Examples of image prompts for Rosia/i.test(block))
    .map((block) => {
      const pair = /^\s*request\s*:\s*([\s\S]*?)\n\s*prompt\s*:\s*([\s\S]+)$/i.exec(block);
      return pair ? { request: pair[1].trim(), prompt: pair[2].trim() } : { request: '', prompt: block.replace(/^\s*prompt\s*:\s*/i, '').trim() };
    })
    .filter((e) => e.prompt.length >= 20);
}

export function loadExamples() {
  const candidates = [config.images.promptExamples, path.join(config.home, 'image-prompts.txt'), path.join(root, 'image-prompts.example.txt')].filter(Boolean);
  const file = candidates.find((f) => fs.existsSync(f));
  if (!file) return [];
  const mtime = fs.statSync(file).mtimeMs;
  if (cached.file !== file || cached.mtime !== mtime) cached = { file, mtime, items: parseExamples(fs.readFileSync(file, 'utf8')) };
  return cached.items;
}

const words = (t) => new Set(String(t).toLowerCase().match(/[a-z]{4,}/g) || []);

/** The examples most like this request (by shared words); a request that matches nothing still gets the first few. */
export function pickExamples(request, examples, count = 3) {
  const wanted = words(request);
  return examples
    .map((e, i) => ({ e, i, score: [...words(`${e.request} ${e.prompt}`)].filter((w) => wanted.has(w)).length }))
    .sort((a, b) => b.score - a.score || a.i - b.i)
    .slice(0, count)
    .map((x) => x.e);
}

const PROMPT_RULES =
  'You write prompts for a text-to-image model. Turn the person\'s request into ONE prompt in the same style as the examples. ' +
  'Copy the examples\' structure, vocabulary, level of detail, camera and style wording, and length. ' +
  'Keep every detail the person asked for exactly as they asked, whatever it is, and add concrete visual detail where the request is short. ' +
  'Say what is there, never what is not. Reply with the prompt only: no title, no quotes, no explanation.';

export function promptWriterSystem(request, examples = loadExamples()) {
  const chosen = pickExamples(request, examples);
  if (!chosen.length) {
    return `${PROMPT_RULES} Without examples: one rich English paragraph of 40 to 90 words with the subject, setting, lighting, mood, colours and a photographic or art style.`;
  }
  const shown = chosen.map((e, i) => (e.request ? `Example ${i + 1}\nRequest: ${e.request}\nPrompt: ${e.prompt}` : `Example ${i + 1}\nPrompt: ${e.prompt}`)).join('\n\n');
  return `${PROMPT_RULES}\n\nExamples of good prompts:\n\n${shown}`;
}

/**
 * Turns a request (or a prompt her own model already wrote) into one prompt in the style of the examples in
 * image-prompts.txt. Falls back to the text it was given when the model cannot be reached.
 */
export async function styledPrompt(request, signal) {
  // a template in image-base-prompt.txt (with [SLOTS]) takes over: the chat model fills the slots for this request
  const base = loadBasePrompt();
  if (templateSlots(base).length) return fillPromptTemplate(request, base, { signal });
  try {
    const out = await complete({
      messages: [{ role: 'system', content: promptWriterSystem(request) }, { role: 'user', content: `Request: ${request}\nPrompt:` }],
      maxTokens: 450,
      temperature: 0.7,
      signal
    });
    const clean = String(out || '').replace(/^["'\s]+|["'\s]+$/g, '').replace(/^(prompt|image prompt)\s*:\s*/i, '').trim();
    if (clean.length >= 20) return clean.slice(0, 1800);
  } catch (err) {
    if (err?.name === 'AbortError') throw err;
  }
  return request; // the person's own words are a fine prompt
}

/** The tool call to run before the model speaks, or null. */
export async function preflightCall({ session, schemas, signal, mode, tz, user }) {
  const last = [...session.messages].reverse().find((m) => m.role === 'user');
  // the "Create image" button on the page: whatever they typed is a description of the picture they want, no guessing
  if (mode === 'image' && schemas.some((t) => t.function.name === 'generate_image') && String(last?.content || '').trim().length >= 3) {
    const wanted = String(last.content).trim().slice(0, 600);
    return {
      id: 'call_pre_generate_image',
      type: 'function',
      function: { name: 'generate_image', arguments: JSON.stringify({ prompt: wanted, request: wanted, orientation: orientationFor(wanted) }) }
    };
  }
  const sentPoses = session.messages.filter((m) => m.photo).map((m) => m.photo);
  // what she sent most recently (within her last few messages): a follow-up like "more" means more of that
  const lastSent = [...session.messages].slice(-6).reverse().find((m) => m.photo || m.gif || m.video);
  const context = {
    lastMedia: lastSent ? (lastSent.video ? 'video' : lastSent.gif ? 'gif' : 'photo') : '',
    recentPhoto: session.messages.slice(-4).some((m) => m.photo),
    sentPoses: sentPoses.slice(-3),
    lastReply: [...session.messages].reverse().find((m) => m.role === 'assistant')?.content || '',
    // this person's player, if they have one open: "skip" only means the music while there is some
    music: ((p) => (p ? (p.paused ? 'paused' : 'playing') : ''))(playerOf(session.userId)),
    timeZone: tz || config.timezone, // "at 5" is five o'clock where they are
    pictures: last?.images?.length || 0,
    screenAsk: Boolean(pendingAsk(session.userId)), // she asked which window: a short answer picks it
    gameOn: Boolean(user?.games?.active), // a game is going: "stop the game" means that one
    watching: Boolean(watchingOf(session.userId)) // a video is on: "pause the video" means that one
  };
  const names = schemas.map((t) => t.function.name);
  let found = detectIntent(last?.content, names, context);
  // the word rules did not recognise it: the router decides by meaning ("how about some gta 6 music", "lets wtach ...")
  if (!found && !context.pictures && last?.content) {
    found = await route(last.content, names, context).catch(() => null);
    if (found) debug('router', { user: who(session.userId), session: session.id, text: String(last.content).slice(0, 120), name: found.name, args: found.args, why: found.why });
  }
  if (!found) return null;

  let args = found.args;
  if (found.name === 'generate_image') {
    // The shape comes from the whole message ("a wide picture of..."), not the stripped subject, which
    // has already thrown the shape words away. The prompt itself is written in the examples' style, so
    // the tool is marked `styled` and does not rewrite it a second time.
    // (the tool writes the prompt itself, unless a picture drawn earlier fits and is handed over at once)
    args = {
      prompt: found.args.request,
      request: found.args.scene ?? found.args.request,
      orientation: orientationFor(last?.content || found.args.request)
    };
  }
  return { id: `call_pre_${found.name}`, type: 'function', function: { name: found.name, arguments: JSON.stringify(args) } };
}
