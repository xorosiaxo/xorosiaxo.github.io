/*
 * "The two of you": a short history of a person and her, made from what is already stored. Nothing is written by a model
 * and nothing is saved: it is worked out when asked for. Pure, so it is tested directly.
 */

const DAY = 86_400_000;
const MAX = 40;
const COUNTS = [[10, 'Your tenth conversation'], [50, 'Your fiftieth conversation'], [100, 'Your hundredth conversation'], [250, 'Your 250th conversation'], [500, 'Your 500th conversation']];
const SPANS = [[30, 'A month of talking'], [182, 'Six months of talking'], [365, 'A year of talking'], [730, 'Two years of talking']];

/** `since` is when they first talked, if known: it holds even after their first conversation has been deleted. */
export function historyOf({ conversations = [], notes = [], pictures = [], since = 0, now = Date.now() } = {}) {
  const starts = (Array.isArray(conversations) ? conversations : []).map((c) => Number(c?.createdAt) || 0).filter(Boolean).sort((a, b) => a - b);
  if (!starts.length) return [];
  const first = since > 0 && since < starts[0] ? since : starts[0];
  const items = [{ at: first, text: 'You first talked' }];

  for (const [n, text] of COUNTS) if (starts.length >= n) items.push({ at: starts[n - 1], text });
  for (const [days, text] of SPANS) if (now >= first + days * DAY) items.push({ at: first + days * DAY, text });

  const pics = Array.isArray(pictures) ? pictures : [];
  const firstOf = (kind) => pics.filter((p) => p?.kind === kind && p.at).reduce((a, p) => (!a || p.at < a.at ? p : a), null);
  const photo = firstOf('photo');
  if (photo) items.push({ at: photo.at, text: 'She sent you her first photo' });
  const drawn = firstOf('drawn');
  if (drawn) items.push({ at: drawn.at, text: 'She drew you her first picture' });

  // things they told her were coming, once they have happened: the day itself is a day before the note stops mattering
  for (const n of Array.isArray(notes) ? notes : []) {
    if (!n?.expires || !n.text) continue;
    const day = n.expires - DAY;
    if (day <= now) items.push({ at: day, text: String(n.text).replace(/\s+/g, ' ').trim().slice(0, 120) });
  }

  items.sort((a, b) => b.at - a.at);
  if (items.length <= MAX) return items;
  const beginning = items.find((i) => i.text === 'You first talked');
  return [...items.filter((i) => i !== beginning).slice(0, MAX - 1), beginning];
}
