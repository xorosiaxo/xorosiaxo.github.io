import { config } from './config.js';
import { listSessions } from './sessions.js';
import { mediaUsage } from './media.js';

/*
 * Limits per person. They only ever say "no" to something new (a new conversation, another message in a
 * very long one, another picture); nothing is deleted to make room.
 */

export function quotaError(message) {
  const err = new Error(message);
  err.code = 'quota';
  err.status = 403;
  return err;
}

export async function conversationRoom(userId) {
  return (await listSessions(userId)).length < config.quota.conversations;
}

export function conversationFull(session) {
  return session.messages.length >= config.quota.messagesPerConversation;
}

export const TOO_MANY_CONVERSATIONS =
  "You've reached the most conversations this place keeps for one person. Nothing is removed automatically, so ask whoever runs this to raise the limit.";
export const CONVERSATION_FULL = 'This conversation has got very long. Start a new chat and carry on there; I will remember you.';

export async function usageOf(userId) {
  const conversations = (await listSessions(userId)).length;
  return {
    conversations: { used: conversations, limit: config.quota.conversations },
    mediaBytes: { used: await mediaUsage(userId), limit: config.quota.mediaBytes },
    messagesPerConversation: config.quota.messagesPerConversation
  };
}
