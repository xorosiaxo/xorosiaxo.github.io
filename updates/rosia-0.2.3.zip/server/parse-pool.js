import { Worker } from 'node:worker_threads';
import os from 'node:os';

/*
 * Pages from the internet are parsed on a small pool of worker threads, so:
 *  - the main thread keeps answering chats while a big page is being read, and several links are
 *    parsed truly in parallel on different CPU cores
 *  - a page that sends the regular expressions into a spin can only cost one worker for a couple of
 *    seconds: it is then terminated and replaced
 */

const POOL_SIZE = Math.max(1, Math.min(4, Math.floor((os.availableParallelism?.() || 2) / 2)));
const TIMEOUT_MS = 4000;

const workerFile = new URL('./parse-worker.js', import.meta.url);
const workers = []; // { worker, busy }
let nextId = 1;
const waiting = [];

function spawn() {
  const entry = { worker: new Worker(workerFile, { execArgv: [] }), busy: null };
  entry.worker.on('message', (msg) => {
    const job = entry.busy;
    if (!job || job.id !== msg.id) return;
    clearTimeout(job.timer);
    entry.busy = null;
    if (msg.error) job.reject(new Error(msg.error));
    else job.resolve(msg.result);
    pump();
  });
  entry.worker.on('error', () => replace(entry, new Error('The page could not be read.')));
  // after the listeners: adding a 'message' listener takes the reference back
  entry.worker.unref(); // an idle worker must not keep the process alive
  workers.push(entry);
  return entry;
}

function replace(entry, error) {
  const job = entry.busy;
  entry.busy = null;
  const i = workers.indexOf(entry);
  if (i >= 0) workers.splice(i, 1);
  entry.worker.terminate().catch(() => {});
  if (job) {
    clearTimeout(job.timer);
    job.reject(error);
  }
  pump();
}

function pump() {
  while (waiting.length) {
    let entry = workers.find((w) => !w.busy);
    if (!entry && workers.length < POOL_SIZE) entry = spawn();
    if (!entry) return;
    const job = waiting.shift();
    job.timer = setTimeout(() => replace(entry, new Error('That page was too complicated to read quickly.')), TIMEOUT_MS);
    entry.busy = job;
    entry.worker.postMessage({ id: job.id, html: job.html, base: job.base });
  }
}

export function parseInWorker(html, base) {
  return new Promise((resolve, reject) => {
    waiting.push({ id: nextId++, html, base, resolve, reject, timer: 0 });
    pump();
  });
}
