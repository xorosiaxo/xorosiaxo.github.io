import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';

/*
 * The debugging log: what people said, what the model wrote round by round, every tool call with its arguments and result,
 * and what was finally sent. It is for the person running the server, to work out what went wrong in a conversation.
 * (metrics.js is the other one: numbers only, no text.)
 *
 * data/logs/debug.jsonl, one JSON object per line: { t, event, ...fields }. When it passes 25 MB it moves to debug.1.jsonl
 * (replacing the older one), so at most about 50 MB is kept. It is never served over the web. Turn it off with
 * ROSA_DEBUG_LOG=0. Whole prompts (the system prompt and memory sent to the model) are only included with
 * ROSA_DEBUG_PROMPTS=1, because they are large.
 *
 * Link signatures and sign-in tokens are removed, and pictures (data: URLs) are left out.
 */

const MAX_BYTES = 25 * 1024 * 1024;
const MAX_STRING = 6000;

let pending = [];
let timer = 0;

const file = () => path.join(config.dataDir, 'logs', 'debug.jsonl');

export const debugEnabled = () => process.env.ROSA_DEBUG_LOG !== '0';
export const debugPrompts = () => process.env.ROSA_DEBUG_PROMPTS === '1';

/** A user id as shown in the log: enough to tell people apart, not the whole thing. */
export const who = (userId) => String(userId || '').slice(0, 8);

function tidy(s) {
  let out = String(s);
  out = out.replace(/data:[a-z]+\/[a-z0-9.+-]+;base64,[A-Za-z0-9+/=]+/gi, '<picture>');
  out = out.replace(/\bBearer\s+[A-Za-z0-9._~+/=-]{12,}/g, 'Bearer <token>');
  out = out.replace(/([?&])(hm|ex|is|token|sig|signature|key)=[^&\s"')]+/gi, '$1$2=…');
  return out.length > MAX_STRING ? `${out.slice(0, MAX_STRING)}… [${out.length - MAX_STRING} more characters]` : out;
}

function clean(value, depth = 0) {
  if (value == null || typeof value === 'number' || typeof value === 'boolean') return value;
  if (typeof value === 'string') return tidy(value);
  if (depth > 4) return '…';
  if (Array.isArray(value)) return value.slice(0, 40).map((v) => clean(v, depth + 1));
  if (value instanceof Error) return tidy(value.stack || value.message);
  if (typeof value === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      if (/^(vec|bytes|token|password)$/i.test(k) || typeof v === 'function' || Buffer.isBuffer(v)) continue;
      out[k] = clean(v, depth + 1);
    }
    return out;
  }
  return String(value);
}

export function flushDebug() {
  timer = 0;
  if (!pending.length) return;
  const chunk = `${pending.join('\n')}\n`;
  pending = [];
  try {
    fs.mkdirSync(path.dirname(file()), { recursive: true });
    if (fs.existsSync(file()) && fs.statSync(file()).size > MAX_BYTES) fs.renameSync(file(), path.join(path.dirname(file()), 'debug.1.jsonl'));
    fs.appendFileSync(file(), chunk);
  } catch {
    /* the log must never take the app down */
  }
}

/** Adds one line to the debugging log. Cheap: lines are written together, a moment later. */
export function debug(event, fields = {}) {
  if (!debugEnabled()) return;
  try {
    pending.push(JSON.stringify({ t: new Date().toISOString(), event, ...clean(fields) }));
  } catch {
    return;
  }
  if (pending.length >= 200) flushDebug();
  else if (!timer) {
    timer = setTimeout(flushDebug, 250);
    timer.unref?.();
  }
}

process.on('exit', flushDebug);
