import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';

/*
 * The version of this install. The single source of truth is "version" in package.json (semantic versioning: MAJOR.MINOR.PATCH,
 * optionally "-beta.1"); a release bumps it (scripts/release.js) and the updater (update.js) compares it with the latest one.
 */

const SEMVER = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/;

/** { major, minor, patch, pre } for a valid version, otherwise null. */
export function parseVersion(text) {
  const m = SEMVER.exec(String(text ?? '').trim());
  return m ? { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre: m[4] || '' } : null;
}

export const isVersion = (text) => parseVersion(text) !== null;

const comparePre = (a, b) => {
  if (a === b) return 0;
  if (!a) return 1; // 1.0.0 is newer than 1.0.0-beta.1
  if (!b) return -1;
  const x = a.split('.');
  const y = b.split('.');
  for (let i = 0; i < Math.max(x.length, y.length); i += 1) {
    if (x[i] === undefined) return -1;
    if (y[i] === undefined) return 1;
    const nx = /^\d+$/.test(x[i]);
    const ny = /^\d+$/.test(y[i]);
    if (nx && ny && Number(x[i]) !== Number(y[i])) return Number(x[i]) < Number(y[i]) ? -1 : 1;
    if (nx !== ny) return nx ? -1 : 1; // numbers sort before words
    if (!nx && x[i] !== y[i]) return x[i] < y[i] ? -1 : 1;
  }
  return 0;
};

/** -1, 0 or 1. Throws for something that is not a version, so a bad value is never mistaken for "older". */
export function compareVersions(a, b) {
  const x = parseVersion(a);
  const y = parseVersion(b);
  if (!x || !y) throw new Error(`Not a version: ${!x ? a : b}`);
  for (const key of ['major', 'minor', 'patch']) if (x[key] !== y[key]) return x[key] < y[key] ? -1 : 1;
  return comparePre(x.pre, y.pre);
}

export const isNewer = (candidate, current) => compareVersions(candidate, current) > 0;

/** "patch" | "minor" | "major" applied to a version. */
export function bump(version, kind) {
  const v = parseVersion(version);
  if (!v) throw new Error(`Not a version: ${version}`);
  if (kind === 'major') return `${v.major + 1}.0.0`;
  if (kind === 'minor') return `${v.major}.${v.minor + 1}.0`;
  if (kind === 'patch') return `${v.major}.${v.minor}.${v.patch + 1}`;
  throw new Error(`Unknown bump: ${kind}`);
}

let cached = null;

/** The version this install is running (read once: a new version only ever arrives with a restart). */
export function appVersion() {
  if (cached) return cached;
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(config.root, 'package.json'), 'utf8'));
    cached = isVersion(pkg.version) ? pkg.version : '0.0.0';
  } catch {
    cached = '0.0.0';
  }
  return cached;
}
