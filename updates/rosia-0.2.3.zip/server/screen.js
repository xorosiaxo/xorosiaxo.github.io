import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { config } from './config.js';

/*
 * "Look at this": she looks at a window on the owner's computer and talks about it.
 *
 * Only for the owner, on the computer Rosia runs on: a friend on a share link must never see the owner's screen, and
 * there is no screen to see from anywhere else. On Windows, screen.ps1 lists the windows on screen (top first: the one
 * at the top is the one they were using) and saves a picture of one, which her vision model is then shown.
 *
 * Which window: one they named ("look at my code", "the chrome one", "this game") if a window's name or program fits;
 * otherwise, when they named nothing, the one they were just using (the top window that is not Rosia). When what they
 * said fits several windows, or none, she asks which, naming a few, and their answer picks it.
 */

const SCRIPT = path.join(config.root, 'server', 'screen.ps1');
export const screenSupported = () => process.platform === 'win32' && !config.screen.off;

function ps(args, ms = 20_000) {
  return new Promise((resolve, reject) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', SCRIPT, ...args], { timeout: ms, windowsHide: true, maxBuffer: 4 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) reject(new Error(String(stderr || err.message).trim().split(/\r?\n/)[0].slice(0, 200)));
      else resolve(String(stdout || ''));
    });
  });
}

// Rosia's own windows (the app, or a browser showing her) are never what they mean
const OWN = /^rosia\b|\brosia\s*[-–—|]/i;

/** Rows from screen.ps1 as [{ id, app, title }], top first, her own windows left out. */
export function parseWindows(text) {
  return String(text || '')
    .split(/\r?\n/)
    .map((line) => line.split('\t'))
    .filter((p) => p.length >= 3 && /^\d+$/.test(p[0]))
    .map(([id, app, ...rest]) => ({ id, app: app.trim(), title: rest.join(' ').trim() }))
    .filter((w) => w.title && !OWN.test(w.title) && !/^(?:rosia|msedgewebview2|textinputhost|applicationframehost|shellexperiencehost)$/i.test(w.app));
}

export async function listWindows() {
  if (!screenSupported()) return [];
  return parseWindows(await ps(['list']));
}

/** A short name for a window, the way a person would say it: "Visual Studio Code: app.js", "Firefox: YouTube". */
export function windowName(w) {
  const APPS = { code: 'VS Code', chrome: 'Chrome', msedge: 'Edge', firefox: 'Firefox', explorer: 'File Explorer', discord: 'Discord', spotify: 'Spotify', steam: 'Steam', notepad: 'Notepad', winword: 'Word', excel: 'Excel', powerpnt: 'PowerPoint', obs64: 'OBS', vlc: 'VLC', whatsapp: 'WhatsApp', telegram: 'Telegram' };
  const app = APPS[w.app.toLowerCase()] || w.app;
  const title = w.title.replace(/\s*[-–—|]\s*(?:Mozilla Firefox|Google Chrome|Microsoft​? Edge|Visual Studio Code|Discord|Brave)\s*$/i, '').trim();
  return title.toLowerCase().includes(app.toLowerCase()) ? title.slice(0, 90) : `${app}: ${title}`.slice(0, 90);
}

const WORDS_FOR = {
  code: /\b(?:code|coding|script|function|bug|error|vs ?code|editor|programming)\b/i,
  chrome: /\b(?:chrome|browser|tab|website|site|page)\b/i,
  msedge: /\b(?:edge|browser|tab|website|site|page)\b/i,
  firefox: /\b(?:firefox|browser|tab|website|site|page)\b/i,
  explorer: /\b(?:files?|folders?|explorer)\b/i,
  discord: /\b(?:discord|server|dms?)\b/i,
  spotify: /\b(?:spotify|playlist)\b/i,
  steam: /\b(?:steam|game|games)\b/i,
  winword: /\b(?:word|essay|document|doc)\b/i,
  excel: /\b(?:excel|spreadsheet|sheet)\b/i,
  whatsapp: /\b(?:whatsapp|chat|messages?)\b/i
};
const VAGUE = new Set('look at this that it my the a an see screen window can you what do think of about me please here check out on just now one quick bit thing stuff rate tell how is does'.split(' '));

/**
 * Which window they mean, from what they said. Returns { window } when it is clear, { ask: [names] } when she should
 * ask, or { none: true } when nothing is open. Pure, for tests.
 */
export function chooseWindow(windows, said = '') {
  if (!windows.length) return { none: true };
  const text = String(said || '').toLowerCase();
  // words that could name a window: "my code", "the chrome one", "this game", "the youtube video"
  const words = text.replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((w) => w.length >= 3 && !VAGUE.has(w));
  const fits = windows.filter((w) => {
    const hay = `${w.app} ${w.title}`.toLowerCase();
    return words.some((x) => hay.includes(x)) || WORDS_FOR[w.app.toLowerCase()]?.test(text);
  });
  if (fits.length === 1) return { window: fits[0] };
  if (fits.length > 1) {
    // several fit: the top one is the one they were using, if it is far enough ahead of the rest to be the obvious one
    const exact = fits.filter((w) => words.some((x) => w.title.toLowerCase().includes(x)));
    if (exact.length === 1) return { window: exact[0] };
    return { ask: fits.slice(0, 5).map(windowName) };
  }
  // they named something no window has: ask, rather than guess wrong
  if (words.some((w) => !/^(?:this|that|thing|something|stuff)$/.test(w))) return { ask: windows.slice(0, 5).map(windowName) };
  // nothing named: the window they were just using
  return { window: windows[0] };
}

/** A picture of one window, as a data URL for her vision model. */
export async function shotOf(window) {
  const file = path.join(os.tmpdir(), `rosia-look-${crypto.randomBytes(6).toString('hex')}.png`);
  try {
    await ps(['shot', String(window.id), file]);
    const buf = await fs.readFile(file);
    return `data:image/png;base64,${buf.toString('base64')}`;
  } finally {
    fs.rm(file, { force: true }).catch(() => {});
  }
}

/* ---------- the question she asked, and the answer that picks the window ---------- */

const asked = new Map(); // userId -> { at, names }

export const rememberAsk = (userId, names) => asked.set(String(userId), { at: Date.now(), names });
export function pendingAsk(userId, now = Date.now()) {
  const a = asked.get(String(userId));
  if (!a || now - a.at > 5 * 60_000) return null;
  return a;
}
export const clearAsk = (userId) => asked.delete(String(userId));

/* ---------- what counts as asking her to look ---------- */

const LOOK = /\b(?:look|looking|see|check|peep|glance|have a look|take a look)\b[^.?!]{0,30}\b(?:this|my screen|the screen|screen|what i'?m (?:doing|looking at|playing|watching|working on|reading)|my (?:code|game|work|tab|window|desktop|setup|build))\b|\bcan you see (?:this|my screen|it|what i'?m)\b|\bwhat do you (?:think|reckon) (?:of|about) (?:this|my screen|what i'?m (?:doing|playing|watching|working on))\b|\b(?:rate|roast|judge) (?:my|this) (?:screen|setup|code|desktop|tab|build)\b|\bwhat'?s on my screen\b/i;

/**
 * True when a message asks her to look at their screen (and is not about a picture or link they sent with it).
 * `pictures` is how many pictures came with the message.
 */
export function asksToLook(text, { pictures = 0 } = {}) {
  const t = String(text || '');
  if (pictures || /https?:\/\//i.test(t)) return false;
  if (/\b(?:pic|pics|picture|photo|selfie|outfit|you)\b[^.?!]{0,12}$/i.test(t) && !/\bscreen\b/i.test(t)) return false;
  // "i look at this every day": telling her what they do, not asking her to look
  if (/\b(?:i|we|they|he|she)\s+(?:\w+ly\s+|always\s+|often\s+|never\s+)?(?:look|looked|see|saw|check|checked)\b/i.test(t)) return false;
  return LOOK.test(t);
}
