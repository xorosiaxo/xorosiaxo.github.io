/* Everything she has sent that is a picture of her or by her, across a person's conversations. Pure: it is handed the
   conversations and returns a list, so it is tested directly. */

const MAX = 500;
const POSE = /^[a-z][a-z-]{0,30}$/;
const MEDIA = /^[A-Za-z0-9_-]+\.[a-z0-9]{2,5}$/;

export function galleryOf(sessions) {
  const out = [];
  for (const session of Array.isArray(sessions) ? sessions : []) {
    for (const m of Array.isArray(session?.messages) ? session.messages : []) {
      if (m?.role !== 'assistant') continue;
      const at = Number(m.at) || 0;
      if (typeof m.photo === 'string' && POSE.test(m.photo)) {
        out.push({ kind: 'photo', src: `/assets/avatar/web/photo-${m.photo}.webp`, at, conversation: session.id });
      }
      const im = m.image;
      if (im?.state === 'done' && typeof im.media === 'string' && MEDIA.test(im.media)) {
        out.push({ kind: 'drawn', src: `/media/${im.media}`, at, conversation: session.id });
      }
    }
  }
  return out.sort((a, b) => b.at - a.at).slice(0, MAX);
}
