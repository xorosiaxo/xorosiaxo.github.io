import { activeNotes, saveUser } from './users.js';
import { dayOf } from './diary.js';

/*
 * Days that matter: their birthday (from what they told her: "my birthday is 14 march"), and the anniversaries of the
 * day they first talked (each month for the first year, then each year). On the day, she knows, and makes something of
 * it once: when her reply mentions it, it is marked as said for that day.
 */

const MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
const MONTH = `(${MONTHS.map((m) => `${m.slice(0, 3)}(?:${m.slice(3)})?`).join('|')})`;

/** Their birthday as { month (1-12), day }, from a note that says it, or null. Pure, for tests. */
export function birthdayIn(text) {
  const t = String(text || '').toLowerCase();
  if (!/\b(?:birthday|born|bday|b-day)\b/.test(t)) return null;
  let m = new RegExp(`\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?${MONTH}\\b`).exec(t);
  let day;
  let month;
  if (m) {
    day = Number(m[1]);
    month = MONTHS.findIndex((x) => x.startsWith(m[2].slice(0, 3))) + 1;
  } else {
    m = new RegExp(`\\b${MONTH}\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b`).exec(t);
    if (!m) return null;
    month = MONTHS.findIndex((x) => x.startsWith(m[1].slice(0, 3))) + 1;
    day = Number(m[2]);
  }
  return day >= 1 && day <= 31 && month >= 1 ? { month, day } : null;
}

/** The special thing about today for them, as { key, line }, or null. */
export function occasionToday(user, { now = Date.now(), timeZone = 'UTC' } = {}) {
  const today = dayOf(now, timeZone);
  const [, mm, dd] = today.split('-').map(Number);
  const done = user?.celebrated || {};

  for (const note of activeNotes(user || { notes: [] })) {
    const b = birthdayIn(note.text);
    if (b && b.month === mm && b.day === dd) {
      const key = `birthday:${today}`;
      if (done[key]) return null;
      return { key, line: 'Today is their birthday. Make a real fuss of them: wish them a happy birthday warmly, in your own way, before anything else, and ask what they are doing for it.' };
    }
  }

  if (user?.firstSeenAt) {
    const first = dayOf(user.firstSeenAt, timeZone);
    const [fy, fm, fd] = first.split('-').map(Number);
    const [ty] = today.split('-').map(Number);
    if (fd === dd && first !== today) {
      const months = (ty - fy) * 12 + (mm - fm);
      let what = '';
      if (months > 0 && months % 12 === 0) what = `${months / 12} year${months === 12 ? '' : 's'}`;
      else if (months > 0 && months < 12) what = `${months} month${months === 1 ? '' : 's'}`;
      const key = `anniversary:${today}`;
      if (what && !done[key]) {
        return { key, line: `Today is exactly ${what} since you two first talked (${first}). Mention it sweetly, in your own words, once: you noticed.` };
      }
    }
  }
  return null;
}

/** After her reply: an occasion she was told about is marked as said once her reply mentions it. */
export async function markOccasion(user, occasion, replyText) {
  if (!occasion) return false;
  if (!/\b(?:birthday|bday|anniversary|month|months|year|years|since we|since you|first talked|celebrat)/i.test(String(replyText || ''))) return false;
  user.celebrated = { ...(user.celebrated || {}), [occasion.key]: Date.now() };
  // only the last year or so is kept
  const keys = Object.keys(user.celebrated);
  if (keys.length > 40) for (const k of keys.slice(0, keys.length - 40)) delete user.celebrated[k];
  await saveUser(user);
  return true;
}

// the occasion she was told about for each person's reply, so the reply can be checked for it
const offered = new Map();
export const offerOccasion = (userId, occasion) => (occasion ? offered.set(String(userId), occasion) : offered.delete(String(userId)));
export function takeOccasion(userId) {
  const o = offered.get(String(userId)) || null;
  offered.delete(String(userId));
  return o;
}
