import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from './config.js';
import { deleteMedia } from './media.js';
import { linkNote } from './links.js';
import { coalescedWriter } from './atomic.js';
import { outfitOf } from './outfits.js';
import { plainTitle } from './replytext.js';

/*
 * Conversations. One JSON file each in data/sessions/. What she knows *about the person* lives in
 * users.js; a conversation only holds its own messages, a title and a rolling summary of the turns
 * that have scrolled out of the model's window.
 */

// small LRU: a Map iterates in insertion order, so re-inserting on access keeps hot sessions last
const sessions = new Map();
// Every conversation object anyone still holds (a reply in progress, a background job), even after the LRU let it go: a
// later load hands back that same object instead of reading a second copy from disk, so two copies never overwrite each other.
const live = new Map(); // id -> WeakRef(session)
const reading = new Map(); // id -> the read in progress, so two loads at once share it
const forget = new FinalizationRegistry((id) => {
  if (!live.get(id)?.deref()) live.delete(id);
});

function remember(session) {
  sessions.delete(session.id);
  sessions.set(session.id, session);
  if (live.get(session.id)?.deref() !== session) {
    live.set(session.id, new WeakRef(session));
    forget.register(session, session.id);
  }
  while (sessions.size > config.sessionCacheMax) {
    sessions.delete(sessions.keys().next().value);
  }
}

function sessionsDir() {
  return path.join(config.dataDir, 'sessions');
}

function fileFor(id) {
  return path.join(sessionsDir(), `${id}.json`);
}

function safeId(raw) {
  const id = String(raw || '').trim();
  if (!/^[A-Za-z0-9_-]{8,64}$/.test(id)) return null;
  return id;
}

export function newSessionId() {
  return crypto.randomBytes(16).toString('hex');
}

export function normaliseId(raw) {
  return safeId(raw);
}

function blank(id, userId = 'local') {
  return {
    id,
    userId,
    title: '',
    titleByUser: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    messages: [],
    summary: { text: '', upTo: 0 },
    extractedUpTo: 0
  };
}

function fromDisk(id, data) {
  const s = blank(id, data.userId || 'local');
  return Object.assign(s, {
    title: typeof data.title === 'string' ? data.title : '',
    titleByUser: Boolean(data.titleByUser),
    createdAt: data.createdAt || s.createdAt,
    updatedAt: data.updatedAt || s.updatedAt,
    messages: Array.isArray(data.messages) ? data.messages : [],
    summary: data.summary && typeof data.summary.text === 'string' ? data.summary : s.summary,
    extractedUpTo: data.extractedUpTo || 0,
    importedFrom: typeof data.importedFrom === 'string' ? data.importedFrom : undefined, // see portability.js
    legacyMemory: Array.isArray(data.memory) ? data.memory : undefined // pre-profile notes, migrated at start-up
  });
}

async function readSession(id) {
  if (reading.has(id)) return reading.get(id);
  const job = fs
    .readFile(fileFor(id), 'utf8')
    .then((text) => fromDisk(id, JSON.parse(text)))
    .catch(() => null)
    .finally(() => reading.delete(id));
  reading.set(id, job);
  return job;
}

/** Loads a conversation. Returns null if it doesn't exist or belongs to someone else. */
export async function loadSession(rawId, userId = 'local') {
  const id = safeId(rawId);
  if (!id) return null;

  let session = sessions.get(id) || live.get(id)?.deref();
  if (!session) {
    const read = await readSession(id);
    // another load may have finished first: keep the one object
    session = sessions.get(id) || live.get(id)?.deref() || read;
  }
  if (!session || session.deleted) return null;
  remember(session);
  return session.userId === userId ? session : null;
}

export function createSession(userId = 'local') {
  const session = blank(newSessionId(), userId);
  remember(session);
  return session;
}

/* ---------- index of conversations (for the history list) ---------- */

let metaIndex = null; // id -> meta

function previewOf(messages) {
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    const m = messages[i];
    if ((m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content.trim()) {
      return m.content.replace(/\s+/g, ' ').trim().slice(0, 90);
    }
    if (m.images?.length) return 'Picture';
    if (m.photo) return 'Photo';
  }
  return '';
}

function firstWords(messages) {
  return plainTitle(messages.find((m) => m.role === 'user' && m.content)?.content || '');
}

function metaOf(session) {
  return {
    id: session.id,
    userId: session.userId,
    title: session.title || firstWords(session.messages),
    createdAt: session.createdAt,
    updatedAt: session.updatedAt,
    count: session.messages.length,
    preview: previewOf(session.messages)
  };
}

let building = null; // the first build of the index, shared by everyone who asks while it runs

async function buildIndex() {
  const index = new Map();
  let files = [];
  try {
    files = (await fs.readdir(sessionsDir())).filter((f) => f.endsWith('.json'));
  } catch {
    files = [];
  }
  for (const file of files) {
    const id = file.slice(0, -5);
    if (!safeId(id)) continue;
    try {
      const s = fromDisk(id, JSON.parse(await fs.readFile(path.join(sessionsDir(), file), 'utf8')));
      index.set(id, metaOf(s));
    } catch {
      /* unreadable file: leave it alone */
    }
  }
  // saves that happened while it was being read are newer than the files were
  for (const [id, meta] of pendingMeta) index.set(id, meta);
  for (const id of deletedIds) index.delete(id);
  pendingMeta.clear();
  metaIndex = index;
}

// what changed while the index was still being built (it is only assigned once complete)
const pendingMeta = new Map();
const deletedIds = new Set();

function indexSet(session) {
  if (session.deleted) return;
  if (metaIndex) metaIndex.set(session.id, metaOf(session));
  else pendingMeta.set(session.id, metaOf(session));
}

export async function listSessions(userId = 'local') {
  if (!metaIndex) {
    building ||= buildIndex().finally(() => {
      building = null;
    });
    await building;
  }
  return [...metaIndex.values()]
    .filter((m) => m.userId === userId && m.count > 0)
    .sort((a, b) => b.updatedAt - a.updatedAt);
}

/** The most recent *other* conversation, for greetings that pick up where the last one left off. */
export async function lastConversation(userId, exceptId) {
  const list = await listSessions(userId);
  const meta = list.find((m) => m.id !== exceptId);
  return meta ? loadSession(meta.id, userId) : null;
}

export async function renameSession(id, userId, title) {
  const session = await loadSession(id, userId);
  const clean = String(title || '').replace(/\s+/g, ' ').trim().slice(0, 60);
  if (!session || !clean) return null;
  session.title = clean;
  session.titleByUser = true;
  await saveSession(session);
  return session;
}

export async function deleteSession(id, userId) {
  const session = await loadSession(id, userId);
  if (!session) return false;
  session.deleted = true; // a save that is still queued must not bring the file back (nor the list entry)
  sessions.delete(session.id);
  live.delete(session.id);
  metaIndex?.delete(session.id);
  pendingMeta.delete(session.id);
  deletedIds.add(session.id);
  // Pictures they sent go with the conversation. Pictures she drew for them (m.image.media) are kept on purpose, and so is
  // the debugging log: deleting a chat only takes it out of their list.
  await deleteMedia(
    session.userId,
    session.messages.flatMap((m) => [...(m.images || []), ...(m.links || []).map((l) => l.image).filter(Boolean)])
  );
  await fs.rm(fileFor(session.id), { force: true });
  return true;
}

/* ---------- saving ---------- */

const write = coalescedWriter('session');

export function saveSession(session, { touch = true } = {}) {
  if (touch) session.updatedAt = Date.now();
  // Nothing is ever cut from a conversation on disk: the model only sees a window of it (windowStart) plus a summary of
  // the rest, and a conversation stops taking new messages at quota.messagesPerConversation instead.
  indexSet(session);
  // the file is built when it is written, so several saves in a row become one write of the latest state
  return write(fileFor(session.id), () => {
    if (session.deleted) return null;
    const { legacyMemory, ...persistable } = session;
    void legacyMemory;
    return JSON.stringify(persistable);
  });
}

export function appendMessage(session, role, content, extra = {}) {
  session.messages.push({ role, content, at: Date.now(), ...extra });
}

/**
 * Older conversations kept their notes inside the session file. Move them into the person's
 * memory once, then drop them from the session.
 */
export async function takeLegacyMemory() {
  let files = [];
  try {
    files = (await fs.readdir(sessionsDir())).filter((f) => f.endsWith('.json'));
  } catch {
    return [];
  }
  const found = [];
  for (const file of files) {
    const id = file.slice(0, -5);
    try {
      const raw = JSON.parse(await fs.readFile(path.join(sessionsDir(), file), 'utf8'));
      if (Array.isArray(raw.memory) && raw.memory.length) {
        found.push(...raw.memory.map((m) => m.text).filter(Boolean));
        delete raw.memory;
        await fs.writeFile(path.join(sessionsDir(), file), JSON.stringify(raw, null, 2), 'utf8');
        sessions.delete(id);
      }
    } catch {
      /* skip */
    }
  }
  return found;
}

/* ---------- what the model is shown ---------- */

export function windowStart(session) {
  // The window start only moves in steps of historyStep messages. A sliding window would change the
  // first message of the prompt every turn and defeat the model server's prefix cache.
  const n = session.messages.length;
  const max = config.historyForModel;
  return n > max ? Math.ceil((n - max) / config.historyStep) * config.historyStep : 0;
}

/**
 * The recent conversation as chat messages.
 * Returns { messages, preface } where `preface` is anything she said before the person's first
 * message in the window (a greeting): templates want the conversation to open with the user, so
 * the caller folds it into the first message.
 */
export function historyForModel(session) {
  const all = session.messages;
  const lastIndex = all.length - 1;
  const out = [];
  const preface = [];

  all.slice(windowStart(session)).forEach((m, i, slice) => {
    if (m.role !== 'user' && m.role !== 'assistant') return;
    const isLast = windowStart(session) + i === lastIndex;

    // assistant turns are replayed exactly as the model wrote them (mood tag included) so the prompt
    // matches what the server already has cached
    let content = m.role === 'assistant' && typeof m.raw === 'string' && m.raw.trim() ? m.raw : m.content;
    if (typeof content !== 'string') content = '';
    // the model can't see pictures it sent, so remind it in words
    // and what she is wearing in it, so a later "what are you wearing?" matches the picture they saw
    if (m.photo) content += ` (you sent them a ${m.photo} photo with this message${outfitOf(m.photo) ? `, wearing ${outfitOf(m.photo)}` : ''})`;
    // links they shared: the page text is stored on the message, so later turns still know what it said
    if (m.role === 'user' && m.links?.length) content += '\n\n' + linkNote(m.links, isLast);
    // pictures: the ones they attached, and (for the newest message) the ones that came from their links
    const linkPictures = isLast ? (m.links || []).map((l) => l.image).filter(Boolean) : [];
    const images = m.role === 'user' ? [...(m.images || []), ...linkPictures] : [];
    if (images.length && !isLast) content += images.length > 1 ? ' [they sent some pictures]' : ' [they sent a picture]';
    if (!content.trim() && !(isLast && images.length)) return;
    void slice;

    const prev = out.at(-1);
    // a stopped or failed reply leaves two user turns in a row; many chat templates (Gemma's
    // included) reject non-alternating roles, so fold them into one message
    if (prev && prev.role === m.role) {
      prev.content = `${prev.content}\n\n${content}`.trim();
      if (isLast && images.length) prev.images = images;
    } else if (!out.length && m.role === 'assistant') {
      preface.push(content);
    } else {
      out.push({ role: m.role, content: content.trim(), images: isLast && images.length ? images : undefined });
    }
  });

  return { messages: out, preface: preface.join('\n\n') };
}
