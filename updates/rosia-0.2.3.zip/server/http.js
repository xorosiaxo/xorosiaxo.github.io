import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const buckets = new Map();

export function rateLimit({ windowMs, max, key: keyOf }) {
  return (req, res, next) => {
    const key = (keyOf && keyOf(req)) || req.ip || req.socket?.remoteAddress || 'anon';
    const now = Date.now();
    let bucket = buckets.get(key);
    if (!bucket || now - bucket.start > windowMs) {
      bucket = { start: now, count: 0 };
      buckets.set(key, bucket);
    }
    bucket.count += 1;
    if (bucket.count > max) {
      res.statusCode = 429;
      res.setHeader('content-type', 'application/json');
      res.end(JSON.stringify({ error: 'Slow down a sec. Too many messages.' }));
      return;
    }
    next();
  };
}

setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of buckets) {
    if (now - bucket.start > 10 * 60_000) buckets.delete(key);
  }
}, 5 * 60_000).unref();

export const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.mp3': 'audio/mpeg',
  '.txt': 'text/plain; charset=utf-8'
};

/* Text files are compressed once (Brotli and gzip) and kept in memory until the file changes, so a
   page load sends a fraction of the bytes and costs the server no CPU after the first request.
   Pictures are already compressed, so they are sent as they are. */
const COMPRESSIBLE = new Set(['.html', '.css', '.js', '.json', '.svg', '.txt']);
const cache = new Map(); // file path -> { stamp, raw, br, gz }

function pickEncoding(acceptEncoding = '') {
  if (/\bbr\b/.test(acceptEncoding)) return 'br';
  if (/\bgzip\b/.test(acceptEncoding)) return 'gzip';
  return '';
}

async function loadCompressed(filePath, stamp) {
  const hit = cache.get(filePath);
  if (hit && hit.stamp === stamp) return hit;
  const raw = await fs.readFile(filePath);
  const [br, gz] = await Promise.all([
    new Promise((resolve, reject) =>
      zlib.brotliCompress(raw, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 6 } }, (e, out) => (e ? reject(e) : resolve(out)))
    ),
    new Promise((resolve, reject) => zlib.gzip(raw, { level: 9 }, (e, out) => (e ? reject(e) : resolve(out))))
  ]);
  const entry = { stamp, raw, br, gz };
  cache.set(filePath, entry);
  return entry;
}

export async function serveStatic(root, urlPath, res, reqHeaders = {}) {
  const safe = path.normalize(decodeURIComponent(urlPath)).replace(/^(\.\.[/\\])+/, '');
  let filePath = path.join(root, safe);

  if (filePath !== root && !filePath.startsWith(root + path.sep)) {
    res.statusCode = 403;
    res.end('Forbidden');
    return true;
  }

  try {
    let stat = await fs.stat(filePath);
    if (stat.isDirectory()) {
      filePath = path.join(filePath, 'index.html');
      stat = await fs.stat(filePath);
    }
    const ext = path.extname(filePath).toLowerCase();
    const compressible = COMPRESSIBLE.has(ext);
    // weak validator from size + mtime: cheap, and enough for 304s
    const etag = `W/"${stat.size.toString(16)}-${Math.floor(stat.mtimeMs).toString(16)}"`;
    res.setHeader('etag', etag);
    // code revalidates on every load (so edits show up immediately); art is cached for a day and may be
    // shown stale for a week while it is refreshed in the background
    const isAsset = urlPath.startsWith('/assets/');
    res.setHeader('cache-control', isAsset ? 'public, max-age=86400, stale-while-revalidate=604800' : 'no-cache');
    res.setHeader('x-content-type-options', 'nosniff');
    res.setHeader('referrer-policy', 'no-referrer');
    res.setHeader('content-type', MIME[ext] || 'application/octet-stream');
    if (compressible) res.setHeader('vary', 'Accept-Encoding');
    if (reqHeaders['if-none-match'] === etag) {
      res.statusCode = 304;
      res.end();
      return true;
    }

    res.statusCode = 200;
    if (compressible) {
      const entry = await loadCompressed(filePath, etag);
      const enc = pickEncoding(reqHeaders['accept-encoding']);
      const body = enc === 'br' ? entry.br : enc === 'gzip' ? entry.gz : entry.raw;
      if (enc) res.setHeader('content-encoding', enc);
      res.setHeader('content-length', body.length);
      res.end(body);
      return true;
    }

    const data = await fs.readFile(filePath);
    res.setHeader('content-length', data.length);
    res.end(data);
    return true;
  } catch {
    return false;
  }
}

/** "bytes=100-200" against a file of `size` bytes: { start, end }, null when no (usable) range was asked for, or 'bad' when it lies outside the file. */
export function byteRange(header, size) {
  const range = /^bytes=(\d*)-(\d*)$/.exec(String(header || ''));
  if (!range || (!range[1] && !range[2])) return null;
  let start = 0;
  let end = size - 1;
  if (range[1]) {
    start = Number(range[1]);
    if (range[2]) end = Math.min(end, Number(range[2]));
  } else {
    start = Math.max(0, size - Number(range[2])); // "-500": the last 500 bytes
  }
  return start > end || start >= size ? 'bad' : { start, end };
}

/**
 * Sends a file from the disk as it is, answering a request for part of it with just that part (a player jumping to the
 * middle of a song asks for exactly that). Returns false when there is no such file, so the caller can answer.
 */
export async function streamFile(req, res, file, type) {
  let stat;
  try {
    stat = await fs.stat(file);
  } catch {
    return false;
  }
  if (!stat.isFile()) return false;
  const base = { 'content-type': type, 'accept-ranges': 'bytes', 'cache-control': 'private, max-age=86400', 'x-content-type-options': 'nosniff' };
  const range = byteRange(req.headers.range, stat.size);
  if (range === 'bad') {
    res.writeHead(416, { 'content-range': `bytes */${stat.size}` });
    res.end();
    return true;
  }
  const { start, end } = range || { start: 0, end: stat.size - 1 };
  if (range) res.writeHead(206, { ...base, 'content-length': end - start + 1, 'content-range': `bytes ${start}-${end}/${stat.size}` });
  else res.writeHead(200, { ...base, 'content-length': stat.size });
  if (req.method === 'HEAD' || stat.size === 0) {
    res.end();
    return true;
  }
  const body = createReadStream(file, { start, end });
  body.on('error', () => res.destroy());
  body.pipe(res);
  return true;
}

/** JSON API responses: compressed when they are big enough to be worth it. */
export function sendJson(req, res, status, payload) {
  const body = Buffer.from(JSON.stringify(payload));
  res.statusCode = status;
  res.setHeader('content-type', 'application/json; charset=utf-8');
  const enc = body.length > 1400 ? pickEncoding(req.headers['accept-encoding']) : '';
  if (!enc) {
    res.setHeader('content-length', body.length);
    return res.end(body);
  }
  res.setHeader('vary', 'Accept-Encoding');
  res.setHeader('content-encoding', enc);
  const out = enc === 'br'
    ? zlib.brotliCompressSync(body, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 3 } })
    : zlib.gzipSync(body, { level: 4 });
  res.setHeader('content-length', out.length);
  return res.end(out);
}
