/*
 * Stage directions: a small model sometimes narrates what it is "doing" in brackets instead of doing it, e.g.
 *
 *     (you send a GIF of someone gripping their hips with a wide, breathy moan)
 *     (the GIF has already been sent)
 *
 * Nobody texts like that, and it is a sign nothing was really sent. Such parentheses are removed while the reply streams
 * (StageGuard) and from the finished text (stripStage). Ordinary asides, like "(i think)", are left alone.
 */

const MEDIA = /\b(?:gifs?|videos?|vids?|clips?|photos?|pics?|pictures?)\b/i;
const SENDING = /\b(?:send|sends|sent|sending|attach\w*|shows?|showing)\b/i;

/** True when a parenthesis (with its brackets) is a narrated action rather than an aside. */
export function isStageDirection(segment) {
  const inner = String(segment).replace(/^\(|\)$/g, '').trim();
  if (!inner) return false;
  if (SENDING.test(inner) && MEDIA.test(inner)) return true;
  if (/^the (?:gif|video|vid|clip|photo|pic|picture)\b.{0,40}\b(?:has|was|is|been)\b/i.test(inner)) return true;
  // "(calls the tool)", "(uses the send_photo function)": nobody texts like that, and it means she did not really do it
  if (/\b(?:tool|function|send_photo|send_gif|send_video|send_picture|generate_image)\b/i.test(inner) && /\b(?:call|calls|calling|called|use|uses|using|run|runs|running|trigger|triggers|invoke|invokes)\b/i.test(inner)) return true;
  // an action in the third person, in brackets: "(winks)", "(turns around slowly)", "(bites lip)"
  if (/^(?:winks?|smiles?|grins?|leans?|bites?|laughs?|giggles?|blushes|sighs?|pauses?|turns?|smirks?|shrugs?|waits?|nods?|sends?|shows?|poses?|strikes)\b/i.test(inner) && inner.length <= 60) return true;
  return /^(?:you|she|rosia)\b/i.test(inner) && inner.length > 25;
}

const MAX_PAREN = 240;

export class StageGuard {
  constructor() {
    this.buf = '';
  }

  push(text) {
    this.buf += text;
    let out = '';
    for (;;) {
      const open = this.buf.indexOf('(');
      if (open === -1) {
        out += this.buf;
        this.buf = '';
        return out;
      }
      out += this.buf.slice(0, open);
      this.buf = this.buf.slice(open);
      const close = this.buf.indexOf(')');
      if (close === -1) {
        if (this.buf.length > MAX_PAREN) {
          out += this.buf[0]; // far too long for an aside: an ordinary bracket after all
          this.buf = this.buf.slice(1);
          continue;
        }
        return out; // wait for the rest
      }
      const segment = this.buf.slice(0, close + 1);
      this.buf = this.buf.slice(close + 1);
      if (!isStageDirection(segment)) out += segment;
    }
  }

  flush() {
    const rest = this.buf;
    this.buf = '';
    return rest;
  }
}

/** The finished text without any stage directions, and the gaps they leave tidied. */
export function stripStage(text) {
  const guard = new StageGuard();
  const out = guard.push(String(text || '')) + guard.flush();
  return out.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').replace(/[ \t]{2,}/g, ' ').trim();
}
