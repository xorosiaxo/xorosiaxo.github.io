import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from './config.js';
import { appVersion, compareVersions, isNewer, isVersion } from './version.js';
import { readZip, ZipError } from './zip.js';
import { UPDATE_EXIT_CODE, FILES, MAX_AUTO_ATTEMPTS, AUTO_RETRY_GAP_MS, isProtected, updatesDir, updateFile, signedText, readFailure, autoInstallAllowed } from './update-protocol.js';
import { renameRetrying } from './atomic.js';
import { debug } from './debuglog.js';

/*
 * Keeping installs up to date.
 *
 *   publisher  scripts/release.js builds dist/rosia-<version>.zip and dist/latest.json (the "release list") and signs it with a
 *              private key that never leaves the publisher's machine. Both files are put anywhere that serves static files.
 *   install    every few hours this module fetches latest.json from the address in config.update.url and checks:
 *                - the signature, with the public key that ships in every install (server/update-key.pub),
 *                - the version is semantic and newer than the running one (and not one that already failed on this machine).
 *              Then it downloads the zip, checks its size and SHA-256 against what was signed (so it does not matter who hosts
 *              it), unpacks it into data/updates/staged/<version>, and leaves a note (pending.json).
 *   launcher   the app exits with UPDATE_EXIT_CODE; scripts/supervisor.js swaps the files in (scripts/apply-update.js), starts the
 *              new version and puts the old one back if it does not come up (see updater.js).
 *
 * Nothing about the person or their data is sent: the request is a plain GET of a static file. The person's data and settings
 * (data/, rosia.local.json, ...) are never part of an update and never touched by one.
 *
 * Modes (config.update.mode): 'auto' installs it by itself when nobody has chatted for ten minutes; 'notify' stages it and waits
 * for the owner to press the button; 'off' does nothing at all.
 */

const MANIFEST_MAX = 64 * 1024;
const ZIP_MAX = 200 * 1024 * 1024;
const QUIET_BEFORE_AUTO_MS = 10 * 60_000;

let state = null; // the persisted record
let busy = null; // the check or download in progress
let timer = null;
let waiting = null;
let publicKey;

const dir = () => updatesDir(config.dataDir);
const file = (name) => updateFile(config.dataDir, name);

/* ---------- the record ---------- */

function load() {
  if (state) return state;
  let saved = {};
  try {
    saved = JSON.parse(fs.readFileSync(file(FILES.state), 'utf8'));
  } catch {
    /* first run */
  }
  state = { checkedAt: 0, manifest: null, stage: 'idle', stagedVersion: '', error: '', ...saved };
  // an update that has been installed is no longer pending
  if (state.manifest && !isNewer(state.manifest.version, appVersion())) Object.assign(state, { manifest: null, stage: 'idle', stagedVersion: '' });
  // nothing is mid-download after a restart, and "ready" only holds while the launcher still has its note (after an install, or a
  // rollback, it does not)
  if (state.stage === 'downloading' || (state.stage === 'ready' && !fs.existsSync(file(FILES.pending)))) Object.assign(state, { stage: 'idle', stagedVersion: '' });
  return state;
}

async function save() {
  await fsp.mkdir(dir(), { recursive: true });
  const target = file(FILES.state);
  const tmp = `${target}.${process.pid}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(state, null, 2), 'utf8');
  await renameRetrying(tmp, target);
}

/* ---------- the signature ---------- */

/** The public key every install trusts, or null when this install has none (updates are then switched off). */
function trustedKey() {
  if (publicKey !== undefined) return publicKey;
  try {
    publicKey = crypto.createPublicKey(fs.readFileSync(config.update.keyFile, 'utf8'));
  } catch {
    publicKey = null;
  }
  return publicKey;
}

export { signedText };

export function verifyManifest(manifest, key = trustedKey()) {
  if (!key) throw new Error('This install has no update key.');
  if (!manifest || manifest.app !== 'rosia') throw new Error('That is not a Rosia release list.');
  if (!isVersion(manifest.version)) throw new Error('The release list has a bad version.');
  if (manifest.minVersion && !isVersion(manifest.minVersion)) throw new Error('The release list has a bad minimum version.');
  if (!/^[a-f0-9]{64}$/.test(String(manifest.sha256))) throw new Error('The release list has a bad checksum.');
  if (!Number.isInteger(manifest.size) || manifest.size < 1 || manifest.size > ZIP_MAX) throw new Error('The release list has a bad size.');
  const ok = crypto.verify(null, Buffer.from(signedText(manifest)), key, Buffer.from(String(manifest.signature || ''), 'base64'));
  if (!ok) throw new Error('The release list is not signed by the publisher.');
  return manifest;
}

/* ---------- fetching ---------- */

function allowed(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'https:' || (config.update.insecure && u.protocol === 'http:');
  } catch {
    return false;
  }
}

async function fetchBuffer(url, maxBytes, timeoutMs) {
  if (!allowed(url)) throw new Error('Updates are only fetched over https.');
  const res = await fetch(url, { signal: AbortSignal.timeout(timeoutMs), redirect: 'follow', headers: { 'user-agent': `Rosia/${appVersion()}` } });
  if (!res.ok) throw new Error(`The update server answered ${res.status}.`);
  if (!allowed(res.url || url)) throw new Error('The update was redirected somewhere that is not https.');
  const declared = Number(res.headers.get('content-length') || 0);
  if (declared > maxBytes) throw new Error('The update is bigger than allowed.');
  const chunks = [];
  let size = 0;
  for await (const chunk of res.body) {
    size += chunk.length;
    if (size > maxBytes) throw new Error('The update is bigger than allowed.');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

/* ---------- looking for an update ---------- */

export function updatesEnabled() {
  if (config.update.mode === 'off') return { enabled: false, reason: 'Updates are switched off.' };
  if (!config.update.url) return { enabled: false, reason: 'No update address is set.' };
  if (!trustedKey()) return { enabled: false, reason: 'This install has no update key, so it cannot check that an update is genuine.' };
  return { enabled: true, reason: '' };
}

/** Fetches the release list and records whether there is something newer. Never throws: the result says what happened. */
export async function checkForUpdate() {
  if (busy) return busy;
  busy = (async () => {
    const st = load();
    const on = updatesEnabled();
    if (!on.enabled) return status();
    try {
      const body = await fetchBuffer(config.update.url, MANIFEST_MAX, 15_000);
      const manifest = verifyManifest(JSON.parse(body.toString('utf8')));
      st.checkedAt = Date.now();
      st.error = '';
      // a version that failed here before is still on offer (see update-protocol.js: it is only not installed by itself, again and again)
      const newer = isNewer(manifest.version, appVersion());
      if (!newer) {
        Object.assign(st, { manifest: null, stage: 'idle', stagedVersion: '' });
      } else if (st.manifest?.version !== manifest.version) {
        Object.assign(st, { manifest, stage: 'idle', stagedVersion: '' }); // a newer one than what was staged: start again
      } else {
        st.manifest = manifest;
      }
      debug('update.check', { current: appVersion(), latest: manifest.version, newer });
    } catch (err) {
      st.checkedAt = Date.now();
      st.error = `Could not check for updates: ${String(err.message || err).slice(0, 160)}`;
      debug('update.check.failed', { error: err });
    }
    await save().catch(() => {});
    return status();
  })().finally(() => {
    busy = null;
  });
  return busy;
}

/* ---------- downloading and checking it ---------- */

/** Files an update may not contain (the person's own things) are dropped, never written. */
const wanted = (entries) => entries.filter((e) => !isProtected(e.name));

/** Downloads, checks and unpacks the release into data/updates/staged/<version>, then leaves pending.json. */
export async function stageUpdate() {
  if (busy) await busy.catch(() => {});
  const st = load();
  const manifest = st.manifest;
  if (!manifest) throw new Error('There is no update to download.');
  if (st.stage === 'ready' && st.stagedVersion === manifest.version && fs.existsSync(file(FILES.pending))) return status();

  st.stage = 'downloading';
  st.error = '';
  await save().catch(() => {});
  try {
    const url = new URL(manifest.url, config.update.url).href; // a release list may give its zip as a relative address
    const zip = await fetchBuffer(url, Math.min(ZIP_MAX, manifest.size), 10 * 60_000);
    if (zip.length !== manifest.size) throw new Error('The download is not the size that was signed.');
    if (crypto.createHash('sha256').update(zip).digest('hex') !== manifest.sha256) throw new Error('The download does not match the signed checksum.');

    const entries = wanted(readZip(zip));
    const pkg = entries.find((e) => e.name === 'package.json');
    if (!pkg || JSON.parse(pkg.data.toString('utf8')).version !== manifest.version) throw new Error('The release is not the version it says it is.');
    for (const need of ['server/index.js', 'public/index.html', 'scripts/supervisor.js']) {
      if (!entries.some((e) => e.name === need)) throw new Error(`The release is missing ${need}.`);
    }

    const staged = path.join(dir(), 'staged', manifest.version);
    await fsp.rm(staged, { recursive: true, force: true });
    for (const e of entries) {
      const target = path.join(staged, ...e.name.split('/'));
      await fsp.mkdir(path.dirname(target), { recursive: true });
      await fsp.writeFile(target, e.data);
    }
    const pending = { version: manifest.version, from: appVersion(), dir: staged, files: entries.map((e) => e.name), stagedAt: Date.now() };
    await fsp.writeFile(file(FILES.pending), JSON.stringify(pending, null, 2), 'utf8');
    Object.assign(st, { stage: 'ready', stagedVersion: manifest.version });
    debug('update.staged', { version: manifest.version, files: entries.length });
  } catch (err) {
    st.stage = 'failed';
    st.error = `Could not get the update: ${err instanceof ZipError ? err.message : String(err.message || err).slice(0, 160)}`;
    debug('update.stage.failed', { error: err });
  }
  await save().catch(() => {});
  return status();
}

/* ---------- what the page is shown ---------- */

export function status() {
  const st = load();
  const on = updatesEnabled();
  const latest = st.manifest;
  const failure = latest ? readFailure(config.dataDir) : null;
  const failedHere = failure && failure.version === latest.version ? failure : null;
  return {
    enabled: on.enabled,
    reason: on.reason,
    mode: config.update.mode,
    current: appVersion(),
    latest: latest?.version || appVersion(),
    available: on.enabled && Boolean(latest), // a switched-off updater (or one without a key) offers nothing, whatever it saw before
    required: Boolean(latest?.minVersion && compareVersions(appVersion(), latest.minVersion) < 0),
    notes: latest?.notes ? String(latest.notes).slice(0, 4000) : '',
    publishedAt: latest?.publishedAt || '',
    stage: st.stage, // idle | downloading | ready | failed
    ready: st.stage === 'ready',
    error: st.error,
    // this version was installed on this machine, did not come up, and the previous one was put back: what happened and when it
    // will be tried again by itself (the owner can install it again whenever they like)
    failure: failedHere && {
      version: failedHere.version,
      reason: failedHere.reason,
      at: failedHere.at,
      attempts: failedHere.attempts,
      log: failedHere.tail || [],
      autoPaused: !autoInstallAllowed(failedHere, failedHere.version),
      nextAutoTryAt: failedHere.attempts < MAX_AUTO_ATTEMPTS ? failedHere.at + AUTO_RETRY_GAP_MS : null
    },
    checkedAt: st.checkedAt,
    canInstall: config.update.supervised, // only the launcher can replace a running app's files
    manual: config.update.supervised ? '' : 'This copy was not started by the launcher (start.bat), so it cannot update itself. Restart it with start.bat, or install the update by hand.'
  };
}

/* ---------- installing it ---------- */

/**
 * Stages the update if it is not yet, then leaves so the launcher can swap it in. `exit` is for tests.
 * Resolves with the status; the process is gone a moment later.
 */
export async function installUpdate({ exit = (code) => process.exit(code), flush = () => {} } = {}) {
  if (!config.update.supervised) throw Object.assign(new Error(status().manual), { status: 409 });
  const st = load();
  if (!st.manifest) throw Object.assign(new Error('There is no update to install.'), { status: 409 });
  if (st.stage !== 'ready') await stageUpdate();
  if (load().stage !== 'ready') throw Object.assign(new Error(load().error || 'The update could not be prepared.'), { status: 502 });
  debug('update.install', { from: appVersion(), to: load().stagedVersion });
  flush();
  setTimeout(() => exit(UPDATE_EXIT_CODE), 400).unref?.();
  return { ...status(), restarting: true };
}

/* ---------- on its own ---------- */

/**
 * Checks now and then; in 'auto' mode downloads what it finds and installs it once nobody has chatted for a while.
 * quiet() says whether the machine is idle; flush() saves anything in memory before the app leaves.
 */
export function startUpdates({ quiet = () => true, msSinceActivity = () => Infinity, flush = () => {} } = {}) {
  if (timer || config.update.mode === 'off') return;
  const failed = readFailure(config.dataDir);
  if (failed && isNewer(failed.version, appVersion())) {
    console.log(`[update] version ${failed.version} did not come up on this machine (${failed.reason}), so ${failed.from || 'the previous version'} was put back. It stays on offer.`);
    debug('update.rolled_back', failed);
  }
  const installIfQuiet = async () => {
    if (config.update.mode !== 'auto' || !config.update.supervised || !status().ready) return;
    if (!autoInstallAllowed(readFailure(config.dataDir), status().latest)) return; // it failed here: not tried again straight away
    if (quiet() && msSinceActivity() > QUIET_BEFORE_AUTO_MS) await installUpdate({ flush });
  };
  const tick = async () => {
    try {
      const s = await checkForUpdate();
      if (!s.available || !s.enabled) return;
      if (s.failure?.autoPaused) return; // failed here recently: waiting (the owner can still press install)
      if (s.stage !== 'ready') await stageUpdate(); // downloaded ahead of time in 'notify' mode too, so installing is instant
      await installIfQuiet();
    } catch (err) {
      debug('update.tick.failed', { error: err });
    }
  };
  setTimeout(tick, 2 * 60_000).unref?.();
  timer = setInterval(tick, Math.max(60_000, config.update.checkMs));
  timer.unref?.();
  // a staged update waits for a quiet moment: looked at again every few minutes, not only at the next check
  waiting = setInterval(() => installIfQuiet().catch((err) => debug('update.install.failed', { error: err })), 5 * 60_000);
  waiting.unref?.();
}

/** For tests. */
export function resetUpdateState() {
  state = null;
  busy = null;
  publicKey = undefined;
  if (timer) clearInterval(timer);
  if (waiting) clearInterval(waiting);
  timer = null;
  waiting = null;
}
