import { config } from './config.js';
import { cosine } from './embed.js';
import { getUser, saveUser, clearSentForTests } from './users.js';

/*
 * Choosing a GIF, a video or a stocked picture of her by MEANING, the same way for all three:
 *
 *  - what was asked for (or, for something she sends on her own, what she just said) is turned into a vector and compared
 *    with the vector of each item's description;
 *  - only items that score at least the floor for the embedding model in use count as "what they want" (the floors were
 *    measured on the real catalogue with EmbeddingGemma: a right match scores about 0.42 to 0.65, while the median item
 *    scores about 0.2 to 0.3 against any query, so the old floor of 0.2 let nearly anything through);
 *  - of those, the ones within a small band of the best are the candidates, and one is picked, usually the best;
 *  - nothing she has sent this person lately comes round again (kept per person on disk, across all their chats and
 *    restarts), and neither does a near-identical copy of it (the same GIF saved twice has the same vector).
 */

// [ask, react, pool]: a request for something specific, a reaction to her own reply, a stocked picture of her
const FLOORS = {
  embeddinggemma: { ask: 0.4, react: 0.44, pool: 0.45 },
  nomic: { ask: 0.6, react: 0.62, pool: 0.65 },
  bge: { ask: 0.6, react: 0.62, pool: 0.65 },
  none: { ask: 0.45, react: 0.47, pool: 0.5 }
};
const HASH = { ask: 0.25, react: 0.33, pool: 0.35 };

/** How close in meaning an item must be. `purpose` is 'ask' | 'react' | 'pool'. */
export function matchFloor(kind, purpose = 'ask') {
  const table = kind === 'hash' ? HASH : FLOORS[config.embedStyle] || FLOORS.none;
  const base = table[purpose] ?? table.ask;
  // ROSA_MATCH_FLOOR moves every floor of a real model by the same amount relative to the "ask" one
  return kind !== 'hash' && config.matchFloor ? base - table.ask + config.matchFloor : base;
}

/* ---------- what was sent lately ---------- */

const KEEP = { gif: 80, video: 40, picture: 40 }; // how many of each are remembered per person
const STRICT = { gif: 20, video: 10, picture: 40 }; // never one of these, even when it is the only thing that fits
const memory = new Map(); // `${userId}:${kind}` -> keys, newest last (what was sent since the person was last loaded)

const slot = (userId, kind) => `${userId}:${kind}`;

/** Remembers that `key` was sent to this person (on disk with the rest of what is known about them). */
export function noteSent(userId, kind, key) {
  if (!userId || !key) return;
  const list = memory.get(slot(userId, kind)) || [];
  list.push(String(key));
  memory.set(slot(userId, kind), list.slice(-KEEP[kind]));
  getUser(userId)
    .then((user) => {
      user.sent ||= {};
      const merged = [...(user.sent[kind] || []).filter((k) => k !== String(key)), String(key)];
      user.sent[kind] = merged.slice(-KEEP[kind]);
      return saveUser(user);
    })
    .catch(() => {});
}

/** What was sent to this person lately, newest last. */
export async function sentLately(userId, kind) {
  let stored = [];
  try {
    stored = (await getUser(userId)).sent?.[kind] || [];
  } catch {
    stored = [];
  }
  const extra = memory.get(slot(userId, kind)) || [];
  const out = [];
  for (const k of [...stored, ...extra]) {
    const i = out.indexOf(k);
    if (i >= 0) out.splice(i, 1);
    out.push(k);
  }
  return out.slice(-KEEP[kind]);
}

/** For tests. */
export function resetSent() {
  memory.clear();
  clearSentForTests();
}

/* ---------- picking ---------- */

/**
 * Picks one item by meaning.
 *   items     the candidates (already filtered for adult content, shape and so on)
 *   query     { vec, kind } of what is wanted, or null for "any one"
 *   keyOf     item -> its identity (two copies of one file share it)
 *   vecOf     item -> its vector (in query.kind), or null
 *   recent    keys sent lately, newest last
 *   floor     the minimum score; band: how far below the best a candidate may be
 *   bonus     item -> extra score (e.g. words shared with its name), optional
 * Returns { item, score } or null. With no query, any item that was not sent lately, at random.
 */
export function pickByMeaning({ items, query, keyOf, vecOf, recent = [], floor, band = 0.05, strict = 0, bonus, rng = Math.random }) {
  const order = new Map(recent.map((k, i) => [k, i])); // older sends have lower numbers
  // An item may come back only once it is older than the last `strict` sends; with no `strict`, nothing sent lately does.
  const allowedBelow = strict ? recent.length - strict : -1;
  // the vectors of what was sent lately (the newest 30), so a near-identical copy of one counts as sent at the same time
  const recentVecs = query
    ? items.filter((i) => order.has(keyOf(i))).map((i) => [vecOf(i), order.get(keyOf(i))]).filter(([v]) => v).sort((a, b) => b[1] - a[1]).slice(0, 30)
    : [];
  /** When this item (or a copy of it) was last sent, as a position in `recent`, or -1 if it was not. */
  const sentAt = (item) => {
    const own = order.get(keyOf(item));
    if (own !== undefined) return own;
    const v = vecOf(item);
    if (!v) return -1;
    for (const [r, at] of recentVecs) if (r !== v && cosine(r, v) >= 0.985) return at;
    return -1;
  };

  if (!query) {
    const fresh = items.filter((i) => !order.has(keyOf(i)));
    if (fresh.length) return { item: fresh[Math.floor(rng() * fresh.length)], score: 0 };
    // everything has gone round: the one sent longest ago, if it is old enough to come back
    const older = items.filter((i) => order.get(keyOf(i)) < allowedBelow).sort((a, b) => order.get(keyOf(a)) - order.get(keyOf(b)));
    return older.length ? { item: older[0], score: 0 } : null;
  }

  const scored = [];
  for (const item of items) {
    const v = vecOf(item);
    const sim = v ? cosine(query.vec, v) : 0;
    const score = sim + (bonus ? bonus(item) : 0);
    if (score >= floor) scored.push({ item, score });
  }
  if (!scored.length) return null;
  scored.sort((a, b) => b.score - a.score);

  for (const s of scored) s.at = sentAt(s.item);
  const fresh = scored.filter((s) => s.at === -1);
  if (fresh.length) {
    const best = fresh[0].score;
    const top = fresh.filter((s) => s.score >= best - band).slice(0, 5);
    // usually the best, sometimes one of the next few, so the same request does not always give the same thing
    const pick = top[Math.floor(rng() ** 2 * top.length)];
    return { item: pick.item, score: pick.score };
  }
  // everything that fits was sent lately: the one sent longest ago, if it is old enough to come back
  const older = scored.filter((s) => s.at < allowedBelow).sort((a, b) => a.at - b.at);
  return older.length ? { item: older[0].item, score: older[0].score } : null;
}

export { STRICT as SENT_STRICT };
