import crypto from 'node:crypto';
import { config } from './config.js';
import { isQuiet, msSinceActivity } from './activity.js';
import { generate, freeMemory } from './comfy.js';
import { control, setPhase, swapAvailable, chatReady, chatWaiters } from './gpu.js';
import { complete as modelComplete } from './llm.js';
import { styledPrompt } from './preflight.js';
import { addToPool, loadPool, poolSize, poolRequests, poolLastBatch, markPoolBatch, poolNeed } from './pool.js';
import { saveImageBuffer } from './media.js';
import { loadSession, saveSession } from './sessions.js';
import { record } from './metrics.js';
import { debug, who } from './debuglog.js';
import { withBasePrompt } from './baseprompt.js';
import { imageOverride } from './imageoverride.js';

/*
 * Pictures she draws. A tool call puts a job on the queue; one worker makes them one at a time:
 * wait for replies in progress to finish, lend the graphics card to the image generator, draw, keep the
 * picture, hand the card back. The picture is attached to her message, which the page shows as a
 * "drawing" placeholder until it is done.
 */

const jobs = new Map();
const queue = [];
let working = false;
let swapped = false;

const RATIO = { portrait: '3 / 4', landscape: '4 / 3', square: '1 / 1' };
export const normaliseOrientation = (o) => (RATIO[o] ? o : 'portrait');

export function imagesEnabled() {
  return Boolean(config.images.url);
}

/** Whether pictures are offered to this person at all (the tool is hidden from the model when not). */
export function mayDraw(userId) {
  return imagesEnabled() && (userId === 'local' || config.images.guests);
}

/** Why this person cannot ask for a picture right now, or '' if they can. */
export function whyNot(userId) {
  if (!imagesEnabled()) return 'Drawing is not set up on this server.';
  if (!mayDraw(userId)) return 'Only the owner can ask for pictures here.';
  if (queue.filter((j) => !j.pool).length >= config.images.maxQueue) return 'She has a lot of pictures to draw right now. Try again in a few minutes.';
  const mine = [...jobs.values()].filter((j) => j.userId === userId && !j.pool);
  if (mine.filter((j) => !['done', 'failed'].includes(j.state)).length >= config.images.pendingPerPerson) return 'There are already pictures being drawn for you. Wait for those first.';
  const lastHour = mine.filter((j) => Date.now() - j.createdAt < 3600_000).length;
  if (lastHour >= config.images.perHour) return `That is the most pictures per hour (${config.images.perHour}). Try again a bit later.`;
  return '';
}

export function enqueue({ userId, sessionId, prompt, orientation, pool = false, request = '' }) {
  const job = {
    id: crypto.randomBytes(8).toString('hex'),
    userId,
    sessionId,
    prompt: String(prompt).trim().slice(0, 1800),
    orientation: normaliseOrientation(orientation),
    pool, // drawn ahead of time for the stock (pool.js), not for anyone
    request: String(request).slice(0, 300),
    state: 'queued',
    step: 0,
    steps: config.images.steps,
    media: null,
    error: '',
    createdAt: Date.now(),
    startedAt: 0
  };
  jobs.set(job.id, job);
  // a person's picture goes ahead of any that are only being stocked up
  const firstStock = queue.findIndex((j) => j.pool);
  if (pool || firstStock === -1) queue.push(job);
  else queue.splice(firstStock, 0, job);
  // forget old finished ones
  for (const [id, j] of jobs) if (['done', 'failed'].includes(j.state) && Date.now() - j.createdAt > 3600_000) jobs.delete(id);
  setImmediate(work);
  return job;
}

// how long a picture takes on this machine, learned from the last few (a first guess until then)
let typicalMs = 120_000;

/**
 * While the card is lent out: whether a picture of this person's is among the work, and about how many seconds until the chat
 * model is back (the picture being drawn, the ones queued ahead, and handing the card back).
 */
export function drawingEta(userId) {
  const active = [...jobs.values()].find((j) => ['waiting', 'starting', 'drawing', 'finishing'].includes(j.state));
  const waiting = queue.filter((j) => !j.pool);
  let ms = 0;
  if (active) {
    const elapsed = Date.now() - (active.startedAt || active.createdAt);
    const byStep = active.state === 'drawing' && active.step > 0 && active.steps ? ((active.steps - active.step) / active.steps) * typicalMs * 0.8 : null;
    ms += Math.max(5_000, byStep ?? typicalMs - elapsed);
  }
  ms += waiting.length * typicalMs + 10_000;
  const forYou = Boolean((active && active.userId === userId && !active.pool) || waiting.some((j) => j.userId === userId));
  return { forYou, etaS: Math.round(ms / 1000) };
}

export function jobView(job) {
  return {
    job: job.id,
    state: job.state,
    ratio: RATIO[job.orientation],
    step: job.step,
    steps: job.steps,
    ahead: job.state === 'queued' ? queue.indexOf(job) : 0,
    media: job.media || undefined,
    error: job.error || undefined
  };
}

export function getJob(id, userId) {
  const job = jobs.get(id);
  return job && job.userId === userId ? job : null;
}

/** What a saved message shows for its picture: live progress while it is being made. */
export function publicImage(message) {
  const im = message.image;
  if (!im) return undefined;
  const ratio = RATIO[im.orientation] || RATIO.portrait;
  if (im.state === 'done') return { job: im.job, state: 'done', ratio, media: im.media };
  if (im.state === 'failed') return { job: im.job, state: 'failed', ratio, error: im.error };
  const live = jobs.get(im.job);
  if (!live) return { job: im.job, state: 'failed', ratio, error: 'That picture was interrupted, so it never finished.' };
  return jobView(live);
}

/* ---------- the worker ---------- */

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitUntilQuiet(maxMs = 5 * 60_000) {
  const end = Date.now() + maxMs;
  while (!isQuiet() && Date.now() < end) await sleep(300);
}

async function handBack() {
  if (!swapped) {
    // nothing was lent out, but a job may have reserved the card and then failed before it got it: chat must not stay locked
    if (!chatReady()) setPhase('chat');
    return;
  }
  await freeMemory();
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      await control('/gpu/chat');
      swapped = false;
      setPhase('chat');
      return;
    } catch (err) {
      console.error('[images] could not hand the card back:', err.message);
      await sleep(5000);
    }
  }
  // let chat try anyway: it reports a clear error if the model really is not there
  swapped = false;
  setPhase('chat');
}

async function attach(job) {
  try {
    const session = await loadSession(job.sessionId, job.userId);
    const message = session?.messages.find((m) => m.image?.job === job.id);
    if (!message) return;
    message.image = { ...message.image, state: job.state, media: job.media || undefined, error: job.error || undefined };
    await saveSession(session, { touch: false });
  } catch (err) {
    console.error('[images] could not attach the picture:', err.message);
  }
}

const friendly = (err) => (String(err?.message || '').length > 3 ? String(err.message).slice(0, 220) : 'Something went wrong while drawing it.');

async function runJob(job) {
  const started = Date.now();
  // stocking up only happens while nobody is around: if someone has turned up since it was queued, it is dropped (and retried later)
  if (job.pool && (!isQuiet() || chatWaiters() > 0 || msSinceActivity() < config.images.poolIdleMs / 3)) {
    job.state = 'failed';
    job.error = 'skipped: someone is chatting';
    debug('pool.skipped', { job: job.id });
    return;
  }
  try {
    if (swapAvailable()) {
      job.state = 'waiting';
      setPhase('reserved');
      await waitUntilQuiet();
      job.state = 'starting';
      // marked before asking: if the launcher fails part-way (the chat model already stopped, ComfyUI never came up),
      // handBack() still asks for the chat model back and unlocks chat
      swapped = true;
      await control('/gpu/image');
      setPhase('image');
    } else {
      job.state = 'starting';
    }
    job.state = 'drawing';
    job.startedAt = Date.now();
    // a prompt pinned in data/image-override.json (a testing aid) is sent as it is; otherwise the base prompt (image-base-prompt.txt) is applied
    const fullPrompt = imageOverride().prompt || withBasePrompt(job.prompt);
    debug('image.start', { user: who(job.userId), job: job.id, orientation: job.orientation, prompt: job.prompt, sent: fullPrompt === job.prompt ? undefined : fullPrompt, waitedMs: job.startedAt - started, override: imageOverride().seed != null || imageOverride().unet ? { seed: imageOverride().seed, unet: imageOverride().unet } : undefined });
    const out = await generate({
      prompt: fullPrompt,
      orientation: job.orientation,
      onProgress: ({ step, steps }) => {
        job.step = step;
        job.steps = steps;
      }
    });
    if (job.pool) {
      const file = await addToPool({ request: job.request || job.prompt, prompt: fullPrompt, orientation: job.orientation }, out.buffer);
      job.state = 'done';
      debug('pool.added', { job: job.id, file, ms: Date.now() - started, comfyMs: out.execMs, size: poolSize(), request: job.request });
      record('job', { name: 'pool', ok: true, ms: Date.now() - started });
      return; // nothing to attach: the picture belongs to the stock, not to a conversation
    }
    job.state = 'finishing';
    const media = await saveImageBuffer(job.userId, out.buffer);
    if (!media) throw new Error('The picture could not be kept: there is no room left for pictures, or it was too big.');
    job.media = media;
    job.state = 'done';
    debug('image.done', { user: who(job.userId), job: job.id, ms: Date.now() - started, drawMs: Date.now() - job.startedAt, comfyMs: out.execMs, seed: out.seed, size: `${out.width}x${out.height}`, unet: out.unet, picture: typeof media === 'string' ? media : media?.id });
    record('job', { name: 'image', ok: true, ms: Date.now() - started });
    typicalMs = Math.round(typicalMs * 0.6 + (Date.now() - started) * 0.4);
  } catch (err) {
    job.state = 'failed';
    job.error = friendly(err);
    debug('image.failed', { user: who(job.userId), job: job.id, ms: Date.now() - started, pool: job.pool || undefined, error: err });
    record('job', { name: job.pool ? 'pool' : 'image', ok: false, ms: Date.now() - started });
    record('error', { where: job.pool ? 'pool' : 'image', message: String(err?.message || err).replace(/https?:\/\/\S+/g, '<link>').slice(0, 120) });
    console.error('[images] failed:', err?.message || err);
  }
  if (!job.pool) await attach(job);
}

/**
 * A picture that already exists (taken from the stock) handed to someone as if it had just been drawn: kept in their own
 * pictures, and shown at once. Returns a finished job.
 */
export async function instantImage({ userId, sessionId, buffer, orientation, prompt, request }) {
  const media = await saveImageBuffer(userId, buffer);
  if (!media) throw new Error('The picture could not be kept: there is no room left for pictures, or it was too big.');
  const job = {
    id: crypto.randomBytes(8).toString('hex'), userId, sessionId, prompt: String(prompt).slice(0, 1800), request: String(request || '').slice(0, 300),
    orientation: normaliseOrientation(orientation), pool: false, state: 'done', step: 0, steps: config.images.steps, media, error: '', createdAt: Date.now(), startedAt: Date.now()
  };
  jobs.set(job.id, job);
  debug('image.instant', { user: who(userId), job: job.id, request: job.request, left: poolSize() });
  record('job', { name: 'image', ok: true, ms: 0 });
  return job;
}

/* ---------- stocking up ---------- */

const FALLBACK_SCENES = [
  'in a red satin slip dress at a bedroom mirror, holding her phone, warm lamp light, evening',
  'in a small bikini on a sunny balcony, leaning on the railing, bright morning light',
  'in an oversized white shirt and nothing else, sitting on a kitchen counter with a coffee, soft daylight',
  'in black lace lingerie lying on an unmade bed, looking at the camera, dim bedside light',
  'in tight gym leggings and a sports bra in a gym mirror, ponytail, harsh overhead light',
  'wrapped in a towel after a shower, bathroom mirror steamed up, warm light',
  'in a short summer dress on a rooftop at golden hour, wind in her hair',
  'in cosy pyjama shorts and a crop top on a sofa under a blanket, TV glow, late night'
];

async function scenesFor(count, already) {
  try {
    const out = await modelComplete({
      messages: [
        { role: 'system', content: 'You write short scene descriptions for photos of one adult woman taking flirty, casual, sexy photos of herself.' },
        {
          role: 'user',
          content:
            `Write ${count} different scenes. Each is ONE line of 10 to 20 words: what she is wearing, where she is, what she is doing, the light. ` +
            'Vary the outfits (lingerie, bikini, dresses, gym wear, pyjamas, a towel, a shirt), the places and the time of day. ' +
            `${already.length ? `Do not repeat these: ${already.slice(0, 8).join(' | ')}. ` : ''}Reply with ONLY a JSON array of ${count} strings.`
        }
      ],
      maxTokens: 400,
      temperature: 0.9
    });
    const list = JSON.parse(/\[[\s\S]*\]/.exec(String(out))[0]);
    const scenes = list.map((s) => String(s).replace(/\s+/g, ' ').trim()).filter((s) => s.length >= 15 && s.length <= 260);
    if (scenes.length) return scenes.slice(0, count);
  } catch {
    /* the model is busy or answered badly: the fallback list will do */
  }
  const unused = FALLBACK_SCENES.filter((s) => !already.includes(s));
  return (unused.length ? unused : FALLBACK_SCENES).sort(() => Math.random() - 0.5).slice(0, count);
}

const bootedAt = Date.now();

/** Queues pictures for the stock if it is low and nobody has been around for a while. Returns how many were queued. */
export async function refillPool({ now = Date.now() } = {}) {
  const target = config.images.pool;
  if (!target || !imagesEnabled() || !swapAvailable()) return 0;
  if (!isQuiet() || !chatReady() || msSinceActivity() < config.images.poolIdleMs || now - bootedAt < config.images.poolIdleMs) return 0;
  await loadPool();
  if (now - poolLastBatch() < 20 * 60_000) return 0; // (kept on disk: a restart does not start another straight away)
  const inFlight = queue.filter((j) => j.pool).length;
  const need = poolNeed({ size: poolSize(), inFlight, target, batch: config.images.poolBatch });
  if (need <= 0) return 0;
  await markPoolBatch(now);
  const scenes = await scenesFor(need, poolRequests());
  let queued = 0;
  for (const scene of scenes) {
    if (!isQuiet() || chatWaiters() > 0 || msSinceActivity() < config.images.poolIdleMs / 3) break; // someone has turned up
    const prompt = await styledPrompt(scene);
    enqueue({ userId: '_pool', sessionId: '', prompt, orientation: 'portrait', pool: true, request: scene });
    queued += 1;
  }
  debug('pool.refill', { queued, size: poolSize(), target });
  return queued;
}

let poolTimer = null;
export function startPool() {
  if (poolTimer || !config.images.pool) return;
  poolTimer = setInterval(() => refillPool().catch((err) => debug('pool.error', { error: err })), config.images.poolCheckMs);
  poolTimer.unref?.();
}

async function work() {
  if (working) return;
  working = true;
  try {
    for (;;) {
      while (queue.length) await runJob(queue.shift());
      await handBack(); // only once nothing is waiting, so back-to-back pictures do not swap the card each time
      if (!queue.length) break;
    }
  } finally {
    working = false;
  }
}
