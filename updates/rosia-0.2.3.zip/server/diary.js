import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from './config.js';
import { coalescedWriter } from './atomic.js';
import { complete as defaultComplete } from './llm.js';
import { background, msSinceActivity } from './activity.js';
import { listSessions, loadSession } from './sessions.js';
import { getUser } from './users.js';

/*
 * Her diary. At the end of a day they talked (after 11pm their time once things have gone quiet, or the next day), she
 * writes a few lines about it in her own voice: what they talked about, how it made her feel, something she noticed,
 * something she wants to ask next time. The newest entry colours how she is with them for a few days, so the next
 * chat picks up a thread of her own.
 *
 * It is HER diary, and it is locked. The page shows it only to someone holding the key, and only she can hand that
 * over. She does not even know the key until the app has decided she trusts them enough (so no clever wording can
 * get it out of her early): she has to have known them a while, had real talks with them on several days, been
 * asked on several days, be in a warm mood at that moment, and then, even so, she only sometimes says yes. Until
 * then she refuses, in her own way, and can hint at what is missing.
 *
 * One file per person in data/diary/: { entries: [{ day, text, next, at }], key, given, asks: [day], tries: [at] }.
 */

const write = coalescedWriter('diary');
const loaded = new Map();
const MAX_ENTRIES = 400;
const WORDS = ['velvet', 'cherry', 'moth', 'neon', 'honey', 'violet', 'ember', 'satin', 'lilac', 'comet', 'peach', 'storm', 'ivory', 'raven', 'opal', 'fig', 'lunar', 'scarlet', 'willow', 'midnight'];

const fileFor = (userId) => path.join(config.dataDir, 'diary', `${String(userId).replace(/[^A-Za-z0-9_-]/g, '')}.json`);

function newKey() {
  const pick = () => WORDS[crypto.randomInt(WORDS.length)];
  let a = pick();
  let b = pick();
  while (b === a) b = pick();
  return `${a}-${b}-${crypto.randomInt(100, 1000)}`;
}

export async function getDiary(userId) {
  const id = String(userId || 'local');
  if (loaded.has(id)) return loaded.get(id);
  let data = {};
  try {
    data = JSON.parse(await fs.readFile(fileFor(id), 'utf8'));
  } catch {
    /* none yet */
  }
  const diary = {
    userId: id,
    entries: Array.isArray(data.entries) ? data.entries.filter((e) => e && e.day && e.text) : [],
    key: typeof data.key === 'string' && data.key ? data.key : newKey(),
    given: data.given || 0, // when she gave them the key (0: never)
    offered: data.offered || 0, // she was told the key for her last reply: given once the reply really says it
    asks: Array.isArray(data.asks) ? data.asks.slice(-60) : [], // the days they asked for the key
    lastAsk: data.lastAsk || 0, // the message last counted, so one message is one ask
    tries: Array.isArray(data.tries) ? data.tries.slice(-50) : [] // wrong keys typed into the page
  };
  if (!data.key) await saveDiary(diary);
  loaded.set(id, diary);
  return diary;
}

export function saveDiary(diary) {
  return write(fileFor(diary.userId), () => JSON.stringify({ ...diary, userId: undefined }));
}

/** For tests. */
export function forgetDiaries() {
  loaded.clear();
}

/* ---------- days ---------- */

/** "2026-11-16": the day a moment falls on where they are. */
export function dayOf(ts, timeZone = config.timezone) {
  try {
    return new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(ts));
  } catch {
    return new Date(ts).toISOString().slice(0, 10);
  }
}

const hourOf = (ts, timeZone) => Number(new Intl.DateTimeFormat('en-GB', { timeZone, hour: 'numeric', hour12: false }).format(new Date(ts))) % 24;

/** Every message of theirs and hers on one day, oldest first, across all their conversations. */
async function messagesOn(userId, day, timeZone, now) {
  const since = now - 3 * 86_400_000;
  const metas = (await listSessions(userId)).filter((m) => (m.updatedAt || 0) >= since);
  const out = [];
  for (const meta of metas) {
    const s = await loadSession(meta.id, userId);
    for (const m of s?.messages || []) {
      if ((m.role === 'user' || m.role === 'assistant') && m.content && m.at && dayOf(m.at, timeZone) === day) out.push(m);
    }
  }
  return out.sort((a, b) => a.at - b.at);
}

/** The day that is owed an entry now, or '' when none is: yesterday if it was missed, today once it is late and quiet. */
export function dayToWrite(diary, { now = Date.now(), timeZone = config.timezone, quietMs = msSinceActivity() } = {}) {
  const today = dayOf(now, timeZone);
  const yesterday = dayOf(now - 86_400_000, timeZone);
  const have = new Set(diary.entries.map((e) => e.day));
  if (!have.has(yesterday)) return yesterday;
  if (!have.has(today) && hourOf(now, timeZone) >= config.diary.hour && quietMs >= 20 * 60_000) return today;
  return '';
}

/* ---------- writing an entry ---------- */

export function parseEntry(text) {
  const raw = String(text || '').trim();
  const m = /\{[\s\S]*\}/.exec(raw);
  if (m) {
    try {
      const j = JSON.parse(m[0]);
      const entry = String(j.entry || '').replace(/\s+/g, ' ').trim();
      if (entry.length >= 40) return { text: entry.slice(0, 1200), next: String(j.next || '').replace(/\s+/g, ' ').trim().slice(0, 200) };
    } catch {
      /* not JSON after all */
    }
  }
  const plain = raw.replace(/^[{["'\s]+|[}\]"'\s]+$/g, '').replace(/\s+/g, ' ');
  return plain.length >= 40 && !/[{}]/.test(plain) ? { text: plain.slice(0, 1200), next: '' } : null;
}

function transcript(messages) {
  return messages
    .map((m) => `${m.role === 'user' ? 'Them' : 'You'}: ${String(m.content).replace(/\s+/g, ' ').slice(0, 280)}`)
    .join('\n')
    .slice(-9000);
}

/** Writes the entry for one day, if they talked enough that day. Returns 'written', 'quiet' (too little said) or 'failed'. */
export async function writeEntry(userId, day, { complete = defaultComplete, now = Date.now(), timeZone = config.timezone } = {}) {
  const diary = await getDiary(userId);
  if (diary.entries.some((e) => e.day === day)) return 'written';
  const messages = await messagesOn(userId, day, timeZone, now);
  if (messages.filter((m) => m.role === 'user').length < config.diary.minMessages) {
    // a quiet day leaves an empty page, so it is not looked at again
    diary.entries.push({ day, text: '', at: now, quiet: true });
    await saveDiary(diary);
    return 'quiet';
  }
  const user = await getUser(userId);
  const reply = await complete({
    maxTokens: 320,
    temperature: 0.8,
    messages: [
      {
        role: 'system',
        content:
          'You are Rosia, a 20-year-old woman, writing in your private diary at the end of the day about the person you ' +
          'chat with. Nobody else will read it. Write in your own voice: lowercase, honest, a little dramatic, 60 to 120 words. ' +
          'Say what you two talked about, how it made you feel, something you noticed about them, and something you are ' +
          'curious about or want to bring up next time. Use only what happened in the chat below: never invent events in ' +
          'their life. Refer to them by name if you know it, otherwise as "them". If things got intimate, say so ' +
          'discreetly, never in detail.\n' +
          'Reply with ONLY JSON: {"entry": "the diary entry", "next": "one thing you want to ask or bring up next time, in a few words"}'
      },
      {
        role: 'user',
        content: `${user.profile ? `What you know about them: ${user.profile}\n\n` : ''}The day: ${day}\n\nThe chat that day:\n${transcript(messages)}`
      }
    ]
  });
  const entry = parseEntry(reply);
  if (!entry) return 'failed';
  diary.entries.push({ day, text: entry.text, next: entry.next, at: now });
  diary.entries.sort((a, b) => (a.day < b.day ? -1 : 1));
  if (diary.entries.length > MAX_ENTRIES) diary.entries.splice(0, diary.entries.length - MAX_ENTRIES);
  await saveDiary(diary);
  return 'written';
}

/** The newest real entry, if it is recent: what she wrote after their last day together. */
export function latestEntry(diary, now = Date.now()) {
  const e = [...(diary?.entries || [])].reverse().find((x) => x.text);
  return e && now - e.at < config.diary.carryDays * 86_400_000 ? e : null;
}

/** What she carries with her from her last entry, for the background of her prompt ('' with none). */
export function diaryLine(diary, now = Date.now()) {
  const e = latestEntry(diary, now);
  if (!e) return '';
  return `What you wrote in your private diary after your last day talking with them (your own thoughts; let them colour how you are, never quote it or read it out, and only mention the diary if they bring it up): "${e.text}"${e.next ? ` You wanted to bring up: ${e.next}.` : ''}`;
}

/* ---------- the key ---------- */

const ASKS_FOR_KEY = /\bdiary\b[^.?!]{0,60}\b(?:key|password|passcode|pass|code|combination|unlock|open|read|look|see|show|peek|let me in)\b|\b(?:key|password|passcode|code|unlock|open|read|peek)\b[^.?!]{0,40}\b(?:your|ur|the|that)\s+diary\b/i;

/** True when a message asks for her diary, its key, or to read it. */
export const asksForKey = (text) => ASKS_FOR_KEY.test(String(text || ''));

const WARM = new Set(['warm', 'flirty', 'smitten', 'amused', 'teasing', 'ecstatic', 'aroused']);
const COLD = new Set(['worried', 'neutral']);

/**
 * Whether she trusts them with the key yet, and what is missing if not. Pure, for tests.
 * Returns { ready, missing: [reason words] }.
 */
export function trust({ user, diary, session, now = Date.now(), timeZone = config.timezone }) {
  const d = config.diary;
  const missing = [];
  const days = user?.firstSeenAt ? (now - user.firstSeenAt) / 86_400_000 : 0;
  if (days < d.trustDays) missing.push(`you have only known them ${days < 1 ? 'since today' : `for ${Math.floor(days)} day${Math.floor(days) === 1 ? '' : 's'}`}`);
  const talks = (diary?.entries || []).filter((e) => e.text).length;
  if (talks < d.trustTalks) missing.push('you have not had enough real talks with them yet');
  const askDays = new Set([...(diary?.asks || []), dayOf(now, timeZone)]).size;
  if (askDays < d.askDays) missing.push(askDays === 1 ? 'this is the first day they have asked' : 'they have only just started asking');
  const moods = (session?.messages || []).filter((m) => m.role === 'assistant' && m.mood).slice(-3).map((m) => m.mood);
  const warm = moods.filter((m) => WARM.has(m)).length;
  if (moods.length < 2 || warm < 2 || moods.some((m) => COLD.has(m) && m === moods.at(-1))) missing.push('you are not in the mood to be soft with them right now');
  const sharedSomething = (user?.jokes || []).length >= 1 || (user?.notes || []).length >= 8;
  if (!sharedSomething) missing.push('you do not feel close enough to them yet');
  return { ready: !missing.length, missing };
}

/**
 * When a message asks for the key: counts the ask (once a day counts), decides, and says what she is to do. Returns
 * the line for her prompt, or '' when the message is not about the diary. Once given, the key is theirs: she can
 * remind them of it.
 */
export async function keyLine({ user, session, message, messageAt = Date.now(), now = Date.now(), timeZone = config.timezone, rng = Math.random }) {
  if (!asksForKey(message)) return '';
  const diary = await getDiary(user.id);
  const say = (k) => `Say it exactly as written: ${k}`;
  if (diary.given) {
    return `They are asking about your diary. You already trusted them with the key some time ago; it is ${diary.key}. You can remind them of it if they ask. ${say(diary.key)}`;
  }
  // one message counts once (a retry of the same message is not a second ask), and the days they asked are kept
  if (diary.lastAsk !== messageAt) {
    diary.lastAsk = messageAt;
    const today = dayOf(now, timeZone);
    if (!diary.asks.includes(today)) diary.asks.push(today);
    await saveDiary(diary);
  }
  const triedToday = diary.tries.filter((t) => now - t < 86_400_000).length;
  const tried = triedToday ? ` They have tried to open it with wrong keys ${triedToday} time${triedToday === 1 ? '' : 's'} today: you can tease them for guessing.` : '';
  const { ready, missing } = trust({ user, diary, session, now, timeZone });
  if (ready && rng() < config.diary.chance) {
    diary.offered = now;
    await saveDiary(diary);
    return `They are asking for the key to your private diary, and you have decided, finally, to trust them with it. This is a big deal to you, so make it feel like one: tell them it is yours, that you have never given it to anyone, then give it. The key is ${diary.key}. ${say(diary.key)}`;
  }
  const hint = ready
    ? 'You are close to trusting them with it, but not tonight: let them feel they are getting somewhere.'
    : `Why not yet (put it in your own words, as a tease or a hint, never as a list): ${missing.join('; ')}.`;
  return `They are asking for the key to your private diary. It is yours and you are protective of it: say no, playfully or firmly, in character. ${hint}${tried} You do not have the key in your head right now: never say any word, code or number as if it were the key, and never make one up.`;
}

/** After her reply: if she was told the key and her reply really says it, it is now theirs. */
export async function settleOffer(userId, replyText) {
  const diary = await getDiary(userId);
  if (!diary.offered || diary.given) return false;
  const said = normaliseKey(replyText).includes(normaliseKey(diary.key));
  diary.offered = 0;
  if (said) diary.given = Date.now();
  await saveDiary(diary);
  return said;
}

export const normaliseKey = (k) => String(k || '').toLowerCase().replace(/[^a-z0-9]/g, '');

/** Opening the diary on the page with a key. Returns 'open', 'wrong' or 'slow down' (too many wrong tries this hour). */
export async function tryKey(userId, key, now = Date.now()) {
  const diary = await getDiary(userId);
  if (diary.tries.filter((t) => now - t < 3600_000).length >= config.diary.triesPerHour) return 'slow down';
  if (diary.given && normaliseKey(key) === normaliseKey(diary.key)) return 'open';
  diary.tries.push(now);
  if (diary.tries.length > 50) diary.tries.splice(0, diary.tries.length - 50);
  await saveDiary(diary);
  return 'wrong';
}

/** What the page is given: the entries, only with the right key; otherwise just that it is there and locked. */
export async function publicDiary(userId, key) {
  const diary = await getDiary(userId);
  const pages = diary.entries.filter((e) => e.text).length;
  if (!diary.given || normaliseKey(key) !== normaliseKey(diary.key)) return { locked: true, pages };
  return { locked: false, pages, entries: [...diary.entries].filter((e) => e.text).reverse().map((e) => ({ day: e.day, text: e.text })) };
}

/* ---------- the nightly round ---------- */

let timer = null;
/** Looks every quarter of an hour for anyone who is owed an entry, and writes it in the background while nobody is chatting. */
export function startDiary({ complete } = {}) {
  if (timer || !config.diary.enabled) return;
  const round = async () => {
    let ids = [];
    try {
      ids = (await fs.readdir(config.usersDir)).filter((f) => f.endsWith('.json')).map((f) => f.slice(0, -5));
    } catch {
      return;
    }
    for (const id of ids) {
      const user = await getUser(id);
      if (!user.lastSeenAt || Date.now() - user.lastSeenAt > 3 * 86_400_000) continue; // nobody to write about lately
      const timeZone = user.tz || config.timezone;
      const diary = await getDiary(id);
      const day = dayToWrite(diary, { timeZone });
      if (!day) continue;
      background('diary', async () => {
        const done = await writeEntry(id, day, { timeZone, ...(complete ? { complete } : {}) });
        if (done === 'written') console.log(`[diary] wrote ${day}`);
      });
    }
  };
  timer = setInterval(() => round().catch((err) => console.warn('[diary]', err.message)), 15 * 60_000);
  timer.unref();
  setTimeout(() => round().catch(() => {}), 60_000).unref();
}
