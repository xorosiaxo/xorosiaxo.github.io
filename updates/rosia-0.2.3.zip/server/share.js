import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { config } from './config.js';
import { setAccessMode, accessMode } from './auth.js';

/*
 * Sharing with friends: the owner starts a Cloudflare quick tunnel from Settings and gives the link out; friends then use
 * the owner's computer. Two things are kept here:
 *
 *  - who a link lets in ("open": anyone with the link gets their own private space; "invite": only machines linked with a
 *    code, which share the owner's chats). Saved in data/share.json, so what was chosen in Settings survives a restart
 *    and wins over the launcher's setting.
 *  - the tunnel itself: cloudflared is started, the address it prints is read, and it is stopped again on request or when
 *    the app stops. Nothing is published unless the owner presses the button.
 */

const file = path.join(config.dataDir, 'share.json');
const BIN = process.env.ROSA_CLOUDFLARED || 'cloudflared';

/** The address a quick tunnel prints once it is up, or ''. */
export function tunnelUrlFrom(text) {
  return /https:\/\/[a-z0-9-]+\.trycloudflare\.com/i.exec(String(text || ''))?.[0] || '';
}

/** 'open' or 'invite' from anything; anything else is 'invite', the careful one. */
export function cleanAccess(value) {
  return /^open$/i.test(String(value || '')) ? 'open' : 'invite';
}

/** What was chosen in Settings wins; otherwise the launcher's setting; otherwise invite. */
export function chooseAccess(saved, fromLauncher) {
  if (saved === 'open' || saved === 'invite') return saved;
  return cleanAccess(fromLauncher);
}

export function initShare() {
  let saved;
  try {
    saved = JSON.parse(fs.readFileSync(file, 'utf8')).access;
  } catch {
    /* nothing chosen in Settings yet */
  }
  setAccessMode(chooseAccess(saved, process.env.ROSA_ACCESS));
}

export function saveAccess(value) {
  const mode = cleanAccess(value);
  setAccessMode(mode);
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify({ access: mode }), 'utf8');
  } catch (err) {
    console.error('[share] could not save the access setting:', err.message);
  }
  return mode;
}

/* ---------- the tunnel ---------- */

let child = null;
const tunnel = { running: false, starting: false, url: '', error: '', startedAt: 0 };

export function tunnelState() {
  return { running: tunnel.running, starting: tunnel.starting, url: tunnel.url, error: tunnel.error, startedAt: tunnel.startedAt };
}

/** Starts the tunnel and resolves once it has an address (or with the reason it has none). */
export function startTunnel({ spawnFn = spawn, waitMs = 30_000 } = {}) {
  if (child) return Promise.resolve(tunnelState());
  Object.assign(tunnel, { running: false, starting: true, url: '', error: '', startedAt: 0 });

  return new Promise((resolve) => {
    let settled = false;
    const done = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(tunnelState());
    };
    const fail = (message) => {
      Object.assign(tunnel, { running: false, starting: false, url: '', error: message });
      const c = child;
      child = null;
      try { c?.kill(); } catch { /* already gone */ }
      done();
    };
    const timer = setTimeout(() => fail('The link did not come up in time. Check the internet connection and try again.'), waitMs);

    try {
      child = spawnFn(BIN, ['tunnel', '--no-autoupdate', '--url', `http://127.0.0.1:${config.port}`], { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    } catch (err) {
      return fail(`Could not start cloudflared: ${err.message}`);
    }
    const mine = child;

    let seen = '';
    const read = (chunk) => {
      if (tunnel.url) return;
      seen = (seen + chunk).slice(-8000);
      const url = tunnelUrlFrom(seen);
      if (url) {
        Object.assign(tunnel, { running: true, starting: false, url, error: '', startedAt: Date.now() });
        done();
      }
    };
    mine.stdout?.on('data', read);
    mine.stderr?.on('data', read);
    mine.on('error', (err) => {
      if (child !== mine) return;
      fail(err.code === 'ENOENT' ? 'cloudflared is not installed on this computer. Install it from Cloudflare, then try again.' : `Could not start cloudflared: ${err.message}`);
    });
    mine.on('exit', () => {
      if (child !== mine) return;
      child = null;
      const had = tunnel.running;
      Object.assign(tunnel, { running: false, starting: false, url: '', error: had ? 'Sharing stopped: the link went down.' : (tunnel.error || 'cloudflared stopped before the link came up.') });
      done();
    });
  });
}

export function stopTunnel() {
  const c = child;
  child = null;
  Object.assign(tunnel, { running: false, starting: false, url: '', error: '', startedAt: 0 });
  try { c?.kill(); } catch { /* already gone */ }
  return tunnelState();
}

/** What the owner's Settings shows. */
export function shareStatus(friends) {
  return { access: accessMode, tunnel: tunnelState(), friends };
}
