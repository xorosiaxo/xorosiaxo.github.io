import fs from 'node:fs/promises';
import path from 'node:path';
import { config } from './config.js';
import { debug } from './debuglog.js';

/*
 * A nightly copy of everything that cannot be recreated: conversations, memory, the list of who is signed in, and the
 * GIF/video catalogues. Chats and memory are small, so each night gets a dated folder of its own
 * (Rosia-Backups/rosia-2026-11-11-0400/). Pictures are never changed once saved, so they are kept in one shared
 * Rosia-Backups/media folder that only ever has new files added to it, instead of a full copy every night.
 *
 * To restore: close Rosia, copy the folders of the night you want (users, sessions, auth.json, gifs) back into `data`, and
 * the media folder next to them.
 *
 * The debugging log, the picture stock and ComfyUI's files are not included (they can be recreated or are large).
 * ROSA_BACKUP=0 turns it off, ROSA_BACKUP_DIR chooses where, ROSA_BACKUP_KEEP how many nights to keep (7).
 * Old nights beyond that are removed; nothing else in the folder is touched.
 */

const NAME = /^rosia-(\d{4})-(\d{2})-(\d{2})-(\d{2})(\d{2})$/;
const stampOf = (d) => {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
};

async function exists(p) {
  try {
    await fs.access(p);
    return true;
  } catch {
    return false;
  }
}

/** Copies a folder, skipping files that are already there with the same size. Returns how many files were copied. */
async function copyMissing(from, to) {
  let copied = 0;
  let entries;
  try {
    entries = await fs.readdir(from, { withFileTypes: true });
  } catch {
    return 0;
  }
  await fs.mkdir(to, { recursive: true });
  for (const entry of entries) {
    const src = path.join(from, entry.name);
    const dst = path.join(to, entry.name);
    if (entry.isDirectory()) {
      copied += await copyMissing(src, dst);
    } else if (entry.isFile()) {
      let same = false;
      try {
        same = (await fs.stat(dst)).size === (await fs.stat(src)).size;
      } catch {
        /* not there yet */
      }
      if (!same) {
        await fs.copyFile(src, dst);
        copied += 1;
      }
    }
  }
  return copied;
}

/** The dated folders in the backup folder, newest first, as { name, at }. */
export async function listBackups(dir = config.backup.dir) {
  let names = [];
  try {
    names = await fs.readdir(dir);
  } catch {
    return [];
  }
  return names
    .map((name) => {
      const m = NAME.exec(name);
      return m ? { name, at: new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5])).getTime() } : null;
    })
    .filter(Boolean)
    .sort((a, b) => b.at - a.at);
}

/** Makes one backup now. Returns { folder, files, pictures, removed }. */
export async function backupNow({ dir = config.backup.dir, keep = config.backup.keep, data = config.dataDir, now = new Date() } = {}) {
  if (!dir) throw new Error('No backup folder is set.');
  const folder = path.join(dir, `rosia-${stampOf(now)}`);
  await fs.mkdir(folder, { recursive: true });

  let files = 0;
  for (const part of ['users', 'sessions']) files += await copyMissingAlways(path.join(data, part), path.join(folder, part));
  if (await exists(path.join(data, 'auth.json'))) {
    await fs.copyFile(path.join(data, 'auth.json'), path.join(folder, 'auth.json'));
    files += 1;
  }
  for (const f of ['library.json', 'video-library.json', 'cleared.json']) {
    const src = path.join(data, 'gifs', f);
    if (await exists(src)) {
      await fs.mkdir(path.join(folder, 'gifs'), { recursive: true });
      await fs.copyFile(src, path.join(folder, 'gifs', f));
      files += 1;
    }
  }
  const pictures = await copyMissing(path.join(data, 'media'), path.join(dir, 'media'));

  // only our own dated folders are ever removed, and only the ones beyond the newest `keep`
  const all = await listBackups(dir);
  const old = all.slice(Math.max(1, keep));
  for (const b of old) await fs.rm(path.join(dir, b.name), { recursive: true, force: true });
  debug('backup', { folder: path.basename(folder), files, pictures, removed: old.length });
  return { folder, files, pictures, removed: old.length };
}

/** Everything under `from` is copied again every time (chats change; they are small). */
async function copyMissingAlways(from, to) {
  let copied = 0;
  let entries;
  try {
    entries = await fs.readdir(from, { withFileTypes: true });
  } catch {
    return 0;
  }
  await fs.mkdir(to, { recursive: true });
  for (const entry of entries) {
    const src = path.join(from, entry.name);
    const dst = path.join(to, entry.name);
    if (entry.isDirectory()) copied += await copyMissingAlways(src, dst);
    else if (entry.isFile() && !entry.name.endsWith('.tmp')) {
      await fs.copyFile(src, dst);
      copied += 1;
    }
  }
  return copied;
}

/** True when the newest backup is older than `hours` (or there is none). */
export async function backupDue({ dir = config.backup.dir, hours = 23, now = Date.now() } = {}) {
  const [newest] = await listBackups(dir);
  return !newest || now - newest.at > hours * 3600_000;
}

let timer = null;

/** A backup a couple of minutes after start-up if the last one is more than a day old, then a check every half hour. */
export function startBackups() {
  if (timer || !config.backup.enabled) return;
  const check = async () => {
    try {
      if (await backupDue()) await backupNow();
    } catch (err) {
      debug('backup.failed', { error: err });
      console.error('[backup] failed:', err.message);
    }
  };
  setTimeout(check, 2 * 60_000).unref?.();
  timer = setInterval(check, 30 * 60_000);
  timer.unref?.();
}
