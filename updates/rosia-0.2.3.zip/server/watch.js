import { config } from './config.js';
import { videoFor, ytdlpInstalled, VIDEO_ID } from './music/ytdlp.js';

/*
 * Watching a video together. "watch the gta 6 trailer with me": she finds it on YouTube, it plays in a small window in
 * the page (passed on by the app like the music, /video/yt/<id>, so the bar can jump), and she knows what is on, where
 * it has got to and, from its captions, what is being said right now, so she can react to it as it goes.
 *
 * One video at a time per person, kept in memory (like the music player). The page tells the app where the video has
 * got to every few seconds.
 */

export const watchReady = () => Boolean(config.music.youtube && ytdlpInstalled());

const watching = new Map(); // userId -> { id, title, channel, duration, art, position, paused, at, seq }
const captions = new Map(); // video id -> [{ at, end, text }]

/* ---------- finding a video ---------- */

const CLIENT = { clientName: 'WEB', clientVersion: '2.20251110.00.00', hl: 'en', gl: 'US' };
const ONLY_VIDEOS = 'EgIQAQ%3D%3D';
const clock = (s) => String(s || '').split(':').reduce((sum, n) => sum * 60 + Number(n), 0) || 0;

/** Every video in a YouTube search answer, in order. */
export function videosIn(body) {
  const out = [];
  const walk = (o) => {
    if (!o || typeof o !== 'object') return;
    if (o.videoRenderer) {
      const v = o.videoRenderer;
      if (VIDEO_ID.test(String(v.videoId || '')) && v.lengthText) {
        out.push({
          id: v.videoId,
          title: String(v.title?.runs?.map((r) => r.text).join('') || '').slice(0, 160),
          channel: String(v.ownerText?.runs?.[0]?.text || '').slice(0, 100),
          duration: clock(v.lengthText?.simpleText),
          art: v.thumbnail?.thumbnails?.at(-1)?.url || ''
        });
      }
      return;
    }
    for (const x of Object.values(o)) walk(x);
  };
  walk(body);
  return out;
}

/** "the latest sidemen video": newest first, and "latest" is not part of the search. Pure, for tests. */
export function searchFor(query) {
  const text = String(query || '');
  const newest = /\b(?:latest|newest|most recent|new|recent|just (?:came|come) out|today'?s)\b/i.test(text);
  const words = newest ? text.replace(/\b(?:the\s+)?(?:latest|newest|most recent|new|recent|today'?s)\b/gi, ' ').replace(/\bjust (?:came|come) out\b/gi, ' ').replace(/\s+/g, ' ').trim() : text.trim();
  // YouTube's own filters: videos only, and videos only sorted by upload date
  return { words: words || text, params: newest ? 'CAISAhAB' : ONLY_VIDEOS, newest };
}

export async function searchVideos(query, { signal } = {}) {
  const want = searchFor(query);
  const gaveUp = AbortSignal.timeout(config.music.timeoutMs);
  const res = await fetch(`${config.watch.searchUrl}/youtubei/v1/search?prettyPrint=false`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', origin: 'https://www.youtube.com', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36' },
    body: JSON.stringify({ context: { client: CLIENT }, query: want.words.slice(0, 200), params: want.params }),
    signal: signal ? AbortSignal.any([signal, gaveUp]) : gaveUp
  });
  if (!res.ok) throw new Error(`YouTube answered ${res.status}.`);
  // nothing longer than three hours: a stream or a mix is not something to watch together in a small window
  return videosIn(await res.json()).filter((v) => v.duration > 0 && v.duration <= 3 * 3600);
}

/* ---------- what is being said ---------- */

/** YouTube's json3 captions as [{ at, end, text }] in seconds. */
export function parseCaptions(json) {
  return (json?.events || [])
    .filter((e) => Array.isArray(e.segs))
    .map((e) => ({ at: (e.tStartMs || 0) / 1000, end: ((e.tStartMs || 0) + (e.dDurationMs || 0)) / 1000, text: e.segs.map((s) => s.utf8 || '').join('').replace(/\s+/g, ' ').trim() }))
    .filter((c) => c.text && c.text !== '[Music]');
}

async function loadCaptions(id, link) {
  if (captions.has(id) || !link) return;
  captions.set(id, []); // asked for once
  try {
    const res = await fetch(link, { signal: AbortSignal.timeout(10_000) });
    if (res.ok) captions.set(id, parseCaptions(await res.json()));
  } catch {
    /* no captions: she just knows what it is */
  }
  while (captions.size > 30) captions.delete(captions.keys().next().value);
}

/** What was said in the half minute up to `position` (seconds), as one line, or ''. */
export function saidAround(lines, position, { before = 30, after = 4 } = {}) {
  const near = (lines || []).filter((c) => c.end >= position - before && c.at <= position + after);
  return near.map((c) => c.text).join(' ').replace(/\s+/g, ' ').slice(-500);
}

/* ---------- the window ---------- */

export const watchingOf = (userId) => watching.get(String(userId || 'local')) || null;

/** Where the video is now: the last position the page told, plus the time since if it is playing. */
export function positionNow(w, now = Date.now()) {
  if (!w) return 0;
  const p = (w.position || 0) + (w.paused ? 0 : Math.max(0, (now - w.at) / 1000));
  return w.duration ? Math.min(p, w.duration) : p;
}

/** Puts a video on for someone. Looks it up first (so a video that will not play is never shown). */
export async function startWatching(userId, video, { signal } = {}) {
  const found = await videoFor(video.id);
  if (signal?.aborted) throw new Error('Stopped.');
  loadCaptions(video.id, found.captions); // in the background: she can react once they are in
  const before = watchingOf(userId);
  const w = {
    id: video.id,
    title: found.title || video.title,
    channel: found.channel || video.channel,
    duration: found.duration || video.duration || 0,
    art: video.art || '',
    url: `/video/yt/${video.id}`,
    position: 0,
    paused: false,
    at: Date.now(),
    seq: (before?.seq || 0) + 1
  };
  watching.set(String(userId), w);
  return w;
}

/** A change from her or from the page: pause, resume, stop, seek, or the page saying where it is. */
export function changeWatching(userId, { type, position, paused }) {
  const w = watchingOf(userId);
  if (!w) throw new Error('Nothing is on.');
  const now = Date.now();
  if (type === 'stop') {
    watching.delete(String(userId));
    return { did: 'stopped', w: null };
  }
  const at = Number(position);
  if (Number.isFinite(at) && at >= 0) w.position = w.duration ? Math.min(at, w.duration) : at;
  else w.position = positionNow(w, now);
  w.at = now;
  if (type === 'pause') w.paused = true;
  if (type === 'resume') w.paused = false;
  if (type === 'report' && typeof paused === 'boolean') w.paused = paused;
  if (type === 'ended') w.paused = true;
  if (type === 'seek') w.seq += 1;
  return { did: type, w };
}

const mmss = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

/** What she is told with every message while a video is on: what, where it has got to, and what is being said. */
export function watchLine(userId, now = Date.now()) {
  const w = watchingOf(userId);
  if (!w) return '';
  const at = positionNow(w, now);
  const said = saidAround(captions.get(w.id), at);
  const where = w.duration ? `${mmss(at)} of ${mmss(w.duration)}` : mmss(at);
  return `Watching together: you and they are watching "${w.title}"${w.channel ? ` by ${w.channel}` : ''} in their video window, ${w.paused ? 'paused' : 'playing'} at ${where}.` +
    (said ? ` What is being said right about now: "${said}". React to what is happening in it like you are watching it with them (a few words, now and then), not every time.` : ' React to it like you are watching it with them, now and then.') +
    ' You control it with video_control.';
}

/** What the page is given. */
export function publicWatching(userId) {
  const w = watchingOf(userId);
  return w ? { id: w.id, title: w.title, channel: w.channel, duration: w.duration, url: w.url, position: positionNow(w), paused: w.paused, seq: w.seq } : null;
}

/** For tests. */
export function resetWatching() {
  watching.clear();
  captions.clear();
}
export const setCaptionsForTest = (id, lines) => captions.set(id, lines);
