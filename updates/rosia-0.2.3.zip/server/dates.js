/*
 * Turns the way a person (or a small model) says when something stops mattering into a moment.
 * Working out "Friday" from today is done here, in code, because language models get it wrong.
 *
 * Accepts: an ISO date (2026-11-13), "today", "tomorrow", a weekday ("friday", "next friday",
 * "on Monday"), "this weekend", "next week", "this month". Anything else gives undefined.
 *
 * The result is the end of that day plus a day of grace, so a fact never disappears before it is over.
 */

const DAY = 86_400_000;
const DAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

/** y, m (0-11), d and weekday (0 = Sunday) of `now` in the given time zone. */
function today(now, timeZone) {
  const parts = new Intl.DateTimeFormat('en-GB', { timeZone, year: 'numeric', month: 'numeric', day: 'numeric', weekday: 'long' })
    .formatToParts(new Date(now));
  const get = (type) => parts.find((p) => p.type === type)?.value;
  return {
    y: Number(get('year')),
    m: Number(get('month')) - 1,
    d: Number(get('day')),
    weekday: DAYS.indexOf(String(get('weekday')).toLowerCase())
  };
}

const endOfDay = (y, m, d) => Date.UTC(y, m, d, 23, 59, 59);

export function resolveUntil(value, now = Date.now(), timeZone = 'UTC') {
  const text = String(value ?? '').trim().toLowerCase().replace(/^(on|by|until|till|before)\s+/, '');
  if (!text || text === 'null' || text === 'none') return undefined;
  const t = today(now, timeZone);

  let target; // days from today
  const iso = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
  if (iso) {
    const end = endOfDay(Number(iso[1]), Number(iso[2]) - 1, Number(iso[3]));
    const real = new Date(end); // 2026-13-45 rolls over into a different date: refuse it
    if (!Number.isFinite(end) || real.getUTCMonth() !== Number(iso[2]) - 1 || real.getUTCDate() !== Number(iso[3])) return undefined;
    target = Math.round((end - endOfDay(t.y, t.m, t.d)) / DAY);
  } else if (text === 'today' || text === 'tonight') {
    target = 0;
  } else if (text === 'tomorrow') {
    target = 1;
  } else if (/^(this )?weekend$/.test(text)) {
    target = (7 - t.weekday) % 7 || (t.weekday === 0 ? 0 : 7); // the coming Sunday
  } else if (/^(next week|in a week)$/.test(text)) {
    target = 7;
  } else if (/^(this month|end of (the )?month)$/.test(text)) {
    target = Math.round((endOfDay(t.y, t.m + 1, 0) - endOfDay(t.y, t.m, t.d)) / DAY);
  } else {
    const m = /^(?:(next|this)\s+)?(sunday|monday|tuesday|wednesday|thursday|friday|saturday)$/.exec(text);
    if (!m) return undefined;
    const want = DAYS.indexOf(m[2]);
    target = (want - t.weekday + 7) % 7; // today counts when it is that day
    if (m[1] === 'next') target += 7;
  }

  if (!Number.isFinite(target) || target < -1 || target > 366) return undefined;
  return endOfDay(t.y, t.m, t.d) + target * DAY + DAY; // end of that day, plus a day of grace
}
