import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import { isQuiet, msSinceActivity, untilActivity } from '../activity.js';
import { chatReady } from '../gpu.js';
import { visionSupported } from '../llm.js';
import { record } from '../metrics.js';
import { debug } from '../debuglog.js';
import { describeItem, extractStrip, searchText, DESC_VERSION } from './describe.js';
import { config } from '../config.js';
import { embedMany, currentKind } from '../embed.js';
import { syncVideoCatalog, nextPendingVideo, indexNextVideo, saveVideoCatalog, nextVideoUpgrade, upgradeNextVideo, staleVideoVectors } from '../videos/catalog.js';
import { gifsConfigured, loadLibrary, syncLibrary, nextPending, pendingItems, allItems, fileFor, saveLibrary, isFlagged, quarantine, sweepFlagged } from './library.js';

/*
 * Works through the collection in the background, one clip at a time, only while nobody is chatting and the chat model
 * is on the graphics card (a clip takes the model for a few seconds). It carries on where it left off after a restart,
 * and picks up new files the export plugin adds.
 *
 * Two things keep it quick: the frames of the NEXT clip are cut while the model is still looking at this one, and a clip
 * that is a byte-for-byte copy of one already looked at (the same GIF saved from two places) is not looked at again.
 */

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let started = false;
let lastError = '';
const prefetched = new Map(); // id -> the frames of that clip, already being cut

export const indexerError = () => lastError;

/** A fingerprint of a file: its size and its first 64 KB. Two copies of one clip match; two different clips do not. */
export async function signatureOf(item) {
  const handle = await fs.open(fileFor(item), 'r');
  try {
    const { size } = await handle.stat();
    const buf = Buffer.alloc(Math.min(65536, size));
    await handle.read(buf, 0, buf.length, 0);
    return `${size}-${crypto.createHash('md5').update(buf).digest('hex')}`;
  } finally {
    await handle.close();
  }
}

/** A clip already looked at (kept, or refused for showing someone who might be a minor) with the same fingerprint. */
function twinOf(item) {
  return allItems().find((o) => o !== item && o.sig === item.sig && (o.status === 'ok' || (o.status === 'skip' && /under 18/.test(o.why || ''))));
}

function prefetch(next, deps) {
  if (!next || prefetched.has(next.id) || prefetched.size > 4) return;
  const promise = (deps.strip || extractStrip)(fileFor(next));
  promise.catch(() => {}); // a failure is reported when that clip's turn comes
  prefetched.set(next.id, promise);
}

/** Looks at one pending clip. Returns true if there was one. deps are for tests. */
export async function indexNext(deps = {}) {
  const [item, following] = pendingItems(2);
  if (!item) return false;
  const began = Date.now();
  try {
    try {
      item.sig = await (deps.signature || signatureOf)(item);
    } catch {
      item.sig = '';
    }
    const twin = item.sig ? twinOf(item) : null;
    if (twin) {
      Object.assign(item, twin.status === 'ok'
        ? { status: 'ok', ...describedFields(twin), dupOf: twin.id }
        : { status: 'skip', why: twin.why, adult: twin.adult, dupOf: twin.id });
    } else {
      const own = deps.strip || extractStrip;
      const work = describeItem(item, {
        ...deps,
        strip: (file) => {
          const ready = prefetched.get(item.id);
          prefetched.delete(item.id);
          return ready || own(file);
        }
      });
      prefetch(following, deps); // the next clip's frames are cut while the model reads this one
      Object.assign(item, await work);
    }
    if (isFlagged(item)) await quarantine(item).catch(() => {}); // out of the main folder at once, into flagged/
    item.tries = 0;
    lastError = '';
    record('job', { name: 'gif', ok: true, ms: Date.now() - began });
  } catch (err) {
    prefetched.delete(item.id);
    if (deps.signal?.aborted) return true; // someone started chatting: not a failure, the clip is looked at later
    item.tries = (item.tries || 0) + 1;
    item.status = item.tries >= 3 ? 'skip' : 'error';
    item.why = item.tries >= 3 ? `could not be read: ${String(err.message).slice(0, 100)}` : undefined;
    lastError = String(err.message || err).slice(0, 160);
    debug('gif.index.failed', { file: item.file, tries: item.tries, error: err });
    record('job', { name: 'gif', ok: false, ms: Date.now() - began });
  }
  return true;
}

/** What a description consists of, to copy from a clip onto its byte-for-byte copies. */
export function describedFields(item) {
  const { description, reaction, useWhen, mood, intensity, tags, text, adult, vec, vecKind, descVersion } = item;
  return { description, reaction, useWhen, mood, intensity, tags, text, adult, vec, vecKind, descVersion };
}

/** The next clip with an older, shorter description that is worth describing again (never a copy: copies follow their original). */
export function nextUpgrade() {
  if (!config.gifs.redescribe) return null;
  for (const item of allItems()) {
    if (item.status === 'ok' && !item.dupOf && (item.descVersion || 1) < DESC_VERSION && !item.upgradeFailed) return item;
  }
  return null;
}

/**
 * Describes one clip again with the fuller prompt. The old description stays until the new one is ready, and stays for
 * good if the clip cannot be read again. Its copies get the new description too. Returns true if there was one.
 */
export async function upgradeNext(deps = {}) {
  const item = nextUpgrade();
  if (!item) return false;
  const began = Date.now();
  try {
    const fresh = await describeItem(item, deps);
    Object.assign(item, fresh);
    if (fresh.status === 'ok') delete item.why;
    for (const twin of allItems()) {
      if (twin.dupOf !== item.id) continue;
      Object.assign(twin, fresh.status === 'ok' ? { status: 'ok', ...describedFields(item) } : { status: fresh.status, why: fresh.why, descVersion: fresh.descVersion });
    }
    if (isFlagged(item)) await quarantine(item).catch(() => {});
    debug('gif.redescribe', { file: item.file, reaction: item.reaction, status: item.status, ms: Date.now() - began });
    record('job', { name: 'gif-redescribe', ok: true, ms: Date.now() - began });
  } catch (err) {
    if (deps.signal?.aborted) return true; // someone started chatting: tried again later
    item.upgradeFailed = true; // the old description is kept
    debug('gif.redescribe.failed', { file: item.file, error: err });
    record('job', { name: 'gif-redescribe', ok: false, ms: Date.now() - began });
  }
  return true;
}

/**
 * Clips and videos whose vector was made by the fallback word matcher (the embedding model was down when they were
 * catalogued) get a real one, in one batch, as soon as the model is back. Without this they could never be found by meaning.
 */
export async function reembedStale(limit = 64) {
  const kind = currentKind();
  if (kind === 'hash') return 0;
  const gifs = allItems().filter((i) => i.status === 'ok' && i.vec && i.vecKind !== kind).slice(0, limit);
  const videos = staleVideoVectors(kind).slice(0, Math.max(0, limit - gifs.length));
  const all = [...gifs, ...videos];
  if (!all.length) return 0;
  const { vecs, kind: madeBy } = await embedMany(all.map((e) => searchText({ ...e, tags: e.tags || [] })), 'document');
  if (madeBy !== kind) return 0;
  all.forEach((e, i) => Object.assign(e, { vec: vecs[i], vecKind: kind }));
  return all.length;
}

async function loop() {
  await loadLibrary();
  await sleep(20_000);
  let saveAt = 0;
  for (;;) {
    try {
      if (!gifsConfigured()) {
        await sleep(10 * 60_000);
        continue;
      }
      await syncLibrary();
      await sweepFlagged(); // anything flagged earlier (or moved by hand) is tidied into flagged/
      await syncVideoCatalog(); // saved video links join the same queue, after the GIFs
      if (isQuiet() && chatReady() && (await reembedStale())) {
        await saveLibrary();
        await saveVideoCatalog();
      }
      if (!nextPending() && !nextPendingVideo() && !nextUpgrade() && !nextVideoUpgrade()) {
        await saveLibrary(); // everything looked at: make sure the last ones are on disk
        await saveVideoCatalog();
        await sleep(10 * 60_000);
        continue;
      }
      // wait for a quiet moment with the chat model available
      if (!isQuiet() || !chatReady() || msSinceActivity() < config.gifs.idleMs) {
        await sleep(3000);
        continue;
      }
      if (!(await visionSupported())) {
        lastError = 'the chat model cannot see pictures (it needs its mmproj)';
        await sleep(5 * 60_000);
        continue;
      }
      // new clips first, then new videos, then the older descriptions are redone
      // the moment someone writes, the clip in hand is dropped, so their message is not kept waiting behind it
      const watch = untilActivity();
      try {
        const deps = { signal: watch.signal };
        if (nextPending()) await indexNext(deps);
        else if (nextPendingVideo()) await indexNextVideo(deps);
        else if (nextUpgrade()) await upgradeNext(deps);
        else await upgradeNextVideo(deps);
      } finally {
        watch.stop();
      }
      if (Date.now() - saveAt > 15_000) {
        saveAt = Date.now();
        await saveLibrary();
        await saveVideoCatalog();
      }
      if (lastError) await sleep(5000); // a run of failures should not spin
    } catch (err) {
      lastError = String(err.message || err).slice(0, 160);
      await sleep(30_000);
    }
  }
}

export function startIndexer() {
  if (started) return;
  started = true;
  loop().catch((err) => console.error('[gifs] indexer stopped:', err));
}
