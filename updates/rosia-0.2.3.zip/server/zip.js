import zlib from 'node:zlib';

/*
 * A small zip reader and writer (the project has no dependencies, and Node has no zip of its own). It only handles what the
 * releases need: plain files, stored or deflated, no encryption, no zip64. The reader is for files that came from the
 * internet, so it is strict: every name is checked (no absolute paths, no "..", no drive letters), the number and size of
 * entries are capped, a declared size is never trusted past its cap, and every file's CRC is checked.
 */

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

export function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i += 1) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

const DOS_TIME = 0;
const DOS_DATE = (1 << 5) | 1; // 1980-01-01: the same bytes every time, so a release can be rebuilt identically

/** files: [{ name: 'server/index.js', data: Buffer }] -> a zip file as a Buffer. */
export function createZip(files) {
  const locals = [];
  const centrals = [];
  let offset = 0;
  for (const file of files) {
    const name = Buffer.from(String(file.name).replace(/\\/g, '/'), 'utf8');
    const data = Buffer.isBuffer(file.data) ? file.data : Buffer.from(file.data);
    const packed = zlib.deflateRawSync(data, { level: 9 });
    const useDeflate = packed.length < data.length;
    const body = useDeflate ? packed : data;
    const crc = crc32(data);

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4); // version needed
    local.writeUInt16LE(0x0800, 6); // names are UTF-8
    local.writeUInt16LE(useDeflate ? 8 : 0, 8);
    local.writeUInt16LE(DOS_TIME, 10);
    local.writeUInt16LE(DOS_DATE, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(body.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28);
    locals.push(local, name, body);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4); // made by
    central.writeUInt16LE(20, 6); // needed
    central.writeUInt16LE(0x0800, 8);
    central.writeUInt16LE(useDeflate ? 8 : 0, 10);
    central.writeUInt16LE(DOS_TIME, 12);
    central.writeUInt16LE(DOS_DATE, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(body.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt32LE(offset, 42);
    centrals.push(central, name);

    offset += local.length + name.length + body.length;
  }
  const centralBytes = Buffer.concat(centrals);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralBytes.length, 12);
  end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, centralBytes, end]);
}

export class ZipError extends Error {}

/** True for a path that stays inside the folder it is unpacked into. */
export function safeName(raw) {
  const name = String(raw).replace(/\\/g, '/');
  if (!name || name.includes('\0') || name.startsWith('/') || /^[A-Za-z]:/.test(name)) return null;
  const parts = name.split('/').filter((p) => p !== '');
  if (!parts.length || parts.some((p) => p === '..' || p === '.')) return null;
  return parts.join('/');
}

/** A zip file (Buffer) -> [{ name, data }]. Directories are left out. Throws ZipError for anything unsafe or damaged. */
export function readZip(buf, { maxEntries = 5000, maxEntryBytes = 100 * 1024 * 1024, maxTotalBytes = 300 * 1024 * 1024 } = {}) {
  if (buf.length < 22) throw new ZipError('That is not a zip file.');
  let end = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 22 - 65535); i -= 1) {
    if (buf.readUInt32LE(i) === 0x06054b50) {
      end = i;
      break;
    }
  }
  if (end < 0) throw new ZipError('That is not a zip file.');
  const count = buf.readUInt16LE(end + 10);
  const centralSize = buf.readUInt32LE(end + 12);
  const centralAt = buf.readUInt32LE(end + 16);
  if (count === 0xffff || centralAt === 0xffffffff) throw new ZipError('Zip64 files are not supported.');
  if (count > maxEntries) throw new ZipError('The zip has too many files.');
  if (centralAt + centralSize > buf.length) throw new ZipError('The zip is damaged.');

  const out = [];
  const seen = new Set();
  let total = 0;
  let p = centralAt;
  for (let n = 0; n < count; n += 1) {
    if (p + 46 > buf.length || buf.readUInt32LE(p) !== 0x02014b50) throw new ZipError('The zip is damaged.');
    const flags = buf.readUInt16LE(p + 8);
    const method = buf.readUInt16LE(p + 10);
    const crc = buf.readUInt32LE(p + 16);
    const packedSize = buf.readUInt32LE(p + 20);
    const size = buf.readUInt32LE(p + 24);
    const nameLen = buf.readUInt16LE(p + 28);
    const extraLen = buf.readUInt16LE(p + 30);
    const commentLen = buf.readUInt16LE(p + 32);
    const localAt = buf.readUInt32LE(p + 42);
    const rawName = buf.toString('utf8', p + 46, p + 46 + nameLen);
    p += 46 + nameLen + extraLen + commentLen;

    if (rawName.endsWith('/')) continue; // a folder
    if (flags & 1) throw new ZipError('The zip is encrypted.');
    if (method !== 0 && method !== 8) throw new ZipError('The zip uses a compression this reader does not know.');
    const name = safeName(rawName);
    if (!name) throw new ZipError(`The zip has an unsafe file name: ${rawName.slice(0, 60)}`);
    if (seen.has(name.toLowerCase())) throw new ZipError(`The zip has the same file twice: ${name}`);
    seen.add(name.toLowerCase());
    if (size > maxEntryBytes) throw new ZipError(`${name} is too big.`);
    total += size;
    if (total > maxTotalBytes) throw new ZipError('The zip unpacks to too much.');

    if (localAt + 30 > buf.length || buf.readUInt32LE(localAt) !== 0x04034b50) throw new ZipError('The zip is damaged.');
    const dataAt = localAt + 30 + buf.readUInt16LE(localAt + 26) + buf.readUInt16LE(localAt + 28);
    if (dataAt + packedSize > buf.length) throw new ZipError('The zip is damaged.');
    const packed = buf.subarray(dataAt, dataAt + packedSize);
    let data;
    try {
      // the declared size is only a limit: a file that unpacks to more than it said is refused, not trusted
      data = method === 8 ? zlib.inflateRawSync(packed, { maxOutputLength: Math.max(size, 1) }) : Buffer.from(packed);
    } catch {
      throw new ZipError(`${name} could not be unpacked.`);
    }
    if (data.length !== size || crc32(data) !== crc) throw new ZipError(`${name} is damaged.`);
    out.push({ name, data });
  }
  return out;
}
