import fs from 'node:fs';
import path from 'node:path';
import { complete as modelComplete } from './llm.js';

/*
 * The base prompt for every picture: image-base-prompt.txt (next to package.json; kept out of git), read again whenever
 * it changes, so editing it needs no restart. Lines starting with # are notes and are ignored; the rest is joined.
 *
 * Two ways to use it:
 *
 *  1. A TEMPLATE with slots in capitals in square brackets, like [OUTFIT] or [LIGHTING DESCRIPTION]. For each picture the
 *     chat model fills in the slots to match what was asked for (see fillPromptTemplate), and the filled template IS the
 *     prompt that goes to the image generator.
 *
 *  2. Plain text, with no slots: it is put in front of the prompt she writes, or where {prompt} is.
 *
 * ROSA_IMAGE_BASE_PROMPT (the text) or ROSA_IMAGE_BASE_FILE (a path) point somewhere else.
 */

import { config } from './config.js';
let cached = { file: '', mtime: -1, text: '' };

// a test run has no base prompt of its own unless it is told where to find one
const baseFile = () => process.env.ROSA_IMAGE_BASE_FILE || (process.env.NODE_TEST_CONTEXT ? '' : path.join(config.home, 'image-base-prompt.txt'));

/** The base prompt as written, without comments, or ''. */
export function loadBasePrompt() {
  if (process.env.ROSA_IMAGE_BASE_PROMPT) return process.env.ROSA_IMAGE_BASE_PROMPT.trim();
  const file = baseFile();
  if (!file) return '';
  let mtime = 0;
  try {
    mtime = fs.statSync(file).mtimeMs;
  } catch {
    return '';
  }
  if (cached.file !== file || cached.mtime !== mtime) {
    const text = fs
      .readFileSync(file, 'utf8')
      .split(/\r?\n/)
      .filter((line) => !/^\s*#/.test(line))
      .join(' ')
      .replace(/\s+/g, ' ')
      .trim();
    cached = { file, mtime, text };
  }
  return cached.text;
}

const SLOT = /\[([A-Z][A-Z0-9 /&-]{1,40})\]/g;

/** The slot names in a template, in order, without repeats. */
export function templateSlots(base = loadBasePrompt()) {
  return [...new Set([...String(base).matchAll(SLOT)].map((m) => m[1].trim()))];
}

/**
 * Her prompt with the base prompt added. A template is already a whole prompt (filled in by fillPromptTemplate), so the
 * prompt is returned as it is.
 */
export function withBasePrompt(prompt, base = loadBasePrompt()) {
  const p = String(prompt || '').trim();
  if (!base || templateSlots(base).length) return p;
  if (/\{prompt\}/i.test(base)) return base.replace(/\{prompt\}/gi, p);
  const glue = /[,.;:]$/.test(base) ? ' ' : ', ';
  return `${base}${glue}${p}`;
}

/* ---------- filling a template ---------- */

// what each familiar slot wants, and a fallback for when the model gives nothing usable
const SLOTS = {
  OUTFIT: { hint: 'what she is wearing, starting with "wearing", with materials, colours and fit, and any accessories', fallback: 'wearing a fitted top and jeans' },
  POSE: { hint: 'what she is doing and how she is posed, as a short phrase', fallback: 'standing relaxed and looking at the camera' },
  FRAMING: { hint: 'the shot: how close, what it focuses on, the camera angle', fallback: 'medium close-up focused on her face and chest at a natural eye-level angle' },
  'CLOSE DETAILS': { hint: 'what is immediately around her in the foreground (a short phrase that follows "Immediate surroundings show")', fallback: 'her clothes and soft skin' },
  MIDGROUND: { hint: 'what is in the middle distance (follows "Midground reveals")', fallback: 'her hands and the room around her' },
  BACKGROUND: { hint: 'what is far behind her (follows "Distant background shows")', fallback: 'a softly lit room with soft indoor depth' },
  'LIGHTING DESCRIPTION': { hint: 'the light, starting with a capital: its source, warmth and softness (it is followed by "creates clean highlights")', fallback: 'Soft warm indoor lighting' },
  'COLOR TONE': { hint: 'the overall colour tones, e.g. "warm golden color tones"', fallback: 'warm golden color tones' }
};

const EXAMPLE = {
  OUTFIT: 'wearing a beige knitted cropped cardigan unbuttoned low, a delicate pearl bracelet',
  POSE: 'holding a phone taking a mirror selfie',
  FRAMING: 'medium close-up focused on her face and chest at a natural eye-level angle',
  'CLOSE DETAILS': 'the knitted beige cardigan and soft skin',
  MIDGROUND: 'her hand and the phone',
  BACKGROUND: 'a wooden door and soft indoor depth',
  'LIGHTING DESCRIPTION': 'Soft warm indoor lighting',
  'COLOR TONE': 'warm golden color tones'
};

const tidy = (v) => String(v ?? '').replace(/\s+/g, ' ').replace(/^["'\s]+|["'\s.,;]+$/g, '').replace(/[[\]]/g, '').trim().slice(0, 300);

/** Reads the slot values out of what the model wrote: a JSON object, or lines like "OUTFIT: ...". */
export function parseSlotValues(text, slots) {
  const wanted = new Map(slots.map((s) => [s.toUpperCase(), s]));
  const out = {};
  const raw = String(text || '');
  const json = /\{[\s\S]*\}/.exec(raw);
  if (json) {
    try {
      for (const [k, v] of Object.entries(JSON.parse(json[0]))) {
        const slot = wanted.get(String(k).trim().toUpperCase().replace(/[_-]+/g, ' '));
        if (slot && tidy(v)) out[slot] = tidy(v);
      }
    } catch {
      /* fall through to the line form */
    }
  }
  for (const line of raw.split(/\r?\n/)) {
    const m = /^\W*([A-Za-z][A-Za-z _/&-]{1,40}?)\W*[:=]\s*(.+)$/.exec(line);
    const slot = m && wanted.get(m[1].trim().toUpperCase().replace(/[_-]+/g, ' '));
    if (slot && !out[slot] && tidy(m[2])) out[slot] = tidy(m[2]);
  }
  return out;
}

/** The template with its slots replaced. Any slot without a value gets its fallback, so no bracket is ever left in. */
export function fillTemplate(base, values = {}) {
  return String(base).replace(SLOT, (_m, name) => {
    const slot = name.trim();
    return values[slot] || SLOTS[slot]?.fallback || '';
  }).replace(/\s+,/g, ',').replace(/\s{2,}/g, ' ').trim();
}

function fillerSystem(slots) {
  const guide = slots.map((s) => `- ${s}: ${SLOTS[s]?.hint || 'a short visual phrase that fits the picture'}`).join('\n');
  const example = JSON.stringify(Object.fromEntries(slots.map((s) => [s, EXAMPLE[s] || ''])), null, 1);
  return (
    'You fill in a picture prompt for a text-to-image model. The picture always shows the same woman (she is already described ' +
    'in the template), so you only write the parts that change, so that the picture shows what the person asked for. ' +
    'Keep every detail they asked for exactly as they asked, whatever it is, and make everything else concrete and visual: ' +
    'clothes, materials, colours, surroundings, light. Say what is there, never what is not. If the request is not about her ' +
    '(a place or an object), she is still the subject and the requested thing is in the surroundings.\n\n' +
    `Slots to fill:\n${guide}\n\nReply with ONLY a JSON object with one short English phrase per slot, using exactly these names ` +
    `as keys. For example, for "a mirror selfie in a beige cardigan":\n${example}`
  );
}

/**
 * Fills the template for one request, using the chat model. Never fails: whatever the model does not supply gets a
 * fallback, and the request itself is kept as the pose if the model cannot be reached.
 * deps.complete is for tests.
 */
export async function fillPromptTemplate(request, base = loadBasePrompt(), { complete = modelComplete, signal } = {}) {
  const slots = templateSlots(base);
  let values = {};
  try {
    const answer = await complete({
      messages: [{ role: 'system', content: fillerSystem(slots) }, { role: 'user', content: `Request: ${String(request).slice(0, 600)}` }],
      maxTokens: 450,
      temperature: 0.7,
      signal
    });
    values = parseSlotValues(answer, slots);
  } catch (err) {
    if (err?.name === 'AbortError') throw err;
  }
  if (!Object.keys(values).length && slots.includes('POSE')) values = { POSE: tidy(request) };
  return fillTemplate(base, values);
}
