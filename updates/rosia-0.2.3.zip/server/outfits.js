/*
 * What she is wearing in each of her photos (public/assets/avatar/web/photo-<pose>.webp). When she sends one she is told this, and it
 * is put back in front of her in later turns, so "what are you wearing?" gets the outfit that is on the person's screen and never a
 * made-up one ("tube top and comfy black leggings" next to a photo of a white skirt). Change these when the pictures change.
 */
export const OUTFITS = {
  front: 'a white strapless tube top and a white pleated mini skirt, gold hoop earrings, barefoot',
  back: 'a white strapless tube top and a white pleated mini skirt (seen from behind), gold hoop earrings',
  feet: 'a white strapless tube top and a white pleated mini skirt, sitting barefoot with her soles to the camera',
  kneeling: 'a white strapless tube top and a white pleated mini skirt, kneeling on all fours',
  bikini: 'a tiny black string bikini, gold hoop earrings, barefoot',
  gymwear: 'a black sports crop top and black gym shorts with white trim, gold hoop earrings',
  swimsuit: 'a navy one-piece swimsuit, arms up behind her head, barefoot',
  'swimsuit-back': 'a navy one-piece swimsuit (seen from behind), looking over her shoulder, barefoot'
};

export const outfitOf = (pose) => OUTFITS[pose] || '';
