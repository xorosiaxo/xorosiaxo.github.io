import crypto from 'node:crypto';
import { saveUser, activeNotes } from './users.js';

/*
 * Games to play with her. The rules live here, in code, not in her head: a small model forgets the secret in 20
 * questions, loses count, or lets you win. So the app picks secrets and her moves, counts, checks answers and keeps
 * the score; every message during a game moves it on (see `gameTurn`), and she is told exactly where it stands and
 * what to say next. She only has to play it in character.
 *
 *  - twenty      20 questions: she thinks of something (the app picks it), they ask yes/no questions and guess.
 *  - rather      would you rather: she asks, they choose, she says hers.
 *  - truth       truth or dare: they pick, she gives one, and they can turn it round on her.
 *  - rps         rock paper scissors, first to three: her move is picked by the app before she sees theirs.
 *  - knows       how well does she know you: five guesses about them from her notes; they say if she is right.
 *
 * Kept on the person (user.games): the game going on, and the scores across days.
 */

const pick = (list) => list[crypto.randomInt(list.length)];

export const GAMES = {
  twenty: { name: '20 questions', words: /\b(?:20|twenty) ?questions\b/i },
  rather: { name: 'would you rather', words: /\bwould you rather\b|\bwyr\b/i },
  truth: { name: 'truth or dare', words: /\btruth or dare\b/i },
  rps: { name: 'rock paper scissors', words: /\brock,? paper,? scissors?\b|\brps\b/i },
  knows: { name: 'how well do I know you', words: /\bhow well (?:do )?you know me\b|\bquiz (?:me|about me)\b|\b(?:a |the )?quiz\b|\btest (?:how well )?you know me\b/i }
};

const SECRETS = [
  'a penguin', 'a giraffe', 'an octopus', 'a hamster', 'a dolphin', 'a sloth', 'a flamingo', 'a kangaroo', 'a bee', 'a shark', 'a cat', 'an owl',
  'a pizza', 'sushi', 'a banana', 'chocolate', 'a pineapple', 'popcorn', 'a croissant', 'ice cream', 'coffee', 'an avocado',
  'a guitar', 'a toothbrush', 'an umbrella', 'a mirror', 'a candle', 'a skateboard', 'a pillow', 'a phone charger', 'sunglasses', 'a teddy bear',
  'a lipstick', 'a bicycle', 'a hot air balloon', 'a lighthouse', 'a volcano', 'the moon', 'a rainbow', 'a snowman', 'a cactus', 'a sunflower',
  'the Eiffel Tower', 'a submarine', 'a rollercoaster', 'a disco ball', 'a treasure chest', 'a dragon', 'a robot', 'a vampire', 'a mermaid',
  'Spider-Man', 'Shrek', 'Harry Potter', 'Pikachu', 'Barbie', 'Mario', 'SpongeBob', 'Taylor Swift', 'a wedding dress', 'a tattoo', 'a hammock'
];

const RATHER = [
  'be able to read minds, or be invisible whenever you want', 'never use social media again, or never watch another film or show',
  'always be 10 minutes late, or always be 20 minutes early', 'have a rewind button, or a pause button for your life',
  'live by the beach, or in a cabin in the mountains', 'only eat pizza forever, or never eat pizza again',
  'know when you are going to die, or how', 'be famous, or be rich but nobody knows who you are',
  'have a personal chef, or a personal driver', 'go on a date at a theme park, or a fancy dinner',
  'have your search history made public, or your texts', 'fight one horse-sized duck, or a hundred duck-sized horses',
  'only whisper, or only shout', 'be stuck in a lift with your ex, or with your boss', 'never sleep again, or never eat again',
  'be a famous singer, or a famous actor', 'travel to the past, or to the future', 'lose your phone, or your wallet',
  'have a dog that talks, or a cat that talks', 'kiss on the first date, or wait', 'cuddle all night, or stay up talking all night',
  'have a partner who is always early, or always funny', 'give up music, or give up films', 'live without coffee, or without chocolate',
  'have unlimited flights, or unlimited food deliveries', 'be the funniest person in the room, or the smartest',
  'only wear one outfit forever, or never wear the same thing twice', 'be stuck on a desert island alone, or with someone annoying',
  'say everything you think out loud, or never speak again', 'have a slow-burn romance, or love at first sight'
];

const TRUTHS = [
  'what is the most embarrassing thing on your phone right now?', 'who was your first crush, and do they know?',
  'what is a lie you have told this week?', 'what is the last thing you searched online?', 'what is your most irrational fear?',
  'what is the worst date you have ever been on?', 'what is something you have never told anyone?', 'what is your guilty pleasure song?',
  'what is the pettiest thing you have ever done?', 'have you ever pretended to be ill to get out of something?',
  'what is the cringiest text you have ever sent?', 'what do you notice first about someone?', 'what is your biggest red flag?',
  'what is a habit you would never admit to on a first date?', 'who in your life would you swap places with for a day?',
  'what is the most childish thing you still do?', 'when did you last cry, and why?', 'what is one thing you would change about yourself?',
  'what was your most awkward moment at school?', 'what is the weirdest thing you have ever eaten?'
];

const DARES = [
  'send me the last picture in your camera roll (or describe it, honestly)', 'type your next three messages in ALL CAPS',
  'tell me your most-played song right now and defend it', 'write me a two-line poem, right now, no thinking',
  'describe your outfit right now in detail', 'send the fifth emoji in your recently used', 'tell me a joke, and it has to make me laugh',
  'give me your best pickup line', 'text the last person you messaged "you are a legend" and tell me what they say',
  'do your best impression of me in one message', 'tell me three things you like about yourself', 'rate your own cooking out of ten and justify it',
  'say something nice about the last person who annoyed you', 'speak only in questions for your next three messages',
  'tell me your most unpopular opinion', 'describe your dream date in exactly ten words', 'confess the last thing you lied to me about (or anyone)',
  'send me a voice note... in text form: write exactly how you would say it', 'name your celebrity crush and explain yourself',
  'do ten jumping jacks and tell me when you are done'
];

const RPS = ['rock', 'paper', 'scissors'];
const BEATS = { rock: 'scissors', paper: 'rock', scissors: 'paper' };

/* ---------- state ---------- */

function games(user) {
  user.games ||= { active: null, scores: {}, played: [] };
  user.games.scores ||= {};
  user.games.played ||= [];
  return user.games;
}

const score = (user, game) => (games(user).scores[game] ||= { played: 0, won: 0, lost: 0 });

function finish(user, game, outcome, detail, now) {
  const g = games(user);
  const s = score(user, game);
  s.played += 1;
  if (outcome === 'won') s.won += 1;
  if (outcome === 'lost') s.lost += 1;
  s.last = now;
  if (detail?.best !== undefined) s.best = Math.max(s.best || 0, detail.best);
  g.played.push({ game, outcome, at: now, ...(detail?.note ? { note: detail.note } : {}) });
  if (g.played.length > 60) g.played.splice(0, g.played.length - 60);
  g.active = null;
}

/** Which game a message names, or ''. */
export function gameNamed(text) {
  const t = String(text || '');
  return Object.entries(GAMES).find(([, g]) => g.words.test(t))?.[0] || '';
}

/** Starts a game. Returns what she is told, or throws in words she can pass on. */
export async function startGame(user, game, { now = Date.now() } = {}) {
  if (!GAMES[game]) throw new Error('There is no such game. She can play 20 questions, would you rather, truth or dare, rock paper scissors, or how well she knows them.');
  const g = games(user);
  if (g.active) await stopGame(user, { now }); // a new game ends the one going on, and it still counts as played
  if (game === 'knows') {
    const notes = activeNotes(user).filter((n) => n.text.length >= 8);
    if (notes.length < 5) throw new Error('She does not know enough about them yet for that one (she needs at least five things she remembers)');
    const chosen = [...notes].sort(() => crypto.randomInt(3) - 1).slice(0, 5).map((n) => n.text);
    // (the first guess is made as the game opens, so the next message is the answer to it)
    g.active = { game, at: now, step: 0, right: 0, notes: chosen, waiting: true, lastMsg: 0 };
  } else if (game === 'twenty') {
    g.active = { game, at: now, secret: pick(SECRETS), asked: 0, lastMsg: 0 };
  } else if (game === 'rps') {
    g.active = { game, at: now, mine: 0, theirs: 0, rounds: 0, lastMsg: 0 };
  } else if (game === 'rather') {
    const seen = new Set(g.seenRather || []);
    const fresh = RATHER.filter((q) => !seen.has(q));
    const q = pick(fresh.length ? fresh : RATHER);
    g.seenRather = [...seen, q].slice(-RATHER.length + 3);
    g.active = { game, at: now, question: q, count: 1, lastMsg: 0 };
  } else {
    g.active = { game, at: now, turns: 0, lastMsg: 0 };
  }
  await saveUser(user);
  return { game: GAMES[game].name, started: true, record: recordOf(user, game) };
}

export async function stopGame(user, { now = Date.now() } = {}) {
  const g = games(user);
  const was = g.active;
  if (!was) return null;
  const reveal = was.game === 'twenty' ? was.secret : undefined;
  if (['twenty', 'rps', 'knows'].includes(was.game)) finish(user, was.game, 'stopped', null, now);
  else {
    score(user, was.game).played += 1;
    g.active = null;
  }
  await saveUser(user);
  return { game: GAMES[was.game].name, reveal };
}

/** Their record at a game, in words: "you have won 3 of 5". */
export function recordOf(user, game) {
  const s = games(user).scores[game];
  if (!s?.played) return 'first time playing this one';
  if (game === 'knows') return `she has played ${s.played} time${s.played === 1 ? '' : 's'}; her best is ${s.best || 0} out of 5`;
  if (game === 'twenty' || game === 'rps') return `they have won ${s.won} of ${s.played}`;
  return `played ${s.played} time${s.played === 1 ? '' : 's'} before`;
}

/* ---------- each message during a game ---------- */

const YES = /^\s*(?:yes+|yeah|yep|yup|ya|yea|correct|right|true|exactly|of course|ofc|100%?|spot on|bingo|you got it|absolutely|definitely)\b/i;
const NO = /^\s*(?:no+|nope|nah|wrong|false|not really|incorrect|not quite|close but|haha no)\b/i;
const QUIT = /\b(?:i give up|give up|stop (?:the |this )?game|end (?:the |this )?game|quit|i'?m done (?:playing)?|enough of this|stop playing)\b/i;

const plainWords = (t) => String(t).toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').replace(/\b(?:a|an|the)\b/g, ' ').replace(/\s+/g, ' ').trim();

/** True when a guess names the secret ("is it a penguin?", "penguin!"). */
export function guessed(secret, text) {
  const s = plainWords(secret);
  const t = ` ${plainWords(text)} `;
  return t.includes(` ${s} `) || (s.endsWith('s') ? false : t.includes(` ${s}s `));
}

/**
 * Moves the game on by one of their messages and says what she is to do. Returns '' with no game going. `messageAt`
 * makes one message count once, whatever happens to the reply.
 */
export async function gameTurn(user, message, { messageAt = 0, now = Date.now(), rng = Math.random } = {}) {
  const g = games(user);
  const a = g.active;
  if (!a) return '';
  if (now - a.at > 6 * 3600_000) {
    // a game left hanging for hours is over
    g.active = null;
    await saveUser(user);
    return '';
  }
  const text = String(message || '');
  const fresh = a.lastMsg !== messageAt;
  a.lastMsg = messageAt;
  const name = GAMES[a.game].name;
  const head = `You are playing ${name} with them.`;

  if (fresh && QUIT.test(text)) {
    const stopped = await stopGame(user, { now });
    return `${head} They want to stop. Stop the game${stopped?.reveal ? ` and tell them what you were thinking of: ${stopped.reveal}` : ''}, in character, then carry on talking.`;
  }

  let line = '';
  switch (a.game) {
    case 'twenty': {
      if (fresh && guessed(a.secret, text)) {
        finish(user, 'twenty', 'won', { note: a.secret }, now);
        line = `${head} They just guessed it: you were thinking of ${a.secret}, and they got it in ${a.asked + 1}. Tell them they won, make a fuss of it, and say their record (${recordOf(user, 'twenty')}).`;
        break;
      }
      if (fresh) a.asked += 1;
      if (a.asked >= 20) {
        finish(user, 'twenty', 'lost', { note: a.secret }, now);
        line = `${head} That was their twentieth question and they did not get it. Answer it, then tell them they lost: you were thinking of ${a.secret}. Tease them a little, and say their record (${recordOf(user, 'twenty')}).`;
        break;
      }
      line = `${head} You are thinking of ${a.secret}; never say it, never hint at its name, and never change it. Answer their question about it truthfully with yes, no, sort of, or "i don't know" plus a few playful words. That was question ${a.asked} of 20 (${20 - a.asked} left). If they made a guess and it was wrong, say no.`;
      break;
    }
    case 'rather': {
      const next = pick(RATHER.filter((q) => q !== a.question));
      line = `${head} You asked: would you rather ${a.question}? React to their choice, give your own answer to it with a reason, then ask the next one: would you rather ${next}?`;
      if (fresh) {
        a.question = next;
        a.count += 1;
      }
      break;
    }
    case 'truth': {
      if (fresh) a.turns += 1;
      const wantsTruth = /\btruth\b/i.test(text);
      const wantsDare = /\bdare\b/i.test(text);
      const forHer = /\b(?:your turn|you pick|now you|you choose|truth or dare for you|ask you)\b/i.test(text);
      if (forHer) line = `${head} They have turned it round on you. Pick truth or dare yourself, play it honestly in character (keep it to things you can do in a chat), then ask them: truth or dare?`;
      else if (wantsTruth && !wantsDare) line = `${head} They picked truth. Ask them this, in your own words: ${pick(TRUTHS)}`;
      else if (wantsDare && !wantsTruth) line = `${head} They picked dare. Give them this one, in your own words: ${pick(DARES)}`;
      else line = `${head} React to what they said, then ask them: truth or dare?`;
      break;
    }
    case 'rps': {
      const theirs = RPS.find((m) => new RegExp(`\\b${m}\\b`, 'i').test(text));
      if (!theirs || !fresh) {
        line = `${head} First to three wins; it is ${a.theirs}-${a.mine} to them. Ask them to throw: rock, paper or scissors.`;
        break;
      }
      const mine = RPS[Math.floor(rng() * 3)];
      a.rounds += 1;
      const result = mine === theirs ? 'draw' : BEATS[theirs] === mine ? 'they win' : 'you win';
      if (result === 'they win') a.theirs += 1;
      if (result === 'you win') a.mine += 1;
      const score2 = `${a.theirs}-${a.mine} to them`;
      if (a.theirs >= 3 || a.mine >= 3) {
        const theyWon = a.theirs >= 3;
        finish(user, 'rps', theyWon ? 'won' : 'lost', null, now);
        line = `${head} They threw ${theirs}, you threw ${mine}: ${result}. That is the game, ${theyWon ? 'they won' : 'you won'} (${score2}). ${theyWon ? 'Be a sore loser about it, playfully' : 'Gloat a little'}, and say their record (${recordOf(user, 'rps')}).`;
      } else {
        line = `${head} They threw ${theirs}, you threw ${mine}: ${result} this round. Score: ${score2}, first to three. Say what you threw and the score, then ask for their next throw.`;
      }
      break;
    }
    case 'knows': {
      if (fresh && a.waiting) {
        if (YES.test(text)) a.right += 1;
        a.waiting = false;
        a.step += 1;
        a.lastSaid = YES.test(text) ? 'right' : NO.test(text) ? 'wrong' : 'unclear';
      }
      if (a.step >= a.notes.length) {
        const got = a.right;
        finish(user, 'knows', 'done', { best: got, note: `${got}/5` }, now);
        line = `${head} That was the last one${a.lastSaid ? ` (they said you were ${a.lastSaid})` : ''}. You got ${got} out of 5. Say the score and react to it (proud, or sulky), and say your record (${recordOf(user, 'knows')}).`;
        break;
      }
      const before = a.lastSaid && a.step > 0 ? `They said your last guess was ${a.lastSaid}. React to that in a few words. ` : '';
      line = `${head} ${before}Guess number ${a.step + 1} of 5 (${a.right} right so far). Make a confident guess about them from this thing you remember, as a short question they can say yes or no to (for example "you hate olives, right?"): "${a.notes[a.step]}". Do not just read it out; make it a guess.`;
      a.waiting = true;
      break;
    }
    default:
      break;
  }
  await saveUser(user);
  return line;
}

/** What she is told when a game starts (from the tool's answer). */
export function openingLine(user) {
  const a = games(user).active;
  if (!a) return '';
  switch (a.game) {
    case 'twenty': return `You are thinking of ${a.secret} (never say it or hint at its name). Tell them you have thought of something and they have 20 yes/no questions to guess it.`;
    case 'rather': return `Ask them the first one: would you rather ${a.question}?`;
    case 'truth': return 'Ask them: truth or dare?';
    case 'rps': return 'First to three wins. Ask them to throw: rock, paper or scissors (you will throw at the same time).';
    case 'knows': return 'Tell them you are going to make five guesses about them from what you remember, and they say if you are right. Then make the first guess, from this: "' + a.notes[0] + '", as a short yes/no question.';
    default: return '';
  }
}

/** What the page shows: the scores across days. */
export function publicGames(user) {
  const g = games(user);
  return {
    active: g.active ? GAMES[g.active.game].name : '',
    scores: Object.entries(g.scores).filter(([k, s]) => GAMES[k] && s.played).map(([k, s]) => ({ game: GAMES[k].name, played: s.played, won: s.won, lost: s.lost, best: s.best })),
    recent: g.played.slice(-8).reverse().map((p) => ({ game: GAMES[p.game]?.name || p.game, outcome: p.outcome, at: p.at, note: p.note }))
  };
}
