import fs from 'node:fs/promises';
import path from 'node:path';
import { config } from './config.js';
import { backupNow } from './backup.js';
import { debug } from './debuglog.js';
import { renameRetrying } from './atomic.js';

/*
 * The shape of the data in data/ (chats, memory, catalogues) has a number. When an update changes that shape, the new version
 * brings a migration that turns the old shape into the new one, and the number goes up. On start-up every migration the data has
 * not been through yet is run in order, after a backup of everything, and the number is saved only when all of them worked.
 *
 * Two rules keep updates safe, because a version that fails its trial is taken out again and must still be able to read the data:
 *   1. A migration only ADDS (a new field, a new file) or fills in what is missing; it never deletes or renames what the previous
 *      version reads. Removing something old is its own, later release.
 *   2. A migration can be run twice with the same result.
 *
 *   MIGRATIONS.push({ to: 2, name: 'what it does', run: async ({ dataDir }) => { ... } });
 */

export const MIGRATIONS = [];

export const currentSchema = () => MIGRATIONS.reduce((n, m) => Math.max(n, m.to), 1);

const file = () => path.join(config.dataDir, 'schema.json');

async function stored() {
  try {
    const n = Number(JSON.parse(await fs.readFile(file(), 'utf8')).schema);
    return Number.isInteger(n) && n >= 1 ? n : 1;
  } catch {
    return 1; // data from before this existed is version 1
  }
}

async function remember(schema) {
  await fs.mkdir(config.dataDir, { recursive: true });
  const tmp = `${file()}.${process.pid}.tmp`;
  await fs.writeFile(tmp, JSON.stringify({ schema, at: Date.now() }), 'utf8');
  await renameRetrying(tmp, file());
}

/**
 * Brings the data up to date. Returns { from, to, ran: [names], newer }:
 * `newer` is true when the data was made by a NEWER version than this one (an update was taken out again): nothing is changed.
 */
export async function migrate({ migrations = MIGRATIONS, backup = true } = {}) {
  const target = migrations.reduce((n, m) => Math.max(n, m.to), 1);
  const from = await stored();
  if (from > target) {
    debug('migrate.newer', { stored: from, known: target });
    return { from, to: from, ran: [], newer: true };
  }
  const todo = migrations.filter((m) => m.to > from).sort((a, b) => a.to - b.to);
  if (!todo.length) {
    if (from !== target || !(await fs.access(file()).then(() => true, () => false))) await remember(target);
    return { from, to: target, ran: [], newer: false };
  }
  if (backup && config.backup.dir) await backupNow().catch((err) => debug('migrate.backup.failed', { error: err }));
  const ran = [];
  for (const m of todo) {
    await m.run({ dataDir: config.dataDir });
    ran.push(m.name);
    debug('migrate.ran', { to: m.to, name: m.name });
  }
  await remember(target); // only once every one of them has worked: a failure is retried at the next start
  return { from, to: target, ran, newer: false };
}
