/* Connecting Discord: the optional setup step and its Settings section share this. Rosia's GIFs and clips can come from
   the person's own Discord favourites, through the Rosia plugin for BetterDiscord, which keeps their links working. */

const ASKED = 'rosia.discordAsked';

async function call(method, url) {
  const res = await fetch(url, { method });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'That did not work. Try again in a moment.');
  return data;
}

/** One line on where things stand, and which step comes next. */
export function discordStep(s) {
  if (!s?.supported) return { step: 'unsupported', text: 'Connecting Discord works on Windows only.' };
  if (!s.discord) return { step: 'no-discord', text: 'Discord is not installed on this computer. Install it, sign in, then come back here.' };
  if (!s.betterDiscord) return { step: 'betterdiscord', text: 'Step 1 of 2: BetterDiscord, which lets Discord run the Rosia plugin.' };
  if (!s.plugin?.installed || !s.plugin.current || !s.plugin.enabled) return { step: 'plugin', text: 'Step 2 of 2: the Rosia plugin.' };
  return { step: 'done', text: `Connected. The Rosia plugin ${s.plugin.installed} is on. Your favourite GIFs and videos will appear within a few minutes of Discord starting.` };
}

/**
 * Draws the controls into `host` and keeps them current. `onDone` runs when everything is in place or the person says not
 * now (the setup step closes then).
 */
export function mountDiscord(host, { onDone = () => {} } = {}) {
  host.innerHTML = `
    <p class="dc-state" role="status"></p>
    <div class="data-actions dc-actions"></div>
    <p class="dc-error" role="alert"></p>`;
  const stateEl = host.querySelector('.dc-state');
  const actions = host.querySelector('.dc-actions');
  const error = host.querySelector('.dc-error');

  const button = (label, solid, run) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = `pill-btn${solid ? ' solid' : ''}`;
    b.textContent = label;
    b.addEventListener('click', async () => {
      error.textContent = '';
      b.disabled = true;
      try { await run(); } catch (err) { error.textContent = err.message; }
      b.disabled = false;
    });
    return b;
  };

  async function show(s) {
    const { step, text } = discordStep(s);
    stateEl.textContent = text;
    actions.replaceChildren();
    if (step === 'betterdiscord') {
      actions.append(
        button('Download and open the BetterDiscord installer (11 MB)', true, async () => {
          stateEl.textContent = 'Downloading BetterDiscord from its official GitHub page and checking it…';
          await call('POST', '/api/discord/betterdiscord');
          stateEl.textContent = 'The BetterDiscord installer is open. Choose Install, pick your Discord, and let it finish. Then press "I have installed it".';
          actions.replaceChildren(button('I have installed it', true, refresh));
        }),
        button('Check again', false, refresh)
      );
    } else if (step === 'plugin') {
      actions.append(button(s.plugin?.installed ? 'Update the Rosia plugin' : 'Add the Rosia plugin', true, async () => {
        show(await call('POST', '/api/discord/plugin'));
        stateEl.textContent = 'The Rosia plugin is in place and switched on. Restart Discord (right-click it in the tray, Quit, then open it again) and your favourites start arriving.';
      }));
    } else if (step === 'no-discord') {
      actions.append(button('Check again', false, refresh));
    } else if (step === 'done') {
      onDone();
    }
  }

  async function refresh() {
    try {
      show(await call('GET', '/api/discord'));
    } catch (err) {
      stateEl.textContent = '';
      error.textContent = err.message;
    }
  }

  refresh();
  return { refresh };
}

/** The setup step: asked once, of the owner at this computer only. Resolves when they are done or say not now. */
export function askDiscord({ doc = document, storage = localStorage } = {}) {
  if (storage.getItem(ASKED) === '1') return Promise.resolve();
  const card = doc.getElementById('discordStep');
  card.hidden = false;
  doc.getElementById('discordYes').focus();
  return new Promise((resolve) => {
    const finish = () => {
      storage.setItem(ASKED, '1');
      card.hidden = true;
      resolve();
    };
    doc.getElementById('discordLater').addEventListener('click', finish, { once: true });
    doc.getElementById('discordYes').addEventListener('click', () => {
      doc.getElementById('discordIntro').hidden = true;
      doc.getElementById('discordFlow').hidden = false;
      doc.getElementById('discordFinish').hidden = false;
      mountDiscord(doc.getElementById('discordFlow'), { onDone: () => {} });
    }, { once: true });
    doc.getElementById('discordFinish').addEventListener('click', finish, { once: true });
  });
}
