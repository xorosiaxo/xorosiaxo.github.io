/* The sidebar is hidden. It opens when the pointer rests on the left edge, when the edge is clicked or tapped, or with
   Ctrl+B; it closes when the pointer leaves it, on Esc (panel.js), or on a click outside (the scrim, panel.js). */

export function hoverIntent({ delay = 150, onIntent, timers = { set: (fn, ms) => setTimeout(fn, ms), clear: (id) => clearTimeout(id) } }) {
  let t = 0;
  return {
    enter() {
      timers.clear(t);
      t = timers.set(onIntent, delay);
    },
    leave() {
      timers.clear(t);
      t = 0;
    }
  };
}

export function bindSidebar({ edge, drawer, panel, doc = document }) {
  let byHover = false;
  const intent = hoverIntent({
    onIntent: () => {
      if (panel.isOpen()) return;
      byHover = true;
      panel.open('chats');
    }
  });

  edge.addEventListener('pointerenter', (e) => { if (e.pointerType === 'mouse') intent.enter(); });
  edge.addEventListener('pointerleave', () => intent.leave());
  edge.addEventListener('click', () => {
    intent.leave();
    byHover = false;
    panel.toggle();
  });

  // opened by hover: leaving it closes it, unless they are in the middle of typing something there
  const leaving = hoverIntent({
    delay: 250,
    onIntent: () => {
      const typing = drawer.contains(doc.activeElement) && /^(INPUT|TEXTAREA)$/.test(doc.activeElement.tagName);
      if (byHover && panel.isOpen() && !typing) panel.close();
    }
  });
  drawer.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse') leaving.enter(); });
  drawer.addEventListener('pointerenter', () => leaving.leave());

  doc.addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() === 'b' && (e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey) {
      e.preventDefault();
      byHover = false;
      panel.toggle();
    }
  });
}
