/*
 * A voice call with her: hands-free. The microphone stays open; when they stop talking, what they said is heard by
 * Whisper on this device (whisper-worker.js) and sent as a message; her reply is read aloud; and talking over her cuts
 * her off the moment they start, the way it would on a real call.
 *
 * Telling speech from silence is done here, from how loud the microphone is: a level well above the room's own hum
 * for a fifth of a second is someone talking; a second of quiet after it is the end of what they said. While she is
 * speaking it takes more to count, so her own voice coming back through the speakers does not cut her off (the browser's
 * echo cancelling does most of that work).
 *
 * hooks: send(text) sends a message as if typed; speaking() says whether her voice is playing; hush() stops it;
 * busy() says whether a reply is being written; onState(state) shows 'starting' | 'listening' | 'hearing' | 'thinking' |
 * 'speaking' | 'muted' | 'ended'; onError(message).
 */

const RATE = 16000;
const START_MS = 200; // this long above the line is someone talking
const END_MS = 1000; // this long below it is the end of what they said
const PRE_MS = 350; // kept from just before they started, so the first word is not clipped
const MAX_MS = 25_000; // one utterance at most

export const callSupported = () => Boolean(navigator.mediaDevices?.getUserMedia && (window.AudioContext || window.webkitAudioContext) && window.Worker);

/** The loudness line from the room's own hum: speech has to be clearly above it. Pure, for tests. */
export function speechLine(floor, { herVoice = false } = {}) {
  const line = Math.max(0.012, floor * 3.2);
  return herVoice ? Math.max(line * 2.6, 0.045) : line;
}

/** How loud a block of samples is (root mean square). */
export function loudness(samples) {
  let sum = 0;
  for (let i = 0; i < samples.length; i += 1) sum += samples[i] * samples[i];
  return Math.sqrt(sum / Math.max(1, samples.length));
}

export function createCall({ send, speaking, hush, busy, onState = () => {}, onError = () => {}, onProgress = () => {} }) {
  let stream = null;
  let ctx = null;
  let node = null;
  let source = null;
  let worker = null;
  let state = 'ended';
  let muted = false;
  let floor = 0.006; // the room's own level, learnt as the call goes
  let inSpeech = false;
  let above = 0;
  let below = 0;
  let chunks = [];
  let pre = [];
  let spokenMs = 0;
  let nextId = 1;
  let queued = '';
  let ticker = null;

  const set = (s) => {
    if (state === s) return;
    state = s;
    onState(s);
  };

  function ear() {
    if (worker) return worker;
    worker = new Worker('/whisper-worker.js', { type: 'module' });
    worker.onmessage = ({ data }) => {
      if (data.type === 'progress') onProgress(data.percent);
      else if (data.type === 'ready') onProgress(100);
      else if (data.type === 'text') heard(data.text);
      else if (data.type === 'error') {
        onError(data.id ? "I couldn't make out what you said." : "Her hearing couldn't be loaded. Check the connection.");
        if (state === 'hearing') set('listening');
      }
    };
    worker.postMessage({ type: 'load' });
    return worker;
  }

  /** What they said, as text: sent now, or once she has finished the reply she is writing. */
  function heard(text) {
    if (state === 'ended') return;
    const t = String(text || '').trim();
    if (!t) {
      set(speaking() ? 'speaking' : 'listening');
      return;
    }
    queued = [queued, t].filter(Boolean).join(' ');
    flush();
  }

  function flush() {
    if (!queued || state === 'ended') return;
    if (busy()) return; // sent when this reply is done (the ticker looks every moment)
    const text = queued;
    queued = '';
    set('thinking');
    send(text);
  }

  function endUtterance() {
    inSpeech = false;
    const total = chunks.reduce((n, c) => n + c.length, 0);
    const ms = (total / RATE) * 1000;
    const samples = new Float32Array(total);
    let at = 0;
    for (const c of chunks) {
      samples.set(c, at);
      at += c.length;
    }
    chunks = [];
    // a cough or a click is not a sentence
    if (ms - PRE_MS < 350) {
      set(speaking() ? 'speaking' : 'listening');
      return;
    }
    set('hearing');
    ear().postMessage({ type: 'hear', id: nextId++, samples }, [samples.buffer]);
  }

  function onAudio(e) {
    if (state === 'ended') return;
    const block = new Float32Array(e.inputBuffer.getChannelData(0));
    const ms = (block.length / RATE) * 1000;
    if (muted) return;
    const level = loudness(block);
    const herVoice = speaking();
    const line = speechLine(floor, { herVoice });

    if (!inSpeech) {
      // the room's hum is learnt only while nobody is talking
      if (!herVoice && level < line) floor = floor * 0.95 + level * 0.05;
      pre.push(block);
      while (pre.reduce((n, c) => n + c.length, 0) > (PRE_MS / 1000) * RATE) pre.shift();
      above = level >= line ? above + ms : 0;
      if (above >= START_MS) {
        inSpeech = true;
        below = 0;
        spokenMs = 0;
        chunks = [...pre];
        pre = [];
        // they started talking over her: she stops, as she would on a real call
        if (herVoice) hush();
        set('listening');
      }
      return;
    }
    chunks.push(block);
    spokenMs += ms;
    below = level < speechLine(floor) ? below + ms : 0;
    if (below >= END_MS || spokenMs >= MAX_MS) endUtterance();
  }

  async function start() {
    if (state !== 'ended') return;
    set('starting');
    ear();
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } });
    } catch {
      set('ended');
      onError('Allow the microphone for this page to call her.');
      return;
    }
    const AC = window.AudioContext || window.webkitAudioContext;
    ctx = new AC({ sampleRate: RATE });
    source = ctx.createMediaStreamSource(stream);
    node = ctx.createScriptProcessor(2048, 1, 1);
    node.onaudioprocess = onAudio;
    source.connect(node);
    node.connect(ctx.destination); // (silent: nothing is written to the output)
    ticker = setInterval(() => {
      flush();
      if (state === 'thinking' && !busy() && !queued) set(speaking() ? 'speaking' : 'listening');
      if (state === 'speaking' && !speaking() && !busy()) set('listening');
      if ((state === 'listening' || state === 'thinking') && speaking() && !inSpeech) set('speaking');
    }, 150);
    set('listening');
  }

  function end() {
    if (state === 'ended') return;
    clearInterval(ticker);
    try { node?.disconnect(); } catch { /* gone */ }
    try { source?.disconnect(); } catch { /* gone */ }
    stream?.getTracks().forEach((t) => t.stop());
    ctx?.close().catch(() => {});
    stream = ctx = node = source = null;
    inSpeech = false;
    chunks = [];
    pre = [];
    queued = '';
    muted = false;
    set('ended');
  }

  function mute(on = !muted) {
    muted = Boolean(on);
    if (muted) {
      inSpeech = false;
      chunks = [];
    }
    set(muted ? 'muted' : speaking() ? 'speaking' : 'listening');
    return muted;
  }

  /** Starts fetching her hearing early (the first time it is about 80 MB), so a call starts sooner. */
  const prepare = () => { ear(); };

  return { start, end, mute, prepare, get active() { return state !== 'ended'; }, get state() { return state; }, get muted() { return muted; } };
}
