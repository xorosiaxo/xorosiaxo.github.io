/*
 * Hearing them on a call: Whisper, running in the visitor's own browser (in a worker, so the page never stutters). The
 * model (about 80 MB, once; the browser keeps it) and the code come from public CDNs, and what is said never leaves the
 * device. It works where the browser's own speech recognition does not (the desktop app, Firefox), and sends nothing to
 * Google.
 *
 * Messages in:  { type: 'load' }   { type: 'hear', id, samples (Float32Array, 16 kHz mono) }
 * Messages out: { type: 'progress', percent }  { type: 'ready', device }  { type: 'text', id, text }  { type: 'error', id?, message }
 */

const TRANSFORMERS = 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.7.1/+esm';
const MODEL = 'onnx-community/whisper-base.en';

let ear = null;
let loading = null;
let device = '';

let lastPercent = -1;
const files = new Map(); // file -> { loaded, total }: one number for the whole download, not one per file
function progress(p) {
  if (p.status !== 'progress' || !p.total || !p.file) return;
  files.set(p.file, { loaded: p.loaded, total: p.total });
  let loaded = 0;
  let total = 0;
  for (const f of files.values()) {
    loaded += f.loaded;
    total += f.total;
  }
  const percent = Math.min(99, Math.floor((loaded / total) * 100));
  if (percent !== lastPercent) {
    lastPercent = percent;
    postMessage({ type: 'progress', percent });
  }
}

async function load() {
  if (ear) return ear;
  loading ||= (async () => {
    const { pipeline } = await import(TRANSFORMERS);
    const gpu = typeof navigator !== 'undefined' && navigator.gpu && (await navigator.gpu.requestAdapter().catch(() => null));
    try {
      if (!gpu) throw new Error('no graphics card');
      ear = await pipeline('automatic-speech-recognition', MODEL, { device: 'webgpu', dtype: { encoder_model: 'fp32', decoder_model_merged: 'q4' }, progress_callback: progress });
      device = 'webgpu';
    } catch {
      ear = await pipeline('automatic-speech-recognition', MODEL, { device: 'wasm', dtype: 'q8', progress_callback: progress });
      device = 'wasm';
    }
    // warmed up with a moment of silence, so the first real sentence does not wait for the graphics card to get ready
    await ear(new Float32Array(16000)).catch(() => null);
    postMessage({ type: 'ready', device });
    return ear;
  })();
  try {
    return await loading;
  } catch (err) {
    loading = null;
    throw err;
  }
}

// what Whisper writes for silence, noise or music: never sent to her as words
const NOT_WORDS = /^\s*(?:\[[^\]]*\]|\([^)]*\)|you\.?|thank you\.?|thanks for watching!?|bye\.?|\.+|-+)?\s*$/i;

self.onmessage = async ({ data }) => {
  if (data?.type === 'load') {
    load().catch((err) => postMessage({ type: 'error', message: String(err?.message || err) }));
    return;
  }
  if (data?.type === 'hear') {
    try {
      const model = await load();
      // (an English-only model: it is given no language or task, which it would refuse)
      const out = await model(data.samples);
      const text = String(out?.text || '').replace(/\s+/g, ' ').trim();
      // her name is not in its dictionary: "Rosie", "Rosa" and "Rosier" are her
      const named = text.replace(/\bRos(?:ie|ia|ea|ier|y|a)\b/g, 'Rosia');
      postMessage({ type: 'text', id: data.id, text: NOT_WORDS.test(named) ? '' : named });
    } catch (err) {
      postMessage({ type: 'error', id: data.id, message: String(err?.message || err) });
    }
  }
};
