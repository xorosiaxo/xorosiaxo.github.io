/* The owner's view of the debugging log. Read-only; every value goes in as text, never as markup. */

const $ = (id) => document.getElementById(id);
const list = $('list');
const detail = $('detail');
const hours = $('hours');

function el(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined && text !== null) node.textContent = String(text);
  if (className) node.className = className;
  return node;
}

const when = (iso) => new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });
const short = (iso) => new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
const pretty = (v) => (typeof v === 'string' ? v : JSON.stringify(v, null, 1));

async function get(path) {
  const res = await fetch(path, { cache: 'no-store' });
  if (res.status === 403) throw new Error('Only the owner can see this page.');
  if (!res.ok) throw new Error(`Could not load (${res.status}).`);
  return res.json();
}

async function loadList() {
  list.replaceChildren(el('p', 'Loading…', 'empty'));
  try {
    const { chats, logging } = await get(`/api/admin/chats?hours=${hours.value}`);
    list.replaceChildren();
    if (!chats.length) list.append(el('p', logging ? 'No conversations in this time. They appear here from the moment the debugging log started.' : 'The debugging log is switched off (ROSA_DEBUG_LOG=0).', 'empty'));
    for (const c of chats) {
      const row = el('button', null, 'row');
      row.type = 'button';
      row.dataset.session = c.session;
      const meta = el('span', `${when(c.last)} · user ${c.user || '?'} · ${c.messages} message${c.messages === 1 ? '' : 's'}, ${c.tools} tool call${c.tools === 1 ? '' : 's'}`, 't');
      const open = el('span', c.opening || '(she spoke first)', 'o');
      row.append(meta, open);
      if (c.problems) row.append(el('span', `${c.problems} problem${c.problems === 1 ? '' : 's'}`, 'm bad'));
      row.addEventListener('click', () => show(c.session, row));
      list.append(row);
    }
  } catch (err) {
    list.replaceChildren(el('p', err.message, 'empty bad'));
  }
}

function event(e) {
  const box = el('section', null, 'ev');
  const head = el('div', null, 'h');
  head.append(el('b', e.event), el('span', short(e.t)));
  box.append(head);
  const add = (label, value, cls) => {
    if (value === undefined || value === null || value === '' || (Array.isArray(value) && !value.length)) return;
    const row = el('div');
    row.append(el('span', `${label}: `, 'k'));
    row.append(el('pre', pretty(value), cls));
    box.append(row);
  };

  if (e.event === 'chat.request') {
    box.classList.add('user');
    add('they wrote', e.text || e.kind);
    if (e.pictures) add('pictures', e.pictures);
  } else if (e.event === 'model.round') {
    add(`model wrote (round ${e.round})`, e.raw);
    if (e.shown !== e.raw) add('shown on screen', e.shown);
    add('tool calls it made', e.nativeCalls?.map((n, i) => `${n} ${e.nativeArgs?.[i] ?? ''}`));
    if (e.textCalls?.length) {
      box.classList.add('fail');
      add('tool calls it wrote as text (run for it)', e.textCalls);
    }
    if (e.stop) add('stopped early', e.stop);
  } else if (e.event === 'tool') {
    if (e.ok === false) box.classList.add('fail');
    add(`${e.name} ${e.ok === false ? 'FAILED' : 'ok'} (${e.ms ?? '?'} ms)`, '');
    add('arguments', e.args);
    add(e.ok === false ? 'error' : 'result', e.ok === false ? e.error : e.result);
  } else if (e.event === 'chat.reply') {
    box.classList.add('reply');
    add('she said', e.text);
    const sent = [e.photo && `photo: ${e.photo}`, e.gif && 'a GIF', e.video && 'a video', e.image && 'a picture'].filter(Boolean);
    add('and sent', sent.join(', '));
    add('mood', e.mood);
    if (e.stats) add('speed', `${e.stats.ttftMs ?? '?'} ms to first word, ${e.stats.totalMs ?? '?'} ms in all, ${e.stats.genPerSec ?? '?'} tokens/s, ${e.stats.rounds ?? 1} round(s)`);
  } else {
    if (/fail|error|crash/.test(e.event)) box.classList.add('fail');
    const { t, event: _e, session: _s, user: _u, ...rest } = e;
    add('', rest);
  }
  return box;
}

async function show(session, row) {
  for (const r of list.querySelectorAll('.row')) r.removeAttribute('aria-current');
  row?.setAttribute('aria-current', 'true');
  detail.replaceChildren(el('p', 'Loading…', 'empty'));
  try {
    const { events } = await get(`/api/admin/chat?session=${encodeURIComponent(session)}`);
    detail.replaceChildren();
    detail.append(el('h2', `Conversation ${session}`));
    if (!events.length) detail.append(el('p', 'Nothing logged for this conversation.', 'empty'));
    for (const e of events) detail.append(event(e));
    detail.scrollTop = detail.scrollHeight;
  } catch (err) {
    detail.replaceChildren(el('p', err.message, 'empty bad'));
  }
}

hours.addEventListener('change', loadList);
loadList();
