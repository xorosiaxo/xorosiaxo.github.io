/*
 * The small music player at the top left of her window.
 *
 * The sound plays here, in this person's own browser. What is lined up, which song it is on, whether it is paused and how
 * loud are kept by the app for this person (see server/music/state.js), so she knows about them too. Everything that
 * changes those goes to the app first (a click here, or her doing it from the chat) and the answer is then put into
 * effect by sync(). Dragging the bar and the volume are felt at once and told to the app afterwards.
 */

/** "3:07", or "1:02:45" for something long. Anything that is not a time yet is "0:00". */
export function clock(seconds) {
  const s = Number.isFinite(seconds) && seconds > 0 ? Math.floor(seconds) : 0;
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = String(s % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${ss}` : `${m}:${ss}`;
}

/** How far through, as a whole percentage from 0 to 100. */
export function percent(part, whole) {
  if (!Number.isFinite(part) || !Number.isFinite(whole) || whole <= 0) return 0;
  return Math.min(100, Math.max(0, Math.round((part / whole) * 100)));
}

/**
 * What the browser has to do to match the player the app describes. `applied` is what this page last put into effect:
 * { seq, trackId, paused }. Pure, so the rules can be tested without a browser:
 *   - no player: close;
 *   - a new song, or the same one told to start again (`seq` went up): load it and go to the place given;
 *   - otherwise only start or stop the sound if that is what changed.
 */
export function syncPlan(applied, player) {
  const track = player?.tracks?.[player.index];
  if (!track) return { close: true };
  const load = applied.seq !== player.seq || applied.trackId !== track.id;
  return {
    close: false,
    track,
    load,
    seekTo: load ? Number(player.position) || 0 : null,
    play: !player.paused && (load || applied.paused),
    pause: player.paused && !load && !applied.paused,
    volume: Math.min(1, Math.max(0, (Number(player.volume) || 0) / 100))
  };
}

const ICON = {
  play: '<path d="M5 3.2v9.6L12.5 8 5 3.2Z" fill="currentColor" stroke="none"/>',
  pause: '<path d="M5.2 3.5v9M10.8 3.5v9" stroke-width="2.2"/>',
  prev: '<path d="M11.8 3.6v8.8L5.6 8l6.2-4.4Z" fill="currentColor" stroke="none"/><path d="M4.2 3.6v8.8"/>',
  next: '<path d="M4.2 3.6v8.8L10.4 8 4.2 3.6Z" fill="currentColor" stroke="none"/><path d="M11.8 3.6v8.8"/>',
  restart: '<path d="M3.2 8a4.8 4.8 0 1 0 1.5-3.5"/><path d="M3 2.6v2.6h2.6"/>',
  close: '<path d="m4 4 8 8M12 4l-8 8"/>',
  more: '<path d="m4.5 6.5 3.5 3.5 3.5-3.5"/>',
  note: '<path d="M6.2 11.6V3.8l6-1.3v7.6"/><circle cx="4.7" cy="11.6" r="1.6"/><circle cx="10.7" cy="10.1" r="1.6"/>',
  volume: '<path d="M2.5 6.3h2.2L7.6 3.8v8.4L4.7 9.7H2.5V6.3Z"/><path d="M10 6a2.8 2.8 0 0 1 0 4M11.8 4.2a5.4 5.4 0 0 1 0 7.6"/>'
};
const svg = (name, size = 16) => `<svg viewBox="0 0 16 16" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[name]}</svg>`;

export function createPlayer({ host, doc = document, fetchFn = (...a) => fetch(...a), toast = () => {}, makeAudio = () => new Audio() }) {
  host.innerHTML = `
    <div class="player-top">
      <span class="player-art" id="playerArt">${svg('note', 18)}</span>
      <button class="player-what" id="playerWhat" type="button" aria-expanded="false" aria-controls="player" title="Show or hide the rest of the player">
        <span class="player-title" id="playerTitle"></span>
        <span class="player-artist" id="playerArtist"></span>
      </button>
      <button class="player-btn player-close" id="playerClose" type="button" aria-label="Stop the music and close the player" title="Close">${svg('close', 14)}</button>
    </div>
    <div class="player-seek">
      <span class="player-time" id="playerNow">0:00</span>
      <input class="player-bar" id="playerBar" type="range" min="0" max="0" step="1" value="0" aria-label="Where in the song" />
      <span class="player-time" id="playerLength">0:00</span>
    </div>
    <div class="player-row">
      <button class="player-btn player-prev" id="playerPrev" type="button" aria-label="Previous song" title="Previous song">${svg('prev')}</button>
      <button class="player-btn player-restart" id="playerRestart" type="button" aria-label="Start this song again" title="Start this song again">${svg('restart')}</button>
      <button class="player-btn player-play" id="playerPlay" type="button" aria-label="Play" title="Play"></button>
      <button class="player-btn player-next" id="playerNext" type="button" aria-label="Next song" title="Next song">${svg('next')}</button>
      <label class="player-vol" title="Volume">${svg('volume', 15)}<input id="playerVol" type="range" min="0" max="100" step="1" value="70" aria-label="Volume" /></label>
    </div>`;
  const $ = (id) => host.querySelector(`#${id}`);
  const ui = { art: $('playerArt'), what: $('playerWhat'), title: $('playerTitle'), artist: $('playerArtist'), bar: $('playerBar'), now: $('playerNow'), length: $('playerLength'), play: $('playerPlay'), vol: $('playerVol') };

  const audio = makeAudio();
  audio.preload = 'auto';
  let applied = { seq: -1, trackId: '', paused: true };
  let current = null; // the player as the app last described it
  let wantSeek = null; // where to go once the song has loaded enough to be moved about in
  let dragging = false;
  let failures = 0;
  let reportTimer = 0;
  let volumeTimer = 0;

  const fill = (input) => input.style.setProperty('--p', `${percent(Number(input.value), Number(input.max))}%`);
  const length = () => (Number.isFinite(audio.duration) && audio.duration > 0 ? audio.duration : current?.tracks?.[current.index]?.duration || 0);

  function paintPlay() {
    const playing = !audio.paused && !audio.ended;
    ui.play.innerHTML = svg(playing ? 'pause' : 'play', 18);
    ui.play.setAttribute('aria-label', playing ? 'Pause' : 'Play');
    ui.play.title = playing ? 'Pause' : 'Play';
    host.classList.toggle('playing', playing);
  }

  function paintTime() {
    const total = length();
    ui.bar.max = String(Math.floor(total));
    if (!dragging) ui.bar.value = String(Math.floor(audio.currentTime || 0));
    ui.now.textContent = clock(dragging ? Number(ui.bar.value) : audio.currentTime);
    ui.length.textContent = clock(total);
    fill(ui.bar);
    host.style.setProperty('--played', `${percent(audio.currentTime, total)}%`);
  }

  function paintTrack(track, player) {
    ui.title.textContent = track.title;
    ui.artist.textContent = [track.artist, player.tracks.length > 1 ? `${player.index + 1} of ${player.tracks.length}` : ''].filter(Boolean).join(' · ');
    ui.art.innerHTML = svg('note', 18);
    if (track.art) {
      const img = new Image();
      img.alt = '';
      img.decoding = 'async';
      img.addEventListener('load', () => { if (current?.tracks?.[current.index]?.id === track.id) ui.art.replaceChildren(img); });
      img.src = track.art;
    }
    host.querySelector('#playerPrev').disabled = false;
    host.querySelector('#playerNext').disabled = player.index >= player.tracks.length - 1;
    // the keys on a keyboard or headset, and the phone's lock screen
    if ('mediaSession' in navigator && typeof MediaMetadata === 'function') {
      navigator.mediaSession.metadata = new MediaMetadata({ title: track.title, artist: track.artist || 'Rosia', artwork: track.art ? [{ src: track.art, sizes: '150x150' }] : [] });
    }
  }

  async function tell(action, extra = {}) {
    try {
      const res = await fetchFn('/api/music', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action, ...extra }) });
      const data = await res.json().catch(() => null);
      return data && 'player' in data ? data : null;
    } catch {
      return null; // the app could not be reached: the sound carries on as it is
    }
  }

  /** A change made here: told to the app, and whatever it answers is put into effect. */
  async function change(action, extra) {
    const answer = await tell(action, extra);
    if (answer) sync(answer.player);
  }

  function startSound() {
    const started = audio.play();
    if (started?.catch) {
      started.catch((err) => {
        if (err?.name === 'AbortError') return; // a newer song replaced this one before it began
        // the browser would not start sound by itself (it wants a click first): the player waits, and the app is told
        applied.paused = true;
        paintPlay();
        tell('pause', { position: audio.currentTime || 0 });
        if (err?.name === 'NotAllowedError') toast('Press play on the music player to start it.');
      });
    }
  }

  /** Makes this page's sound and buttons match the player the app describes (null closes it). */
  function sync(player) {
    current = player || null;
    const plan = syncPlan(applied, current);
    if (plan.close) {
      audio.pause();
      audio.removeAttribute('src');
      audio.load();
      applied = { seq: -1, trackId: '', paused: true };
      clearInterval(reportTimer);
      host.hidden = true;
      host.classList.remove('open');
      return;
    }
    host.hidden = false;
    paintTrack(plan.track, current);
    audio.volume = plan.volume;
    if (doc.activeElement !== ui.vol) ui.vol.value = String(Math.round(plan.volume * 100));
    fill(ui.vol);
    if (plan.load) {
      wantSeek = plan.seekTo > 0 ? plan.seekTo : null;
      audio.src = plan.track.url;
      audio.load();
    }
    if (plan.play) startSound();
    else if (plan.pause) audio.pause();
    applied = { seq: current.seq, trackId: plan.track.id, paused: current.paused };
    paintPlay();
    paintTime();
  }

  /* ---------- what the sound itself reports ---------- */

  audio.addEventListener('loadedmetadata', () => {
    if (wantSeek !== null) {
      audio.currentTime = Math.min(wantSeek, Math.max(0, (audio.duration || wantSeek) - 1));
      wantSeek = null;
    }
    paintTime();
  });
  audio.addEventListener('timeupdate', paintTime);
  audio.addEventListener('durationchange', paintTime);
  audio.addEventListener('playing', () => { failures = 0; });
  for (const name of ['play', 'pause', 'ended']) audio.addEventListener(name, paintPlay);
  audio.addEventListener('ended', () => change('ended'));
  audio.addEventListener('error', () => {
    if (!current || !audio.getAttribute('src')) return;
    failures += 1;
    // a song that will not play is stepped over; after a few in a row something bigger is wrong, so it stops trying
    if (failures <= 3 && current.index < current.tracks.length - 1) change('ended');
    else {
      toast('That song would not play.');
      tell('pause', { position: 0 });
      applied.paused = true;
      paintPlay();
    }
  });

  // every so often the app is told where the song has got to, so she can answer "what's this?" truthfully
  function keepReporting() {
    clearInterval(reportTimer);
    reportTimer = setInterval(() => {
      if (current && !audio.paused) tell('report', { position: audio.currentTime || 0, paused: false });
    }, 15_000);
  }
  audio.addEventListener('play', keepReporting);

  /* ---------- the buttons ---------- */

  ui.play.addEventListener('click', () => {
    if (!current) return;
    if (audio.paused) {
      // started straight from the click, so a browser that only allows sound after one lets it through
      startSound();
      applied.paused = false;
      tell('resume');
    } else {
      audio.pause();
      applied.paused = true;
      tell('pause', { position: audio.currentTime || 0 });
    }
  });
  $('playerPrev').addEventListener('click', () => change('previous'));
  $('playerNext').addEventListener('click', () => change('next'));
  $('playerRestart').addEventListener('click', () => change('restart'));
  $('playerClose').addEventListener('click', () => {
    sync(null); // silent at once; the app is told so she knows it is off
    tell('stop');
  });
  // on a phone the player is one slim line; touching the song's name opens the rest
  ui.what.addEventListener('click', () => ui.what.setAttribute('aria-expanded', String(host.classList.toggle('open'))));

  ui.bar.addEventListener('input', () => {
    dragging = true;
    ui.now.textContent = clock(Number(ui.bar.value));
    fill(ui.bar);
  });
  ui.bar.addEventListener('change', () => {
    dragging = false;
    if (audio.getAttribute('src')) audio.currentTime = Number(ui.bar.value);
    tell('report', { position: Number(ui.bar.value), paused: audio.paused });
  });
  ui.vol.addEventListener('input', () => {
    audio.volume = Number(ui.vol.value) / 100;
    fill(ui.vol);
    clearTimeout(volumeTimer);
    volumeTimer = setTimeout(() => tell('volume', { value: Number(ui.vol.value) }), 250);
  });

  if ('mediaSession' in navigator) {
    const keys = { play: () => ui.play.click(), pause: () => ui.play.click(), nexttrack: () => change('next'), previoustrack: () => change('previous') };
    for (const [name, run] of Object.entries(keys)) {
      try { navigator.mediaSession.setActionHandler(name, run); } catch { /* this browser does not have that key */ }
    }
  }

  /**
   * When the page opens: if this person already had music on (they reloaded, or came back), the player is shown again
   * where it was, paused. A page cannot start sound before it has been touched, so it waits for them to press play.
   */
  async function restore() {
    try {
      const res = await fetchFn('/api/music', { cache: 'no-store' });
      if (!res.ok) return;
      const { player } = await res.json();
      if (!player) return;
      sync({ ...player, paused: true });
      if (!player.paused) tell('pause', { position: player.position || 0 });
    } catch { /* no player to bring back */ }
  }

  return { sync, restore, audio };
}
