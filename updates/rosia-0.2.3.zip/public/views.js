/* The right-hand side shows one thing at a time: the chat, what she remembers, reminders, the gallery, her diary, or settings.
   Her portrait stays where it is. */

export const VIEW_TITLES = { chat: '', memory: 'What she remembers', reminders: 'Reminders', gallery: 'Gallery', diary: 'Her diary', settings: 'Settings' };
const IDS = { chat: 'viewChat', memory: 'viewMemory', reminders: 'viewReminders', gallery: 'viewGallery', diary: 'viewDiary', settings: 'viewSettings' };

export function nextView(name) {
  return Object.hasOwn(IDS, name) ? name : 'chat';
}

export function createViews({ doc = document, onShow = () => {} } = {}) {
  const $ = (id) => doc.getElementById(id);
  const head = $('chatHead');
  const title = $('viewTitle');
  let current = 'chat';
  let cameFrom = null;

  function show(name) {
    const want = nextView(name);
    if (want === current) return;
    if (current === 'chat') cameFrom = doc.activeElement instanceof HTMLElement ? doc.activeElement : null;
    for (const [key, id] of Object.entries(IDS)) $(id).hidden = key !== want;
    current = want;
    head.classList.toggle('in-view', want !== 'chat');
    title.textContent = VIEW_TITLES[want];
    if (want === 'chat') (cameFrom?.isConnected ? cameFrom : $('input')).focus();
    else $('backToChat').focus();
    onShow(want);
  }

  $('backToChat').addEventListener('click', () => show('chat'));
  doc.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && current !== 'chat' && !doc.querySelector('.drawer.open, .lightbox')) show('chat');
  });

  return { show, current: () => current };
}
