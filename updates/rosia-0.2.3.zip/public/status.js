/* The status page. Read-only; every value goes in as text, never as markup. */

const $ = (id) => document.getElementById(id);
const hoursSelect = $('hours');
let timer = 0;

function el(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined && text !== null) node.textContent = String(text);
  if (className) node.className = className;
  return node;
}

const ms = (n) => (n === null || n === undefined ? '–' : n >= 10_000 ? `${(n / 1000).toFixed(0)} s` : n >= 1000 ? `${(n / 1000).toFixed(1)} s` : `${Math.round(n)} ms`);
const pct = (n) => (n === null || n === undefined ? '–' : `${Math.round(n * 100)}%`);
const bytes = (n) => (n >= 1073741824 ? `${(n / 1073741824).toFixed(1)} GB` : n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.round(n / 1024)} KB`);
const ago = (t) => {
  const s = Math.max(0, Math.round((Date.now() - t) / 1000));
  return s < 90 ? `${s} s ago` : s < 5400 ? `${Math.round(s / 60)} min ago` : `${Math.round(s / 3600)} h ago`;
};
const duration = (s) => (s < 3600 ? `${Math.round(s / 60)} min` : s < 172800 ? `${(s / 3600).toFixed(1)} h` : `${Math.round(s / 86400)} days`);

function card(value, label) {
  const c = el('div', null, 'card');
  c.append(el('b', value), el('span', label));
  return c;
}

function fill(tbody, rows, empty, cols) {
  tbody.replaceChildren();
  if (!rows.length) {
    const tr = el('tr');
    const td = el('td', empty, 'muted');
    td.colSpan = cols;
    tr.append(td);
    tbody.append(tr);
    return;
  }
  for (const cells of rows) {
    const tr = el('tr');
    for (const cell of cells) {
      const td = el('td', cell.text, [cell.num ? 'num' : '', cell.tone || ''].join(' ').trim());
      tr.append(td);
    }
    tbody.append(tr);
  }
}

function render(d) {
  const llm = $('llm');
  llm.className = `pill ${d.llm.up ? 'up' : 'down'}`;
  llm.lastElementChild.textContent = d.llm.up ? `Model up: ${d.llm.model}${d.llm.vision ? ' (sees pictures)' : ''}` : 'Model not reachable';

  const r = d.replies;
  const cards = $('cards');
  cards.replaceChildren(
    card(r.count, `replies (${Object.entries(r.byKind).map(([k, v]) => `${v} ${k}`).join(', ') || 'none yet'})`),
    card(ms(r.ttftMs.p50), `to first word, typical (slowest 1 in 20: ${ms(r.ttftMs.p95)})`),
    card(ms(r.totalMs.p50), `whole reply, typical (slowest 1 in 20: ${ms(r.totalMs.p95)})`),
    card(r.tokensPerSecond ?? '–', 'tokens per second'),
    card(pct(r.cacheHitRate), 'of the prompt already remembered by the model'),
    card(`${r.errors} / ${r.aborted}`, 'failed / stopped by the person'),
    card(duration(d.uptimeS), `server up (${d.process.rssMb} MB, Node ${d.process.node.replace(/^v/, '')})`)
  );
  if (d.pool?.target) {
    cards.append(card(`${d.pool.size} / ${d.pool.target}`, 'pictures drawn ahead of time, ready to send at once (drawn while nobody is chatting)'));
  }
  if (d.videos?.total) {
    const v = d.videos;
    cards.append(card(`${v.ok} / ${v.total}`, `saved videos looked at and ready (${v.pending} waiting, ${v.skip} left out${v.adult ? `, ${v.adult} adult` : ''}${v.ok && v.fuller < v.ok ? `; ${v.fuller} with the fuller descriptions so far` : ''})${v.error ? `. Last problem: ${v.error}` : ''}`));
  }
  if (d.gifs?.enabled) {
    const g = d.gifs;
    cards.append(card(`${g.ok} / ${g.total}`, `GIFs described and ready (${g.pending} waiting, ${g.skip} left out${g.adult ? `, ${g.adult} adult` : ''}${g.ok && g.fuller < g.ok ? `; ${g.fuller} with the fuller descriptions so far` : ''})${g.error ? `. Last problem: ${g.error}` : ''}`));
  }

  const peak = Math.max(1, ...d.timeline.map((b) => b.replies + b.errors));
  const bars = $('bars');
  bars.replaceChildren(...d.timeline.map((b) => {
    const bar = el('div', null, `bar${b.errors ? ' err' : ''}`);
    bar.style.height = `${Math.max(2, ((b.replies + b.errors) / peak) * 100)}%`;
    bar.title = `${new Date(b.t).toLocaleString()}: ${b.replies} replies${b.errors ? `, ${b.errors} errors` : ''}`;
    return bar;
  }));
  $('barsNote').textContent = `Busiest slot: ${peak === 1 && !d.replies.count ? 'nothing yet' : `${peak} replies and errors`}. Red bars had errors.`;

  fill($('search'), d.search.map((s) => [
    { text: s.name },
    { text: s.up ? 'ok' : `paused until ${new Date(s.retryAt).toLocaleTimeString()}`, tone: s.up ? 'good' : 'bad' },
    { text: s.calls, num: true },
    { text: s.failures, num: true, tone: s.failures ? 'bad' : '' },
    { text: s.lastError || '' }
  ]), 'No searches have run yet.', 5);

  fill($('tools'), d.tools.map((t) => [
    { text: t.name }, { text: t.calls, num: true }, { text: t.failures, num: true, tone: t.failures ? 'bad' : '' }, { text: ms(t.meanMs), num: true }
  ]), 'No tools used in this time.', 4);

  fill($('jobs'), d.jobs.map((t) => [
    { text: t.name }, { text: t.calls, num: true }, { text: t.failures, num: true, tone: t.failures ? 'bad' : '' }, { text: ms(t.meanMs), num: true }
  ]), 'No background work in this time.', 4);
  $('queue').textContent = d.background.chatting ? 'A reply is being written right now.' : d.background.queued ? `${d.background.queued} background job${d.background.queued === 1 ? '' : 's'} waiting for the model to be free.` : 'Nothing waiting.';

  fill($('errors'), d.errors.recent.map((e) => [{ text: ago(e.t) }, { text: e.where }, { text: e.message }]), 'No errors in this time.', 3);

  const c = d.you.conversations;
  const m = d.you.mediaBytes;
  const usage = $('usage');
  usage.replaceChildren();
  for (const [value, label, used, limit] of [
    [`${c.used} / ${c.limit}`, 'conversations', c.used, c.limit],
    [`${bytes(m.used)} / ${bytes(m.limit)}`, 'pictures', m.used, m.limit]
  ]) {
    const node = card(value, label);
    const meter = el('div', null, 'meter');
    const fillBar = el('div');
    fillBar.style.width = `${Math.min(100, (used / limit) * 100)}%`;
    meter.append(fillBar);
    node.append(meter);
    usage.append(node);
  }

  $('content').hidden = false;
  $('message').textContent = '';
}

async function load() {
  clearTimeout(timer);
  try {
    const res = await fetch(`/api/admin/stats?hours=${hoursSelect.value}`, { cache: 'no-store' });
    if (res.status === 403) {
      $('content').hidden = true;
      $('message').textContent = 'Only the owner of this Rosia can see the status page.';
      return;
    }
    if (res.status === 401) {
      $('content').hidden = true;
      $('message').textContent = 'This machine has no access yet. Open the chat first, then come back.';
      return;
    }
    if (!res.ok) throw new Error(`The server answered ${res.status}.`);
    render(await res.json());
  } catch (err) {
    $('message').textContent = `Could not load the numbers: ${err.message}`;
  } finally {
    timer = setTimeout(() => { if (!document.hidden) load(); else timer = setTimeout(load, 10_000); }, 10_000);
  }
}

hoursSelect.addEventListener('change', load);
document.addEventListener('visibilitychange', () => { if (!document.hidden) load(); });
load();
