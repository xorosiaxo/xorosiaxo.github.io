/* In "What she remembers": your running jokes (remove any you would rather she let go) and what she has worked out
   about your music from what you play, skip and go back to. */

const when = (ts) => new Date(ts).toLocaleDateString('en-GB', { day: 'numeric', month: 'long' });

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
}

export function renderMind(host, { jokes = [], taste = {}, games = {} } = {}, { remove, clearTaste } = {}) {
  host.replaceChildren();

  const scores = games.scores || [];
  if (scores.length || games.active) {
    const box = el('section', 'mind-box');
    box.setAttribute('aria-label', 'Your games');
    box.append(el('div', 'mem-label', games.active ? `Your games · playing ${games.active} now` : 'Your games'));
    const dl = el('dl', 'mind-taste');
    for (const s of scores) {
      const bits = [`played ${s.played}`];
      if (s.won || s.lost) bits.push(`you won ${s.won}, she won ${s.lost}`);
      if (s.best !== undefined) bits.push(`her best ${s.best}/5`);
      dl.append(el('dt', '', s.game), el('dd', '', bits.join(' · ')));
    }
    box.append(dl);
    host.append(box);
  }

  if (jokes.length) {
    const box = el('section', 'mind-box');
    box.setAttribute('aria-label', 'Your running jokes');
    box.append(el('div', 'mem-label', 'Your running jokes'));
    const list = el('ul', 'mind-jokes');
    for (const j of jokes) {
      const li = el('li', 'mind-joke');
      const words = el('div', 'mind-joke-words');
      words.append(el('strong', '', j.name), el('span', '', j.about), el('time', '', `since ${when(j.at)}${j.used ? ` · brought back ${j.used === 1 ? 'once' : `${j.used} times`}` : ''}`));
      const drop = el('button', 'mind-x', 'Let it go');
      drop.type = 'button';
      drop.setAttribute('aria-label', `Let go of the joke "${j.name}"`);
      drop.addEventListener('click', () => remove?.(j.id));
      li.append(words, drop);
      list.append(li);
    }
    box.append(list);
    host.append(box);
  }

  const loves = taste.loves || [];
  const skips = taste.skips || [];
  const replayed = taste.replayed || [];
  if (loves.length || skips.length || replayed.length) {
    const box = el('section', 'mind-box');
    box.setAttribute('aria-label', 'Your music');
    box.append(el('div', 'mem-label', 'Your music, as she sees it'));
    const lines = [];
    if (loves.length) lines.push(['You love', loves.join(', ')]);
    if (replayed.length) lines.push(['On repeat', replayed.join(', ')]);
    if (skips.length) lines.push(['You keep skipping', skips.join(', ')]);
    const dl = el('dl', 'mind-taste');
    for (const [k, v] of lines) dl.append(el('dt', '', k), el('dd', '', v));
    box.append(dl);
    if (taste.hers?.length) box.append(el('p', 'mind-hers', `Hers: ${taste.hers.join(', ')}.`));
    const reset = el('button', 'mind-x', 'Forget my music taste');
    reset.type = 'button';
    reset.addEventListener('click', () => clearTaste?.());
    box.append(reset);
    host.append(box);
  }
  host.hidden = !host.children.length;
}

export async function loadMind(host, fetchFn = (...a) => fetch(...a)) {
  const draw = (data) => renderMind(host, data, {
    remove: async (id) => {
      const res = await fetchFn(`/api/jokes/${id}`, { method: 'DELETE' }).catch(() => null);
      if (res?.ok) draw({ ...data, jokes: (await res.json()).jokes });
    },
    clearTaste: async () => {
      const res = await fetchFn('/api/taste', { method: 'DELETE' }).catch(() => null);
      if (res?.ok) draw({ ...data, taste: (await res.json()).taste });
    }
  });
  try {
    const res = await fetchFn('/api/mind');
    draw(res.ok ? await res.json() : {});
  } catch {
    draw({});
  }
}
