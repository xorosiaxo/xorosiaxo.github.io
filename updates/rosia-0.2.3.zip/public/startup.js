/*
 * "She's getting ready": while the launcher is still starting her parts (her chat model takes the longest), the page shows
 * each one and how far it has got, instead of opening on a chat she cannot answer yet. The launcher writes what it is doing
 * and the app passes it on at /api/startup. With no launcher (the server was started by itself) there is nothing to wait for.
 */

const WORDS = { waiting: 'waiting', working: 'starting', done: 'ready', skipped: 'not needed', failed: 'not ready' };

/** "12s" for a part that is being started, "ready in 9s" for one that took a while, else ''. */
export function timing(step, sinceStartMs) {
  if (step.state === 'working') return `${Math.max(1, Math.round(sinceStartMs / 1000))}s`;
  if (step.state === 'done' && step.ms >= 1500) return `${Math.round(step.ms / 1000)}s`;
  return '';
}

/** What is said beside a part: its own note when it has one, otherwise the plain word for its state; then how long. */
export function stepText(step, sinceStartMs = 0) {
  const said = step.note || WORDS[step.state] || '';
  const took = timing(step, sinceStartMs);
  if (step.state === 'done' && !step.note) return took ? `ready in ${took}` : 'ready';
  return [said, took].filter(Boolean).join(' · ');
}

function render(list, status) {
  const since = Math.max(0, (status.at || 0) - (status.startedAt || 0));
  const rows = status.steps.map((step) => {
    const li = document.createElement('li');
    li.className = `start-step is-${step.state}`;
    const dot = document.createElement('span');
    dot.className = 'start-dot';
    dot.setAttribute('aria-hidden', 'true');
    const label = document.createElement('span');
    label.className = 'start-label';
    label.textContent = step.label;
    const note = document.createElement('span');
    note.className = 'start-note';
    note.textContent = stepText(step, since);
    li.append(dot, label, note);
    return li;
  });
  list.replaceChildren(...rows);
}

async function ask(fetchFn) {
  try {
    const res = await fetchFn('/api/startup', { cache: 'no-store' });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

/**
 * Resolves once she can be talked to. Shows the list only if there is something to wait for, and never for longer than
 * giveUpMs: after that the chat opens anyway and says in its own words what is missing.
 */
export async function waitUntilReady({ doc = document, fetchFn = fetch, everyMs = 600, giveUpMs = 4 * 60_000 } = {}) {
  let status = await ask(fetchFn);
  if (!status || status.ready || !status.steps?.length) return;
  const card = doc.getElementById('starting');
  const list = doc.getElementById('startingSteps');
  if (!card || !list) return;
  card.hidden = false;
  const end = Date.now() + giveUpMs;
  let misses = 0;
  while (Date.now() < end) {
    render(list, status);
    await new Promise((r) => setTimeout(r, everyMs));
    const next = await ask(fetchFn);
    if (!next) {
      misses += 1; // the app is being restarted, or the link dropped for a moment
      if (misses > 20) break;
      continue;
    }
    misses = 0;
    status = next;
    if (status.ready || !status.steps?.length) break;
  }
  if (status?.steps?.length) render(list, status);
  // the finished list stays for a blink, so the last tick is seen rather than the screen just vanishing
  await new Promise((r) => setTimeout(r, 350));
  card.hidden = true;
}
