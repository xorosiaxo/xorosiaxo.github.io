/*
 * Talking to her: the microphone button uses the browser's speech recognition (Web Speech API). In Chrome and
 * Edge that is Google's speech service, so the audio goes to Google while the button is on; in Safari it is
 * Apple's. Firefox has none, so the button is simply not shown there.
 */

const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;

export const dictationSupported = Boolean(Recognition);

/**
 * button: the mic button. input: the message box.
 * hooks: { onStart(), onText(), onDone(text), onError(message), autoSend() }
 */
export function createDictation({ button, input, hooks = {} }) {
  if (!Recognition) {
    button.hidden = true;
    return { listening: false, stop() {}, toggle() {} };
  }

  let rec = null;
  let base = '';
  let heard = '';
  let wasStopped = false;
  const api = { listening: false, toggle, stop };

  const setState = (on) => {
    api.listening = on;
    button.classList.toggle('listening', on);
    button.setAttribute('aria-pressed', String(on));
    button.setAttribute('aria-label', on ? 'Stop listening' : 'Talk to her');
    button.title = on ? 'Listening… click to stop' : 'Talk to her';
  };
  setState(false);

  function start() {
    hooks.onStart?.();
    rec = new Recognition();
    rec.lang = navigator.language || 'en-GB';
    rec.interimResults = true;
    rec.continuous = false;
    rec.maxAlternatives = 1;
    base = input.value.trim();
    heard = '';
    wasStopped = false;

    rec.onresult = (event) => {
      let text = '';
      for (let i = 0; i < event.results.length; i += 1) text += event.results[i][0].transcript;
      heard = text.trim();
      input.value = [base, heard].filter(Boolean).join(' ');
      input.dispatchEvent(new Event('input', { bubbles: true }));
      hooks.onText?.();
    };
    rec.onerror = (event) => {
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') hooks.onError?.('Allow the microphone for this page to talk to her.');
      else if (event.error === 'audio-capture') hooks.onError?.("I can't find a microphone.");
      else if (event.error === 'network') hooks.onError?.("The speech service couldn't be reached. Check the connection.");
      else if (event.error === 'no-speech') hooks.onError?.("I didn't hear anything.");
    };
    rec.onend = () => {
      setState(false);
      const text = input.value.trim();
      if (heard && !wasStopped) hooks.onDone?.(text);
      else if (heard && wasStopped) hooks.onDone?.(text, { stopped: true });
      rec = null;
    };

    try {
      rec.start();
      setState(true);
    } catch {
      setState(false);
      rec = null;
    }
  }

  function stop() {
    if (!rec) return;
    wasStopped = true;
    try {
      rec.stop(); // finishes what it has heard, then onend fires
    } catch {
      /* not running */
    }
  }

  function toggle() {
    if (rec) stop();
    else start();
  }

  button.addEventListener('click', toggle);
  return api;
}
