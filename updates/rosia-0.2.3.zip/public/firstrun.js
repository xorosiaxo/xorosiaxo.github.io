/* First run, after the age screen: what should she call you? Asked once; skipping is fine. */

const KEY = 'rosia.named';

export function cleanName(raw) {
  return String(raw || '').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 40);
}

export function askName({ doc = document, storage = localStorage } = {}) {
  if (storage.getItem(KEY) === '1') return Promise.resolve('');
  const card = doc.getElementById('name');
  const form = doc.getElementById('nameForm');
  const input = doc.getElementById('nameInput');
  card.hidden = false;
  input.focus();
  return new Promise((resolve) => {
    const done = (name) => {
      storage.setItem(KEY, '1');
      card.hidden = true;
      resolve(name);
    };
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      done(cleanName(input.value));
    }, { once: true });
    doc.getElementById('nameSkip').addEventListener('click', () => done(''), { once: true });
  });
}
