import { createPanel } from '/panel.js';
import { format, splitBlocks, escapeHtml } from '/markdown.js';
import { genFigure } from '/imagegen.js';
import { createVoice } from '/voice.js';
import { createDictation } from '/dictation.js';
import { ringState } from '/ring.js';
import { dayKey, dayLabel, timeLabel } from '/days.js';
import { bindSidebar } from '/sidebar.js';
import { bindResizer } from '/resize.js';
import { createViews } from '/views.js';
import { createGallery } from '/gallery.js';
import { createDiary } from '/diary.js';
import { loadMind } from '/mind.js';
import { createSettings } from '/settings.js';
import { askName } from '/firstrun.js';
import { waitUntilReady } from '/startup.js';
import { askDiscord, mountDiscord } from '/discord.js';
import { askModels } from '/models.js';
import { loadHistory } from '/history.js';
import { createPlayer } from '/music.js';
import { createWatch } from '/watch.js';
import { createCall, callSupported } from '/call.js';
import { createReminders } from '/reminders.js';

const $ = (id) => document.getElementById(id);

const el = {
  thread: $('thread'),
  input: $('input'),
  composer: $('composer'),
  send: $('send'),
  newChat: $('newChat'),
  jump: $('jump'),
  avatar: $('avatar'),
  sparks: $('sparks'),
  presence: $('presence'),
  ring: $('ring'),
  presenceText: $('presenceText'),
  attach: $('attach'),
  file: $('file'),
  attachStrip: $('attachStrip'),
  dropHint: $('dropHint'),
  announce: $('srAnnounce'),
  tpl: $('tpl-turn')
};

const store = {
  get session() { return localStorage.getItem('rosia.session'); },
  set session(v) { v ? localStorage.setItem('rosia.session', v) : localStorage.removeItem('rosia.session'); }
};

const SUGGESTIONS = [
  'Tell me something I did not know about transformers.',
  'Roast my project idea, be brutal.',
  'What are you working on at the moment?'
];

const AVATAR_BASE = '/assets/avatar/web';
const PHOTO_POSES = ['bikini', 'front', 'back', 'feet', 'kneeling', 'gymwear', 'swimsuit', 'swimsuit-back'];
const MINUTE = 60_000;
const HOUR = 60 * MINUTE;
const TIMEZONE = Intl.DateTimeFormat().resolvedOptions().timeZone;

const state = {
  sessionId: store.session || null,
  busy: false,
  text: '',
  mood: null,
  frame: 0,
  ctl: null,
  slowTimer: 0,
  nudgeTimer: 0,
  pinned: true,
  lastDay: '',         // the day of the newest message on screen, so a divider is drawn when it changes
  online: false,
  imageMode: false,    // the "Create image" button is on: the next message is a picture request
  vision: true,
  lastAt: 0,           // when the last message in the open conversation was sent
  attachments: []      // pictures waiting to be sent: { dataUrl }
};

let avatar = null;
let panel = null;
let views = null;
let settings = null;
let player = null; // the music player (music.js): hers to work from the chat, theirs to work by hand
let watch = null; // the video window (watch.js): something the two of them are watching together
let call = null; // a voice call with her (call.js)
let reminders = null; // what she is keeping to remind them of (reminders.js)
let me = { owner: false, access: 'invite', version: '' }; // who the server says this is

/* ============================================================
   Boot
   ============================================================ */

/* ============================================================
   Access: this machine's key
   ============================================================ */

/* Every request carries this machine's key (an HttpOnly cookie the server set on the page load).
   If the server says there isn't one, either a reload fetches it (this computer, or an open server)
   or the machine has to be let in with a code from one that is already signed in. */
const nativeFetch = window.fetch.bind(window);
window.fetch = async (...args) => {
  const res = await nativeFetch(...args);
  if (res.status === 401) {
    res.clone().json().then((d) => { if (d && d.code === 'no_token') onNoToken(d); }).catch(() => {});
  }
  return res;
};

function onNoToken(info) {
  if (info.canSelfIssue && !sessionStorage.getItem('rosia.retried')) {
    sessionStorage.setItem('rosia.retried', '1');
    location.reload();
    return;
  }
  showLock();
}

function showLock(message = '') {
  const lock = $('lock');
  lock.hidden = false;
  document.querySelector('.app').inert = true;
  $('lockError').textContent = message;
  $('lockCode').focus();
}

async function redeem(code) {
  const res = await nativeFetch('/api/devices/redeem', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ code })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'That code did not work.');
}

function bindLock() {
  $('lockForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const code = $('lockCode').value.trim();
    if (!code) return;
    try {
      await redeem(code);
      location.reload();
    } catch (err) {
      $('lockError').textContent = err.message;
    }
  });
}

/* A link like /?pair=ABCD2345 (from "Link another machine") signs this machine in. */
async function redeemFromAddress() {
  const code = new URLSearchParams(location.search).get('pair');
  if (!code) return false;
  history.replaceState(null, '', location.pathname);
  if (store.session && !window.confirm('Connect this browser to the memory of the machine that made this code?')) return false;
  try {
    await redeem(code);
    location.reload();
    return true;
  } catch (err) {
    showLock(err.message);
    return false;
  }
}

let dictation = null;
const voice = createVoice({
  onLevel: (level) => document.querySelector('.portrait-wrap')?.style.setProperty('--voice', level.toFixed(3)),
  onSpeaking: (on) => {
    el.avatar.classList.toggle('speaking', on);
    if (on) avatar?.setState('talking');
    else if (!state.busy) avatar?.setState('idle');
  },
  onError: (message) => toast(message)
});

/* ---------- "Create image": a button by the message box that makes what they type a picture request ---------- */

/** Shows the button when pictures can be drawn for this person. */
async function loadFeatures() {
  try {
    const f = await (await nativeFetch('/api/features', { cache: 'no-store' })).json();
    if (f && f.images) $('modeRow').hidden = false;
    else if (f) $('imageMode').hidden = true;
    // "look at my screen": only on the computer she runs on, for the owner, with a model that can see
    if (f && f.screen) {
      $('lookMode').hidden = false;
      $('modeRow').hidden = false;
    }
  } catch {
    /* no button: the message box works as normal */
  }
}

/* ---------- a voice call: hands-free, she answers out loud, and talking over her cuts her off (call.js) ---------- */

const CALL_WORDS = { starting: 'Starting…', listening: 'Listening', hearing: 'Hearing you…', thinking: 'Thinking…', speaking: 'Talking', muted: 'Muted' };

function setUpCall() {
  const button = $('callBtn');
  if (!callSupported()) return;
  button.hidden = false;
  const bar = $('callBar');
  let began = 0;
  let clock = null;
  let loadingNoted = false;
  let loadingSince = 0;
  call = createCall({
    send: (text) => {
      el.input.value = text;
      send();
    },
    speaking: () => voice.speaking,
    hush: () => voice.stop(),
    busy: () => state.busy,
    onState: (s) => {
      if (s === 'ended') {
        bar.hidden = true;
        clearInterval(clock);
        button.classList.remove('on');
        button.setAttribute('aria-label', 'Call her');
        button.title = 'Call her';
        if (dictation) $('mic').hidden = false;
        return;
      }
      $('callState').textContent = CALL_WORDS[s] || '';
      bar.dataset.state = s;
    },
    onError: (message) => toast(message),
    onProgress: (percent) => {
      // the first call fetches her hearing (once): say so, so a slow start is not a mystery
      // (a model already kept by the browser also reports, in a moment: only a download that takes a while is mentioned)
      if (!loadingSince) loadingSince = Date.now();
      if (percent < 90 && !loadingNoted && Date.now() - loadingSince > 2000) {
        loadingNoted = true;
        toast('Getting her hearing ready for the first call (once)…');
      }
      if (percent < 100 && call?.state === 'listening') $('callState').textContent = `Getting ready ${percent}%`;
    }
  });
  const tick = () => {
    const s = Math.floor((Date.now() - began) / 1000);
    $('callTime').textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  };
  // pointing at the button (or tabbing to it) starts getting her hearing ready, so the call starts sooner
  for (const ev of ['pointerenter', 'focus']) button.addEventListener(ev, () => call.prepare(), { once: true });
  button.addEventListener('click', async () => {
    if (call.active) {
      call.end();
      return;
    }
    voice.unlock(); // her voice needs a click to be allowed to play
    dictation?.stop?.();
    $('mic').hidden = true; // the call is listening already
    began = Date.now();
    tick();
    clock = setInterval(tick, 1000);
    bar.hidden = false;
    button.classList.add('on');
    button.setAttribute('aria-label', 'Hang up');
    button.title = 'Hang up';
    await call.start();
  });
  $('callEnd').addEventListener('click', () => {
    voice.stop();
    call.end();
  });
  $('callMute').addEventListener('click', () => {
    const on = call.mute();
    $('callMute').setAttribute('aria-pressed', String(on));
    $('callMute').textContent = on ? 'Unmute' : 'Mute';
  });
}

function setImageMode(on) {
  state.imageMode = Boolean(on);
  const chip = $('imageMode');
  chip.setAttribute('aria-pressed', String(state.imageMode));
  el.input.placeholder = state.imageMode ? 'Describe your picture…' : 'Message Rosia';
  el.composer.classList.toggle('image-mode', state.imageMode);
  if (state.imageMode) el.input.focus();
}

/* First run: her first note about them is their name. Asked once, and not at all of someone she already has notes about. */
async function firstName() {
  if (localStorage.getItem('rosia.named') === '1') return;
  try {
    const { notes } = await (await fetch('/api/memory')).json();
    if (notes?.length) {
      localStorage.setItem('rosia.named', '1');
      return;
    }
  } catch { return; }
  const name = await askName();
  if (!name) return;
  await fetch('/api/memory', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ text: `Their name is ${name}.` }) }).catch(() => {});
}

async function init() {
  bindLock();
  if (await redeemFromAddress()) return;
  // just started: her parts are still loading, so show which, and open the chat when she can answer
  await waitUntilReady();
  // who this is: the owner sees a little more (updates, diagnostics), and is not told that "whoever runs this" can read their chats
  let signedIn = false;
  try {
    const res = await fetch('/api/me', { cache: 'no-store' });
    if (res.ok) {
      Object.assign(me, await res.json());
      signedIn = true;
    }
  } catch { /* offline: the usual handling takes it from here */ }
  if (signedIn) await firstName();
  // the owner, at this computer: an optional step to bring in their Discord GIFs (asked once; also in Settings)
  // the owner, at this computer, with no chat model or runner yet: set her up first
  if (signedIn && me.local) await askModels();
  if (signedIn && me.local) await askDiscord();
  bind();
  mountAvatar();
  bindResizer({ handle: $('resizer'), app: document.querySelector('.app') });
  await voice.init($('setVoiceHost'), { inline: true });
  el.avatar.addEventListener('click', () => {
    if (avatar?.posing) openLightbox(avatar.layers.get(avatar.posing).src);
  });
  el.avatar.addEventListener('keydown', (e) => {
    if ((e.key === 'Enter' || e.key === ' ') && avatar?.posing) {
      e.preventDefault();
      openLightbox(avatar.layers.get(avatar.posing).src);
    }
  });
  $('poseClose').addEventListener('click', () => avatar?.clearPose());
  dictation = createDictation({
    button: $('mic'),
    input: el.input,
    hooks: {
      onStart: () => voice.stop(), // so she does not hear herself
      onText: () => grow(),
      onError: (message) => toast(message),
      // when they stop talking, send it (if they have that switched on); otherwise it waits in the box
      onDone: (text, { stopped } = {}) => { if (voice.prefs.autoSend && !stopped && text) send(); }
    }
  });
  const gallery = createGallery({ host: $('viewGallery'), openLightbox, openConversation });
  const diary = createDiary({ host: $('viewDiary') });
  views = createViews({
    onShow: (name) => {
      if (name === 'gallery') gallery.load();
      if (name === 'diary') diary.load();
      if (name === 'memory') {
        panel.loadMemory();
        loadHistory($('memHistory'));
        loadMind($('memMind'));
      }
      if (name === 'settings') settings?.load();
      if (name === 'reminders') reminders?.show();
    }
  });
  panel = createPanel({
    getCurrentId: () => state.sessionId,
    openConversation,
    onDeletedCurrent: () => startNew({ greet: false }),
    currentView: () => views.current()
  });
  settings = createSettings({ host: $('viewSettings'), me, panel });
  $('openMemory').addEventListener('click', () => views.show('memory'));
  $('openReminders').addEventListener('click', () => views.show('reminders'));
  for (const [id, name] of [['navMemory', 'memory'], ['navReminders', 'reminders'], ['navGallery', 'gallery'], ['navDiary', 'diary'], ['navSettings', 'settings']]) {
    $(id).addEventListener('click', () => {
      panel.close();
      views.show(name);
    });
  }
  bindSidebar({ edge: $('edge'), drawer: $('drawer'), panel });
  player = createPlayer({ host: $('player'), toast });
  player.restore(); // music that was on before a reload comes back paused, where it was
  watch = createWatch({ host: $('watch'), toast });
  watch.restore(); // a video that was on before a reload comes back, paused
  setUpCall();
  await restore();
  const status = await health();
  if (status.ok) sessionStorage.removeItem('rosia.retried');
  // she speaks first when you turn up after a while (or for the very first time). A blank chat shows nothing until then, so
  // the suggestions do not flash up for a moment and vanish under her hello; they appear only if she is not going to say it.
  if (status.ok) {
    const greeting = maybeGreet();
    if (!el.thread.querySelector('.turn')) showIntro();
    await greeting;
    if (!el.thread.querySelector('.turn, .intro')) showIntro(); // the hello was not wanted after all
  } else if (!el.thread.querySelector('.turn')) {
    showIntro();
  }
  panel.checkMemory();
  // only now, so her hello comes before anything that fell due while they were away
  reminders = createReminders({ view: $('viewReminders'), bar: $('reminderBar'), dot: $('remindersDot'), toast, announce: sayReminder });
  reminders.start();
}

/* On a phone the keyboard covers part of the screen: the page is sized to the part that is still visible, so the message
   box stays above the keyboard and the latest message stays in view. */
function fitToScreen() {
  const vv = window.visualViewport;
  if (!vv) return;
  const apply = () => {
    const shrunk = window.innerHeight - vv.height > 80; // the keyboard (or similar) is up
    document.documentElement.style.setProperty('--app-h', shrunk ? `${Math.round(vv.height)}px` : '100dvh');
    if (shrunk) window.scrollTo(0, 0); // iOS scrolls the page up to the box; the layout already makes room
    if (state.pinned) scroll(true);
  };
  vv.addEventListener('resize', apply);
  vv.addEventListener('scroll', apply);
}

function bind() {
  fitToScreen();
  $('imageMode')?.addEventListener('click', () => setImageMode(!state.imageMode));
  $('lookMode')?.addEventListener('click', () => {
    if (state.busy) return;
    el.input.value = 'look at my screen';
    send();
  });
  loadFeatures();
  el.composer.addEventListener('submit', (e) => {
    e.preventDefault();
    if (state.busy) stop();
    else send();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && state.busy) stop();
  });

  el.input.addEventListener('input', () => {
    grow();
    el.input.scrollTop = el.input.scrollHeight;
    cancelNudge(); // they are typing: not gone quiet
  });

  el.input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      send();
    }
  });

  el.newChat.addEventListener('click', () => {
    panel?.close();
    startNew({ greet: true });
  });

  // pictures: button, paste, drag and drop
  el.attach.addEventListener('click', () => {
    if (!state.vision) return toast("The model that's running can't look at pictures.");
    el.file.click();
  });
  el.file.addEventListener('change', () => {
    addFiles([...el.file.files]);
    el.file.value = '';
  });
  el.input.addEventListener('paste', (e) => {
    const files = [...(e.clipboardData?.files || [])].filter((f) => f.type.startsWith('image/'));
    if (files.length) {
      e.preventDefault();
      addFiles(files);
    }
  });
  let dragDepth = 0;
  const hasFiles = (e) => [...(e.dataTransfer?.types || [])].includes('Files');
  document.addEventListener('dragenter', (e) => {
    if (!hasFiles(e)) return;
    dragDepth += 1;
    el.dropHint.classList.add('show');
  });
  document.addEventListener('dragleave', (e) => {
    if (!hasFiles(e)) return;
    dragDepth = Math.max(0, dragDepth - 1);
    if (!dragDepth) el.dropHint.classList.remove('show');
  });
  document.addEventListener('dragover', (e) => { if (hasFiles(e)) e.preventDefault(); });
  document.addEventListener('drop', (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    dragDepth = 0;
    el.dropHint.classList.remove('show');
    if (!state.vision) return toast("The model that's running can't look at pictures.");
    addFiles([...e.dataTransfer.files]);
  });

  // any activity wakes her if she has dozed off
  for (const type of ['keydown', 'pointerdown']) {
    document.addEventListener(type, () => avatar?.touch(), { passive: true });
  }
  el.jump.addEventListener('click', () => scroll(true));

  el.thread.addEventListener('scroll', onScroll, { passive: true });

  // one delegated handler for copy + suggestions
  el.thread.addEventListener('click', async (e) => {
    const codeCopy = e.target.closest('.code-copy');
    if (codeCopy) {
      const text = codeCopy.closest('.code')?.querySelector('code')?.textContent || '';
      try {
        await navigator.clipboard.writeText(text);
        codeCopy.textContent = 'Copied';
      } catch {
        codeCopy.textContent = 'Press Ctrl+C';
      }
      setTimeout(() => { codeCopy.textContent = 'Copy'; }, 1400);
      return;
    }
    const copy = e.target.closest('.copy');
    if (copy) {
      const turn = copy.closest('.turn');
      const text = turn?.querySelector('.body')?.innerText?.trim();
      await copyText(text, copy);
      return;
    }
    const suggest = e.target.closest('.suggest');
    if (suggest) {
      el.input.value = suggest.dataset.prompt || suggest.innerText.trim();
      grow();
      send();
    }
  });

  // pointer devices only: reveal-on-hover has no meaning on touch
  if (window.matchMedia?.('(hover: none)').matches) {
    document.documentElement.classList.add('touch');
  }

  document.addEventListener('visibilitychange', () => {
    document.documentElement.classList.toggle('tab-hidden', document.hidden);
    if (!document.hidden && !state.busy) health();
  });
}

function grow() {
  el.input.style.height = 'auto';
  el.input.style.height = `${Math.min(el.input.scrollHeight, 190)}px`;
}

function toast(message) {
  const box = document.createElement('div');
  box.className = 'toast';
  box.setAttribute('role', 'status');
  box.textContent = message;
  document.body.appendChild(box);
  setTimeout(() => box.classList.add('out'), 2600);
  setTimeout(() => box.remove(), 3000);
}

/* ============================================================
   Health
   ============================================================ */

let healthAbort;
let healthTimer;

async function health() {
  healthAbort?.abort();
  healthAbort = new AbortController();
  let status = { ok: false };
  try {
    const res = await fetch('/api/health', { signal: healthAbort.signal });
    const data = await res.json();
    const ok = Boolean(data.model);
    status = { ok };
    state.online = ok || Boolean(data.drawing);
    state.vision = data.vision !== false;
    el.attach.classList.toggle('off', !state.vision);
    if (!state.busy) {
      if (data.drawing) presence('drawing', 'busy');
      else presence(ok ? 'online' : 'no model', ok ? 'ok' : 'offline');
    }
  } catch (err) {
    state.online = false;
    if (err.name !== 'AbortError' && !state.busy) presence('offline', 'offline');
  } finally {
    clearTimeout(healthTimer);
    healthTimer = setTimeout(health, 30_000);
  }
  return status;
}

function presence(text, tone) {
  const { ring, word } = ringState(text, tone);
  el.presenceText.textContent = word;
  el.ring.className = `ring ${ring}`;
}

/* ============================================================
   Thread rendering
   ============================================================ */

function clearThread() {
  el.thread.replaceChildren();
  state.lastDay = '';
}

/** Takes a turn out again (a hello that was not wanted, an empty reply), and the day divider if it now heads nothing. */
function dropTurn(turn) {
  const before = turn.previousElementSibling;
  const after = turn.nextElementSibling;
  turn.remove();
  if (before?.classList.contains('day') && !after) {
    before.remove();
    state.lastDay = ''; // the next message draws its own divider
  }
}

/** Puts a turn at the end of the thread, with a day divider above it when the date has changed. */
function addTurn(node, at = Date.now(), into = el.thread) {
  const key = dayKey(at);
  if (key !== state.lastDay) {
    state.lastDay = key;
    const day = document.createElement('div');
    day.className = 'day';
    day.setAttribute('role', 'separator');
    day.textContent = dayLabel(at);
    into.appendChild(day);
  }
  node.dataset.time = timeLabel(at);
  into.appendChild(node);
  return node;
}

function showIntro() {
  clearThread();
  const intro = document.createElement('div');
  intro.className = 'intro';
  intro.innerHTML = `
    <div class="intro-title">Say something</div>
    <div class="intro-sub">She answers in a couple of seconds and remembers this conversation.</div>
    <div class="suggests"></div>`;
  const box = intro.querySelector('.suggests');
  for (const prompt of SUGGESTIONS) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'suggest';
    b.dataset.prompt = prompt;
    b.innerHTML = `<span>${escapeHtml(prompt)}</span>
      <svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3.5 10.5 8 6 12.5"/></svg>`;
    box.appendChild(b);
  }
  el.thread.appendChild(intro);
}

/* extras: { photo, images (saved on the server), localImages (data URLs just picked), proactive } */
function makeTurn(side, text = '', extras = {}) {
  const node = el.tpl.content.firstElementChild.cloneNode(true);
  node.classList.add(side);
  if (extras.proactive) node.dataset.proactive = extras.proactive;
  if (extras.links?.length) addLinkCards(node, extras.links);
  const bubble = node.querySelector('.bubble');
  const body = node.querySelector('.body');

  const sources = [...(extras.localImages || []), ...(extras.images || []).map((id) => `/media/${id}`)];
  if (sources.length) {
    const pics = document.createElement('div');
    pics.className = `pics n${Math.min(sources.length, 3)}`;
    for (const src of sources) {
      const b = document.createElement('button');
      b.type = 'button';
      b.setAttribute('aria-label', 'View picture larger');
      const img = new Image();
      img.src = src;
      img.alt = 'A picture you sent';
      img.decoding = 'async';
      img.addEventListener('load', () => scroll(), { once: true });
      b.appendChild(img);
      b.addEventListener('click', () => openLightbox(src));
      pics.appendChild(b);
    }
    bubble.insertBefore(pics, body);
  }

  if (text) renderInto(body, text, false);
  if (side === 'her' && voice.enabled) node.appendChild(listenButton(body));
  if (extras.image) bubble.appendChild(drawing(extras.image));
  if (extras.gif) bubble.appendChild(gifNode(extras.gif));
  if (extras.video) bubble.appendChild(videoNode(extras.video));
  return node;
}

/* "Listen" on her messages: reads that message aloud, or stops if it is already being read. */
function listenButton(body) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'listen';
  b.setAttribute('aria-label', 'Listen to this message');
  b.title = 'Listen';
  b.innerHTML = '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2.5 6.2v3.6h2.6L8.6 12.5v-9L5.1 6.2H2.5Z"/><path d="M10.6 6a3 3 0 0 1 0 4"/><path d="M12.3 4.3a5.4 5.4 0 0 1 0 7.4"/></svg>';
  b.addEventListener('click', () => {
    if (voice.speaking && b.classList.contains('now')) {
      voice.stop();
      return;
    }
    document.querySelectorAll('.listen.now').forEach((x) => x.classList.remove('now'));
    b.classList.add('now');
    voice.say(textToRead(b.closest('.turn'), body)).finally(() => b.classList.remove('now'));
  });
  return b;
}

/* On a computer each text has its own Listen button and reads just that text. On a phone there is one, under her last text,
   and it reads the whole reply (the texts that arrived together). */
function textToRead(turn, body) {
  if (!turn || !window.matchMedia('(max-width: 900px)').matches) return body.dataset.raw || body.innerText;
  const parts = [];
  for (let t = turn; t && t.classList.contains('her') && (t === turn || t.dataset.proactive === turn.dataset.proactive); t = t.previousElementSibling) {
    const raw = t.querySelector('.body')?.dataset.raw;
    if (raw) parts.unshift(raw);
  }
  return parts.join('\n\n') || body.dataset.raw || body.innerText;
}

/* A GIF from her collection, sent as a reaction: animated pictures play as they are, short clips loop silently. */
function gifNode(g) {
  const fig = document.createElement('figure');
  fig.className = 'reaction';
  // a clip on this computer is served by the app; one that ships as a link plays straight from that link
  const src = g.url && /^https:\/\//i.test(g.url) ? g.url : `/gif/${g.id}`;
  if (g.kind === 'video') {
    const v = document.createElement('video');
    v.src = src;
    v.loop = true;
    v.muted = true;
    v.playsInline = true;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) v.controls = true;
    else v.autoplay = true;
    v.setAttribute('aria-label', 'A clip she sent');
    v.addEventListener('loadeddata', () => scroll(), { once: true });
    fig.appendChild(v);
  } else {
    const img = new Image();
    img.src = src;
    img.alt = 'A clip she sent';
    img.decoding = 'async';
    img.addEventListener('load', () => scroll(), { once: true });
    fig.appendChild(img);
  }
  return fig;
}

/* A video she sent: a link to one of her favourites, played right here by this browser (nothing passes through the server). */
function videoNode(info) {
  const fig = document.createElement('figure');
  fig.className = 'sentvideo';
  let href;
  try {
    const u = new URL(info.url);
    if (!/^https?:$/.test(u.protocol)) return fig;
    href = u.href;
  } catch {
    return fig;
  }
  const v = document.createElement('video');
  v.src = href;
  v.controls = true;
  v.loop = true; // plays round again, like a GIF
  v.playsInline = true;
  v.preload = 'metadata';
  v.setAttribute('aria-label', info.name ? `A clip she sent: ${info.name}` : 'A clip she sent');
  v.addEventListener('loadedmetadata', () => scroll(), { once: true });
  v.addEventListener('error', () => {
    // the link stopped working between her check and now (or this browser cannot play the format)
    const note = document.createElement('figcaption');
    const a = document.createElement('a');
    a.href = href;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    a.textContent = 'open the clip in a new tab';
    note.append("Couldn't play it here: ", a);
    v.replaceWith(note);
  }, { once: true });
  fig.appendChild(v);
  return fig;
}

/* While the picture card is lent out: whose picture it is and about how long is left, so a wait never looks like a hang. */
function drawingHint(evt) {
  const who = evt.forYou ? "She's finishing your picture" : "She's finishing a picture for someone else";
  const left = Number(evt.etaS);
  if (!left || left < 5) return `${who}. She'll reply in a moment.`;
  const time = left < 60 ? `about ${Math.max(10, Math.round(left / 10) * 10)} seconds` : `about ${Math.round(left / 60)} minute${Math.round(left / 60) === 1 ? '' : 's'}`;
  return `${who}. She'll reply in ${time}.`;
}

/* A picture she is drawing (or has drawn): shows progress, then the picture. */
function drawing(info) {
  return genFigure(info, {
    open: (src) => openLightbox(src),
    changed: () => scroll(),
    done: () => announce('Rosia drew a picture for you.')
  });
}

/* A preview under a message for each link in it: the picture/GIF if there is one, the title, the site. */
function addLinkCards(turn, links) {
  const bubble = turn.querySelector('.bubble');
  bubble.querySelector('.linkcards')?.remove();
  const safe = (links || []).filter((l) => /^https?:/i.test(l.url));
  if (!safe.length) return;

  const wrap = document.createElement('div');
  wrap.className = 'linkcards';
  for (const l of safe) {
    const card = document.createElement('a');
    card.className = 'linkcard';
    if (!l.ok) card.classList.add('failed');
    if (l.kind === 'image') card.classList.add('picture');
    card.href = l.url;
    card.target = '_blank';
    card.rel = 'noopener noreferrer';

    if (l.image) {
      const img = new Image();
      img.src = '/media/' + l.image;
      img.alt = '';
      img.loading = 'lazy';
      img.addEventListener('load', () => scroll(), { once: true });
      card.appendChild(img);
      if (l.image.endsWith('.gif')) {
        const badge = document.createElement('span');
        badge.className = 'gif-badge';
        badge.textContent = 'GIF';
        card.appendChild(badge);
      }
    }

    if (l.kind !== 'image' || !l.ok) {
      const meta = document.createElement('span');
      meta.className = 'lc-meta';
      const title = document.createElement('span');
      title.className = 'lc-title';
      title.textContent = l.title || l.site || l.url;
      const sub = document.createElement('span');
      sub.className = 'lc-site';
      sub.textContent = l.ok ? l.site : l.error || "Couldn't open this link";
      meta.append(title, sub);
      card.appendChild(meta);
    }
    wrap.appendChild(card);
  }
  bubble.appendChild(wrap);
}

function typingTurn() {
  const turn = makeTurn('her');
  const body = turn.querySelector('.body');
  body.innerHTML = '<span class="typing"><i></i><i></i><i></i></span>';
  addTurn(turn);
  scroll(true);
  return turn;
}

/* ============================================================
   Send
   ============================================================ */

async function send() {
  const text = el.input.value.trim();
  if (state.busy) return;
  if (!text && !state.attachments.length) return;
  voice.stop();
  voice.unlock(); // browsers only allow sound after a click or key press, so this is the moment

  const localImages = state.attachments.map((a) => a.dataUrl);
  el.input.value = '';
  grow();
  clearAttachments();
  el.thread.querySelector('.intro')?.remove();

  addTurn(makeTurn('them', text, { localImages }));
  state.lastAt = Date.now();
  scroll(true);

  // with "Create image" switched on, what they typed is the picture they want (not with pictures attached: that is a question about them)
  const mode = state.imageMode && !localImages.length && text ? 'image' : undefined;
  if (state.imageMode) setImageMode(false); // it applies to this message only, so nobody is left drawing by accident
  await respond({ message: text, images: localImages, mode });
}

/* One reply from her: to something the person said, or (kind = 'greet' | 'nudge') her speaking first. */
async function respond({ message = '', images = [], kind, mode, reminderId } = {}) {
  if (state.busy) return;
  cancelNudge();
  el.thread.querySelector('.intro')?.remove();

  const turn = typingTurn();
  const body = turn.querySelector('.body');
  if (kind) turn.dataset.proactive = kind;
  if (!kind) avatar?.clearPose(); // they have said something new: back to her face

  state.busy = true;
  state.text = '';
  state.mood = null;
  el.send.classList.add('stop');
  el.send.setAttribute('aria-label', 'Stop');
  presence('typing', 'busy');
  avatar?.setState('thinking');

  state.ctl = new AbortController();
  el.thread.setAttribute('aria-busy', 'true');
  armSlowHint(body);
  let completed = false;

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ sessionId: state.sessionId, message, images, kind, mode, reminderId, call: call?.active || undefined, tz: TIMEZONE }),
      signal: state.ctl.signal
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      // a nudge or greeting that is no longer wanted is not worth an error message
      if (kind && res.status === 409) {
        dropTurn(turn);
        return;
      }
      throw new Error(err.error || `Request failed (${res.status})`);
    }

    completed = await stream(res, turn, body);
    if (!state.text.trim() && !turn.querySelector('.photo, .gen, .reaction')) dropTurn(turn);
    else state.lastAt = Date.now();
  } catch (err) {
    if (err.name === 'AbortError') {
      // stopped by the person: stream()'s finally has already settled the text she got out
      if (!state.text) dropTurn(turn);
    } else if (kind === 'remind') {
      // she could not say it (her model is off, say): the strip at the top still shows the reminder, so no error on top of it
      dropTurn(turn);
    } else {
      showError(body, err.message);
    }
    avatar?.setState('idle');
    if (err.name !== 'AbortError') avatar?.flash('worried', 3500);
    presence('online', 'ok');
  } finally {
    clearSlowHint();
    el.thread.removeAttribute('aria-busy');
    state.ctl = null;
    state.busy = false;
    el.send.classList.remove('stop');
    el.send.setAttribute('aria-label', 'Send');
    if (kind !== 'greet') el.input.focus();
    if (completed && kind !== 'nudge') scheduleNudge();
  }
}

function stop() {
  state.ctl?.abort();
}

/* A reminder has come due: she says it in the chat that is open, once she is free (never on top of a reply in progress). */
async function sayReminder(reminder) {
  for (let waited = 0; state.busy && waited < 120; waited += 1) await new Promise((r) => setTimeout(r, 500));
  if (state.busy || !state.online) return;
  await respond({ kind: 'remind', reminderId: reminder.id });
}

/* a busy model (or a game on the same GPU) can take a while: say so instead of looking frozen */
function armSlowHint(body) {
  clearSlowHint();
  state.slowTimer = setTimeout(() => {
    if (!body.isConnected || !body.querySelector('.typing')) return;
    const hint = document.createElement('span');
    hint.className = 'slow';
    hint.textContent = 'Still thinking…';
    body.appendChild(hint);
    scroll();
  }, 7000);
}

function clearSlowHint() {
  clearTimeout(state.slowTimer);
  state.slowTimer = 0;
}

async function stream(res, turn, body) {
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let started = false;
  let failed = false;
  const live = { turn, body, extra: [], frame: 0 }; // her reply as separate texts, written as it arrives

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      let cut;
      while ((cut = buffer.indexOf('\n\n')) !== -1) {
        const frame = buffer.slice(0, cut);
        buffer = buffer.slice(cut + 2);
        if (!frame.startsWith('data:')) continue;
        let evt;
        try { evt = JSON.parse(frame.slice(5).trim()); } catch { continue; }

        if (evt.type === 'session') {
          state.sessionId = evt.id;
          store.session = evt.id;
        } else if (evt.type === 'tool') {
          setTool(turn, evt);
        } else if (evt.type === 'reset') {
          // she is starting the reply over (after a tool call, or because the draft repeated herself):
          // clear what is on screen so the old text does not pile up under the new
          state.text = '';
          state.mood = null;
          avatar?.setMood(null);
          body.replaceChildren();
          clearLiveTexts(live);
        } else if (evt.type === 'photo') {
          // one of her own photos: it is shown where she is, in her portrait, never in the chat
          avatar?.showPose(evt.pose);
        } else if (evt.type === 'image') {
          const bubble = turn.querySelector('.bubble');
          if (!bubble.querySelector('.gen')) bubble.appendChild(drawing({ job: evt.job, state: evt.state, media: evt.media, ratio: evt.ratio === 'landscape' ? '4 / 3' : evt.ratio === 'square' ? '1 / 1' : '3 / 4' }));
          scroll();
        } else if (evt.type === 'gif') {
          const bubble = turn.querySelector('.bubble');
          if (!bubble.querySelector('.reaction')) bubble.appendChild(gifNode({ id: evt.id, kind: evt.kind, url: evt.url }));
          scroll();
        } else if (evt.type === 'video') {
          const bubble = turn.querySelector('.bubble');
          if (!bubble.querySelector('.sentvideo')) bubble.appendChild(videoNode({ url: evt.url, name: evt.name }));
          scroll();
        } else if (evt.type === 'watch') {
          // she put a video on, or paused or closed it: the video window follows (null closes it)
          watch?.sync(evt.video);
        } else if (evt.type === 'music') {
          // she put something on, or changed what is playing: the player follows (null closes it)
          player?.sync(evt.player);
        } else if (evt.type === 'looked') {
          // she took a look at one of their windows: say which, so it is never a surprise
          toast(`She looked at ${evt.window}`);
        } else if (evt.type === 'reminders') {
          // she set or cancelled one: the list, and the watch kept on the clock, follow
          reminders?.set(evt.reminders);
        } else if (evt.type === 'status') {
          if (evt.state === 'drawing' && !started) {
            body.innerHTML = '';
            const hint = document.createElement('span');
            hint.className = 'slow';
            hint.textContent = drawingHint(evt);
            body.appendChild(hint);
          } else if (evt.state === 'ready' && !started) {
            body.innerHTML = '<span class="typing"><i></i><i></i><i></i></span>';
          }
        } else if (evt.type === 'links') {
          // what she found at the address: show it under your message
          const mine = [...el.thread.querySelectorAll('.turn.them')].pop();
          if (mine) addLinkCards(mine, evt.links);
          scroll();
        } else if (evt.type === 'memory') {
          const chip = document.createElement('button');
          chip.type = 'button';
          chip.className = 'note-chip';
          chip.textContent = `Noted: ${evt.text}`;
          chip.title = 'See what she remembers';
          chip.addEventListener('click', () => views.show('memory'));
          turn.querySelector('.bubble').appendChild(chip);
        } else if (evt.type === 'mood') {
          state.mood = evt.mood;
          avatar?.setMood(evt.mood);
        } else if (evt.type === 'delta') {
          if (!started) {
            clearSlowHint();
            body.replaceChildren();
            body.classList.add('streaming');
            started = true;
            avatar?.setState('talking');
            presence('typing', 'busy');
          }
          state.text += evt.text;
          // as she writes: one bubble, or (as separate texts) a new bubble for each paragraph the moment it starts
          if (textsMode()) paintTexts(live);
          else paint(body);
        } else if (evt.type === 'error') {
          failed = true;
          showError(body, evt.message);
        } else if (evt.type === 'end' && evt.id) {
          // the server's final text (stray tags, a repeated paragraph or an over-long line trimmed) is what was saved
          if (typeof evt.text === 'string' && evt.text.trim()) state.text = evt.text;
          state.sessionId = evt.id;
          store.session = evt.id;
          afterReply();
        }
      }
    }
  } finally {
    if (state.frame) {
      cancelFrame(state.frame);
      state.frame = 0;
    }
    setTool(turn, null);
    avatar?.setState('idle');

    if (!failed) {
      if (textsMode()) finishTexts(live, state.text || '…');
      else renderInto(body, state.text || '…', false);
      body.classList.remove('streaming');
      // streaming is silent for screen readers; the finished message is read once
      if (state.text.trim() && !state.ctl?.signal.aborted) announce(`Rosia: ${body.innerText}`);
      if (!state.ctl?.signal.aborted) react(state.text, state.mood);
      // read aloud when voice is on, and always on a call
      if ((voice.auto || call?.active) && state.text.trim() && !state.ctl?.signal.aborted) voice.say(state.text, { mood: state.mood });
      presence('online', 'ok');
    } else {
      body.classList.remove('streaming');
    }
  }

  if (!failed) scroll();
  return !failed && !state.ctl?.signal.aborted;
}

/* ============================================================
   Her replies as separate texts
   ============================================================ */

/* A person texts in short bursts: she writes her reply in short paragraphs, and each one is its own bubble. They are
   written live, as her words arrive: a new bubble appears the moment she starts a new paragraph, so nothing waits for
   the whole reply. Off (one bubble) with localStorage 'rosia.texts' = '0'. */
function textsMode() {
  try { return localStorage.getItem('rosia.texts') !== '0'; } catch { return true; }
}

/** Makes the bubbles match `text`, one per paragraph: the first is the reply's own, the rest are added or taken away. */
function syncTexts(live, text, streaming) {
  const blocks = splitBlocks(text);
  if (!blocks.length) return;
  while (live.extra.length < blocks.length - 1) {
    const next = makeTurn('her');
    if (live.turn.dataset.proactive) next.dataset.proactive = live.turn.dataset.proactive;
    next.querySelector('.body').classList.add('streaming');
    addTurn(next);
    live.extra.push(next);
  }
  while (live.extra.length > blocks.length - 1) live.extra.pop().remove();
  const bodies = [live.body, ...live.extra.map((t) => t.querySelector('.body'))];
  blocks.forEach((block, i) => {
    const writing = streaming && i === blocks.length - 1; // only the one she is still writing shows the cursor
    const key = `${writing ? '…' : ''}${block}`;
    if (bodies[i].dataset.shown === key) return;
    bodies[i].dataset.shown = key;
    renderInto(bodies[i], block, writing);
    if (!writing) bodies[i].classList.remove('streaming');
  });
}

/** As her words arrive (at most once a frame, however fast they come). */
function paintTexts(live) {
  if (live.frame) return;
  live.frame = nextFrame(() => {
    live.frame = 0;
    if (!live.body.isConnected) return;
    syncTexts(live, state.text, true);
    scroll();
  });
}

/** She has finished: the bubbles take the final text (the server may have trimmed it), and what came with it goes last. */
function finishTexts(live, text) {
  if (live.frame) cancelFrame(live.frame);
  live.frame = 0;
  syncTexts(live, text, false);
  for (const b of [live.body, ...live.extra.map((t) => t.querySelector('.body'))]) {
    b.classList.remove('streaming');
    delete b.dataset.shown;
  }
  // a GIF, video, picture or note that came with the reply sits under the last text, not the first
  const last = live.extra.at(-1);
  if (last) {
    const from = live.turn.querySelector('.bubble');
    const to = last.querySelector('.bubble');
    for (const node of from.querySelectorAll('.gen, .reaction, .sentvideo, .note-chip')) to.appendChild(node);
  }
}

/** She is starting over (after a tool, or a repeat): the extra bubbles go. */
function clearLiveTexts(live) {
  if (live.frame) cancelFrame(live.frame);
  live.frame = 0;
  for (const t of live.extra) t.remove();
  live.extra = [];
  delete live.body.dataset.shown;
}

/* The conversation list gets a title and the memory list may grow a little after she has replied. */
/* A desktop notification, when the page is inside the desktop app (Tauri). In a browser this does nothing. */
function desktopNotify(body) {
  const tauri = window.__TAURI_INTERNALS__;
  if (!tauri?.invoke) return;
  tauri.invoke('plugin:notification|notify', { options: { title: 'Rosia', body } }).catch(() => { /* not allowed: stay quiet */ });
}

function afterReply() {
  // in the desktop app: when she has written and the window is not in front, a notification says so (never in a browser)
  if (state.text.trim() && (document.hidden || !document.hasFocus())) desktopNotify(state.text.trim().replace(/\s+/g, ' ').slice(0, 160));
  panel?.refreshChats();
  for (const delay of [9_000, 25_000]) setTimeout(() => panel?.checkMemory(), delay);
}

/** Says something to screen readers without showing it. */
function announce(text) {
  el.announce.textContent = '';
  setTimeout(() => { el.announce.textContent = text; }, 60);
}

function showError(body, message) {
  body.replaceChildren();
  body.classList.remove('streaming');
  const p = document.createElement('p');
  p.style.color = '#ff8fa3';
  p.textContent = message || 'Something went wrong.';
  body.appendChild(p);
}

/* The next screen refresh, or 50 ms, whichever comes first: a window the browser is not drawing (hidden behind another,
   or in a preview) gets no refreshes, and her words must still appear as they arrive. Returns a handle for cancelFrame. */
function nextFrame(fn) {
  let done = false;
  const run = () => {
    if (done) return;
    done = true;
    cancelAnimationFrame(handle.raf);
    clearTimeout(handle.timer);
    fn();
  };
  const handle = { raf: requestAnimationFrame(run), timer: setTimeout(run, 50) };
  return handle;
}
function cancelFrame(handle) {
  if (!handle) return;
  cancelAnimationFrame(handle.raf);
  clearTimeout(handle.timer);
}

/* paint at most once per frame, regardless of token rate */
function paint(body) {
  if (state.frame) return;
  state.frame = nextFrame(() => {
    state.frame = 0;
    if (!body.isConnected) return;
    renderInto(body, state.text, true);
    scroll();
  });
}

const TOOL_LABEL = {
  web_search: 'Searching the web',
  get_time: 'Checking the time',
  remember: 'Making a note',
  recall: 'Thinking back',
  read_link: 'Opening the link',
  send_photo: 'Picking a photo',
  generate_image: 'Getting the picture started',
  play_music: 'Finding a song',
  music_control: 'At the music player',
  set_reminder: 'Setting a reminder',
  cancel_reminder: 'Cancelling a reminder',
  look_at_screen: 'Looking at your screen',
  game: 'Playing',
  watch_video: 'Finding the video',
  video_control: 'At the video'
};

function setTool(turn, evt) {
  const box = turn.querySelector('.tool');
  if (!evt) {
    box.classList.remove('active');
    box.replaceChildren();
    return;
  }
  if (evt.status === 'start') {
    box.classList.add('active');
    box.innerHTML = `<span class="tool-dot"></span><span>${TOOL_LABEL[evt.name] || 'Working'}…</span>`;
    presence('searching', 'busy');
  } else {
    box.classList.remove('active');
    box.replaceChildren();
  }
}

/* ============================================================
   Scrolling
   ============================================================ */

function onScroll() {
  const box = el.thread;
  const distance = box.scrollHeight - box.scrollTop - box.clientHeight;
  state.pinned = distance < 80;
  el.jump.classList.toggle('show', distance > 260);
}

function scroll(force = false) {
  if (!force && !state.pinned) return;
  el.thread.scrollTop = el.thread.scrollHeight;
}

/* ============================================================
   Pictures you send
   ============================================================ */

const MAX_PICTURES = 3;
const MAX_SIDE = 1024;

/* Shrunk in the browser first: the model reads a 1024 px picture just as well, and it is a lot
   less to upload and for it to chew through. */
async function shrink(file) {
  const bitmap = await createImageBitmap(file, { imageOrientation: 'from-image' });
  const scale = Math.min(1, MAX_SIDE / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  // OffscreenCanvas encodes asynchronously, so a big photo doesn't freeze the page while it shrinks
  const canvas = typeof OffscreenCanvas === 'function' ? new OffscreenCanvas(width, height) : Object.assign(document.createElement('canvas'), { width, height });
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#fff'; // transparent PNGs would otherwise go black
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(bitmap, 0, 0, width, height);
  bitmap.close?.();
  const blob = canvas.convertToBlob
    ? await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.86 })
    : await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.86));
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

async function addFiles(files) {
  for (const file of files) {
    if (!file.type.startsWith('image/')) continue;
    if (state.attachments.length >= MAX_PICTURES) {
      toast(`Up to ${MAX_PICTURES} pictures at a time.`);
      break;
    }
    try {
      state.attachments.push({ dataUrl: await shrink(file) });
    } catch {
      toast("Couldn't read that picture. Try a JPEG or PNG.");
    }
  }
  renderAttachments();
  el.input.focus();
}

function renderAttachments() {
  el.attachStrip.replaceChildren();
  el.attachStrip.hidden = !state.attachments.length;
  state.attachments.forEach((a, i) => {
    const box = document.createElement('div');
    box.className = 'thumb';
    const img = new Image();
    img.src = a.dataUrl;
    img.alt = 'Picture to send';
    const x = document.createElement('button');
    x.type = 'button';
    x.setAttribute('aria-label', 'Remove picture');
    x.innerHTML = '<svg viewBox="0 0 16 16" width="10" height="10" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="m4 4 8 8M12 4l-8 8"/></svg>';
    x.addEventListener('click', () => {
      state.attachments.splice(i, 1);
      renderAttachments();
    });
    box.append(img, x);
    el.attachStrip.appendChild(box);
  });
}

function clearAttachments() {
  state.attachments = [];
  renderAttachments();
}

/* ============================================================
   Conversations
   ============================================================ */

function lastTurn() {
  const turns = el.thread.querySelectorAll('.turn');
  return turns[turns.length - 1] || null;
}

function startNew({ greet = true, intro = true } = {}) {
  if (state.busy) return;
  views?.show('chat');
  cancelNudge();
  const alreadyBlank = !el.thread.querySelector('.turn');
  state.sessionId = null;
  store.session = null;
  state.lastAt = 0;
  if (intro) showIntro();
  else clearThread();
  presence(state.online ? 'online' : 'offline', state.online ? 'ok' : 'offline');
  avatar?.setState('idle');
  el.input.focus();
  // a fresh chat opens with her saying hello, unless it was already a blank page
  if (greet && state.online && !alreadyBlank) respond({ kind: 'greet' });
}

async function openConversation(id) {
  if (state.busy) return;
  views?.show('chat');
  cancelNudge();
  try {
    const res = await fetch(`/api/conversations/${encodeURIComponent(id)}`);
    if (!res.ok) return;
    const data = await res.json();
    state.sessionId = id;
    store.session = id;
    renderConversation(data.messages);
    scheduleNudge();
  } catch {
    toast("Couldn't open that chat.");
  }
}

function renderConversation(messages) {
  if (!messages?.length) {
    state.lastAt = 0;
    return showIntro();
  }
  clearThread();
  const frag = document.createDocumentFragment();
  for (const m of messages) {
    const blocks = m.role === 'assistant' && textsMode() ? splitBlocks(m.content || '') : [];
    if (blocks.length > 1) {
      // a saved reply with several paragraphs shows as the separate texts it arrived as; what came with it goes under the last one
      blocks.forEach((block, i) => {
        const last = i === blocks.length - 1;
        addTurn(makeTurn('her', block, last
          ? { photo: m.photo, image: m.image, gif: m.gif, video: m.video, links: m.links, proactive: m.proactive }
          : { proactive: m.proactive }), m.at || Date.now(), frag);
      });
      continue;
    }
    addTurn(makeTurn(m.role === 'user' ? 'them' : 'her', m.content, {
      photo: m.photo,
      image: m.image,
      gif: m.gif,
      video: m.video,
      images: m.images,
      links: m.links,
      proactive: m.proactive
    }), m.at || Date.now(), frag);
  }
  el.thread.appendChild(frag);
  state.lastAt = messages[messages.length - 1].at || 0;
  scroll(true);
}

/* ============================================================
   She speaks first
   ============================================================ */

/* Opening the app: hello if it is a blank chat or you have been away a while (a new conversation
   if it has been many hours, so the old one stays tidy). */
async function maybeGreet() {
  if (state.busy || !state.online) return;
  const last = lastTurn();
  if (!last) return respond({ kind: 'greet' });
  if (last.classList.contains('them')) return; // she owes you a reply, not a hello

  const gap = Date.now() - state.lastAt;
  if (gap > 6 * HOUR) {
    startNew({ greet: false, intro: false }); // her hello is coming: no suggestions flashing up first
    return respond({ kind: 'greet' });
  }
  if (gap > 45 * MINUTE && last.dataset.proactive !== 'greet') return respond({ kind: 'greet' });
  scheduleNudge();
}

/* If you go quiet after her message she may say something once, a few minutes later. */
function nudgeDelay() {
  const override = Number(localStorage.getItem('rosia.nudgeMs'));
  if (override > 0) return override;
  return 5 * MINUTE + Math.random() * 2 * MINUTE;
}

function scheduleNudge() {
  cancelNudge();
  if (localStorage.getItem('rosia.nudge') === '0') return; // switched off in Settings
  const last = lastTurn();
  if (!last || !last.classList.contains('her')) return;
  if (last.dataset.proactive === 'nudge') return; // one per quiet spell
  if (!el.thread.querySelector('.turn.them')) return; // greeting only: nothing to follow up
  state.nudgeTimer = setTimeout(nudge, nudgeDelay());
}

function cancelNudge() {
  clearTimeout(state.nudgeTimer);
  state.nudgeTimer = 0;
}

function nudge() {
  state.nudgeTimer = 0;
  if (state.busy || !state.online || el.input.value.trim()) return;
  const last = lastTurn();
  if (!last || !last.classList.contains('her')) return;
  respond({ kind: 'nudge' });
}

/* ============================================================
   Rendering a reply (the Markdown itself lives in markdown.js)
   ============================================================ */

/* Blocks: a reply is split at blank lines (outside code fences) and each block gets its own node.
   While streaming only the last, still-growing block is rewritten; finished blocks are left alone,
   and each new block fades in once, like another text arriving. */
function renderInto(body, raw, streaming) {
  const blocks = splitBlocks(raw);
  const nodes = [...body.children].filter((n) => n.classList.contains('blk'));

  blocks.forEach((src, i) => {
    let node = nodes[i];
    if (!node) {
      node = document.createElement('div');
      node.className = streaming ? 'blk fresh' : 'blk';
      body.appendChild(node);
    }
    if (node._src !== src) {
      node._src = src;
      node.innerHTML = format(src);
    }
  });
  body.dataset.raw = raw;
  nodes.slice(blocks.length).forEach((n) => n.remove());

  body.querySelector('.blk.open')?.classList.remove('open');
  if (streaming) body.lastElementChild?.classList.add('open');
}


/* ============================================================
   Copy
   ============================================================ */

async function copyText(text, button) {
  if (!text) return;

  let ok = false;
  if (navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      ok = true;
    } catch {
      ok = false;
    }
  }

  if (!ok) {
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.top = '-9999px';
      document.body.appendChild(ta);
      ta.select();
      ta.setSelectionRange(0, text.length);
      ok = document.execCommand('copy');
      ta.remove();
    } catch {
      ok = false;
    }
  }

  if (!ok) {
    flash(button, 'Press Ctrl+C', true);
    return;
  }
  flash(button, 'Copied', false);
}

function flash(button, label, isError) {
  const done = button.querySelector('.copy-done');
  if (!done) return;
  done.textContent = label;
  done.style.color = isError ? '#ff8fa3' : '';
  button.classList.add('copied');
  clearTimeout(button._timer);
  button._timer = setTimeout(() => {
    button.classList.remove('copied');
    done.style.color = '';
  }, 1400);
}

/* ============================================================
   Restore
   ============================================================ */

// A blank chat is left empty here: the start-up decides between her hello and the suggestions (see init), so neither flashes.
async function restore() {
  if (!state.sessionId) return;
  try {
    const res = await fetch(`/api/conversations/${encodeURIComponent(state.sessionId)}`);
    if (!res.ok) return;
    const data = await res.json();
    if (!data.messages?.length) {
      state.sessionId = null;
      store.session = null;
      return;
    }
    renderConversation(data.messages);
  } catch {
    /* offline: init shows the suggestions */
  }
}

/* ============================================================
   Avatar
   ============================================================ */


/* The avatar is a set of pre-made static expression images (see scripts/build-avatar.py). Nothing
   is drawn: each one is a full picture of her, and the rig crossfades between them.

   What each mood does:
     hold    the face while she is talking
     end     a short gesture when the reply finishes (for endMs), then she settles back to neutral
     linger  how long `hold` stays after the reply when there is no end gesture
     sparks  a few floating sparks at the end */
const EXPRESSIONS = [
  'neutral', 'happy', 'laughing', 'winking', 'love', 'thinking',
  'worried', 'sleepy', 'surprised', 'smitten', 'aroused', 'ecstatic'
];

const MOODS = {
  // neutral is the face for when her mood drops (flat, serious, tired); happy is her resting face
  neutral: { hold: 'neutral', linger: 4500 },
  happy: { hold: 'happy' }, // only used when a reply comes back with no mood tag
  flirty: { hold: 'happy', end: 'winking', endMs: 1100, sparks: 5 },
  teasing: { hold: 'happy', end: 'winking', endMs: 900 },
  amused: { hold: 'laughing', end: 'happy', endMs: 1500 },
  curious: { hold: 'thinking' },
  warm: { hold: 'happy', end: 'love', endMs: 2200, sparks: 2 },
  surprised: { hold: 'surprised' },
  worried: { hold: 'worried' },
  smitten: { hold: 'smitten', linger: 6000, sparks: 3 },
  aroused: { hold: 'aroused', linger: 7000 },
  ecstatic: { hold: 'ecstatic', linger: 7000 }
};

const SLEEP_AFTER_MS = 150_000;

class Avatar {
  constructor(root) {
    this.root = root;
    this.layers = new Map();   // expression name -> <img>
    this.current = '';
    this.z = 0;
    this.state = 'idle';
    this.mood = null;
    this.ready = false;
    this.restTimer = 0;
    this.hideTimer = 0;
    this.sleepTimer = 0;
    this.posing = null; // 'photo-<pose>' while one of her photos is showing in place of her face
    this.poseTimer = 0;
  }

  async load() {
    const rig = document.createElement('div');
    rig.className = 'rig';
    this.rig = rig;

    for (const name of EXPRESSIONS) {
      const img = new Image();
      img.className = 'layer';
      img.alt = '';
      img.decoding = 'async';
      img.draggable = false;
      if (name === 'happy') {
        img.fetchPriority = 'high';
        img.src = `${AVATAR_BASE}/${name}.webp`;
      } else {
        img.fetchPriority = 'low';
      }
      this.layers.set(name, img);
      rig.appendChild(img);
    }

    // show her as soon as the happy face is in; the other eleven (about 2.7 MB) are fetched when the
    // browser has nothing better to do, so they never compete with the page or the first reply
    await whenLoaded(this.layers.get('happy'));
    const idle = window.requestIdleCallback || ((fn) => setTimeout(fn, 400));
    idle(() => this.loadAll(), { timeout: 3000 });
    this.root.replaceChildren(rig);
    this.ready = true;
    this.show('happy');
    this.root.classList.add('idle');
    this.touch();
  }

  loadAll() {
    for (const [name, img] of this.layers) if (!img.src) img.src = `${AVATAR_BASE}/${name}.webp`;
  }

  /** Crossfade to an expression: the new one fades in on top, then the old ones are dropped. */
  show(name) {
    if (!this.ready || this.current === name) return;
    if (this.posing && name !== this.posing) return; // a photo stays up until the next thing they say
    const next = this.layers.get(name);
    if (!next) return;
    if (!next.src) next.src = `${AVATAR_BASE}/${name}.webp`; // needed before the idle load got to it
    next.style.zIndex = String(++this.z);
    next.classList.add('on');
    this.current = name;
    clearTimeout(this.hideTimer);
    this.hideTimer = setTimeout(() => {
      for (const [n, img] of this.layers) if (n !== this.current) img.classList.remove('on');
    }, 380);
  }

  hold() {
    return MOODS[this.mood]?.hold || 'happy';
  }

  /** One of her photos (bikini, front, back, feet, kneeling, gymwear, swimsuit, swimsuit-back) shown big in the avatar area, in place of her face. */
  showPose(pose, holdMs = 120_000) {
    if (!this.ready || !PHOTO_POSES.includes(pose)) return;
    const key = `photo-${pose}`;
    if (!this.layers.has(key)) {
      const img = new Image();
      img.className = 'layer pose';
      img.alt = '';
      img.decoding = 'async';
      img.draggable = false;
      img.src = `${AVATAR_BASE}/${key}.webp`;
      this.rig.appendChild(img);
      this.layers.set(key, img);
    }
    this.posing = key;
    this.root.classList.add('posing');
    this.root.closest('.stage')?.classList.add('posing');
    this.root.setAttribute('role', 'button');
    this.root.setAttribute('aria-label', "Rosia's photo. Open it larger");
    this.show(key);
    clearTimeout(this.poseTimer);
    this.poseTimer = setTimeout(() => this.clearPose(), holdMs);
  }

  /** Back to her face. */
  clearPose() {
    if (!this.posing) return;
    clearTimeout(this.poseTimer);
    this.posing = null;
    this.root.classList.remove('posing');
    this.root.closest('.stage')?.classList.remove('posing');
    this.root.setAttribute('role', 'img');
    this.root.setAttribute('aria-label', 'Rosia');
    this.show('happy');
  }

  setState(next) {
    if (this.state === next) return;
    this.state = next;
    this.root.classList.toggle('talking', next === 'talking');
    this.root.classList.toggle('idle', next !== 'talking');
    clearTimeout(this.restTimer);
    this.touch();
    if (next === 'thinking') this.show('thinking');
    else if (next === 'talking') this.show(this.hold());
    else this.restTimer = setTimeout(() => this.rest(), 1200);
  }

  setMood(mood) {
    this.mood = MOODS[mood] ? mood : null;
    if (this.state === 'talking' || this.state === 'thinking') this.show(this.hold());
  }

  /** The reply is done: play the mood's closing gesture, hold the face a moment, then settle. */
  finish(mood) {
    const cfg = MOODS[mood] || { hold: 'happy' };
    clearTimeout(this.restTimer);
    this.touch();
    if (cfg.end) {
      this.show(cfg.end);
      this.restTimer = setTimeout(() => this.rest(), cfg.endMs || 1200);
    } else {
      this.show(cfg.hold);
      this.restTimer = setTimeout(() => this.rest(), cfg.linger || 3500);
    }
  }

  /** Brief expression that isn't tied to a reply, e.g. worried when something fails. */
  flash(name, ms = 3000) {
    clearTimeout(this.restTimer);
    this.show(name);
    this.restTimer = setTimeout(() => this.rest(), ms);
  }

  rest() {
    this.mood = null;
    this.show('happy');
  }

  /** Any activity wakes her; a long silence sends her to sleep. */
  touch() {
    clearTimeout(this.sleepTimer);
    if (this.current === 'sleepy') this.show('happy');
    this.sleepTimer = setTimeout(() => {
      if (this.state === 'idle') this.show('sleepy');
    }, SLEEP_AFTER_MS);
  }
}

/* load/error events fire even in a background tab, unlike img.decode() */
function whenLoaded(img) {
  return new Promise((resolve, reject) => {
    if (img.complete) return img.naturalWidth ? resolve() : reject(new Error(`missing image: ${img.src}`));
    img.addEventListener('load', resolve, { once: true });
    img.addEventListener('error', () => reject(new Error(`missing image: ${img.src}`)), { once: true });
  });
}

async function mountAvatar() {
  avatar = new Avatar(el.avatar);
  try {
    await avatar.load();
  } catch {
    avatar.ready = false;
    el.avatar.replaceChildren();
  }
}

/* ============================================================
   Photos she sends: shown in her portrait (see Avatar.showPose), and enlarged on click
   ============================================================ */


function openLightbox(src) {
  const box = document.createElement('div');
  box.className = 'lightbox';
  box.setAttribute('role', 'dialog');
  box.setAttribute('aria-label', 'Photo');
  const img = new Image();
  img.src = src;
  img.alt = 'Photo from Rosia';
  box.appendChild(img);
  const close = () => {
    box.remove();
    document.removeEventListener('keydown', onKey, true);
  };
  const onKey = (e) => {
    if (e.key === 'Escape') {
      e.stopPropagation();
      close();
    }
  };
  box.addEventListener('click', close);
  document.addEventListener('keydown', onKey, true);
  document.body.appendChild(box);
}

/* ============================================================
   Reactions
   ============================================================ */

/* The model's mood tag decides the closing expression; keyword guesses are only a fallback for
   replies that came back without one. */
function react(text, mood) {
  if (!avatar) return;
  let m = mood;
  if (!MOODS[m]) {
    if (/\b(kiss|cute|date|beautiful|gorgeous|flirt|single)\b/i.test(text) && Math.random() < 0.7) m = 'flirty';
    else if (/\?/.test(text) && Math.random() < 0.4) m = 'curious';
    else m = 'happy';
  }
  avatar.finish(m);
  const n = MOODS[m].sparks;
  if (n) sparks(n);
}

function sparks(count) {
  const frag = document.createDocumentFragment();
  for (let i = 0; i < count; i += 1) {
    const dot = document.createElement('span');
    dot.className = 'spark';
    dot.style.left = `${30 + Math.random() * 40}%`;
    dot.style.top = `${40 + Math.random() * 25}%`;
    dot.style.setProperty('--dx', `${-30 + Math.random() * 60}px`);
    dot.style.animationDelay = `${i * 90}ms`;
    frag.appendChild(dot);
    setTimeout(() => dot.remove(), 1900 + i * 90);
  }
  el.sparks.appendChild(frag);
}

init();
