/* "The two of you": the short history in the Memory view. */

const when = (ts) => new Date(ts).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });

export function renderHistory(host, items) {
  const list = host.querySelector('#historyList');
  list.replaceChildren();
  for (const item of Array.isArray(items) ? items : []) {
    const li = document.createElement('li');
    const date = document.createElement('time');
    date.dateTime = new Date(item.at).toISOString().slice(0, 10);
    date.textContent = when(item.at);
    const text = document.createElement('span');
    text.textContent = item.text;
    li.append(date, text);
    list.appendChild(li);
  }
  host.hidden = !list.children.length;
}

export async function loadHistory(host) {
  try {
    const res = await fetch('/api/history');
    renderHistory(host, res.ok ? (await res.json()).history : []);
  } catch {
    renderHistory(host, []);
  }
}
