/*
 * The picture she is drawing: a shimmering placeholder in the shape of the picture (soft drifting colour,
 * a sweep of light, a status line), which turns into the picture itself, coming into focus, when it is ready.
 * It follows the job by asking the server every moment or two, so it also works after a reload, and on
 * another device.
 */

const LABELS = {
  queued: ['Creating image', 'Getting ready'],
  waiting: ['Creating image', 'Finishing the reply first'],
  starting: ['Creating image', 'Waking up the image model'],
  drawing: ['Creating image', 'Drawing'],
  finishing: ['Creating image', 'Adding the finishing touches']
};

const FINAL = new Set(['done', 'failed']);

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
}

/**
 * info: { job, state, ratio, media?, error?, step?, steps? }
 * hooks: { open(src), changed(), done(src) }
 */
export function genFigure(info, hooks = {}) {
  const fig = el('figure', 'gen');
  fig.dataset.job = info.job;
  fig.style.setProperty('--ratio', info.ratio || '3 / 4');
  fig.setAttribute('role', 'group');
  fig.setAttribute('aria-label', 'A picture she is drawing');

  const field = el('div', 'gen-field');
  field.setAttribute('aria-hidden', 'true');
  for (let i = 0; i < 4; i += 1) field.appendChild(el('span', `gen-blob b${i + 1}`));
  field.appendChild(el('span', 'gen-sheen'));
  field.appendChild(el('span', 'gen-grain'));

  const label = el('figcaption', 'gen-label');
  const title = el('span', 'gen-title');
  const sub = el('span', 'gen-sub');
  label.append(title, sub);
  label.setAttribute('role', 'status');

  const bar = el('span', 'gen-bar');
  bar.appendChild(el('i'));
  fig.append(field, label, bar);

  let timer = 0;
  let finished = false;

  function show(next) {
    if (finished) return;
    if (next.ratio) fig.style.setProperty('--ratio', next.ratio);

    if (next.state === 'done' && next.media) {
      finished = true;
      clearTimeout(timer);
      reveal(next.media);
      return;
    }
    if (next.state === 'failed') {
      finished = true;
      clearTimeout(timer);
      fig.classList.add('failed');
      fig.classList.remove('gen-active');
      field.remove();
      bar.remove();
      title.textContent = "Couldn't draw that one";
      sub.textContent = next.error || 'Something went wrong.';
      hooks.changed?.();
      return;
    }

    fig.classList.add('gen-active');
    const [t, s] = LABELS[next.state] || LABELS.queued;
    title.textContent = t;
    let detail = s;
    if (next.state === 'drawing' && next.steps && next.step > 0) detail = `Drawing, step ${Math.min(next.step || 0, next.steps)} of ${next.steps}`;
    if (next.state === 'queued' && next.ahead) detail = `${next.ahead} ahead of this one`;
    sub.textContent = detail;
    const fraction = next.state === 'drawing' && next.steps ? (next.step || 0) / next.steps
      : next.state === 'finishing' ? 1
      : next.state === 'starting' ? 0.04 : 0;
    bar.firstChild.style.transform = `scaleX(${Math.max(0.02, Math.min(1, fraction))})`;
  }

  function reveal(media) {
    const src = `/media/${media}`;
    const img = new Image();
    img.alt = 'A picture she drew for you';
    img.decoding = 'async';
    img.className = 'gen-img';
    const button = el('button', 'gen-open');
    button.type = 'button';
    button.setAttribute('aria-label', 'View picture larger');
    button.appendChild(img);
    button.addEventListener('click', () => hooks.open?.(src));
    const ready = () => {
      fig.insertBefore(button, fig.firstChild);
      // one frame with the picture blurred, then let it come into focus
      requestAnimationFrame(() => requestAnimationFrame(() => fig.classList.add('revealed')));
      setTimeout(() => {
        fig.classList.remove('gen-active');
        field.remove();
        label.remove();
        bar.remove();
        hooks.changed?.();
      }, 1400);
      hooks.done?.(src);
      hooks.changed?.();
    };
    img.addEventListener('load', ready, { once: true });
    img.addEventListener('error', () => show({ state: 'failed', error: 'The picture could not be loaded.' }), { once: true });
    img.src = src;
  }

  async function poll() {
    try {
      const res = await fetch(`/api/images/${info.job}`, { cache: 'no-store' });
      if (res.status === 404) {
        show({ state: 'failed', error: 'That picture was interrupted, so it never finished.' });
        return;
      }
      if (res.ok) show(await res.json());
    } catch {
      /* the server may be restarting; keep trying */
    }
    // if the picture has left the page (another chat was opened) there is nothing to update; reopening the chat makes a fresh one
    if (!finished && fig.isConnected) timer = setTimeout(poll, 1500);
  }

  show(info);
  if (!FINAL.has(info.state)) timer = setTimeout(poll, 800);
  return fig;
}
