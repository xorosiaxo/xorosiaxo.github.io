/* The edge between her portrait and the chat can be dragged. The width is kept for next time. */

const KEY = 'rosia.panelW';
const MIN = 240;

export function clampPanel(px, windowWidth) {
  const n = Number.isFinite(px) ? px : MIN;
  return Math.round(Math.min(Math.max(n, MIN), windowWidth * 0.5));
}

export function bindResizer({ handle, app, storage = localStorage, win = window }) {
  const apply = (px) => {
    const w = clampPanel(px, win.innerWidth);
    app.style.setProperty('--panel-w', `${w}px`);
    handle.setAttribute('aria-valuenow', String(w));
    return w;
  };
  const save = (w) => { try { storage.setItem(KEY, String(w)); } catch { /* private window: not kept */ } };
  const current = () => app.querySelector('.stage').getBoundingClientRect().width;

  let saved = NaN;
  try { saved = Number(storage.getItem(KEY)); } catch { /* no storage */ }
  if (saved > 0) apply(saved);

  handle.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    handle.setPointerCapture(e.pointerId);
    handle.classList.add('dragging');
    const move = (ev) => apply(ev.clientX);
    const up = () => {
      handle.classList.remove('dragging');
      handle.removeEventListener('pointermove', move);
      save(clampPanel(current(), win.innerWidth));
    };
    handle.addEventListener('pointermove', move);
    handle.addEventListener('pointerup', up, { once: true });
    handle.addEventListener('pointercancel', up, { once: true });
  });

  handle.addEventListener('keydown', (e) => {
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    e.preventDefault();
    save(apply(current() + (e.key === 'ArrowRight' ? 16 : -16)));
  });

  // double-click puts it back to the size it started at
  handle.addEventListener('dblclick', () => {
    app.style.removeProperty('--panel-w');
    handle.removeAttribute('aria-valuenow');
    try { storage.removeItem(KEY); } catch { /* nothing to remove */ }
  });

  win.addEventListener('resize', () => { if (app.style.getPropertyValue('--panel-w')) apply(current()); });
}
