/*
 * Turning her text into something that can be said aloud. Shared by the page (voice in the browser) and the
 * server (voice on the server), so both say exactly the same thing.
 */

const LABELS = { af: 'US', bf: 'UK' };

/** Her voices: the female English ones, with readable names: "Heart (US)". */
export function describeVoices(ids) {
  return ids
    .filter((id) => /^(af|bf)_/.test(id))
    .map((id) => {
      const [prefix, name] = id.split('_');
      return { id, label: `${name[0].toUpperCase()}${name.slice(1)} (${LABELS[prefix]})` };
    });
}

/**
 * The text as it should be spoken: no mood tag, no markdown, no *stage directions*, no emoji, no links read out.
 * Returns '' if nothing speakable is left.
 */
export function speakable(text) {
  let t = String(text ?? '');
  t = t.replace(/^\s*\[[a-z]+\]\s*/i, '');
  t = t.replace(/```[\s\S]*?```/g, ' ');
  t = t.replace(/`([^`]*)`/g, '$1');
  t = t.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '$1');
  t = t.replace(/https?:\/\/\S+/g, 'a link');
  t = t.replace(/\*[^*\n]{1,80}\*(?!\*)/g, (m) => (/^\*\*/.test(m) ? m : ' ')); // *smiles* is an action, not speech
  t = t.replace(/[*_~]+/g, '').replace(/[#>|]/g, ' ');
  t = t.replace(/^\s*[-+]\s+/gm, '');
  t = t.replace(/\p{Extended_Pictographic}|‍|️/gu, ' ');
  t = t.replace(/\s+/g, ' ').replace(/\s+([.,!?;:])/g, '$1').trim();
  return t;
}

/** Splits into pieces that are comfortable to say in one go, at sentence ends where possible. */
export function chunks(text, max = 220) {
  const sentences = String(text).match(/[^.!?…]+(?:[.!?…]+["')\]]*|$)\s*/g) || [];
  const out = [];
  let cur = '';
  const push = () => {
    if (cur.trim()) out.push(cur.trim());
    cur = '';
  };
  for (const raw of sentences) {
    let s = raw;
    while (s.length > max) {
      const cut = s.lastIndexOf(',', max) > 60 ? s.lastIndexOf(',', max) + 1 : s.lastIndexOf(' ', max) > 0 ? s.lastIndexOf(' ', max) : max;
      if (cur) push();
      out.push(s.slice(0, cut).trim());
      s = s.slice(cut);
    }
    if (cur && (cur + s).length > max) push();
    cur += s;
  }
  push();
  return out.filter(Boolean);
}
