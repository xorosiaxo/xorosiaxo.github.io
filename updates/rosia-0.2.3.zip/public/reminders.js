/*
 * Reminders, on the page: the list under "Reminders" (add, change, remove by hand), and the strip that comes up at the
 * top of the chat when one is due, with "Done" and "In 10 minutes".
 *
 * The app keeps the list for this person (server/reminders/store.js); she adds to it from the chat. This page keeps
 * its own watch on the clock, so a reminder comes up on time even if she cannot talk just then; when one comes due it
 * is shown here, a notification goes up if the window is in the background, and she is asked to say it in the chat.
 */

const MIN = 60_000;
const DAY = 86_400_000;

/** A moment as the box for picking a date and time wants it, in this computer's own time: "2026-11-16T17:05". */
export function inputValue(ms) {
  const d = new Date(ms);
  const two = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())}T${two(d.getHours())}:${two(d.getMinutes())}`;
}

/** When a reminder is due, in a few words: "in 10 min", "today 5:00 pm", "tomorrow 9:00 am", "Fri 20 Nov, 3:00 pm"; "now" once it is. */
export function whenText(at, now = Date.now(), locale = undefined) {
  if (at <= now) {
    const late = now - at;
    if (late < 2 * MIN) return 'now';
    if (late < 60 * MIN) return `${Math.round(late / MIN)} min ago`;
    if (late < DAY) return `${Math.round(late / (60 * MIN))} h ago`;
    return `${Math.round(late / DAY)} d ago`;
  }
  if (at - now < 60 * MIN) return `in ${Math.max(1, Math.round((at - now) / MIN))} min`;
  const d = new Date(at);
  const n = new Date(now);
  const time = d.toLocaleTimeString(locale, { hour: 'numeric', minute: '2-digit' });
  const days = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()) - new Date(n.getFullYear(), n.getMonth(), n.getDate())) / DAY);
  if (days === 0) return `today ${time}`;
  if (days === 1) return `tomorrow ${time}`;
  return `${d.toLocaleDateString(locale, { weekday: 'short', day: 'numeric', month: 'short', ...(d.getFullYear() !== n.getFullYear() ? { year: 'numeric' } : {}) })}, ${time}`;
}

/** The reminders whose time has come and which have not been marked done, soonest first. */
export function dueNow(list, now = Date.now()) {
  return (Array.isArray(list) ? list : []).filter((r) => r && !r.done && r.at <= now).sort((a, b) => a.at - b.at);
}

/** The ones she has not said yet and this page has not asked her to say: each reminder is announced once per time it comes due. */
export function toAnnounce(list, announced, now = Date.now()) {
  return dueNow(list, now).filter((r) => !r.told && !announced.has(`${r.id}:${r.at}`));
}

const REPEAT_LABEL = { '': '', daily: 'every day', weekly: 'every week' };
const BELL = '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 11V7.2a4 4 0 0 1 8 0V11l1.2 1.4H2.8L4 11Z"/><path d="M6.6 14a1.5 1.5 0 0 0 2.8 0"/></svg>';

/**
 * @param view      the "Reminders" view (an empty section: this fills it)
 * @param bar       the strip above the chat for reminders that are due
 * @param dot       the mark on the bell in the header, shown while something is due
 * @param announce  called with a reminder that has just come due and she has not said yet; resolves when she has (or could not)
 */
export function createReminders({ view, bar, dot, doc = document, win = window, fetchFn = (...a) => fetch(...a), toast = () => {}, announce = async () => {} }) {
  let list = [];
  let started = false;
  const announced = new Set();
  let saying = Promise.resolve(); // one at a time, in the order they came due
  const el = (tag, cls, text) => {
    const node = doc.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  const button = (label, cls, onClick) => {
    const b = el('button', cls, label);
    b.type = 'button';
    b.addEventListener('click', onClick);
    return b;
  };

  /* ---------- the view: add one by hand, and the list ---------- */

  view.replaceChildren();
  const inner = el('div', 'view-inner');
  inner.appendChild(el('div', 'mem-intro', 'Things she will remind you of. Ask her in the chat ("remind me at 5 to call mum", "wake me at 7") or add one here. When the time comes she tells you in the chat, and it shows at the top of this window until you mark it done.'));

  const form = el('form', 'rem-add');
  form.autocomplete = 'off';
  const what = el('input');
  Object.assign(what, { type: 'text', maxLength: 160, placeholder: 'What should she remind you of?', required: true });
  what.setAttribute('aria-label', 'What to be reminded of');
  const when = el('input', 'rem-when');
  Object.assign(when, { type: 'datetime-local', required: true });
  when.setAttribute('aria-label', 'When');
  const repeat = el('select', 'rem-repeat');
  repeat.setAttribute('aria-label', 'How often');
  for (const [value, label] of [['', 'Once'], ['daily', 'Every day'], ['weekly', 'Every week']]) {
    const o = el('option', '', label);
    o.value = value;
    repeat.appendChild(o);
  }
  const add = el('button', 'pill-btn', 'Add');
  add.type = 'submit';
  const row = el('div', 'rem-row');
  row.append(when, repeat, add);
  // a few common times, so nobody has to work a date picker for "in ten minutes"
  const quick = el('div', 'rem-quick');
  const morning = () => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    d.setHours(9, 0, 0, 0);
    return d.getTime();
  };
  for (const [label, at] of [['In 10 minutes', () => Date.now() + 10 * MIN], ['In an hour', () => Date.now() + 60 * MIN], ['Tomorrow morning', morning]]) {
    quick.appendChild(button(label, 'rem-chip', () => {
      when.value = inputValue(at());
      (what.value.trim() ? add : what).focus();
    }));
  }
  form.append(what, row, quick);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const at = new Date(when.value).getTime();
    if (!what.value.trim() || !Number.isFinite(at)) return;
    if (at <= Date.now()) return toast('That time has already gone. Pick one that is still to come.');
    askToNotify(); // they are setting one by hand: the moment to ask whether it may show outside the window too
    if (await change({ action: 'add', text: what.value, at, repeat: repeat.value, tz: Intl.DateTimeFormat().resolvedOptions().timeZone })) {
      what.value = '';
      when.value = '';
      repeat.value = '';
    }
  });

  const notify = el('div', 'rem-notify');
  const coming = el('div', 'rem-list');
  const earlierTitle = el('div', 'mem-label', 'Earlier');
  const earlier = el('div', 'rem-list rem-earlier');
  inner.append(form, notify, coming, earlierTitle, earlier);
  view.appendChild(inner);

  /** One line of the list: what, when, and what can be done with it. */
  function item(r, now) {
    const line = el('div', `rem-item${r.due ? ' due' : ''}${r.done ? ' done' : ''}`);
    const text = el('div', 'rem-text');
    text.appendChild(el('div', 'rem-what', r.text));
    const about = [r.done ? 'done' : whenText(r.at, now), REPEAT_LABEL[r.repeat], r.by === 'chat' ? 'set in the chat' : ''].filter(Boolean).join(' · ');
    text.appendChild(el('div', 'rem-about', about));
    const acts = el('div', 'rem-acts');
    if (r.due) {
      acts.appendChild(button('Done', 'pill-btn', () => change({ action: 'done', id: r.id })));
      acts.appendChild(button('In 10 minutes', 'pill-btn', () => change({ action: 'snooze', id: r.id, minutes: 10 })));
    } else if (!r.done) {
      acts.appendChild(button('Change', 'pill-btn', () => edit(line, r)));
    }
    const remove = button('Remove', 'pill-btn danger', () => change({ action: 'remove', id: r.id }));
    remove.setAttribute('aria-label', `Remove the reminder: ${r.text}`);
    acts.appendChild(remove);
    line.append(text, acts);
    return line;
  }

  /** "Change": the line becomes the same three boxes as the form above, filled in. */
  function edit(line, r) {
    const f = el('form', 'rem-add rem-edit');
    const t = el('input');
    Object.assign(t, { type: 'text', maxLength: 160, value: r.text, required: true });
    t.setAttribute('aria-label', 'What to be reminded of');
    const w = el('input', 'rem-when');
    Object.assign(w, { type: 'datetime-local', value: inputValue(r.at), required: true });
    w.setAttribute('aria-label', 'When');
    const rp = repeat.cloneNode(true);
    rp.value = r.repeat || '';
    const save = el('button', 'pill-btn', 'Save');
    save.type = 'submit';
    const rw = el('div', 'rem-row');
    rw.append(w, rp, save, button('Cancel', 'pill-btn', () => render()));
    f.append(t, rw);
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const at = new Date(w.value).getTime();
      if (!Number.isFinite(at) || at <= Date.now()) return toast('That time has already gone. Pick one that is still to come.');
      change({ action: 'edit', id: r.id, text: t.value, at, repeat: rp.value });
    });
    line.replaceWith(f);
    t.focus();
  }

  function renderNotify() {
    notify.replaceChildren();
    const N = win.Notification;
    if (!N) return;
    if (N.permission === 'default') {
      notify.append(el('span', '', 'Reminders can also pop up when this window is in the background. '), button('Turn that on', 'rem-link', askToNotify));
    } else if (N.permission === 'denied') {
      notify.textContent = 'Notifications are blocked for this page in your browser, so reminders only show in this window.';
    }
  }

  function render(now = Date.now()) {
    const waiting = list.filter((r) => !r.done).map((r) => ({ ...r, due: r.at <= now }));
    const done = list.filter((r) => r.done);
    coming.replaceChildren(...(waiting.length ? waiting.map((r) => item(r, now)) : [el('div', 'rem-empty', 'Nothing to remind you of yet.')]));
    earlier.replaceChildren(...done.map((r) => item(r, now)));
    earlierTitle.hidden = !done.length;
    renderNotify();
    renderBar(now);
  }

  /* ---------- the strip above the chat ---------- */

  let barKey = '';
  function renderBar(now = Date.now()) {
    const due = dueNow(list, now);
    if (dot) dot.hidden = !due.length;
    const key = due.map((r) => `${r.id}:${r.at}:${r.text}`).join('|');
    if (key === barKey) return;
    barKey = key;
    bar.hidden = !due.length;
    bar.replaceChildren(...due.map((r) => {
      const line = el('div', 'rem-due');
      const icon = el('span', 'rem-bell');
      icon.innerHTML = BELL;
      const text = el('div', 'rem-due-text');
      text.append(el('span', 'rem-due-label', 'Reminder'), el('span', 'rem-due-what', r.text));
      const acts = el('div', 'rem-due-acts');
      acts.append(
        button('Done', 'pill-btn solid', () => change({ action: 'done', id: r.id })),
        button('In 10 minutes', 'pill-btn', () => change({ action: 'snooze', id: r.id, minutes: 10 }))
      );
      line.append(icon, text, acts);
      return line;
    }));
  }

  /* ---------- telling them: a notification, a sound, and her saying it ---------- */

  function askToNotify() {
    const N = win.Notification;
    if (!N || N.permission !== 'default') return;
    try {
      Promise.resolve(N.requestPermission()).then(renderNotify, () => {});
    } catch {
      /* an old browser that wants a callback: it simply stays off */
    }
  }

  /** Two soft notes. A browser that will not make sound before the page has been touched just stays quiet. */
  function chime() {
    try {
      const Ctx = win.AudioContext || win.webkitAudioContext;
      if (!Ctx) return;
      const ctx = new Ctx();
      [[880, 0], [1174.7, 0.16]].forEach(([freq, at]) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.0001, ctx.currentTime + at);
        gain.gain.exponentialRampToValueAtTime(0.16, ctx.currentTime + at + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + at + 0.5);
        osc.connect(gain).connect(ctx.destination);
        osc.start(ctx.currentTime + at);
        osc.stop(ctx.currentTime + at + 0.55);
      });
      setTimeout(() => ctx.close().catch(() => {}), 1500);
    } catch {
      /* no sound: the strip and her message still say it */
    }
  }

  function popUp(r) {
    const N = win.Notification;
    if (!N || N.permission !== 'granted' || !doc.hidden) return; // in front of them already: the strip is enough
    try {
      const n = new N('Rosia: reminder', { body: r.text, tag: `rosia-reminder-${r.id}`, icon: '/favicon.svg' });
      n.onclick = () => {
        win.focus();
        n.close();
      };
    } catch {
      /* some phones only allow notifications from a service worker: the strip still shows it */
    }
  }

  /** Looks at the clock: anything that has just come due is shown, and she is asked to say it (once). */
  function tick(now = Date.now()) {
    renderBar(now);
    const fresh = toAnnounce(list, announced, now);
    if (!fresh.length) return;
    if (view.isConnected && !view.hidden) render(now);
    for (const r of fresh) {
      announced.add(`${r.id}:${r.at}`);
      chime();
      popUp(r);
      saying = saying.then(() => announce(r)).catch(() => {}).then(() => load());
    }
  }

  /* ---------- talking to the app ---------- */

  function set(next) {
    if (!Array.isArray(next)) return;
    list = next;
    render();
    if (started) tick();
  }

  async function load() {
    try {
      const res = await fetchFn('/api/reminders');
      if (res.ok) set((await res.json()).reminders);
    } catch {
      /* offline for a moment: what is already here keeps its times */
    }
  }

  /** One change by hand. True when it went through; either way the list is shown as the app now has it. */
  async function change(body) {
    try {
      const res = await fetchFn('/api/reminders', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
      const data = await res.json().catch(() => ({}));
      if (data.reminders) set(data.reminders);
      if (!res.ok) toast(data.error || 'That did not work. Try again.');
      return res.ok;
    } catch {
      toast('That did not work. Try again.');
      return false;
    }
  }

  /** Starts the watch on the clock. Called once the chat is on screen, so her hello comes before any reminder. */
  async function start() {
    await load();
    started = true;
    tick();
    setInterval(() => tick(), 5000);
    // another window, or her on another device, may have changed the list
    setInterval(() => { if (!doc.hidden) load(); }, 2 * MIN);
    doc.addEventListener('visibilitychange', () => { if (!doc.hidden) load(); });
  }

  return { start, load, set, show: () => { load(); what.focus(); } };
}
