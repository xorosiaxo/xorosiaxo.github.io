/*
 * A small, safe Markdown renderer for chat replies.
 *
 * Safety first: everything is HTML-escaped before any markup is added, so nothing she says (or a web
 * page she read) can inject HTML or script. Links must be http(s); images are not rendered; there is no
 * raw HTML pass-through.
 *
 * Supported: paragraphs (single line breaks kept), headings, bold, italic, strikethrough, inline and
 * fenced code (with a language label and a copy button; a fence still being typed is shown as it
 * grows), nested lists, blockquotes, tables, horizontal rules, links and bare links.
 */

export function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* ---------- blocks: a reply is split at blank lines (outside code fences) ---------- */

export function splitBlocks(raw) {
  const blocks = [];
  let cur = [];
  let fence = false;
  for (const line of String(raw).split('\n')) {
    if (/^\s*```/.test(line)) fence = !fence;
    if (!fence && !line.trim()) {
      if (cur.length) {
        blocks.push(cur.join('\n'));
        cur = [];
      }
      continue;
    }
    cur.push(line);
  }
  if (cur.length) blocks.push(cur.join('\n'));
  return blocks;
}

/* ---------- inline ---------- */

const MARK = '\u0000';

function inline(raw) {
  const stash = [];
  const keep = (html) => {
    stash.push(html);
    return `${MARK}${stash.length - 1}${MARK}`;
  };

  let t = escapeHtml(raw);
  // code first, so nothing inside it is touched
  t = t.replace(/`([^`\n]+)`/g, (_, code) => keep(`<code>${code}</code>`));
  // [text](https://...) before bare links, so the address is not linked twice
  t = t.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, (_, text, url) =>
    keep(`<a href="${url}" target="_blank" rel="noopener noreferrer">${text}</a>`)
  );
  t = t.replace(/(^|[\s(])(https?:\/\/[^\s<]+?)([.,!?;:)]*)(?=\s|$)/g, (_, pre, url, trail) =>
    `${pre}${keep(`<a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`)}${trail}`
  );

  t = t
    .replace(/\*\*([^*\n]+?)\*\*/g, '<strong>$1</strong>')
    .replace(/~~([^~\n]+?)~~/g, '<del>$1</del>')
    .replace(/(^|[^\w*])\*([^*\s][^*\n]*?)\*(?![\w*])/g, '$1<em>$2</em>')
    .replace(/(^|[^\w])_([^_\s][^_\n]*?)_(?!\w)/g, '$1<em>$2</em>');

  return t.replace(new RegExp(`${MARK}(\\d+)${MARK}`, 'g'), (_, i) => stash[Number(i)]);
}

/* ---------- block pieces ---------- */

function codeBlock(lang, lines) {
  const label = lang ? `<span class="code-lang">${escapeHtml(lang)}</span>` : '<span class="code-lang"></span>';
  const code = escapeHtml(lines.join('\n'));
  return `<div class="code"><div class="code-bar">${label}<button class="code-copy" type="button">Copy</button></div><pre><code>${code}</code></pre></div>`;
}

const LIST_ITEM = /^(\s*)([-*+]|\d{1,3}[.)])\s+(.*)$/;

/** Items are { depth, ordered, start, html }; nesting comes from indentation. */
function renderList(items) {
  let html = '';
  const stack = []; // open lists: { depth, tag }
  const closeTo = (depth) => {
    while (stack.length && stack.at(-1).depth > depth) {
      html += `</li></${stack.pop().tag}>`;
    }
  };
  for (const item of items) {
    const tag = item.ordered ? 'ol' : 'ul';
    if (!stack.length || item.depth > stack.at(-1).depth) {
      html += `<${tag}${item.ordered && item.start > 1 ? ` start="${item.start}"` : ''}><li>${item.html}`;
      stack.push({ depth: item.depth, tag });
    } else {
      closeTo(item.depth);
      if (stack.at(-1).tag !== tag) {
        html += `</li></${stack.pop().tag}><${tag}><li>${item.html}`;
        stack.push({ depth: item.depth, tag });
      } else {
        html += `</li><li>${item.html}`;
      }
    }
  }
  closeTo(-1);
  return html;
}

function splitRow(line) {
  return line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((c) => c.trim());
}

const TABLE_SEPARATOR = /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;

function renderTable(head, aligns, rows) {
  const cell = (tag, text, i) => `<${tag}${aligns[i] ? ` style="text-align:${aligns[i]}"` : ''}>${inline(text)}</${tag}>`;
  return (
    '<div class="table-wrap"><table><thead><tr>' +
    head.map((h, i) => cell('th', h, i)).join('') +
    '</tr></thead><tbody>' +
    rows.map((r) => `<tr>${head.map((_, i) => cell('td', r[i] ?? '', i)).join('')}</tr>`).join('') +
    '</tbody></table></div>'
  );
}

/** One block of Markdown to HTML. */
export function format(raw) {
  const lines = String(raw).split('\n');
  const out = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    // fenced code: still being typed (no closing fence yet) is shown as far as it has got
    const fence = /^\s*```\s*([\w+#.-]*)\s*$/.exec(line);
    if (fence) {
      const body = [];
      i += 1;
      while (i < lines.length && !/^\s*```\s*$/.test(lines[i])) {
        body.push(lines[i]);
        i += 1;
      }
      i += 1; // the closing fence
      out.push(codeBlock(fence[1], body));
      continue;
    }

    if (/^\s*(-{3,}|\*{3,}|_{3,})\s*$/.test(line)) {
      out.push('<hr>');
      i += 1;
      continue;
    }

    const heading = /^(#{1,6})\s+(.*?)\s*#*\s*$/.exec(line);
    if (heading) {
      const level = Math.min(5, heading[1].length + 2); // # is a modest h3 here: this is a chat, not a document
      out.push(`<h${level}>${inline(heading[2])}</h${level}>`);
      i += 1;
      continue;
    }

    if (/^\s*>/.test(line)) {
      const quoted = [];
      while (i < lines.length && /^\s*>/.test(lines[i])) {
        quoted.push(lines[i].replace(/^\s*>\s?/, ''));
        i += 1;
      }
      out.push(`<blockquote>${format(quoted.join('\n'))}</blockquote>`);
      continue;
    }

    if (line.includes('|') && i + 1 < lines.length && TABLE_SEPARATOR.test(lines[i + 1]) && lines[i + 1].includes('-')) {
      const head = splitRow(line);
      const aligns = splitRow(lines[i + 1]).map((c) => (/^:-+:$/.test(c) ? 'center' : /-:$/.test(c) ? 'right' : /^:-/.test(c) ? 'left' : ''));
      const rows = [];
      i += 2;
      while (i < lines.length && lines[i].includes('|') && lines[i].trim()) {
        rows.push(splitRow(lines[i]));
        i += 1;
      }
      out.push(renderTable(head, aligns, rows));
      continue;
    }

    if (LIST_ITEM.test(line)) {
      const items = [];
      while (i < lines.length) {
        const m = LIST_ITEM.exec(lines[i]);
        if (m) {
          items.push({
            depth: Math.floor(m[1].replace(/\t/g, '  ').length / 2),
            ordered: /\d/.test(m[2]),
            start: parseInt(m[2], 10) || 1,
            html: inline(m[3])
          });
          i += 1;
        } else if (/^\s{2,}\S/.test(lines[i]) && items.length) {
          items.at(-1).html += `<br>${inline(lines[i].trim())}`; // a wrapped line of the same item
          i += 1;
        } else {
          break;
        }
      }
      out.push(renderList(items));
      continue;
    }

    // a paragraph: consecutive plain lines, with the line breaks kept
    const para = [];
    while (i < lines.length && lines[i].trim() && !/^\s*(```|>|#{1,6}\s|-{3,}\s*$)/.test(lines[i]) && !LIST_ITEM.test(lines[i])) {
      para.push(inline(lines[i]));
      i += 1;
    }
    if (para.length) out.push(`<p>${para.join('<br>')}</p>`);
    else i += 1; // never loop on a line nothing recognised
  }

  return out.join('');
}
