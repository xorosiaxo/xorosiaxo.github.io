/*
 * Her voice in the page: a toggle for reading every reply aloud, a "listen" button on each message, a
 * voice and speed choice, and a level meter so the portrait can react to the sound.
 *
 * By default the voice is made on the visitor's own device: Kokoro runs in their browser (kokoro-worker.js),
 * so what is said never leaves it. If the server has a voice of its own it can be chosen instead.
 * A reply is read sentence by sentence with the next sentence prepared while the current one plays.
 */
import { chunks, speakable as cleanForSpeech } from '/speech-text.js';

const KEY = 'rosia.voice';

// Her voices: the female English ones Kokoro has, with readable names (the same ones the server lists)
const VOICE_IDS = [
  'af_heart', 'af_bella', 'af_nicole', 'af_sky', 'af_sarah', 'af_nova', 'af_jessica', 'af_kore', 'af_aoede', 'af_alloy', 'af_river',
  'bf_emma', 'bf_isabella', 'bf_alice', 'bf_lily'
];
const KIND = { af: 'US', bf: 'UK' };
const VOICES = VOICE_IDS.map((id) => {
  const [prefix, name] = id.split('_');
  return { id, label: `${name[0].toUpperCase()}${name.slice(1)} (${KIND[prefix]})` };
});

function load() {
  try {
    return JSON.parse(localStorage.getItem(KEY) || '{}');
  } catch {
    return {};
  }
}
function save(prefs) {
  try {
    localStorage.setItem(KEY, JSON.stringify(prefs));
  } catch {
    /* private window: the choice just does not stick */
  }
}

// how fast she speaks for each mood: a little slower when she is turned on, quicker when excited
const MOOD_SPEED = { aroused: 0.9, smitten: 0.94, warm: 0.97, worried: 0.98, ecstatic: 1.06, amused: 1.03, teasing: 1.02, surprised: 1.04 };

export function createVoice({ onLevel = () => {}, onSpeaking = () => {}, onError = () => {} } = {}) {
  const prefs = { auto: false, voice: 'af_heart', speed: 1, engine: 'browser', autoSend: true, ...load() };
  if (!VOICE_IDS.includes(prefs.voice)) prefs.voice = 'af_heart'; // a saved male voice from an older version is not offered any more
  const self = {
    enabled: true,
    serverVoice: false,
    prefs,
    get auto() { return prefs.auto; },
    get speaking() { return Boolean(current); }
  };

  let ctx = null;
  let analyser = null;
  let current = null; // { token, source, abort }
  let tokenCounter = 0;
  let frame = 0;
  let toggleButton = null;
  let statusLine = null;

  let lastStatus = '';
  const setStatus = (text) => {
    lastStatus = text;
    if (statusLine) statusLine.textContent = text;
  };

  /* Problems with the voice are sent to the server's debugging log (what went wrong and in which browser, never what was said),
     so they can be found and fixed instead of the voice just not working. At most a few per page load. */
  let reports = 0;
  function report(what, message) {
    if (reports >= 5) return;
    reports += 1;
    try {
      fetch('/api/clientlog', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ kind: 'voice', what, message: String(message || '').slice(0, 300), gpu: Boolean(navigator.gpu), secure: window.isSecureContext })
      }).catch(() => {});
    } catch {
      /* nothing to do */
    }
  }

  /* ---------- engine 1: Kokoro in this browser ---------- */

  let worker = null;
  let workerReady = null;
  let pending = new Map(); // id -> { resolve, reject }
  let nextId = 1;

  function startWorker() {
    if (workerReady) return workerReady;
    workerReady = new Promise((resolve, reject) => {
      try {
        worker = new Worker('/kokoro-worker.js', { type: 'module' });
      } catch (err) {
        workerReady = null;
        reject(new Error('This browser cannot run the voice on this device.'));
        return;
      }
      worker.onmessage = ({ data }) => {
        if (data.type === 'progress') setStatus(`Getting her voice ready… ${data.percent}%`);
        else if (data.type === 'ready') {
          setStatus('Getting her voice ready…');
          resolve(); // it can speak now (the first sentence may take a moment more while it warms up)
        } else if (data.type === 'warm') {
          self.device = data.device;
          setStatus(data.device === 'webgpu' ? 'Her voice is ready.' : 'Her voice is ready (this device has no graphics-card support, so she is a little slower).');
        } else if (data.type === 'fallback') {
          report('fallback', data.message);
        } else if (data.type === 'audio') {
          const job = pending.get(data.id);
          pending.delete(data.id);
          job?.resolve(data);
        } else if (data.type === 'error') {
          report(data.id == null ? 'load-failed' : 'speak-failed', data.message);
          if (data.id == null) {
            workerReady = null;
            setStatus("Her voice couldn't start in this browser.");
            reject(new Error(data.message));
          } else {
            const job = pending.get(data.id);
            pending.delete(data.id);
            job?.reject(new Error(data.message));
          }
        }
      };
      worker.onerror = (e) => {
        workerReady = null;
        report('worker-error', e?.message || 'the voice worker could not start');
        setStatus("Her voice couldn't start in this browser.");
        reject(new Error("Her voice couldn't start here. Check the connection."));
      };
      setStatus('Getting her voice ready…');
      worker.postMessage({ type: 'load' });
    });
    workerReady.catch(() => {});
    return workerReady;
  }

  async function browserPiece(text, speed) {
    await startWorker();
    const id = nextId++;
    const done = new Promise((resolve, reject) => {
      pending.set(id, { resolve, reject });
      // a voice that never answers must not leave her silent forever
      setTimeout(() => {
        if (pending.delete(id)) reject(new Error('Her voice took too long to answer.'));
      }, 90_000);
    });
    worker.postMessage({ type: 'speak', id, text, voice: prefs.voice, speed });
    const out = await done;
    const buffer = ctx.createBuffer(1, out.samples.length, out.rate);
    buffer.copyToChannel(out.samples, 0);
    return buffer;
  }

  /* ---------- engine 2: the server's voice, if it has one ---------- */

  async function serverPiece(text, speed, signal) {
    const res = await fetch('/api/tts', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ text, voice: prefs.voice, speed }),
      signal
    });
    if (res.status === 400) return null; // nothing speakable in this piece
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'No voice just now.');
    return ctx.decodeAudioData(await res.arrayBuffer());
  }

  const useServer = () => prefs.engine === 'server' && self.serverVoice;

  async function piece(text, speed, signal) {
    // the page cleans the text (no mood tags, stage directions, emoji, web addresses) before it is spoken by either engine
    const clean = cleanForSpeech(text);
    if (!clean) return null;
    return useServer() ? serverPiece(clean, speed, signal) : browserPiece(clean, speed);
  }

  /* ---------- audio output ---------- */

  function unlock() {
    try {
      ctx ??= new (window.AudioContext || window.webkitAudioContext)();
      if (ctx.state === 'suspended') ctx.resume();
      if (!analyser) {
        analyser = ctx.createAnalyser();
        analyser.fftSize = 512;
        analyser.smoothingTimeConstant = 0.6;
        analyser.connect(ctx.destination);
      }
    } catch {
      /* no audio in this browser */
    }
  }

  function meter() {
    cancelAnimationFrame(frame);
    const data = new Uint8Array(analyser.fftSize);
    const tick = () => {
      analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (const v of data) sum += ((v - 128) / 128) ** 2;
      onLevel(Math.min(1, Math.sqrt(sum / data.length) * 3.2));
      frame = requestAnimationFrame(tick);
    };
    tick();
  }

  function play(buffer, run) {
    return new Promise((resolve) => {
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(analyser);
      run.source = source;
      source.onended = resolve;
      source.start();
    });
  }

  /** Says the text aloud, replacing anything already being said. */
  async function say(text, { mood } = {}) {
    if (!text?.trim()) return;
    stop();
    unlock();
    if (!ctx) return;
    const run = { token: ++tokenCounter, source: null, abort: new AbortController() };
    current = run;
    onSpeaking(true);
    toggleButton?.classList.add('speaking');
    meter();

    const speed = Math.max(0.7, Math.min(1.4, prefs.speed * (MOOD_SPEED[mood] || 1)));
    const parts = chunks(cleanForSpeech(text) || '');
    try {
      let upcoming = parts.length ? piece(parts[0], speed, run.abort.signal) : null;
      for (let i = 0; i < parts.length; i += 1) {
        const buffer = await upcoming;
        if (current !== run) return;
        upcoming = i + 1 < parts.length ? piece(parts[i + 1], speed, run.abort.signal) : null;
        upcoming?.catch(() => {});
        if (buffer) await play(buffer, run);
        if (current !== run) return;
      }
    } catch (err) {
      if (err.name !== 'AbortError' && current === run) onError(err.message);
    } finally {
      if (current === run) finish();
    }
  }

  function finish() {
    current = null;
    cancelAnimationFrame(frame);
    onLevel(0);
    onSpeaking(false);
    toggleButton?.classList.remove('speaking');
  }

  function stop() {
    const run = current;
    if (!run) return;
    current = null;
    run.abort.abort();
    try {
      run.source?.stop();
    } catch {
      /* not started yet */
    }
    cancelAnimationFrame(frame);
    onLevel(0);
    onSpeaking(false);
    toggleButton?.classList.remove('speaking');
  }

  /* ---------- the controls: laid out in place (Settings), or as a button with a small panel under it ---------- */

  function buildControls(host, inline = false) {
    const wrap = document.createElement('div');
    wrap.className = 'voice-wrap';

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'icon-btn voice-btn';
    button.setAttribute('aria-haspopup', 'true');
    button.setAttribute('aria-expanded', 'false');
    button.innerHTML = '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2.5 6.2v3.6h2.6L8.6 12.5v-9L5.1 6.2H2.5Z"/><path class="wave1" d="M10.6 6a3 3 0 0 1 0 4"/><path class="wave2" d="M12.3 4.3a5.4 5.4 0 0 1 0 7.4"/></svg>';
    toggleButton = button;

    const pop = document.createElement('div');
    pop.className = 'voice-pop';
    pop.hidden = true;
    pop.setAttribute('role', 'group');
    pop.setAttribute('aria-label', 'Voice settings');

    const checkbox = (label, key, after) => {
      const row = document.createElement('label');
      row.className = 'voice-row check';
      const box = document.createElement('input');
      box.type = 'checkbox';
      box.checked = Boolean(prefs[key]);
      box.addEventListener('change', () => {
        prefs[key] = box.checked;
        save(prefs);
        after?.(box.checked);
      });
      row.append(box, document.createTextNode(` ${label}`));
      return row;
    };

    const auto = checkbox('Read her replies aloud', 'auto', (on) => {
      refresh();
      unlock();
      if (on && !useServer()) startWorker().catch((err) => onError(err.message));
      if (!on) stop();
    });
    const tryIt = () => say("Hello, it's me. How do I sound?");

    const voiceRow = document.createElement('label');
    voiceRow.className = 'voice-row';
    voiceRow.textContent = 'Voice';
    const select = document.createElement('select');
    for (const v of VOICES) {
      const opt = document.createElement('option');
      opt.value = v.id;
      opt.textContent = v.label;
      select.appendChild(opt);
    }
    select.value = VOICES.some((v) => v.id === prefs.voice) ? prefs.voice : 'af_heart';
    voiceRow.appendChild(select);
    select.addEventListener('change', () => {
      prefs.voice = select.value;
      save(prefs);
    });

    const speedRow = document.createElement('label');
    speedRow.className = 'voice-row';
    speedRow.textContent = 'Speed';
    const speed = document.createElement('input');
    speed.type = 'range';
    speed.min = '0.7';
    speed.max = '1.3';
    speed.step = '0.05';
    speed.value = String(prefs.speed);
    speedRow.appendChild(speed);
    speed.addEventListener('change', () => {
      prefs.speed = Number(speed.value);
      save(prefs);
    });

    pop.append(auto, voiceRow, speedRow);

    if (self.serverVoice) {
      const engineRow = document.createElement('label');
      engineRow.className = 'voice-row';
      engineRow.textContent = 'Voice is made';
      const engine = document.createElement('select');
      engine.innerHTML = '<option value="browser">On this device (private)</option><option value="server">On the server</option>';
      engine.value = prefs.engine;
      engine.addEventListener('change', () => {
        prefs.engine = engine.value;
        save(prefs);
      });
      engineRow.appendChild(engine);
      pop.appendChild(engineRow);
    }

    if (window.SpeechRecognition || window.webkitSpeechRecognition) {
      pop.appendChild(checkbox('Send when I stop talking (microphone)', 'autoSend'));
    }

    statusLine = document.createElement('div');
    statusLine.className = 'voice-status';
    statusLine.setAttribute('role', 'status');
    statusLine.textContent = lastStatus || 'Her voice is made on this device, so what she says stays private.';

    const test = document.createElement('button');
    test.type = 'button';
    test.className = 'pill-btn';
    test.textContent = 'Try it';
    test.addEventListener('click', tryIt);

    pop.append(test, statusLine);
    if (inline) {
      pop.hidden = false;
      pop.classList.add('inline');
      wrap.append(pop);
    } else {
      wrap.append(button, pop);
    }
    host.prepend(wrap);

    const refresh = () => {
      button.setAttribute('aria-label', prefs.auto ? 'Voice: replies are read aloud' : 'Voice settings');
      button.title = prefs.auto ? 'Voice is on' : 'Voice';
      button.classList.toggle('on', prefs.auto);
    };
    refresh();
    if (inline) return; // nothing to open or close: the controls are simply there

    const closePop = () => {
      pop.hidden = true;
      button.setAttribute('aria-expanded', 'false');
    };
    button.addEventListener('click', () => {
      unlock();
      pop.hidden = !pop.hidden;
      button.setAttribute('aria-expanded', String(!pop.hidden));
    });
    document.addEventListener('click', (e) => { if (!wrap.contains(e.target)) closePop(); });
    wrap.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !pop.hidden) {
        closePop();
        button.focus();
      }
    });
  }

  /** Shows the voice controls. Asks the server whether it also has a voice of its own. */
  async function init(host, { inline = false } = {}) {
    try {
      const res = await fetch('/api/voice', { cache: 'no-store' });
      const data = res.ok ? await res.json() : { enabled: false };
      self.serverVoice = Boolean(data.enabled);
    } catch {
      /* no server voice: the voice on this device is still there */
    }
    buildControls(host, inline);
    // her voice is fetched in the background as soon as the page is up (no button to press, nothing to agree to), so it is
    // ready by the time anyone wants to hear it; the browser keeps it, so later visits are quick
    if (!useServer()) {
      const start = () => startWorker().catch(() => {});
      if ('requestIdleCallback' in window) requestIdleCallback(() => setTimeout(start, 1500), { timeout: 6000 });
      else setTimeout(start, 3000);
    }
    return self;
  }

  return Object.assign(self, { init, say, stop, unlock });
}
