/* The Gallery: every picture she has sent, newest first. */

import { dayLabel } from '/days.js';

export function createGallery({ host, openLightbox, openConversation }) {
  host.innerHTML = '<div class="view-inner"><div class="gallery-grid" id="galleryGrid" role="list"></div><p class="gallery-empty" id="galleryEmpty" hidden>Pictures she sends you will be kept here.</p><p class="gallery-empty" id="galleryError" role="alert" hidden>The gallery could not be loaded. Try again in a moment.</p></div>';
  const grid = host.querySelector('#galleryGrid');
  const empty = host.querySelector('#galleryEmpty');
  const error = host.querySelector('#galleryError');

  function tile(p) {
    const item = document.createElement('div');
    item.className = 'gallery-item';
    item.setAttribute('role', 'listitem');
    const open = document.createElement('button');
    open.type = 'button';
    open.className = 'gallery-open';
    const what = p.kind === 'drawn' ? 'A picture she drew' : 'A photo she sent';
    open.setAttribute('aria-label', `${what}, ${dayLabel(p.at).toLowerCase()}. View larger`);
    const img = new Image();
    img.src = p.src;
    img.alt = '';
    img.loading = 'lazy';
    img.decoding = 'async';
    open.appendChild(img);
    open.addEventListener('click', () => openLightbox(p.src));
    const go = document.createElement('button');
    go.type = 'button';
    go.className = 'gallery-go';
    go.textContent = 'Open the chat';
    go.addEventListener('click', () => openConversation(p.conversation));
    item.append(open, go);
    return item;
  }

  async function load() {
    error.hidden = true;
    try {
      const res = await fetch('/api/gallery');
      if (!res.ok) throw new Error(String(res.status));
      const { pictures } = await res.json();
      grid.replaceChildren(...pictures.map(tile));
      empty.hidden = pictures.length > 0;
    } catch {
      grid.replaceChildren();
      empty.hidden = true;
      error.hidden = false;
    }
  }

  return { load };
}
