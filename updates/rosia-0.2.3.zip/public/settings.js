import { mountDiscord } from './discord.js';
import { mountModels } from './models.js';

/* Settings: the controls that used to be scattered, in one view. Most are wired where they always were (voice.js,
   panel.js); this file wires the rest and shows the owner's sections to the owner. */

const on = (key) => localStorage.getItem(key) !== '0';
const set = (key, value) => (value ? localStorage.removeItem(key) : localStorage.setItem(key, '0'));

function updateText(u) {
  if (!u.enabled) return u.reason || 'Updates are switched off.';
  if (u.failure) {
    const again = u.failure.autoPaused
      ? 'Automatic updates for this version are paused. Press Install now, or wait for the next release.'
      : 'It will be tried again by itself.';
    return `Version ${u.failure.version} did not start on this computer, so the previous version was put back. ${u.failure.reason || ''} ${again}`.replace(/\s+/g, ' ').trim();
  }
  if (u.stage === 'downloading') return `Downloading version ${u.latest}.`;
  if (u.ready) return `Version ${u.latest} is ready to install.`;
  if (u.available && u.latest !== u.current) return `Version ${u.latest} is available${u.required ? ' and is needed to carry on' : ''}.`;
  return `You're on the latest version, ${u.current}.`;
}

/** One sentence for the state of the link. */
function shareText(s) {
  const t = s.tunnel || {};
  if (t.starting) return 'Making the link…';
  if (t.running) {
    return s.access === 'open'
      ? 'Sharing is on. Anyone with this link can talk to her on this computer, each in their own private space.'
      : 'Sharing is on. People who open this link need a code from you (Use on my phone), and then see your chats.';
  }
  return t.error || 'Sharing is off. Nobody outside this computer can reach her.';
}

function friendsText(f = {}) {
  if (!f.count) return 'Nobody has used a link yet.';
  const people = f.count === 1 ? '1 friend has' : `${f.count} friends have`;
  return `${people} their own space here; ${f.today || 0} visited in the last day.`;
}

/** What the Music section says: what she can play, and (to the owner) where their own songs go. */
function musicText(m = {}, me = {}) {
  const songs = m.folder?.songs || 0;
  const mine = songs ? `${songs === 1 ? '1 song' : `${songs} songs`} from ${me.owner ? 'your music folder' : 'the music kept on this computer'}` : '';
  const youtube = m.youtube?.ready ? 'almost any song on YouTube Music, famous ones included (no adverts)' : '';
  const online = m.online && !youtube ? 'a free online catalogue of independent artists (no adverts)' : '';
  const from = [mine, youtube, online].filter(Boolean).join(', and ');
  const lines = [from ? `Ask her to play something and it starts in the small player at the top of the window. She can play ${from}.` : 'There is no music for her to play yet.'];
  if (m.youtube?.on && !m.youtube.ready) lines.push(me.owner && m.youtube.error
    ? `YouTube Music is not working yet: ${m.youtube.error}`
    : 'YouTube Music is getting ready (the player it uses is being fetched).');
  if (me.owner && m.folder?.path) {
    lines.push(songs
      ? `Your own songs are in ${m.folder.path}. Add more there and she can play them by name straight away.`
      : `To have her play songs you own, famous ones included, put the files in a folder at ${m.folder.path}. She finds them by name within a minute.`);
  }
  return lines.join(' ');
}

export { updateText, shareText, friendsText, musicText };

export function createSettings({ host, me, panel, doc = document }) {
  const $ = (id) => doc.getElementById(id);

  const texts = $('setTexts');
  const nudge = $('setNudge');
  texts.checked = on('rosia.texts');
  nudge.checked = on('rosia.nudge');
  texts.addEventListener('change', () => set('rosia.texts', texts.checked));
  nudge.addEventListener('change', () => set('rosia.nudge', nudge.checked));

  $('aboutVersion').textContent = `Rosia ${me.version}`;

  /** Where her music comes from, in a sentence or two; the owner is also told where to put their own songs. */
  async function loadMusic() {
    try {
      const m = await fetch('/api/music').then((r) => r.json());
      $('musicState').textContent = musicText(m, me);
    } catch { /* the line that is already there still holds */ }
  }

  async function loadUpdates() {
    const state = $('updState');
    try {
      const u = await fetch('/api/update').then((r) => r.json());
      state.textContent = updateText(u);
      $('updNotes').hidden = !u.notes || u.latest === u.current;
      $('updNotes').textContent = u.notes || '';
      $('updLog').hidden = !u.failure?.log?.length;
      $('updLogText').textContent = (u.failure?.log || []).join('\n');
      const offered = u.ready || u.failure || (u.available && u.latest !== u.current);
      // a copy the launcher did not start cannot swap its own files: say so, instead of a button that does nothing
      $('updInstall').hidden = !offered || u.canInstall === false;
      if (offered && u.canInstall === false && u.manual) state.textContent = `${state.textContent} ${u.manual}`;
      else if (u.error && !u.failure) state.textContent = `${state.textContent} ${u.error}`;
    } catch {
      state.textContent = 'The update state could not be read.';
    }
  }

  /* ---------- share with friends (owner only) ---------- */

  function showShare(s) {
    $('shareOpen').checked = s.access === 'open';
    $('shareInvite').checked = s.access !== 'open';
    $('shareState').textContent = shareText(s);
    const on = Boolean(s.tunnel?.running);
    $('shareLinkRow').hidden = !on;
    $('shareUrl').value = on ? s.tunnel.url : '';
    $('shareStart').hidden = on;
    $('shareStop').hidden = !on;
    $('shareFriends').textContent = friendsText(s.friends);
  }
  const share = async (path, body) => {
    const res = await fetch(path, body ? { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : undefined);
    if (!res.ok) throw new Error('The sharing settings could not be changed.');
    return res.json();
  };
  async function loadShare() {
    try { showShare(await share('/api/share')); } catch { $('shareState').textContent = 'The sharing state could not be read.'; }
  }

  if (me.owner) {
    $('setShare').hidden = false;
    for (const id of ['shareOpen', 'shareInvite']) {
      $(id).addEventListener('change', async (e) => {
        if (!e.target.checked) return;
        try { showShare(await share('/api/share/access', { mode: e.target.value })); } catch (err) { $('shareState').textContent = err.message; }
      });
    }
    $('shareStart').addEventListener('click', async () => {
      $('shareStart').disabled = true;
      $('shareState').textContent = 'Making the link…';
      try { showShare(await share('/api/share/tunnel', { on: true })); } catch (err) { $('shareState').textContent = err.message; }
      $('shareStart').disabled = false;
    });
    $('shareStop').addEventListener('click', async () => {
      try { showShare(await share('/api/share/tunnel', { on: false })); } catch (err) { $('shareState').textContent = err.message; }
    });
    $('shareCopy').addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText($('shareUrl').value);
      } catch {
        $('shareUrl').select();
        doc.execCommand('copy');
      }
      $('shareCopy').textContent = 'Copied';
      setTimeout(() => { $('shareCopy').textContent = 'Copy'; }, 1400);
    });
  }

  let discord = null;
  let models = null;
  if (me.local) {
    $('setDiscord').hidden = false;
    $('setModels').hidden = false;
  }

  if (me.owner) {
    $('setUpdates').hidden = false;
    $('setDiagnostics').hidden = false;
    $('updCheck').addEventListener('click', async () => {
      $('updState').textContent = 'Checking…';
      await fetch('/api/update/check', { method: 'POST' }).catch(() => {});
      loadUpdates();
    });
    $('updInstall').addEventListener('click', async () => {
      const button = $('updInstall');
      button.disabled = true;
      $('updState').textContent = 'Getting the update ready…';
      let res = null;
      let body = {};
      try {
        res = await fetch('/api/update/install', { method: 'POST' });
        body = await res.json().catch(() => ({}));
      } catch { /* she may already be restarting */ }
      if (res && !res.ok) {
        // say what stopped it, rather than nothing at all
        $('updState').textContent = body.error || 'The update could not be installed.';
        button.disabled = false;
        return;
      }
      $('updState').textContent = 'Installing. She will be back in a moment.';
      // the app restarts with the new version: wait until it answers as that version, then reload the page
      const want = body.latest;
      const until = Date.now() + 3 * 60_000;
      const wait = async () => {
        try {
          const h = await fetch('/api/health', { cache: 'no-store' }).then((r) => r.json());
          if (!want || h.version === want) return location.reload();
        } catch { /* still restarting */ }
        if (Date.now() < until) setTimeout(wait, 1500);
        else { $('updState').textContent = 'The update is taking longer than usual. Close and reopen Rosia.'; button.disabled = false; }
      };
      setTimeout(wait, 2500);
    });
  }

  return {
    load() {
      panel.loadDevices();
      loadMusic();
      if (me.local) {
        if (discord) discord.refresh();
        else discord = mountDiscord($('setDiscordHost'));
        if (models) models.load();
        else models = mountModels($('setModelsHost'));
      }
      if (me.owner) {
        loadUpdates();
        loadShare();
      }
    }
  };
}
