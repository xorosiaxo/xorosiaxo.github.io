/*
 * Kokoro, running in the visitor's own browser (in a worker, so the page never stutters while it speaks).
 * The model (about 330 MB for the graphics card, once; the browser keeps it) and the speech code come from public CDNs, so nothing about
 * what is said is sent anywhere: the words are turned into sound on this device.
 *
 * It is loaded as soon as the page opens, and "warmed up" with a sentence nobody hears: the first sentence on a graphics
 * card spends about ten seconds preparing its shaders, which would otherwise make her first reply wait.
 *
 * Messages in:  { type: 'load' }   { type: 'speak', id, text, voice, speed }
 * Messages out: { type: 'progress', percent }  { type: 'ready', device }  { type: 'warm', device }
 *               { type: 'audio', id, samples, rate }  { type: 'fallback', message }  { type: 'error', id?, message }
 */

const KOKORO = 'https://cdn.jsdelivr.net/npm/kokoro-js@1.2.1/+esm';
const MODEL = 'onnx-community/Kokoro-82M-v1.0-ONNX';

let tts = null;
let loading = null;
let device = '';
let forceWasm = false; // set once the graphics card has let her down, so she keeps talking on the processor

let lastPercent = -1;
let lastPost = 0;
function progress(percent) {
  // the downloader reports every few kilobytes: tell the page only when the number moves, and not more than five times a second
  const now = Date.now();
  if (percent === lastPercent || (now - lastPost < 200 && percent < 99)) return;
  lastPercent = percent;
  lastPost = now;
  postMessage({ type: 'progress', percent });
}

async function create(dev, dtype) {
  const files = new Map();
  const { KokoroTTS } = await import(KOKORO);
  return KokoroTTS.from_pretrained(MODEL, {
    dtype,
    device: dev,
    progress_callback: (p) => {
      if (p.status !== 'progress' || !p.file) return;
      files.set(p.file, { loaded: p.loaded || 0, total: p.total || 0 });
      let loaded = 0;
      let total = 0;
      for (const f of files.values()) {
        loaded += f.loaded;
        total += f.total;
      }
      if (total) progress(Math.min(99, Math.round((loaded / total) * 100)));
    }
  });
}

/** Builds the voice: on the graphics card (WebGPU) wherever the browser has one, otherwise (or after it fails) on the processor. */
async function build() {
  tts = null;
  device = '';
  if (!forceWasm && self.navigator?.gpu) {
    try {
      tts = await create('webgpu', 'fp32');
      device = 'webgpu';
    } catch (err) {
      tts = null;
      postMessage({ type: 'fallback', message: `no usable graphics card: ${String(err?.message || err).slice(0, 160)}` });
    }
  }
  if (!tts) {
    tts = await create('wasm', 'q8');
    device = 'wasm';
  }
  postMessage({ type: 'ready', device });
  // the first sentence is slow (the card prepares its shaders), so one is spoken now, to nobody
  try {
    await tts.generate('Hello there.', { voice: 'af_heart', speed: 1 });
    postMessage({ type: 'warm', device });
  } catch (err) {
    if (device === 'webgpu') {
      postMessage({ type: 'fallback', message: `the graphics card failed the first sentence: ${String(err?.message || err).slice(0, 160)}` });
      forceWasm = true;
      return build();
    }
    throw err;
  }
}

async function load() {
  if (tts) return loading;
  loading ??= build().catch((err) => {
    loading = null; // let a later request try again
    throw err;
  });
  return loading;
}

self.onmessage = async ({ data }) => {
  try {
    if (data.type === 'load') {
      await load();
    } else if (data.type === 'speak') {
      await load();
      let out;
      try {
        out = await tts.generate(data.text, { voice: data.voice, speed: data.speed });
      } catch (err) {
        // the graphics card dropped out part-way (it is shared with other programs): carry on with the processor instead of going quiet
        if (device !== 'webgpu') throw err;
        postMessage({ type: 'fallback', message: `the graphics card failed while speaking: ${String(err?.message || err).slice(0, 160)}` });
        forceWasm = true;
        tts = null;
        loading = null;
        await load();
        out = await tts.generate(data.text, { voice: data.voice, speed: data.speed });
      }
      const samples = out.audio;
      postMessage({ type: 'audio', id: data.id, samples, rate: out.sampling_rate }, [samples.buffer]);
    }
  } catch (err) {
    postMessage({ type: 'error', id: data.id, message: String(err?.message || err).slice(0, 200) });
  }
};
