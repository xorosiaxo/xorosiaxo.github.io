/*
 * The small video window for watching something together with her. She puts a video on (or pauses, or closes it) from
 * the chat; the window has its own controls too, and tells the app where the video has got to every few seconds, so she
 * knows what is happening in it. Bottom left over her panel on a wide window, a strip under the header on a phone.
 */

export function createWatch({ host, toast = () => {}, fetchFn = (...a) => fetch(...a) }) {
  host.innerHTML = `
    <div class="watch-head">
      <span class="watch-title" id="watchTitle"></span>
      <button class="watch-x" id="watchClose" type="button" aria-label="Close the video" title="Close">
        <svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8"/></svg>
      </button>
    </div>
    <video class="watch-video" id="watchVideo" controls playsinline preload="metadata"></video>`;
  const video = host.querySelector('#watchVideo');
  const title = host.querySelector('#watchTitle');
  let current = null; // what the app says is on
  let loadedSeq = -1;
  let timer = null;
  let quietUntil = 0; // while the page itself is changing the video, its own events are not sent back

  const tell = (action, extra = {}) =>
    fetchFn('/api/watch', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action, ...extra }) })
      .then((r) => r.json())
      .catch(() => null);

  function report() {
    if (current && !video.paused) tell('report', { position: video.currentTime || 0, paused: false });
  }

  /** Makes the window match what the app says is on (null closes it). */
  function sync(v) {
    current = v || null;
    if (!current) {
      video.pause();
      video.removeAttribute('src');
      video.load();
      loadedSeq = -1;
      host.hidden = true;
      clearInterval(timer);
      return;
    }
    host.hidden = false;
    title.textContent = current.channel ? `${current.title} · ${current.channel}` : current.title;
    title.title = title.textContent;
    quietUntil = Date.now() + 800;
    if (current.seq !== loadedSeq || !video.getAttribute('src')) {
      loadedSeq = current.seq;
      video.src = current.url;
      video.addEventListener('loadedmetadata', function seek() {
        video.removeEventListener('loadedmetadata', seek);
        if (current?.position > 1) video.currentTime = current.position;
      });
      video.load();
    }
    if (current.paused) video.pause();
    else {
      const started = video.play();
      started?.catch?.((err) => {
        if (err?.name === 'NotAllowedError') toast('Press play on the video to start it.');
      });
    }
    clearInterval(timer);
    timer = setInterval(report, 8000);
  }

  const mine = () => Date.now() > quietUntil;
  video.addEventListener('pause', () => { if (current && mine() && !video.ended) tell('pause', { position: video.currentTime || 0 }); });
  video.addEventListener('play', () => { if (current && mine()) tell('resume', { position: video.currentTime || 0 }); });
  video.addEventListener('seeked', () => { if (current && mine()) tell('report', { position: video.currentTime || 0, paused: video.paused }); });
  video.addEventListener('ended', () => { if (current) tell('ended', { position: video.duration || 0 }); });
  video.addEventListener('error', () => { if (current && video.getAttribute('src')) toast('That video would not play.'); });

  host.querySelector('#watchClose').addEventListener('click', async () => {
    await tell('stop');
    sync(null);
  });

  /** A video that was on before a reload comes back, paused where it was. */
  async function restore() {
    try {
      const { video: v } = await (await fetchFn('/api/watch', { cache: 'no-store' })).json();
      if (v) sync({ ...v, paused: true });
    } catch {
      /* nothing on */
    }
  }

  return { sync, restore };
}
