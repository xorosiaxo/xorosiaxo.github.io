/* What the ring around her photo and the word beside it show. */

const RING = { ok: 'ok', busy: 'busy', offline: 'off' };

export function ringState(text, tone) {
  const ring = RING[tone] || 'off';
  return { ring, word: ring === 'off' ? 'offline' : String(text || 'online') };
}
