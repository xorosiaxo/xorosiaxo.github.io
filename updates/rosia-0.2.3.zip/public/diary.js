/* Her diary: locked until she gives you the key. Only she can; asking her nicely, often, and over time is the only way.
   The key is kept in this browser once it has opened the diary, so it does not have to be typed every time. */

const STORE = 'rosia.diaryKey';
const when = (day) => new Date(`${day}T12:00:00`).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

function saved() {
  try {
    return localStorage.getItem(STORE) || '';
  } catch {
    return '';
  }
}
function keep(key) {
  try {
    if (key) localStorage.setItem(STORE, key);
    else localStorage.removeItem(STORE);
  } catch {
    /* private window: it is typed again next time */
  }
}

export function createDiary({ host, fetchFn = (...a) => fetch(...a) }) {
  host.innerHTML = `
    <div class="view-inner diary">
      <div class="diary-lock" id="diaryLock" hidden>
        <svg class="diary-padlock" viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>
        <h2 class="diary-title">Her diary</h2>
        <p class="diary-sub" id="diaryPages"></p>
        <p class="diary-help">It is locked, and she keeps the key to herself. Only she can give it to you, and she does not hand it out easily.</p>
        <form class="diary-form" id="diaryForm" autocomplete="off">
          <label class="sr-only" for="diaryKey">The key to her diary</label>
          <input id="diaryKey" type="text" maxlength="80" placeholder="The key she gave you" spellcheck="false" autocapitalize="off" />
          <button type="submit" class="pill-btn">Unlock</button>
        </form>
        <p class="diary-error" id="diaryError" role="alert" hidden></p>
      </div>
      <div class="diary-open" id="diaryOpen" hidden>
        <p class="mem-intro">What she wrote after the days you talked. She trusted you with this.</p>
        <ol class="diary-list" id="diaryList"></ol>
        <p class="gallery-empty" id="diaryEmpty" hidden>She has not written anything yet.</p>
        <button class="pill-btn diary-close" id="diaryClose" type="button">Lock it again</button>
      </div>
      <p class="gallery-empty" id="diaryFail" role="alert" hidden>Her diary could not be loaded. Try again in a moment.</p>
    </div>`;
  const $ = (id) => host.querySelector(`#${id}`);

  function showLocked(pages, message = '') {
    $('diaryOpen').hidden = true;
    $('diaryLock').hidden = false;
    $('diaryPages').textContent = pages ? `${pages} page${pages === 1 ? '' : 's'} written` : 'Nothing written yet';
    $('diaryError').textContent = message;
    $('diaryError').hidden = !message;
  }

  function showOpen(entries) {
    $('diaryLock').hidden = true;
    $('diaryOpen').hidden = false;
    const list = $('diaryList');
    list.replaceChildren(...entries.map((e) => {
      const li = document.createElement('li');
      li.className = 'diary-entry';
      const date = document.createElement('time');
      date.dateTime = e.day;
      date.textContent = when(e.day);
      const text = document.createElement('p');
      text.textContent = e.text;
      li.append(date, text);
      return li;
    }));
    $('diaryEmpty').hidden = entries.length > 0;
  }

  async function open(key) {
    const res = await fetchFn('/api/diary', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ key }) });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok, data };
  }

  async function load() {
    $('diaryFail').hidden = true;
    try {
      const key = saved();
      if (key) {
        const { ok, data } = await open(key);
        if (ok && !data.locked) return showOpen(data.entries || []);
        keep(''); // that key no longer opens it
      }
      const res = await fetchFn('/api/diary');
      if (!res.ok) throw new Error(String(res.status));
      const data = await res.json();
      showLocked(data.pages || 0);
    } catch {
      $('diaryLock').hidden = true;
      $('diaryOpen').hidden = true;
      $('diaryFail').hidden = false;
    }
  }

  $('diaryForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const key = $('diaryKey').value.trim();
    if (!key) return;
    try {
      const { ok, data } = await open(key);
      if (ok && !data.locked) {
        keep(key);
        $('diaryKey').value = '';
        showOpen(data.entries || []);
      } else {
        showLocked(Number($('diaryPages').textContent.match(/\d+/)?.[0]) || 0, data.error || 'That is not the key.');
      }
    } catch {
      showLocked(0, 'Her diary could not be reached. Try again in a moment.');
    }
  });

  $('diaryClose').addEventListener('click', () => {
    keep('');
    load();
  });

  return { load };
}
