# Avatar assets

The avatar is a set of **pre-made static images**. Nothing is drawn or generated at runtime: each
expression is a full picture of her, and the page crossfades between them. The only other motion is
a gentle CSS sway on the whole portrait.

## Where things live

```
public/assets/avatar/            your source PNGs (never served to the page directly)
public/assets/avatar/old/        the earlier layered set, kept as a backup, not used
public/assets/avatar/web/        what the page actually loads (generated)
scripts/build-avatar.py          turns the sources into web/
```

After adding or changing a source PNG, rebuild:

```bash
python scripts/build-avatar.py
```

The script resizes everything (840 px wide expressions, 800 px wide photos), re-encodes to WebP
(about 3 MB in total instead of about 17 MB) and, for the expressions, turns the black background
into real transparency so the glow behind her shows through. It needs Python with Pillow.

## Expressions (shown on the avatar)

| Source file | Name | Used for |
| --- | --- | --- |
| `neutral.png` | neutral | her mood has dropped: flat, bored, tired or serious |
| `happy.png` | happy | her default: resting face, and the face she goes back to after every reply |
| `happy laughing.png` | laughing | amused |
| `winking.png` | winking | flirty / teasing |
| `love.png` | love | warm |
| `thinking.png` | thinking | waiting for a reply, curious |
| `worried.png` | worried | worried, and when a request fails |
| `sleepy.png` | sleepy | after about 2.5 minutes of silence; any key press or click wakes her |
| `Surprised.png` | surprised | surprised |
| `licking lips.png` | smitten | the hungry flirty look |
| `horny.png` | aroused | explicit conversations only |
| `ahegao.png` | ecstatic | the peak of an explicit conversation only |

Keep each expression on the same canvas with the head in the same place, so the crossfades don't
jump. (`licking lips.png` is framed a little closer than the rest.)

## How the AI decides which one to show

The model never picks a file. Every reply it writes starts with one mood tag:

`[neutral] [flirty] [teasing] [amused] [curious] [warm] [surprised] [worried] [smitten] [aroused] [ecstatic]`

The server (`server/mood.js`) strips the tag so the person never sees it and sends a `mood` event.
The page (`MOODS` in `public/app.js`) turns each mood into expressions:

| Mood | While she talks | When the reply ends | Then |
| --- | --- | --- | --- |
| neutral | neutral (held about 4 s) | | happy |
| flirty | happy | winking, sparks | happy |
| teasing | happy | winking | happy |
| amused | laughing | happy | happy |
| curious | thinking | | happy |
| warm | happy | love, a few sparks | happy |
| surprised | surprised | | happy |
| worried | worried | | happy |
| smitten | smitten | held about 6 s, a few sparks | happy |
| aroused | aroused | held about 7 s | happy |
| ecstatic | ecstatic | held about 7 s | happy |

The persona (`server/persona.js`) tells the model that `[aroused]` and `[ecstatic]` are only for when
the person has already taken the conversation explicitly sexual, and never to open a conversation.

Other rules, all in the `Avatar` class: `thinking` shows while she waits for the first word, `worried`
flashes for a few seconds when a request fails, and `sleepy` appears after a long silence. If the model
forgets the tag, a few keyword rules pick a mood instead.

## Photos she can send

Eight shots live in the same folder and she can send one in the chat as an image message:

| Source file | Pose name |
| --- | --- |
| `bikini.png` | bikini |
| `full pic front.png` | front |
| `full pic back.png` | back |
| `feet.png` | feet |
| `knees with mouth open.png` | kneeling |
| `gymwear.png` | gymwear (black crop top and shorts, waist up) |
| `swimsuit-front.png` | swimsuit (navy one-piece, arms up) |
| `swimsuit-back.png` | swimsuit-back (the same, from behind) |

The model has a `send_photo` tool (`server/tools/photos.js`). Its instructions say to use it only when
the person asks to see her, or the flirting has clearly invited it, and never unprompted or more than
one per message. The picture appears under her message and opens full size on click (Esc closes).
It is saved with the message, so it is still there after a reload.

Asked for by name: "your bikini", "your swimsuit", "the swimsuit from behind" and "your gym outfit" each pick their own photo (the `POSES` list in `server/preflight.js`, most specific first).

To add a pose: put the PNG in `public/assets/avatar/`, add it to `PHOTOS` in
`scripts/build-avatar.py` and to `PHOTO_POSES` in both `server/tools/photos.js` and
`public/app.js`, add the words that ask for it to `POSES` in `server/preflight.js`, then rebuild.

## Adding a new expression

1. Add the source PNG and an entry in `EXPRESSIONS` in `scripts/build-avatar.py`, then rebuild.
2. Add the name to `EXPRESSIONS` in `public/app.js`.
3. Add a mood that uses it to `MOODS` in `public/app.js` and to `MOODS` in `server/mood.js`, and
   mention it in the tag list in `server/persona.js`.

## Mobile

On phones the portrait is a 56 px circle cropped to the face. The crop is the `.rig` rule in the
`max-width: 900px` block of `styles.css`; adjust it if a new set frames the head differently.
